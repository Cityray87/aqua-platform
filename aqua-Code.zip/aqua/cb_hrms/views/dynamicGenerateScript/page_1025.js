
				page_1025 = Ext.extend(Ext.Panel,{
					paramList:null,
					loadCounter:null,
		
					constructor:function(_cfg){
							if(_cfg==null){_cfg=={};this.paramList={}}else{this.paramList = _cfg.paramList;};
							Ext.apply(this,_cfg);
						page_1025.superclass.constructor.call(this,{
							border:false,
							autoScroll:false,	
							id:'page_1025',
							anchor:'100% 100%',
							layout:'anchor',
							items:[
								
		}]
						})
					},
					listeners:{
						beforerender:function(_grid){
							var winObj = eval(Ext.getCmp(Ext.getCmp('page_1025').paramList.win_id));
							if(typeof(winObj)!='undefined'){
								maskObj = new Ext.LoadMask(winObj.getEl(), {msg:getResource('loading','')});
								maskObj.show();
							}
						},
						render:function(_grid){
							Ext.getCmp('page_1025').loadCounter=0;
		
				if(Ext.getCmp('page_1025').loadCounter==0){
					maskObj.hide();	
					Ext.getCmp('page_1025').loadCounter=0;
				} 
		
						},
						afterrender:function(_grid){
		
					if(getAppPriv('GRID_CTRL_DATA_TYPE','')==0){
				}},
					destroy:function(){
		
					}		
				
					}
				})
		


				picklist_gridpanel__dynamicPanelAdmin_dynamicPanel_treegrid_master_table = Ext.extend(Ext.Window,{
					operatorStore:null,
					picklist_search_store:null,
					filter_form:null,
					picklist_grid:null,
					paramList:null,
					hideLoadingMask:null,
					constructor:function(_cfg){
						if(_cfg==null){_cfg=={};this.paramList={}}else{this.paramList=_cfg.paramList;};
						if((this.paramList.sourcePage).toLowerCase()=='searchpanel'){
							if(typeof(Ext.getCmp('gridpanel__dynamicPanelAdmin_dynamicPanel'))!='undefined'){
								Ext.apply(this.paramList,Ext.getCmp('gridpanel__dynamicPanelAdmin_dynamicPanel').paramList);
							}
						}
						this.paramList.pname='gridpanel__dynamicPanelAdmin_dynamicPanel';
						this.paramList.fname='treegrid_master_table';	
						this.paramList.sql_where=' ';
						this.hideLoadingMask = true;
						var adv_grid_panel_gridpanel__dynamicPanelAdmin_dynamicPanel_treegrid_master_table_loadMask;	
					
						Ext.apply(this,_cfg);
			
						this.operatorStore = new Ext.data.JsonStore({
							remoteSort: true,
							root: 'query.data',
							autoLoad:'true',
							baseParams:this.paramList,
							totalProperty: 'totalcount',
							url: 'index.cfm?event=searchPanel.general.getPopupSearchOperator&date='+new Date(),
							fields: [{name: 'pkey', type: 'string'}, {name: 'pvalue', type: 'string'}]
						});
					
						this.picklist_search_store = new Ext.data.JsonStore({
							remoteSort: true,
							root: 'query.data',
							autoLoad:'true',
							baseParams:this.paramList,
							totalProperty: 'totalcount',
							url: 'index.cfm?event=picklist.general.picklistData&date='+new Date(),
							listeners: {
								beforeload:function() {
									if(typeof(Ext.getCmp('adv_grid_panel_gridpanel__dynamicPanelAdmin_dynamicPanel_treegrid_master_table'))!='undefined') {
									if(!Ext.getCmp('adv_grid_panel_gridpanel__dynamicPanelAdmin_dynamicPanel_treegrid_master_table').hideLoadingMask && typeof(adv_grid_panel_gridpanel__dynamicPanelAdmin_dynamicPanel_treegrid_master_table_loadMask)!='undefined') {
										adv_grid_panel_gridpanel__dynamicPanelAdmin_dynamicPanel_treegrid_master_table_loadMask.show();
									}}
								},
								load:function() {
									if(typeof(Ext.getCmp('adv_grid_panel_gridpanel__dynamicPanelAdmin_dynamicPanel_treegrid_master_table'))!='undefined') {
									Ext.getCmp('adv_grid_panel_gridpanel__dynamicPanelAdmin_dynamicPanel_treegrid_master_table').hideLoadingMask = false;
									if(typeof(adv_grid_panel_gridpanel__dynamicPanelAdmin_dynamicPanel_treegrid_master_table_loadMask) != 'undefined') {
										adv_grid_panel_gridpanel__dynamicPanelAdmin_dynamicPanel_treegrid_master_table_loadMask.hide();
									}}	
								}
							},
							fields: [
		
					        			"name"
					        	,
					        			"xtype"
					        	],
							dummy: true
						});
		
					this.filter_form = new Ext.form.FormPanel({
						frame:true,
						bodyBorder:false,
						buttonAlign:"left",
						id:"gridpanel__dynamicPanelAdmin_dynamicPanel_treegrid_master_table_picklistSerchForm",
						autoWidth:true,
						labelAlign:"left",
						border:false,
						labelWidth:90,
		
						keys:[{key:13,fn:function(){Ext.getCmp("picklist_gridpanel__dynamicPanelAdmin_dynamicPanel_treegrid_master_table").adv_search_event();}}],
			
						items : [
			
							{
								border : false,
								layout : "column",
								items:[{
									border : false,
									layout : "form",
									width : 200,
									items:[
										new Ext.form.ComboBox({
											allowBlank : true,
											displayField : "pvalue",
				
											fieldLabel : getResource("table_name","gridpanel__dynamicPanelAdmin_dynamicPanel"),
					
											forceSelection : true,
											hiddenName : "name_operator",
											id : "name_operator_desc",
											listeners : {
												render : this.comRender,
												scope:this
											},
											mode : "local",
											name : "name_operator",
											resizable : true,
											selectOnFocus : true,
											store : this.operatorStore,
											triggerAction : "all",
											typeAhead : true,
											valueField : "pkey",
											width : 100,
											dummy : true
										})		
					
									]
								},{
									border : false,
									layout : "form",
									width : 100,
									items : [new Ext.form.TextField({
										id:"name",
										name:"name",
										hideLabel:true,
										width:100
									})]
								}]
							}
				,
							{
								border : false,
								layout : "column",
								items:[{
									border : false,
									layout : "form",
									width : 200,
									items:[
										new Ext.form.ComboBox({
											allowBlank : true,
											displayField : "pvalue",
				
											fieldLabel : getResource("object_type","gridpanel__dynamicPanelAdmin_dynamicPanel"),
					
											forceSelection : true,
											hiddenName : "xtype_operator",
											id : "xtype_operator_desc",
											listeners : {
												render : this.comRender,
												scope:this
											},
											mode : "local",
											name : "xtype_operator",
											resizable : true,
											selectOnFocus : true,
											store : this.operatorStore,
											triggerAction : "all",
											typeAhead : true,
											valueField : "pkey",
											width : 100,
											dummy : true
										})		
					
									]
								},{
									border : false,
									layout : "form",
									width : 100,
									items : [new Ext.form.TextField({
										id:"xtype",
										name:"xtype",
										hideLabel:true,
										width:100
									})]
								}]
							}
				
						],
			
						buttons:[
		
						new Ext.Button({
							handler : this.adv_search_event,
							scope:this,
							id : "adv_search_btn_gridpanel__dynamicPanelAdmin_dynamicPanel_treegrid_master_table",
							style : "margin-top:-5px",
							text : getResource("adv_search_btn","searchPanel"),
							dummy : true
						}),
			
						new Ext.Button({
							handler : this.picklistRedirect,
							scope : this,
							id : "picklist_redirect_gridpanel__dynamicPanelAdmin_dynamicPanel_treegrid_master_table",
							style : "margin-top:-5px",
							text : getResource("picklist_redirect", "gridpanel__dynamicPanelAdmin_dynamicPanel"),
							dummy : true
						})	
						],
						listeners: {
							afterrender : function() {
								var privFlag = getPrivPicklistRedirect("");
								if(!privFlag){
									Ext.getCmp("picklist_redirect_gridpanel__dynamicPanelAdmin_dynamicPanel_treegrid_master_table").hide();
								}
		
							}
						}
					})
		
						this.picklist_grid = new Ext.grid.GridPanel({
							border : false,
							height : 300,
							id : 'adv_grid_panel_gridpanel__dynamicPanelAdmin_dynamicPanel_treegrid_master_table',
							store : this.picklist_search_store,
							stripeRows : true,	
							listeners : {
								rowclick:this.rowSelected,
								'render':function(){
									adv_grid_panel_gridpanel__dynamicPanelAdmin_dynamicPanel_treegrid_master_table_loadMask = new Ext.LoadMask(Ext.getCmp('adv_grid_panel_gridpanel__dynamicPanelAdmin_dynamicPanel_treegrid_master_table').getEl(), {msg:getResource('loading','')});
								},
								scope:this
							},
		
							columns:[
			
							{
			
									header:getResource("table_name","gridpanel__dynamicPanelAdmin_dynamicPanel"),
				
									width:150,
				
									dataIndex : "name",
									sortable:true
							}
			,
							{
			
									header:getResource("object_type","gridpanel__dynamicPanelAdmin_dynamicPanel"),
				
									width:150,
				
									dataIndex : "xtype",
									sortable:true
							}
			
							],
			
							bbar : new Ext.PagingToolbar({
								displayInfo : true,
								pageSize : 10,
								store : this.picklist_search_store,
								dummy : true
							})								
						})
							
						picklist_gridpanel__dynamicPanelAdmin_dynamicPanel_treegrid_master_table.superclass.constructor.call(this,{
							constrainHeader:true,
							id:'picklist_gridpanel__dynamicPanelAdmin_dynamicPanel_treegrid_master_table',
							manager:windows,
							width:(400 > window.parent.document.body.clientWidth ? window.parent.document.body.clientWidth : 400),
							height:(400 > window.parent.document.body.clientHeight ? window.parent.document.body.clientHeight : 400),
							title: getResource('treegrid_master_table','gridpanel__dynamicPanelAdmin_dynamicPanel_picklist'),
							maximizable:false,
							resizable:true,
							modal:true,
							items:[
		
							   this.filter_form,
		
							   this.picklist_grid
							],
							listeners:{
								afterrender:this.resizeContent,
								resize:this.resizeContent,
								scope:this
							}
						})
					},
					resizeContent:function(){
						if(Ext.getCmp("picklist_gridpanel__dynamicPanelAdmin_dynamicPanel_treegrid_master_table").filter_form != null){
							var formHeight = Ext.getCmp("picklist_gridpanel__dynamicPanelAdmin_dynamicPanel_treegrid_master_table").filter_form.getHeight();
							Ext.getCmp("picklist_gridpanel__dynamicPanelAdmin_dynamicPanel_treegrid_master_table").picklist_grid.setHeight(Ext.getCmp("picklist_gridpanel__dynamicPanelAdmin_dynamicPanel_treegrid_master_table").getHeight()-formHeight-29-_picklist_height_offset);
							Ext.getCmp("picklist_gridpanel__dynamicPanelAdmin_dynamicPanel_treegrid_master_table").picklist_grid.setWidth(Ext.getCmp("picklist_gridpanel__dynamicPanelAdmin_dynamicPanel_treegrid_master_table").getWidth()-14+_picklist_width_offset);
						}else{
							Ext.getCmp("picklist_gridpanel__dynamicPanelAdmin_dynamicPanel_treegrid_master_table").picklist_grid.setHeight(Ext.getCmp("picklist_gridpanel__dynamicPanelAdmin_dynamicPanel_treegrid_master_table").getHeight()-29-_picklist_height_offset);
							Ext.getCmp("picklist_gridpanel__dynamicPanelAdmin_dynamicPanel_treegrid_master_table").picklist_grid.setWidth(Ext.getCmp("picklist_gridpanel__dynamicPanelAdmin_dynamicPanel_treegrid_master_table").getWidth()-14+_picklist_width_offset);
						}
					},
					clearDestValue:function(){
		
				var paramList1 = Ext.getCmp("picklist_gridpanel__dynamicPanelAdmin_dynamicPanel_treegrid_master_table").paramList;
				var paramList = new Object();
				Ext.apply(paramList,paramList1);
		
					if((paramList.sourcePage).toLowerCase()=="searchpanel"){
						Ext.getCmp(paramList.cid).setValue("");
						Ext.getCmp(paramList.cid).fireEvent("keyUp");
					}else{
						Ext.getCmp("gridpanel__dynamicPanelAdmin_dynamicPanel_treegrid_master_table_id").setValue("");
						Ext.getCmp("gridpanel__dynamicPanelAdmin_dynamicPanel_treegrid_master_table_id").fireEvent("keyUp");
					}
						Ext.getCmp("picklist_gridpanel__dynamicPanelAdmin_dynamicPanel_treegrid_master_table").fireDynamicEvent("clear");
						
					},
					adv_search_event:function(){
						var sqlString = "";
						var valueField = "";
						var i=0;
						var operators="";
		
				valueField = Ext.getCmp("name").getValue();
				operators = Ext.getCmp("name_operator_desc").getValue();
				if(operators == "like"){
					valueField = "%"+valueField+"%";
				}
				if(valueField!="" && valueField!=null){
					sqlString = sqlString + " && [name] "+operators+' "'+valueField+'"';
				}
			
				valueField = Ext.getCmp("xtype").getValue();
				operators = Ext.getCmp("xtype_operator_desc").getValue();
				if(operators == "like"){
					valueField = "%"+valueField+"%";
				}
				if(valueField!="" && valueField!=null){
					sqlString = sqlString + " && [xtype] "+operators+' "'+valueField+'"';
				}
			
						Ext.getCmp("picklist_gridpanel__dynamicPanelAdmin_dynamicPanel_treegrid_master_table").picklist_search_store.baseParams.adv_search_where=sqlString;
						Ext.getCmp("picklist_gridpanel__dynamicPanelAdmin_dynamicPanel_treegrid_master_table").picklist_search_store.load();
					},
					rowSelected:function(){
						var lookupbox = Ext.getCmp("gridpanel__dynamicPanelAdmin_dynamicPanel_treegrid_master_table_id");
						var paramList1 = Ext.getCmp("picklist_gridpanel__dynamicPanelAdmin_dynamicPanel_treegrid_master_table").paramList;
						var paramList = new Object();
						Ext.apply(paramList,paramList1);
						if((paramList.sourcePage).toLowerCase()=="searchpanel"){
							lookupbox = Ext.getCmp(paramList.cid);
						}
						var value = lookupbox.getValue();
						if((paramList.sourcePage).toLowerCase()=="searchpanel"){
							if(paramList.needDelimiter==1 && value!=""){
								lookupbox.setValue(Ext.util.Format.htmlDecode(value+","+Ext.getCmp("adv_grid_panel_gridpanel__dynamicPanelAdmin_dynamicPanel_treegrid_master_table").getSelectionModel().getSelected().get("name")));	
							}else{
								lookupbox.setValue(Ext.util.Format.htmlDecode(Ext.getCmp("adv_grid_panel_gridpanel__dynamicPanelAdmin_dynamicPanel_treegrid_master_table").getSelectionModel().getSelected().get("name")));
							}
							lookupbox.focus();
							lookupbox.fireEvent("keyUp");
						}else if((paramList.sourcePage).toLowerCase()=="formpanel"){
		
						value = Ext.getCmp("gridpanel__dynamicPanelAdmin_dynamicPanel_treegrid_master_table_id").getValue();
						if("" == ""||value==""){
							Ext.getCmp("gridpanel__dynamicPanelAdmin_dynamicPanel_treegrid_master_table_id").setValue(Ext.util.Format.htmlDecode(Ext.getCmp("adv_grid_panel_gridpanel__dynamicPanelAdmin_dynamicPanel_treegrid_master_table").getSelectionModel().getSelected().get("name")));
						}else{
							Ext.getCmp("gridpanel__dynamicPanelAdmin_dynamicPanel_treegrid_master_table_id").setValue(Ext.util.Format.htmlDecode(value+""+Ext.getCmp("adv_grid_panel_gridpanel__dynamicPanelAdmin_dynamicPanel_treegrid_master_table").getSelectionModel().getSelected().get("name")));
						}
				
							lookupbox.fireEvent("focus");
							lookupbox.fireEvent("keyUp");	
						}else if((paramList.sourcePage).toLowerCase()=="editgrid"){
							var myGrid;
							var editor;
							if(typeof(paramList.editgrid_id)!="undefined"){
								myGrid = eval(Ext.getCmp(paramList.editgrid_id));
								myGrid.startEditing(paramList.editorrow,paramList.editorcol);
								editor =  myGrid.activeEditor;
							}
	    
									value = editor.getValue();
									if("" == ""||value==""){
										editor.setValue(Ext.util.Format.htmlDecode(Ext.getCmp("adv_grid_panel_gridpanel__dynamicPanelAdmin_dynamicPanel_treegrid_master_table").getSelectionModel().getSelected().get("name")));
									}else{
										editor.setValue(Ext.util.Format.htmlDecode(value+""+Ext.getCmp("adv_grid_panel_gridpanel__dynamicPanelAdmin_dynamicPanel_treegrid_master_table").getSelectionModel().getSelected().get("name")));
									}
		
							lookupbox.focus();
							lookupbox.fireEvent("keyUp");
						}
						Ext.getCmp("picklist_gridpanel__dynamicPanelAdmin_dynamicPanel_treegrid_master_table").fireDynamicEvent("rowclick");
				},
		
			fireDynamicEvent:function(eventFlag){
				var lookupbox = Ext.getCmp("gridpanel__dynamicPanelAdmin_dynamicPanel_treegrid_master_table_id");
				var paramList1 = Ext.getCmp("picklist_gridpanel__dynamicPanelAdmin_dynamicPanel_treegrid_master_table").paramList;
				var paramList = new Object();
				Ext.apply(paramList,paramList1);
		
						var flag = 1;
						var paramList1 = Ext.getCmp("picklist_gridpanel__dynamicPanelAdmin_dynamicPanel_treegrid_master_table").paramList;
						var formValues = new Object();
						Ext.apply(formValues,paramList1);
						if(paramList.sourcePage.toLowerCase()=="formpanel"&&typeof(Ext.getCmp("gridpanel__dynamicPanelAdmin_dynamicPanel_form").gridpanel__dynamicPanelAdmin_dynamicPanel_setStyle)!="undefined"){
							Ext.getCmp("gridpanel__dynamicPanelAdmin_dynamicPanel_form").gridpanel__dynamicPanelAdmin_dynamicPanel_setStyle();
						}
		
						if(eventFlag != "clear"){
						 	Ext.getCmp("picklist_gridpanel__dynamicPanelAdmin_dynamicPanel_treegrid_master_table").close();
						}
					},
					comRender:function(_combo){
						_combo.store.on("load",function(){
							_combo.setValue(_combo.store.getAt(0).get("pkey"));	
						})						
					},
					picklistRedirect :function(){
						createPicklistRedirect("gridpanel__dynamicPanelAdmin_dynamicPanel","treegrid_master_table","","","800","600",this.picklist_grid);
					}
				});
		


								
				form_panel_edit_sys_agent_menu_single = Ext.extend(Ext.form.FormPanel,{
					paramList:null,
					form_panel_edit_sys_agent_menu_single_globalVariable:null,
					constructor:function(_cfg){
						if(_cfg==null){_cfg=={};this.paramList={}}else{this.paramList=_cfg.paramList;};
						this.form_panel_edit_sys_agent_menu_single_globalVariable=new Array();
		
					this.paramList.panel_name="form_panel_edit_sys_agent_menu_single";
					form_panel_edit_sys_agent_menu_single.superclass.constructor.call(this,{
						autoScroll:true,id:"form_panel_edit_sys_agent_menu_single_form",
						labelAlign:"right",padding:10,
						labelWidth:100,fileUpload:true,enctype:"multipart/form-data",border:false,
						bodyBorder:false,anchor:"100% 100%",items:[
		{ xtype:'panel',layout:'form',border:false,items:[createPicklistCompoment("form_panel_edit_sys_agent_menu_single","menu_name",{isVisibleRender:"1",picklistType:"TREE",fieldI18nKey:getResource('menu_name','form_panel_edit_sys_agent_menu_single'),fieldValue:"",comboboxKeyColumn:"",comboboxValueColumn:"",isNeedConfirmDirtyData:"0",editGridId:"",isNeedPicklistFilter:"0",isEditable:true,picklist_redirect_page:"",redirect_page_panel_list:"",redirect_page_title:"",redirect_page_height:"600",redirect_page_width:"800",edit_mode:"0",header_js:"",footer_js:""},this.form_panel_edit_sys_agent_menu_single_globalVariable,"width:150,editable:false,style:{marginLeft:\"0px\",marginTop:\"0px\",marginRight:\"0px\",marginBottom:\"0px\"}")]},{ xtype:'panel',layout:'form',border:false,items:[{
					enableKeyEvents:true,
					name:'_menu_key',id:'form_panel_edit_sys_agent_menu_single__menu_key_id'
					,xtype:'hidden',hiddenName:'_menu_key',width:150}]}],tbar:new Ext.Toolbar({enableOverflow : true,id:'form_panel_edit_sys_agent_menu_single_tbar_btn',items:[{ text:getResource('add_single_menu','form_panel_edit_sys_agent_menu_single'),icon:'../ext/resources/images/icons/add.gif',id:'form_panel_edit_sys_agent_menu_single_add_single_menu_id',scope:this,
								handler:function(){this.event_add_single_menu();}}]}),listeners:{afterlayout:function(){},resize:function(){if(Ext.getCmp('form_panel_edit_sys_agent_menu_single_tbar_btn')){Ext.getCmp('form_panel_edit_sys_agent_menu_single_tbar_btn').doLayout()}},afterrender:function(){
					if(show_page_designer_shortcut == 1){
						var form_panel_edit_sys_agent_menu_single_pdBtn = dynmaicWebPageDesign('form_edit_sys_agent_menu_single','form_panel_edit_sys_agent_menu_single');
						Ext.getCmp('form_panel_edit_sys_agent_menu_single_form').getTopToolbar().add('->');
						Ext.getCmp('form_panel_edit_sys_agent_menu_single_form').getTopToolbar().add(form_panel_edit_sys_agent_menu_single_pdBtn);Ext.getCmp('form_panel_edit_sys_agent_menu_single_form').getTopToolbar().doLayout();
					}else{
						if(Ext.getCmp('form_panel_edit_sys_agent_menu_single_form').getTopToolbar().items.length==0){
							Ext.getCmp('form_panel_edit_sys_agent_menu_single_form').getTopToolbar().hide();
						}
					}
				
						
						
			
						if(getAppPriv('form_panel_edit_sys_agent_menu_single','add_single_menu')==0){
							Ext.getCmp('form_panel_edit_sys_agent_menu_single_add_single_menu_id').hide();
						}
					},beforerender:function(){}}})},
						event_add_single_menu:function(){
							var globalVariables_form_panel_edit_sys_agent_menu_single=new Object();
							var panelActionData_form_panel_edit_sys_agent_menu_single=new Array();
					
							dynamicFormPanelEvent("form_panel_edit_sys_agent_menu_single","add_single_menu",{panelActionDataArray:panelActionData_form_panel_edit_sys_agent_menu_single,isRequireConfirmation:"0",confirmMessage:"getResource('add_single_menu','form_panel_edit_sys_agent_menu_single')",isRequireValidation:"1",predefinedValues:"",handlerType:"BACKGROUND",actionHandlerEvent:"",dynPageName:"",winWidth:"0",winHeight:"0",winTitleI18n:"",isNeedConfirmDirtyData:"0",gridPanelName:"",isRequireSuccessTip:"1",isCloseWindowAfterAction:"1",resetFormAfterSuccess:"0",isRequireReloadGrid:"1",afterSuccessJs:"",handlerJs:"",isWorkFlowStart:"0",workFlowProcessKey:"",wfTable:"",rptFormat:"",isHtmlXls:"0",rptNumber:"",rptPageType:"MAIN_PANEL",targetPanelName:"",targetPanelType:"",menuKey:"form_edit_sys_agent_menu_single"},globalVariables_form_panel_edit_sys_agent_menu_single);
						}	
					,form_panel_edit_sys_agent_menu_single_setStyle:function() {
			try{
			var varStyleArray_form_panel_edit_sys_agent_menu_single=new Array();
		
			}catch(e){
				exceptionHandling(e,'P10017');
			}
		
					},makeNode:function(name,value){
						var node = document.createElement("input");node.type="hidden";node.name=name;
						node.id=name;node.value=this.URLencode(value);return node;
					},
					insertWithin:function(nodeId, name,value) {
						var node = document.getElementById(nodeId);var newNode = this.makeNode(name,value);node.appendChild(newNode);	
					},
					URLencode:function(sStr) {
						return escape(sStr).replace(/\+/g, "%2B").replace(/\'/g,"%22").replace(/\"/g, "%27").replace(/\//g,"%2F");
					},					
					run_popReport:function(panel_name,rpt_format,rpt_number,width,height,formValues){
						var t_url = "index.cfm?event=rpt.report.report.runReportPage";
						for(var i in formValues){
							t_url = t_url + "&"+ i + "="+this.URLencode(formValues[i]);
						}window.open (t_url) ;
					},
					form_panel_edit_sys_agent_menu_single_clientSideValidation:function(v_event_name){
						var validData = "{[],[_menu_key],[if ('this._menu_key' == '') return false;  else return true;],[getResource('menu_key_empty','form_panel_edit_sys_agent_menu_single')],[getResource('menu_key_empty','form_panel_edit_sys_agent_menu_single')]}";var error_msg = "";
						return formClientSideValidation("form_panel_edit_sys_agent_menu_single",validData,v_event_name);
					}
					});
						
				page_form_edit_sys_agent_menu_single = Ext.extend(Ext.Panel,{
					paramList:null,
					loadCounter:null,
		
					constructor:function(_cfg){
							if(_cfg==null){_cfg=={};this.paramList={}}else{this.paramList = _cfg.paramList;};
							Ext.apply(this,_cfg);
						page_form_edit_sys_agent_menu_single.superclass.constructor.call(this,{
							border:false,
							autoScroll:false,	
							id:'page_form_edit_sys_agent_menu_single',
							anchor:'100% 100%',
							layout:'anchor',
							items:[
								
		
							{
								anchor:'100% 100%',flex:1,
								layout:"fit",
								panel_name:"form_panel_edit_sys_agent_menu_single",
								panel_type:"advformpanel",
								id:"form_panel_edit_sys_agent_menu_single_parentPanel",
								items:[new form_panel_edit_sys_agent_menu_single({paramList:this.paramList})]
						}]
						})
					},
					listeners:{
						beforerender:function(_grid){
							var winObj = eval(Ext.getCmp(Ext.getCmp('page_form_edit_sys_agent_menu_single').paramList.win_id));
							if(typeof(winObj)!='undefined'){
								maskObj = new Ext.LoadMask(winObj.getEl(), {msg:getResource('loading','')});
								maskObj.show();
							}
						},
						render:function(_grid){
							Ext.getCmp('page_form_edit_sys_agent_menu_single').loadCounter=0;
		
				if(Ext.getCmp('page_form_edit_sys_agent_menu_single').loadCounter==0){
					maskObj.hide();	
					Ext.getCmp('page_form_edit_sys_agent_menu_single').loadCounter=0;
				} 
		
									
						
											
						
							if(null!=maskObj&&maskObj!=undefined){
								if(Ext.getCmp('page_form_edit_sys_agent_menu_single').loadCounter<=0){
									maskObj.hide();	
									Ext.getCmp('page_form_edit_sys_agent_menu_single').loadCounter=0;
								}
							}	
						
						},
						afterrender:function(_grid){
		
					if(getAppPriv('form_panel_edit_sys_agent_menu_single','')==0){
				
						if(typeof(Ext.getCmp('form_panel_edit_sys_agent_menu_single_form'))!='undefined'){
							Ext.getCmp('form_panel_edit_sys_agent_menu_single_form').destroy();
							if(typeof(Ext.getCmp('form_panel_edit_sys_agent_menu_single_parentPanel'))!='undefined'){
								var parent = Ext.getCmp('form_panel_edit_sys_agent_menu_single_parentPanel').ownerCt;
								parent.remove(Ext.getCmp('form_panel_edit_sys_agent_menu_single_parentPanel'));
								parent.doLayout();
							}
						}
					}},
					destroy:function(){
		
					}		
				
					}
				})
		

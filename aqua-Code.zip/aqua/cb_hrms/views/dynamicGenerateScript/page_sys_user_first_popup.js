
								
				form_add_sys_user = Ext.extend(Ext.form.FormPanel,{
					paramList:null,
					form_add_sys_user_globalVariable:null,
					constructor:function(_cfg){
						if(_cfg==null){_cfg=={};this.paramList={}}else{this.paramList=_cfg.paramList;};
						this.form_add_sys_user_globalVariable=new Array();
		
					this.paramList.panel_name="form_add_sys_user";
					form_add_sys_user.superclass.constructor.call(this,{
						autoScroll:true,id:"form_add_sys_user_form",
						labelAlign:"right",padding:10,
						labelWidth:100,fileUpload:true,enctype:"multipart/form-data",border:false,
						bodyBorder:false,anchor:"100% 100%",items:[
		{ xtype:'panel',layout:'form',border:false,items:[createPicklistCompoment("form_add_sys_user","user_name",{isVisibleRender:"1",picklistType:"TEXTFIELD",fieldI18nKey:getResource('user_name','grid_sys_user'),fieldValue:"",comboboxKeyColumn:"",comboboxValueColumn:"",isNeedConfirmDirtyData:"0",editGridId:"",isNeedPicklistFilter:"0",isEditable:true,picklist_redirect_page:"",redirect_page_panel_list:"",redirect_page_title:"",redirect_page_height:"600",redirect_page_width:"800",edit_mode:"0",header_js:"",footer_js:""},this.form_add_sys_user_globalVariable,"width:150,style:{marginLeft:\"0px\",marginTop:\"0px\",marginRight:\"0px\",marginBottom:\"0px\"}")]},{ xtype:'panel',layout:'form',border:false,items:[createPicklistCompoment("form_add_sys_user","password",{isVisibleRender:"1",picklistType:"TEXTFIELD",fieldI18nKey:getResource('password','grid_sys_user'),fieldValue:"",comboboxKeyColumn:"",comboboxValueColumn:"",isNeedConfirmDirtyData:"0",editGridId:"",isNeedPicklistFilter:"0",isEditable:true,picklist_redirect_page:"",redirect_page_panel_list:"",redirect_page_title:"",redirect_page_height:"600",redirect_page_width:"800",edit_mode:"0",header_js:"",footer_js:""},this.form_add_sys_user_globalVariable,"width:150,style:{marginLeft:\"0px\",marginTop:\"0px\",marginRight:\"0px\",marginBottom:\"0px\"},inputType:\'password\'")]},{ xtype:'panel',layout:'form',border:false,items:[createPicklistCompoment("form_add_sys_user","employee_no",{isVisibleRender:"1",picklistType:"TEXTFIELD",fieldI18nKey:getResource('employee_no','grid_sys_user'),fieldValue:"",comboboxKeyColumn:"",comboboxValueColumn:"",isNeedConfirmDirtyData:"0",editGridId:"",isNeedPicklistFilter:"0",isEditable:true,picklist_redirect_page:"",redirect_page_panel_list:"",redirect_page_title:"",redirect_page_height:"600",redirect_page_width:"800",edit_mode:"0",header_js:"",footer_js:""},this.form_add_sys_user_globalVariable,"width:150,style:{marginLeft:\"0px\",marginTop:\"0px\",marginRight:\"0px\",marginBottom:\"0px\"}")]},{ xtype:'panel',layout:'form',border:false,items:[{
					enableKeyEvents:true,
					name:'is_active',id:'form_add_sys_user_is_active_id'
					,xtype:'checkbox',inputValue:'1',fieldLabel:getResource('is_active','grid_sys_user'),hiddenName:'is_active',
							listeners:{
						
								check:function(check){
									if (this.readOnly === true) {
										this.el.dom.checked = this.originalValue;
										return false;
									}else{
										this.originalValue = this.el.dom.checked;
									}
						}	},width:150,style:{marginLeft:"0px",marginTop:"0px",marginRight:"0px",marginBottom:"0px"}}]},{ xtype:'panel',layout:'form',border:false,items:[{
					enableKeyEvents:true,
					name:'is_locked',id:'form_add_sys_user_is_locked_id'
					,xtype:'checkbox',inputValue:'1',fieldLabel:getResource('is_locked','grid_sys_user'),hiddenName:'is_locked',
							listeners:{
						
								check:function(check){
									if (this.readOnly === true) {
										this.el.dom.checked = this.originalValue;
										return false;
									}else{
										this.originalValue = this.el.dom.checked;
									}
						}	},width:150,style:{marginLeft:"0px",marginTop:"0px",marginRight:"0px",marginBottom:"0px"}}]},{ xtype:'panel',layout:'form',border:false,items:[{
					enableKeyEvents:true,
					name:'effect_date',id:'form_add_sys_user_effect_date_id'
					,listeners:{},xtype:'datefield',format:web_platform_dateformat,fieldLabel:getResource('effect_date','grid_sys_user'),hiddenName:'effect_date',width:150,style:{marginLeft:"0px",marginTop:"0px",marginRight:"0px",marginBottom:"0px"}}]},{ xtype:'panel',layout:'form',border:false,items:[createPicklistCompoment("form_add_sys_user","email",{isVisibleRender:"1",picklistType:"TEXTFIELD",fieldI18nKey:getResource('email','grid_sys_user'),fieldValue:"",comboboxKeyColumn:"",comboboxValueColumn:"",isNeedConfirmDirtyData:"0",editGridId:"",isNeedPicklistFilter:"0",isEditable:true,picklist_redirect_page:"",redirect_page_panel_list:"",redirect_page_title:"",redirect_page_height:"600",redirect_page_width:"800",edit_mode:"0",header_js:"",footer_js:""},this.form_add_sys_user_globalVariable,"width:150,style:{marginLeft:\"0px\",marginTop:\"0px\",marginRight:\"0px\",marginBottom:\"0px\"}")]},{ xtype:'panel',layout:'form',border:false,items:[createPicklistCompoment("form_add_sys_user","default_lang",{isVisibleRender:"1",picklistType:"COMBOBOX",fieldI18nKey:getResource('default_lang','grid_sys_user'),fieldValue:"",comboboxKeyColumn:"lang_id",comboboxValueColumn:"lang_name",isNeedConfirmDirtyData:"0",editGridId:"",isNeedPicklistFilter:"0",isEditable:true,picklist_redirect_page:"",redirect_page_panel_list:"",redirect_page_title:"",redirect_page_height:"600",redirect_page_width:"800",edit_mode:"0",header_js:"",footer_js:""},this.form_add_sys_user_globalVariable,"width:150,editable:false,style:{marginLeft:\"0px\",marginTop:\"0px\",marginRight:\"0px\",marginBottom:\"0px\"}")]},{ xtype:'panel',layout:'form',border:false,items:[createPicklistCompoment("form_add_sys_user","phone",{isVisibleRender:"1",picklistType:"TEXTFIELD",fieldI18nKey:getResource('phone','grid_sys_user'),fieldValue:"",comboboxKeyColumn:"",comboboxValueColumn:"",isNeedConfirmDirtyData:"0",editGridId:"",isNeedPicklistFilter:"0",isEditable:true,picklist_redirect_page:"",redirect_page_panel_list:"",redirect_page_title:"",redirect_page_height:"600",redirect_page_width:"800",edit_mode:"0",header_js:"",footer_js:""},this.form_add_sys_user_globalVariable,"width:150,style:{marginLeft:\"0px\",marginTop:\"0px\",marginRight:\"0px\",marginBottom:\"0px\"}")]},{ xtype:'panel',layout:'form',border:false,items:[createPicklistCompoment("form_add_sys_user","description",{isVisibleRender:"1",picklistType:"TEXTFIELD",fieldI18nKey:getResource('description','grid_sys_user'),fieldValue:"",comboboxKeyColumn:"",comboboxValueColumn:"",isNeedConfirmDirtyData:"0",editGridId:"",isNeedPicklistFilter:"0",isEditable:true,picklist_redirect_page:"",redirect_page_panel_list:"",redirect_page_title:"",redirect_page_height:"600",redirect_page_width:"800",edit_mode:"0",header_js:"",footer_js:""},this.form_add_sys_user_globalVariable,"width:150,style:{marginLeft:\"0px\",marginTop:\"0px\",marginRight:\"0px\",marginBottom:\"0px\"}")]},{ xtype:'panel',layout:'form',border:false,items:[{
					enableKeyEvents:true,
					name:'pwd_change_req',id:'form_add_sys_user_pwd_change_req_id'
					,xtype:'checkbox',inputValue:'1',fieldLabel:getResource('pwd_change_req','grid_sys_user'),hiddenName:'pwd_change_req',
							listeners:{
						
								check:function(check){
									if (this.readOnly === true) {
										this.el.dom.checked = this.originalValue;
										return false;
									}else{
										this.originalValue = this.el.dom.checked;
									}
						}	},width:150,style:{marginLeft:"0px",marginTop:"0px",marginRight:"0px",marginBottom:"0px"}}]},{ xtype:'panel',layout:'form',border:false,items:[createPicklistCompoment("form_add_sys_user","business_unit_key",{isVisibleRender:"1",picklistType:"TREE",fieldI18nKey:getResource('business_unit_key','grid_sys_user'),fieldValue:"",comboboxKeyColumn:"",comboboxValueColumn:"",isNeedConfirmDirtyData:"0",editGridId:"",isNeedPicklistFilter:"0",isEditable:true,picklist_redirect_page:"",redirect_page_panel_list:"",redirect_page_title:"",redirect_page_height:"600",redirect_page_width:"800",edit_mode:"0",header_js:"",footer_js:""},this.form_add_sys_user_globalVariable,"width:150,style:{marginLeft:\"0px\",marginTop:\"0px\",marginRight:\"0px\",marginBottom:\"0px\"}")]},{ xtype:'panel',layout:'form',border:false,items:[createPicklistCompoment("form_add_sys_user","default_home_page",{isVisibleRender:"1",picklistType:"TREE",fieldI18nKey:getResource('default_home_page','grid_sys_user'),fieldValue:"",comboboxKeyColumn:"",comboboxValueColumn:"",isNeedConfirmDirtyData:"0",editGridId:"",isNeedPicklistFilter:"0",isEditable:true,picklist_redirect_page:"",redirect_page_panel_list:"",redirect_page_title:"",redirect_page_height:"600",redirect_page_width:"800",edit_mode:"0",header_js:"",footer_js:""},this.form_add_sys_user_globalVariable,"width:150")]},{ xtype:'panel',layout:'form',border:false,items:[createPicklistCompoment("form_add_sys_user","is_admin_user",{isVisibleRender:"0",picklistType:"TEXTFIELD",fieldI18nKey:getResource('is_admin_user','form_add_sys_user'),fieldValue:"",comboboxKeyColumn:"",comboboxValueColumn:"",isNeedConfirmDirtyData:"0",editGridId:"",isNeedPicklistFilter:"1",isEditable:true,picklist_redirect_page:"",redirect_page_panel_list:"",redirect_page_title:"",redirect_page_height:"600",redirect_page_width:"800",edit_mode:"0",header_js:"",footer_js:""},this.form_add_sys_user_globalVariable,"width:150,style:{marginLeft:\"0px\",marginTop:\"0px\",marginRight:\"0px\",marginBottom:\"0px\"}")]},{ xtype:'panel',layout:'form',border:false,items:[{
					enableKeyEvents:true,
					name:'is_admin',id:'form_add_sys_user_is_admin_id'
					,xtype:'checkbox',inputValue:'1',fieldLabel:getResource('is_admin','form_add_sys_user'),hiddenName:'is_admin',
							listeners:{
						
								check:function(check){
									if (this.readOnly === true) {
										this.el.dom.checked = this.originalValue;
										return false;
									}else{
										this.originalValue = this.el.dom.checked;
									}
						}	}, hideMode:'visibility',hidden:true,width:150,style:{marginLeft:"0px",marginTop:"0px",marginRight:"0px",marginBottom:"0px"},listeners:{render:function(){Ext.getCmp('form_add_sys_user_is_admin_id').setVisible(false);Ext.getCmp('form_add_sys_user_form').doLayout();
											}}}]}],tbar:new Ext.Toolbar({enableOverflow : true,id:'form_add_sys_user_tbar_btn',items:[{ text:getResource('add','form_add_sys_user'),icon:'../ext/resources/images/icons/add.gif',id:'form_add_sys_user_form_add_sys_user_add_record_id',scope:this,
								handler:function(){this.event_form_add_sys_user_add_record();}}]}),listeners:{afterlayout:function(){},resize:function(){if(Ext.getCmp('form_add_sys_user_tbar_btn')){Ext.getCmp('form_add_sys_user_tbar_btn').doLayout()}},afterrender:function(){
							if(_platform_current_bu_list.length==_platform_current_bu.length+2){
								Ext.getCmp('form_add_sys_user_business_unit_key_id').readOnly=true;	
								Ext.getCmp('form_add_sys_user_business_unit_key_id').setValue(_platform_current_bu);
							}
					
					if(show_page_designer_shortcut == 1){
						var form_add_sys_user_pdBtn = dynmaicWebPageDesign('sys_user_first_popup','form_add_sys_user');
						Ext.getCmp('form_add_sys_user_form').getTopToolbar().add('->');
						Ext.getCmp('form_add_sys_user_form').getTopToolbar().add(form_add_sys_user_pdBtn);Ext.getCmp('form_add_sys_user_form').getTopToolbar().doLayout();
					}else{
						if(Ext.getCmp('form_add_sys_user_form').getTopToolbar().items.length==0){
							Ext.getCmp('form_add_sys_user_form').getTopToolbar().hide();
						}
					}
				
						
						
			
						if(getAppPriv('form_add_sys_user','form_add_sys_user_add_record')==0){
							Ext.getCmp('form_add_sys_user_form_add_sys_user_add_record_id').hide();
						}
					},beforerender:function(){}}})},
						event_form_add_sys_user_add_record:function(){
							var globalVariables_form_add_sys_user=new Object();
							var panelActionData_form_add_sys_user=new Array();
					
							dynamicFormPanelEvent("form_add_sys_user","form_add_sys_user_add_record",{panelActionDataArray:panelActionData_form_add_sys_user,isRequireConfirmation:"0",confirmMessage:"getResource('form_add_sys_user','')",isRequireValidation:"1",predefinedValues:"",handlerType:"BACKGROUND",actionHandlerEvent:"",dynPageName:"",winWidth:"0",winHeight:"0",winTitleI18n:"",isNeedConfirmDirtyData:"0",gridPanelName:"",isRequireSuccessTip:"1",isCloseWindowAfterAction:"0",resetFormAfterSuccess:"0",isRequireReloadGrid:"1",afterSuccessJs:"Ext.getCmp(\"userrole2_parentPanel\").enable();\nExt.getCmp(\"userrole2_parentPanel\").show();\nExt.getCmp(\"form_add_sys_user_parentPanel\").hide();\nExt.getCmp(\"form_add_sys_user_parentPanel\").disable();",handlerJs:"",isWorkFlowStart:"0",workFlowProcessKey:"",wfTable:"",rptFormat:"",isHtmlXls:"0",rptNumber:"",rptPageType:"MAIN_PANEL",targetPanelName:"",targetPanelType:"",menuKey:"sys_user_first_popup"},globalVariables_form_add_sys_user);
						}	
					,form_add_sys_user_setStyle:function() {
			try{
			var varStyleArray_form_add_sys_user=new Array();
		
			}catch(e){
				exceptionHandling(e,'P10017');
			}
		
					},makeNode:function(name,value){
						var node = document.createElement("input");node.type="hidden";node.name=name;
						node.id=name;node.value=this.URLencode(value);return node;
					},
					insertWithin:function(nodeId, name,value) {
						var node = document.getElementById(nodeId);var newNode = this.makeNode(name,value);node.appendChild(newNode);	
					},
					URLencode:function(sStr) {
						return escape(sStr).replace(/\+/g, "%2B").replace(/\'/g,"%22").replace(/\"/g, "%27").replace(/\//g,"%2F");
					},					
					run_popReport:function(panel_name,rpt_format,rpt_number,width,height,formValues){
						var t_url = "index.cfm?event=rpt.report.report.runReportPage";
						for(var i in formValues){
							t_url = t_url + "&"+ i + "="+this.URLencode(formValues[i]);
						}window.open (t_url) ;
					},
					form_add_sys_user_clientSideValidation:function(v_event_name){
						var validData = "{[],[user_name],[if('this.user_name'==''||'this.user_name'==null)   {  return false;   }  {return true;}],[getResource('user_name_null','form_add_sys_user')],[getResource('user_name_null','form_add_sys_user')]}{[],[effect_date],[if('this.effect_date'==''||'this.effect_date'==null)   {return false;}  else  {   return true;  }  ],[getResource('effect_date_null','form_add_sys_user')],[getResource('effect_date_null','form_add_sys_user')]}{[],[email],[if(!'this.email')  {  return true;  }  var pattern = /^([a-zA-Z0-9_.-])+@([a-zA-Z0-9_-])+(.[a-zA-Z0-9_-])+/;    var is_email_flag = pattern.test('this.email');   if(is_email_flag)   {    return true;   }   else    {     return false;     } ],[getResource('email_format_error','form_add_sys_user')],[getResource('email_format_error','form_add_sys_user')]}{[],[default_lang],[if('this.default_lang'==null||'this.default_lang'=='')return false;  return true;],[getResource('default_lang_null','form_add_sys_user')],[getResource('default_lang_null','form_add_sys_user')]}{[],[password],[	if(!'this.password')   	{    return true; }   	var pattern =/^[\x21-\x7E]*$/;     	var is_ascii = pattern.test('this.password');    	if(is_ascii)   {    return true;   }     	else    {     return false;     } ],[getResource('password_should_be_ascii','form_add_sys_user')],[getResource('password_should_be_ascii','form_add_sys_user')]}{[],[password],[if('this.password'==''||'this.password'==null) return false; return true;],[getResource('password_should_be_ascii','form_add_sys_user')],[getResource('password_should_be_ascii','form_add_sys_user')]}";var error_msg = "";
						return formClientSideValidation("form_add_sys_user",validData,v_event_name);
					}
					});
						
								
				userrole2 = Ext.extend(Ext.grid.EditorGridPanel,{paramList:null,hideLoadingMask:null,
		
					rowIndex:null,columnIndex:null,is_allow_edit:null,
					myJSON_userrole2:null,
					userrole2_rowdblclick:null,
					userrole2_globalVariable:null,
					constructor:function(_cfg){if(_cfg==null){_cfg=={};this.paramList={}}else{this.paramList=_cfg.paramList;};var userrole2_jsonParams = new Object();
						Ext.apply(userrole2_jsonParams,this.paramList);userrole2_jsonParams.sql_where=" and 1=1";this.hideLoadingMask = true;var userrole2_loadMask;
						this.is_allow_edit=1;
						this.userrole2_globalVariable=new Array();
		this.userrole2_rowdblclick=function(e){
					if(!this.getColumnModel().isCellEditable(this.columnIndex,this.rowIndex)||this.is_allow_edit==0)
					{if(!Ext.getCmp("event_set_as_default_role_2_userrole2").disabled&&!Ext.getCmp("event_set_as_default_role_2_userrole2").hidden)this.event_set_as_default_role_2();}};	
						this.myJSON_userrole2 = new Ext.data.JsonStore({
							autoLoad : false,remoteSort : true,id:"myJSON_userrole2",baseParams:userrole2_jsonParams,
							root : "query.data",totalProperty : "totalcount",
							listeners:{beforeload:function(_store){
									var globalVariables_userrole2=new Object();
									_store.baseParams.panel_name="userrole2";_store.baseParams.currentPanel="userrole2";
									if(!Ext.getCmp("userrole2").hideLoadingMask && typeof(userrole2_loadMask)!="undefined") {
										userrole2_loadMask.show();
									}},load:function(_store){
										if(Ext.getCmp("userrole2")){
										Ext.getCmp("userrole2").setingEditorGridStyle(_store);
		
									Ext.getCmp("userrole2").hideLoadingMask = false;
									if(typeof(userrole2_loadMask) != "undefined") {userrole2_loadMask.hide();}
									if(_store.baseParams.sql_where != null){Ext.getCmp("userrole2").paramList.sql_where = _store.baseParams.sql_where;
									}else{Ext.getCmp("userrole2").paramList.sql_where = " and 1=1";}Ext.apply(Ext.getCmp("userrole2").paramList,_store.baseParams);
									}},exception:function(misc){
										if(userrole2_loadMask){
											userrole2_loadMask.hide();
										}
										if(Ext.getCmp("page_sys_user_first_popup")){
											Ext.getCmp("page_sys_user_first_popup").loadCounter = Ext.getCmp("page_sys_user_first_popup").loadCounter - 1;
										}
										exceptionHandling("","P10002");
									}},
									 proxy: new Ext.data.HttpProxy({   
							              url:"index.cfm?event=dynamicEditGrid.editgrid.editgridData&datenow=" + new Date() + "&_rid=" + Math.random(),
							              timeout: ajaxTimeOut
							         }),
									fields:[
		"role_name","description","is_default_role","user_role_id","user_name","is_mobile_role","is_mobile_role_name"]});var selectModel=new Ext.grid.RowSelectionModel({singleSelect: true});
						userrole2.superclass.constructor.call(this,{
							id:"userrole2",autoScroll:true,header:true,stripeRows:true,border:false,
							trackMouseOver:true,store:this.myJSON_userrole2,
				view : new Ext.ux.grid.LockingGridView({
					doRender : function(cs, rs, ds, startRow, colCount, stripe){
						var ts = this.templates, ct = ts.cell, rt = ts.row, last = colCount-1;
						var tstyle = "width:"+this.getTotalWidth()+";";
						var lstyle = "width:"+this.getLockedWidth()+";";
						var buf = [],lbuf = [], cb, lcb, c, p = {}, rp = {tstyle: tstyle}, r;
						for(var j = 0, len = rs.length; j < len; j++){
							r = rs[j]; cb = [];lcb = [];var rowIndex = (j+startRow);
							for(var i = 0; i < colCount; i++){c = cs[i];p.id = c.id;p.css = (i === 0 ? "x-grid3-cell-first " : (i == last ? "x-grid3-cell-last " : ""))+(this.cm.config[i].cellCls ? ""+ this.cm.config[i].cellCls : "");
								p.attr = p.cellAttr = "";p.value = c.renderer(r.data[c.name], p, r, rowIndex, i, ds);p.style = c.style;
		
								if(Ext.isEmpty(p.value)){p.value = " ";}if(this.markDirty && r.dirty && Ext.isDefined(r.modified[c.name])){p.css += " x-grid3-dirty-cell";}if(c.locked){lcb[lcb.length] = ct.apply(p);}else{cb[cb.length] = ct.apply(p);}
							}var alt = [];
							if(stripe && ((rowIndex+1) % 2 === 0)){alt[0] = "x-grid3-row-alt";}
							if(r.dirty){alt[1] = " x-grid3-dirty-row";}
							rp.cols = colCount;
							if(this.getRowClass){alt[2] = this.getRowClass(r, rowIndex, rp, ds);}
							rp.alt = alt.join(" ");rp.cells = cb.join("");rp.tstyle = tstyle;buf[buf.length] =  rt.apply(rp);rp.cells = lcb.join(" ");rp.tstyle = lstyle;lbuf[lbuf.length] = rt.apply(rp);}	return [buf.join(""), lbuf.join("")];	}}),
		title:getResource('user_role','userrole'),sm:selectModel,
								tbar:new Ext.Toolbar({enableOverflow : true,id:"userrole2_tbar_btn",items:[	
				{ id:"event_add_user_role_2_userrole2",text:getResource('add_user_role','userrole'),icon:"../ext/resources/images/icons/add.gif",handler:function(){this.event_add_user_role_2();},scope:this},{ id:"event_set_as_default_role_2_userrole2",text:getResource('set_as_default_role','userrole'),icon:"../ext/resources/images/icons/cog_edit.png",handler:function(){this.event_set_as_default_role_2();},scope:this},{ id:"event_delete_user_role_2_userrole2",text:getResource('delete_user_role','userrole'),icon:"../ext/resources/images/icons/delete.gif",handler:function(){this.event_delete_user_role_2();},scope:this}]}),
							listeners:{
								"cellclick":function(grid,rowIndex,columnIndex,e){
									this.columnIndex=columnIndex;this.rowIndex=rowIndex;
								},
								"rowclick":function(_grid){
									var selectedRow = _grid.getSelectionModel().getSelections();
									if(selectedRow.length == 1){
							
								if(Ext.getCmp("userrole2_tbar_btn")){
									Ext.getCmp("userrole2_tbar_btn").doLayout();
								}
							}},"beforerender":function(){},"resize":function(){
				if(Ext.getCmp("userrole2_tbar_btn")){
					Ext.getCmp("userrole2_tbar_btn").doLayout();
				}
		},"render":function(_grid){userrole2_loadMask = new Ext.LoadMask(Ext.getCmp("userrole2").getEl(), {msg:getResource("loading","")});
				if(show_page_designer_shortcut == 1){
					var userrole2_pdBtn = dynmaicWebPageDesign("sys_user_first_popup","userrole2");
					if(typeof(tbar_userrole2)!="undefined"){
						tbar_userrole2.add("->");
						tbar_userrole2.add(userrole2_pdBtn);
						tbar_userrole2.doLayout();
					}else{
						_grid.getTopToolbar().add("->");
						_grid.getTopToolbar().add(userrole2_pdBtn);
					}
					_grid.getTopToolbar().doLayout();
				}else{
					if(_grid.getTopToolbar().items.length==0){
						_grid.getTopToolbar().hide();
					}
				}
			if(getAppPriv('userrole2','add_user_role_2')==0){Ext.getCmp('event_add_user_role_2_userrole2').hide();}if(getAppPriv('userrole2','set_as_default_role_2')==0){Ext.getCmp('event_set_as_default_role_2_userrole2').hide();}if(getAppPriv('userrole2','delete_user_role_2')==0){Ext.getCmp('event_delete_user_role_2_userrole2').hide();}
				if(getAppPriv('userrole2','set_as_default_role_2')==1){
					Ext.getCmp('userrole2').on('rowdblclick',Ext.getCmp('userrole2').userrole2_rowdblclick);
				}	
			
				try{Ext.getCmp("userrole2").getStore().baseParams=new Object({user_name:Ext.getCmp("form_add_sys_user_user_name_id").getValue()});}catch(e){
					exceptionHandling(e,'P10005');
				}
			
				if(typeof(tbar_userrole2)!="undefined"){
					tbar_userrole2.doLayout();
				}
			},"beforeedit":function(e){if(e.grid.is_allow_edit==0){
										e.grid.getColumnModel().setEditable(e.column,false);}else{var _value='';var flag;}if(typeof(e.record.data.allowedit) != 'undefined' && e.record.data.allowedit == 0){return false;}if(e.value){if(typeof(e.value)!= 'number' && typeof(e.value) != 'boolean'&& typeof(e.value) != 'object'){e.record.data[e.field]=e.value.replace(new RegExp('&lt;', 'g'),'<').replace(new RegExp('&gt;', 'g'),'>');}}}},bbar : new Ext.PagingToolbar({id:"userrole2_page_toolbar_id",
							displayInfo : true,pageSize : 20,store : this.myJSON_userrole2,dummy : true}),colModel:new Ext.ux.grid.LockingColumnModel([
					{header:getResource("role_name","userrole2"),
						hidden:false,sortable:true,dataIndex:"role_name"},
					{header:getResource("description","userrole2"),
						hidden:false,sortable:true,dataIndex:"description"},
					{header:getResource("is_default_role","userrole2"),
						hidden:false,sortable:true,dataIndex:"is_default_role"},
							{header:getResource('user_role_id','sys_user_role'),width:100,hidden:true,
								resizable:true,sortable:true,hideable:true,
								menuDisabled:false,dataIndex:"user_role_id" },
							{header:getResource('user_name','userrole'),width:100,hidden:true,
								resizable:true,sortable:true,hideable:true,
								menuDisabled:false,dataIndex:"user_name" },
							{header:getResource('is_mobile_role','grid_user_role'),width:0,hidden:true,
								resizable:false,sortable:false,hideable:false,
								menuDisabled:false,dataIndex:"is_mobile_role" },
					{header:getResource("is_mobile_role_name","userrole2"),
						hidden:false,sortable:true,dataIndex:"is_mobile_role_name"}])})},listeners: {afteredit:function(e) {
									if(typeof(e.value)=="object"){
											if(e.value instanceof Date){
												Ext.getCmp("userrole2").store.getAt(e.row).data[e.field] = e.value.format("Y-m-d");
											}
									}
									var _store = Ext.getCmp("userrole2").store;
									Ext.getCmp("userrole2").setingEditorGridStyle(_store);
									Ext.getCmp("userrole2").getSelectionModel().selectRow(e.row);
								},columnmove : function(oldIndex,newIndex){if(Ext.getCmp("userrole2")){Ext.getCmp("userrole2").setingEditorGridStyle(Ext.getCmp("userrole2").store)}},afterrender:function(g){var valueList = "";if(valueList!=""){var dataIndexArray = new Array();dataIndexArray = valueList.split(",");initLockGridColumn(g,dataIndexArray);}}},setingEditorGridStyle:function(_store) {
						},
				event_add_user_role_2:function(e){
					globalVariables_userrole2=new Object();
					panelActionData_userrole2=new Array();
				
						dynamicGridPanelEvent(e,"userrole2","add_user_role_2",{panelActionDataArray:panelActionData_userrole2,winHeight:400,winWidth:400,isRequireGridRowSelection:"0",columnList:"role_name,description,is_default_role,user_role_id,user_name,is_mobile_role,is_mobile_role_name",handlerType:"POPUP",isUseDynamicPanel:"1",isRequireConfirmation:"0",isRequireReloadGrid:"1",confirmMessage:"",predefinedValues:"",gridPanelName:"",saveType:"EDITGRID",isCloseWindowAfterAction:"0",isRequireSuccessTip:"1",isWorkFlowStart:"0",workflowProcessKey:"",wfTable:"",dynPageName:"add_user_role_2",actionHandlerEvent:"",isDestroyWin:"0",isNeedConfirmDirtyData:"0",titleI18nKey:"getResource('add_user_role','add_user_role')",afterSuccessJs:"",handlerJs:"",rptFormat:"",isHtmlXls:"0",rptNumber:"",rptPageType:"MAIN_PANEL",targetPanelName:"",targetPanelType:"",menuKey:"sys_user_first_popup",menuId:"0"},globalVariables_userrole2);
					}
				,
				event_set_as_default_role_2:function(e){
					globalVariables_userrole2=new Object();
					panelActionData_userrole2=new Array();
				
						dynamicGridPanelEvent(e,"userrole2","set_as_default_role_2",{panelActionDataArray:panelActionData_userrole2,winHeight:0,winWidth:0,isRequireGridRowSelection:"1",columnList:"role_name,description,is_default_role,user_role_id,user_name,is_mobile_role,is_mobile_role_name",handlerType:"BACKGROUND",isUseDynamicPanel:"0",isRequireConfirmation:"1",isRequireReloadGrid:"1",confirmMessage:"getResource('cfm_default_role','userrole')",predefinedValues:"",gridPanelName:"",saveType:"EDITGRID",isCloseWindowAfterAction:"0",isRequireSuccessTip:"1",isWorkFlowStart:"0",workflowProcessKey:"",wfTable:"",dynPageName:"",actionHandlerEvent:"",isDestroyWin:"0",isNeedConfirmDirtyData:"0",titleI18nKey:"getResource('add_user_role','add_user_role')",afterSuccessJs:"",handlerJs:"",rptFormat:"",isHtmlXls:"0",rptNumber:"",rptPageType:"MAIN_PANEL",targetPanelName:"",targetPanelType:"",menuKey:"sys_user_first_popup",menuId:"0"},globalVariables_userrole2);
					}
				,
				event_delete_user_role_2:function(e){
					globalVariables_userrole2=new Object();
					panelActionData_userrole2=new Array();
				
						dynamicGridPanelEvent(e,"userrole2","delete_user_role_2",{panelActionDataArray:panelActionData_userrole2,winHeight:0,winWidth:0,isRequireGridRowSelection:"1",columnList:"role_name,description,is_default_role,user_role_id,user_name,is_mobile_role,is_mobile_role_name",handlerType:"BACKGROUND",isUseDynamicPanel:"0",isRequireConfirmation:"1",isRequireReloadGrid:"1",confirmMessage:"getResource('delete_message','grid_sys_user')",predefinedValues:"",gridPanelName:"",saveType:"EDITGRID",isCloseWindowAfterAction:"0",isRequireSuccessTip:"1",isWorkFlowStart:"0",workflowProcessKey:"",wfTable:"",dynPageName:"",actionHandlerEvent:"",isDestroyWin:"0",isNeedConfirmDirtyData:"0",titleI18nKey:"getResource('add_user_role','add_user_role')",afterSuccessJs:"",handlerJs:"",rptFormat:"",isHtmlXls:"0",rptNumber:"",rptPageType:"MAIN_PANEL",targetPanelName:"",targetPanelType:"",menuKey:"sys_user_first_popup",menuId:"0"},globalVariables_userrole2);
					}
				
				,URLencode:function(sStr){ return escape(sStr).replace(/\+/g, '%2B').replace(/\"/g,'%22').replace(/\'/g, '%27').replace(/\//g,'%2F');	},
				run_popReport:function(panel_name,rpt_format,rpt_number,width,height,formValues){var t_url = 'index.cfm?event=rpt.report.report.runReportPage';for(var i in formValues){t_url = t_url + '&'+ i + '='+URLencode(formValues[i]);}window.open (t_url) ;}	
								
				});
		
						
				page_sys_user_first_popup = Ext.extend(Ext.Panel,{
					paramList:null,
					loadCounter:null,
		
							form_add_sys_user_loadFormData:function(){
								var paramList = Ext.getCmp('form_add_sys_user_form').paramList;
							
								paramList.panel_name='form_add_sys_user';
								var action = arguments[0];
								Ext.Ajax.request({
					           		url:'index.cfm?event=dynamicGenerateScript.dynamicGenerateScript.dynamicGetAdvFormData&_dc='+new Date() + '&_rid=' + Math.random(),
					                method:'POST',
					                timeout : ajaxTimeOut,
					                params:paramList,
					                failure:function(response,options){
										if(Ext.getCmp('page_sys_user_first_popup')){
											Ext.getCmp('page_sys_user_first_popup').loadCounter = Ext.getCmp('page_sys_user_first_popup').loadCounter - 1;
										}
										if(typeof(Ext.getCmp('form_add_sys_user_form'))!='undefined'){
											exceptionHandling('','P10013');
										}
					                },
					                success:function(response,options){
					                   if(typeof(Ext.getCmp('form_add_sys_user_form'))!='undefined'){
					                   try{
								           var responseText = Ext.util.JSON.decode(response.responseText).jsonObject;
								           var controlTypeList = Ext.util.JSON.decode(response.responseText).success_msg;
								           loadFormData('form_add_sys_user',action,responseText,controlTypeList);
						 			   Ext.getCmp('form_add_sys_user_form').form_add_sys_user_setStyle();
						 
						 			   try{
						 			   		Ext.getCmp("userrole2_parentPanel").disable();
Ext.getCmp("grid_sys_user_grid_sys_user_add_record_win_popUp_parent").on("hide",function(p){Ext.getCmp("grid_sys_user_grid_sys_user_add_record_win_popUp_parent").destroy();});
						 			   }catch(e){
						 			   		exceptionHandling(e,'P10014');
						 			   }
							 
							  		addPicklistFilterEvent('form_add_sys_user','',2);
						 	  
										if(null!=maskObj&&maskObj!=undefined){
											Ext.getCmp('page_sys_user_first_popup').loadCounter=Ext.getCmp('page_sys_user_first_popup').loadCounter-1;
											if(Ext.getCmp('page_sys_user_first_popup').loadCounter<=0){
												maskObj.hide();	
												Ext.getCmp('page_sys_user_first_popup').loadCounter=0;
											}
										}
										var globalVariables_form_add_sys_user=new Object();
										
										}catch(e){
					                       if(Ext.getCmp('page_sys_user_first_popup')){
												Ext.getCmp('page_sys_user_first_popup').loadCounter = Ext.getCmp('page_sys_user_first_popup').loadCounter - 1;
										   }
										   exceptionHandling(e,'P10015');
					     			   }
					     			}
							 		}
						  		});
						  	},
					  	
							form_add_sys_user:function(){
						
							if(getAppPriv('form_add_sys_user','')){
								var winObj = eval(Ext.getCmp(Ext.getCmp('page_sys_user_first_popup').paramList.win_id));
								if(typeof(winObj)!='undefined'){
									maskObj = new Ext.LoadMask(winObj.getEl(), {msg:getResource('loading','')});
								}else{
									maskObj = new Ext.LoadMask(Ext.getBody(), {msg:getResource('loading','')});	
								}
								maskObj.show();
								Ext.getCmp('form_add_sys_user_form').getForm().reset();
								var baseParams = new Object();
								var paramList = Ext.getCmp('form_add_sys_user_form').paramList;
								Ext.apply(baseParams,paramList);
								baseParams.panel_name='form_add_sys_user';
								baseParams.currentPanel='form_add_sys_user';
								baseParams.pname='form_add_sys_user';
								Ext.Ajax.request({
									params:baseParams,
									method: 'POST',
									timeout : ajaxTimeOut,
									url: 'index.cfm?event=dynamicGenerateScript.dynamicGenerateScript.dynamicGetPanelComboData&datenow=' + new Date() + '&_rid=' + Math.random(),
									failure: function(response,options){
										if(!Ext.Msg.isVisible()){
										   if (maskObj) {
										       maskObj.hide();
					                       }
					                       if(Ext.getCmp('page_sys_user_first_popup')){
												Ext.getCmp('page_sys_user_first_popup').loadCounter = Ext.getCmp('page_sys_user_first_popup').loadCounter - 1;
										   }
										   if(typeof(Ext.getCmp('form_add_sys_user_form'))!='undefined'){
						                       Ext.Msg.show({
												   title : getResource('warning', ''),
												   msg : getResource('requestException', ''),
												   buttons : Ext.Msg.OK,
												   icon : Ext.MessageBox.WARNING
								               });
							               }
							           }
									},
									success: function(response,options){
										if(typeof(Ext.getCmp('form_add_sys_user_form'))!='undefined'){
										try{
										var responseText = Ext.util.JSON.decode(response.responseText);
										//Ext.MessageBox.hide();
						
									Ext.getCmp("form_add_sys_user_default_lang_id").getStore().loadData(responseText.jsonObject.default_lang);
								
								   Ext.getCmp('page_sys_user_first_popup').form_add_sys_user_loadFormData();
							
								
								
										} catch (e) {
											if(Ext.getCmp('page_sys_user_first_popup')){
												Ext.getCmp('page_sys_user_first_popup').loadCounter = Ext.getCmp('page_sys_user_first_popup').loadCounter - 1;
											}
											exceptionHandling(e,'P10016');
										}
										}
									}
								});
							}
						},
							userrole2:function(){
						
							if(getAppPriv('userrole2','')){
					
							var winObj = eval(Ext.getCmp(Ext.getCmp('page_sys_user_first_popup').paramList.win_id));
							if(typeof(winObj)!='undefined'){
								maskObj = new Ext.LoadMask(winObj.getEl(), {msg:getResource('loading','')});
							}else{
								maskObj = new Ext.LoadMask(Ext.getBody(), {msg:getResource('loading','')});	
							}
							maskObj.show();
							Ext.getCmp('userrole2').getStore().removeAll();
					
							var baseParams = Ext.getCmp('userrole2').getStore().baseParams;
							var paramList = Ext.getCmp('userrole2').paramList;
							Ext.apply(baseParams,paramList);
							baseParams.panel_name='userrole2';
							baseParams.pname='userrole2';
					
									Ext.apply(baseParams,paramList);
									baseParams.currentPanel='userrole2';
									baseParams.panel_name='userrole2';
									if(typeof(paramList.win_id)!='undefined' || (typeof(Ext.getCmp('userrole2_parentPanel'))!='undefined'&&Ext.getCmp('userrole2_parentPanel').ownerCt.xtype=='tabpanel')) {
										Ext.getCmp('userrole2').hideLoadingMask = true;	
									}									
									if(typeof(Ext.getCmp('userrole2_simplepanel_criteriadata_combo'))!='undefined') {
										var _sql = Ext.getCmp('userrole2_simplepanel_criteriadata_combo').getValue()+'';
										if(_sql.replace(/(^\s*)|(\s*$)/g, '') != '') {
											Ext.getCmp('userrole2').store.setBaseParam('sql_where', ' && '+_sql);
										}else {
											baseParams.sql_where=' and 1=1';
										}			
									}else {
										baseParams.sql_where=' and 1=1';
									}
									Ext.getCmp('userrole2').getStore().baseParams=baseParams;
									Ext.getCmp('userrole2').store.load();	
									if(typeof(Ext.getCmp('userrole2_simplepanel_criteriadata_combo')) == 'undefined') {
							Ext.getCmp('userrole2').getStore().load();
									}else {
										if(Ext.getCmp('userrole2_simplepanel_criteriadata_combo').getStore().getCount()==0) {
											Ext.getCmp('userrole2_simplepanel_criteriadata_combo').getStore().reload();
										}
									}
									Ext.getCmp('userrole2').getStore().on('load',function() {
										if(null!=maskObj&&maskObj!=undefined){
											if(Ext.getCmp('page_sys_user_first_popup')){
												Ext.getCmp('page_sys_user_first_popup').loadCounter=Ext.getCmp('page_sys_user_first_popup').loadCounter-1;
												if(Ext.getCmp('page_sys_user_first_popup').loadCounter<=0){
													maskObj.hide();	
													Ext.getCmp('page_sys_user_first_popup').loadCounter=0;
												}
											}
										}
									});
							
							}
					},
					constructor:function(_cfg){
							if(_cfg==null){_cfg=={};this.paramList={}}else{this.paramList = _cfg.paramList;};
							Ext.apply(this,_cfg);
						page_sys_user_first_popup.superclass.constructor.call(this,{
							border:false,
							autoScroll:false,	
							id:'page_sys_user_first_popup',
							anchor:'100% 100%',
							layout:'anchor',
							items:[
								
		{
								anchor:'100% 100%',flex:1,activeTab:0,
								id:'user_admin_tabpanel_tabpanel',
								enableTabScroll : true,
								listeners:{
									beforetabchange:function(_tab,_new,_old){
										if (validateDataFlag == 1) {			
											Ext.Msg.confirm(getResource('confirm_title',''),getResource('confirm_msg','confirm_modify_data'),function(_btn){
												if(_btn=='no'){
													return false;
												}else{
													validateDataFlag = 0;
													_tab.setActiveTab(_new);
												}
											},this);
											
											return false;
										}
									},
									tabchange:function(_tab, _pan) {
										if(_pan.panel_type=='advformpanel'||_pan.panel_type=='gridpanel'||_pan.panel_type=='editorgridpanel'||_pan.panel_type=='treegridpanel'||_pan.panel_type=='chartpanel'){
											Ext.getCmp('page_sys_user_first_popup').loadCounter = Ext.getCmp('page_sys_user_first_popup').loadCounter+1;
											eval('this.'+_pan.panel_name+'()');
										}
										_pan.doLayout();
									},
									scope:this
								},
								xtype:'tabpanel'
						,items:[
							{
								anchor:'100% 100%',flex:1,border:false,title:getResource('form_add_sys_user','form_add_sys_user'),disabled:false,
								layout:"fit",
								panel_name:"form_add_sys_user",
								panel_type:"advformpanel",
								id:"form_add_sys_user_parentPanel",
								items:[new form_add_sys_user({paramList:this.paramList})]
						},
							{
								anchor:'100% 100%',flex:1,border:false,title:getResource('userrole2','userrole2'),
								layout:"fit",
								panel_name:"userrole2",
								panel_type:"editorgridpanel",
								id:"userrole2_parentPanel",
								items:[new userrole2({paramList:this.paramList})]		
						}]}]
						})
					},
					listeners:{
						beforerender:function(_grid){
							var winObj = eval(Ext.getCmp(Ext.getCmp('page_sys_user_first_popup').paramList.win_id));
							if(typeof(winObj)!='undefined'){
								maskObj = new Ext.LoadMask(winObj.getEl(), {msg:getResource('loading','')});
								maskObj.show();
							}
						},
						render:function(_grid){
							Ext.getCmp('page_sys_user_first_popup').loadCounter=0;
		
				if(Ext.getCmp('page_sys_user_first_popup').loadCounter==0){
					maskObj.hide();	
					Ext.getCmp('page_sys_user_first_popup').loadCounter=0;
				} 
		
							if('undefined'!=typeof(Ext.getCmp('user_admin_tabpanel_tabpanel'))&&(Ext.getCmp('user_admin_tabpanel_tabpanel').items.getCount()>0&&null!=Ext.getCmp('user_admin_tabpanel_tabpanel').getActiveTab()||Ext.getCmp('user_admin_tabpanel_tabpanel').getActiveTab()!=undefined)){
								var _panel_type = Ext.getCmp('user_admin_tabpanel_tabpanel').getActiveTab().panel_type;
								if((_panel_type=='gridpanel' || _panel_type=='editorgridpanel') && typeof(win_obj)!='undefined') {
									Ext.getCmp(Ext.getCmp('user_admin_tabpanel_tabpanel').getActiveTab().panel_name).hideLoadingMask = true;
								}
								Ext.getCmp('user_admin_tabpanel_tabpanel').fireEvent('tabchange',Ext.getCmp('user_admin_tabpanel_tabpanel'),Ext.getCmp('user_admin_tabpanel_tabpanel').getItem(Ext.getCmp('user_admin_tabpanel_tabpanel').getActiveTab()));
							}
						
						},
						afterrender:function(_grid){
		
					if(getAppPriv('user_admin_tabpanel','')==0){
				}
					if(getAppPriv('form_add_sys_user','')==0){
				
						if(typeof(Ext.getCmp('form_add_sys_user_form'))!='undefined'){
							Ext.getCmp('form_add_sys_user_form').destroy();
							if(typeof(Ext.getCmp('form_add_sys_user_parentPanel'))!='undefined'){
								var parent = Ext.getCmp('form_add_sys_user_parentPanel').ownerCt;
								parent.remove(Ext.getCmp('form_add_sys_user_parentPanel'));
								parent.doLayout();
							}
						}
					}
					if(getAppPriv('userrole2','')==0){
				
						if(typeof(Ext.getCmp('userrole2'))!='undefined'){
							Ext.getCmp('userrole2').destroy();
							if(typeof(Ext.getCmp('userrole2_parentPanel'))!='undefined'){
								var parent = Ext.getCmp('userrole2_parentPanel').ownerCt;
								parent.remove(Ext.getCmp('userrole2_parentPanel'));
								parent.doLayout();
							}
						}
					}
					if(typeof(Ext.getCmp('user_admin_tabpanel_tabpanel'))!='undefined'){
						if(Ext.getCmp('user_admin_tabpanel_tabpanel').items.getCount()==0){
							var parent = Ext.getCmp('user_admin_tabpanel_tabpanel').ownerCt;
							parent.remove(Ext.getCmp('user_admin_tabpanel_tabpanel'));	
							parent.doLayout();
						}
					}
				},
					destroy:function(){
		
					}		
				
					}
				})
		

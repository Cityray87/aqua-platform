
								
				add_multilang_language = Ext.extend(Ext.form.FormPanel,{
					paramList:null,
					add_multilang_language_globalVariable:null,
					constructor:function(_cfg){
						if(_cfg==null){_cfg=={};this.paramList={}}else{this.paramList=_cfg.paramList;};
						this.add_multilang_language_globalVariable=new Array();
		
					this.paramList.panel_name="add_multilang_language";
					add_multilang_language.superclass.constructor.call(this,{
						autoScroll:true,id:"add_multilang_language_form",
						labelAlign:"right",padding:10,
						labelWidth:100,fileUpload:true,enctype:"multipart/form-data",border:false,
						bodyBorder:false,anchor:"100% 100%",items:[
		{ xtype:'panel',layout:'form',border:false,items:[createPicklistCompoment("add_multilang_language","lang",{isVisibleRender:"1",picklistType:"TEXTFIELD",fieldI18nKey:getResource('lang','grid_multilang_language'),fieldValue:"",comboboxKeyColumn:"",comboboxValueColumn:"",isNeedConfirmDirtyData:"0",editGridId:"",isNeedPicklistFilter:"0",isEditable:true,picklist_redirect_page:"",redirect_page_panel_list:"",redirect_page_title:"",redirect_page_height:"600",redirect_page_width:"800",edit_mode:"0",header_js:"",footer_js:""},this.add_multilang_language_globalVariable,"")]},{ xtype:'panel',layout:'form',border:false,items:[createPicklistCompoment("add_multilang_language","lang_name",{isVisibleRender:"1",picklistType:"TEXTFIELD",fieldI18nKey:getResource('lang_name','grid_multilang_language'),fieldValue:"",comboboxKeyColumn:"",comboboxValueColumn:"",isNeedConfirmDirtyData:"0",editGridId:"",isNeedPicklistFilter:"0",isEditable:true,picklist_redirect_page:"",redirect_page_panel_list:"",redirect_page_title:"",redirect_page_height:"600",redirect_page_width:"800",edit_mode:"0",header_js:"",footer_js:""},this.add_multilang_language_globalVariable,"")]},{ xtype:'panel',layout:'form',border:false,items:[{
					enableKeyEvents:true,
					name:'is_active',id:'add_multilang_language_is_active_id'
					,xtype:'checkbox',inputValue:'1',fieldLabel:getResource('is_active','grid_multilang_language'),hiddenName:'is_active',
							listeners:{
						
								check:function(check){
									if (this.readOnly === true) {
										this.el.dom.checked = this.originalValue;
										return false;
									}else{
										this.originalValue = this.el.dom.checked;
									}
						}	}}]}],tbar:new Ext.Toolbar({enableOverflow : true,id:'add_multilang_language_tbar_btn',items:[{ text:getResource('add_language','add_multilang_language'),icon:'../ext/resources/images/icons/cog_edit.png',id:'add_multilang_language_add_data_language_id',scope:this,
								handler:function(){this.event_add_data_language();}}]}),listeners:{afterlayout:function(){},resize:function(){if(Ext.getCmp('add_multilang_language_tbar_btn')){Ext.getCmp('add_multilang_language_tbar_btn').doLayout()}},afterrender:function(){
					if(show_page_designer_shortcut == 1){
						var add_multilang_language_pdBtn = dynmaicWebPageDesign('add_multilang_language','add_multilang_language');
						Ext.getCmp('add_multilang_language_form').getTopToolbar().add('->');
						Ext.getCmp('add_multilang_language_form').getTopToolbar().add(add_multilang_language_pdBtn);Ext.getCmp('add_multilang_language_form').getTopToolbar().doLayout();
					}else{
						if(Ext.getCmp('add_multilang_language_form').getTopToolbar().items.length==0){
							Ext.getCmp('add_multilang_language_form').getTopToolbar().hide();
						}
					}
				
						
						
			
						if(getAppPriv('add_multilang_language','add_data_language')==0){
							Ext.getCmp('add_multilang_language_add_data_language_id').hide();
						}
					},beforerender:function(){}}})},
						event_add_data_language:function(){
							var globalVariables_add_multilang_language=new Object();
							var panelActionData_add_multilang_language=new Array();
					
							dynamicFormPanelEvent("add_multilang_language","add_data_language",{panelActionDataArray:panelActionData_add_multilang_language,isRequireConfirmation:"0",confirmMessage:"",isRequireValidation:"1",predefinedValues:"",handlerType:"BACKGROUND",actionHandlerEvent:"",dynPageName:"",winWidth:"0",winHeight:"0",winTitleI18n:"",isNeedConfirmDirtyData:"0",gridPanelName:"",isRequireSuccessTip:"1",isCloseWindowAfterAction:"1",resetFormAfterSuccess:"0",isRequireReloadGrid:"1",afterSuccessJs:"",handlerJs:"",isWorkFlowStart:"0",workFlowProcessKey:"",wfTable:"",rptFormat:"",isHtmlXls:"0",rptNumber:"",rptPageType:"MAIN_PANEL",targetPanelName:"",targetPanelType:"",menuKey:"add_multilang_language"},globalVariables_add_multilang_language);
						}	
					,add_multilang_language_setStyle:function() {
			try{
			var varStyleArray_add_multilang_language=new Array();
		
			}catch(e){
				exceptionHandling(e,'P10017');
			}
		
					},makeNode:function(name,value){
						var node = document.createElement("input");node.type="hidden";node.name=name;
						node.id=name;node.value=this.URLencode(value);return node;
					},
					insertWithin:function(nodeId, name,value) {
						var node = document.getElementById(nodeId);var newNode = this.makeNode(name,value);node.appendChild(newNode);	
					},
					URLencode:function(sStr) {
						return escape(sStr).replace(/\+/g, "%2B").replace(/\'/g,"%22").replace(/\"/g, "%27").replace(/\//g,"%2F");
					},					
					run_popReport:function(panel_name,rpt_format,rpt_number,width,height,formValues){
						var t_url = "index.cfm?event=rpt.report.report.runReportPage";
						for(var i in formValues){
							t_url = t_url + "&"+ i + "="+this.URLencode(formValues[i]);
						}window.open (t_url) ;
					},
					add_multilang_language_clientSideValidation:function(v_event_name){
						var validData = "";var error_msg = "";
						return formClientSideValidation("add_multilang_language",validData,v_event_name);
					}
					});
						
				page_add_multilang_language = Ext.extend(Ext.Panel,{
					paramList:null,
					loadCounter:null,
		
					constructor:function(_cfg){
							if(_cfg==null){_cfg=={};this.paramList={}}else{this.paramList = _cfg.paramList;};
							Ext.apply(this,_cfg);
						page_add_multilang_language.superclass.constructor.call(this,{
							border:false,
							autoScroll:false,	
							id:'page_add_multilang_language',
							anchor:'100% 100%',
							layout:'anchor',
							items:[
								
		
							{
								anchor:'100% 100%',border:false,
								layout:"fit",
								panel_name:"add_multilang_language",
								panel_type:"advformpanel",
								id:"add_multilang_language_parentPanel",
								items:[new add_multilang_language({paramList:this.paramList})]
						}]
						})
					},
					listeners:{
						beforerender:function(_grid){
							var winObj = eval(Ext.getCmp(Ext.getCmp('page_add_multilang_language').paramList.win_id));
							if(typeof(winObj)!='undefined'){
								maskObj = new Ext.LoadMask(winObj.getEl(), {msg:getResource('loading','')});
								maskObj.show();
							}
						},
						render:function(_grid){
							Ext.getCmp('page_add_multilang_language').loadCounter=0;
		
				if(Ext.getCmp('page_add_multilang_language').loadCounter==0){
					maskObj.hide();	
					Ext.getCmp('page_add_multilang_language').loadCounter=0;
				} 
		
									
						
											
						
							if(null!=maskObj&&maskObj!=undefined){
								if(Ext.getCmp('page_add_multilang_language').loadCounter<=0){
									maskObj.hide();	
									Ext.getCmp('page_add_multilang_language').loadCounter=0;
								}
							}	
						
						},
						afterrender:function(_grid){
		
					if(getAppPriv('add_multilang_language','')==0){
				
						if(typeof(Ext.getCmp('add_multilang_language_form'))!='undefined'){
							Ext.getCmp('add_multilang_language_form').destroy();
							if(typeof(Ext.getCmp('add_multilang_language_parentPanel'))!='undefined'){
								var parent = Ext.getCmp('add_multilang_language_parentPanel').ownerCt;
								parent.remove(Ext.getCmp('add_multilang_language_parentPanel'));
								parent.doLayout();
							}
						}
					}},
					destroy:function(){
		
					}		
				
					}
				})
		

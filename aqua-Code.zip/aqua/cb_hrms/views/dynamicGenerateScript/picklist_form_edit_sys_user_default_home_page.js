
			picklist_form_edit_sys_user_default_home_page = Ext.extend(Ext.Window,{
				picklistTree:null,
				paramList:null,
				constructor:function(_cfg){
					if(_cfg==null){_cfg=={};this.paramList={}}else{this.paramList=_cfg.paramList;};
						if((this.paramList.sourcePage).toLowerCase()=="searchpanel"){
							if(typeof(Ext.getCmp("form_edit_sys_user"))!="undefined"){
								Ext.apply(this.paramList,Ext.getCmp("form_edit_sys_user").paramList);
							}
						}
						this.paramList.picklistPanel="form_edit_sys_user";
						this.paramList.field_name="default_home_page";	
						this.paramList.sql_where=" and 1=1";
						Ext.apply(this,_cfg);	
					
					this.picklistTree = new Ext.ux.tree.FilterTreeGrid({
						id: "picklistTree_form_edit_sys_user_default_home_page",
						width: 585,
						height: 468,
						enableDD: false,
						enableSort: false,
						cls:"picklistTree_cls",
						border: false,
						columns:[{
							header:getResource("title","PickListTree"),
							dataIndex: "text",
							width: 263
						}],
						loader: new Ext.tree.TreeLoader({
							url: "index.cfm?event=picklistTree.general.picklistTreeData&now=" + new Date(),
							baseParams:this.paramList
						}),
						listeners:{
							"click": this.onNodeClickEvent,
							"afterrender":function(){
								Ext.getCmp("picklistTree_form_edit_sys_user_default_home_page").setWidth(Ext.getCmp("picklist_form_edit_sys_user_default_home_page").getWidth()-14+_picklist_width_offset);
								Ext.getCmp("picklistTree_form_edit_sys_user_default_home_page").setHeight(Ext.getCmp("picklist_form_edit_sys_user_default_home_page").getHeight()-32-_picklist_height_offset);
		
							}
						}
					});
					picklist_form_edit_sys_user_default_home_page.superclass.constructor.call(this,{
						constrainHeader:true,
						id:"picklist_form_edit_sys_user_default_home_page",
						setZIndex:Ext.emptyFn,
						width:(600 > window.parent.document.body.clientWidth ? window.parent.document.body.clientWidth : 600),
						height:(500 > window.parent.document.body.clientHeight ? window.parent.document.body.clientHeight : 500),
						title: getResource("default_home_page","form_edit_sys_user_picklist"),
						maximizable:false,
						resizable:true,
						modal:true,
						listeners:{
							resize:function(_w,_width,_height,_rawWidth,_rawHeight){
								Ext.getCmp("picklistTree_form_edit_sys_user_default_home_page").setWidth(_width-14+_picklist_width_offset);
								Ext.getCmp("picklistTree_form_edit_sys_user_default_home_page").setHeight(_height-32-_picklist_height_offset);
							},
							beforedestroy:function() {
								Ext.getCmp("picklistTree_form_edit_sys_user_default_home_page").getSelectionModel().select = Ext.emptyFn;
							}
						},
						items:[this.picklistTree]
					})
				},
				onNodeClickEvent:function(node,e){
					var lookupbox = Ext.getCmp("form_edit_sys_user_default_home_page_id");
					var paramList1 = Ext.getCmp("picklist_form_edit_sys_user_default_home_page").paramList;
					var paramList = new Object();
					Ext.apply(paramList,paramList1);
					if((paramList.sourcePage).toLowerCase()=="searchpanel"){
						lookupbox = Ext.getCmp(paramList.cid);
					}
					var value = lookupbox.getValue();
					if(node.attributes.is_enable == "1"){
						if((paramList.sourcePage).toLowerCase()=="searchpanel"){
							if((paramList.needDelimiter)==1&&value!=""){
								lookupbox.setValue(Ext.util.Format.htmlDecode(lookupbox.getValue()+","+node.attributes.menu_key));
							}else{
								lookupbox.setValue(Ext.util.Format.htmlDecode(node.attributes.menu_key));
							}
							lookupbox.focus();
							lookupbox.fireEvent("keyUp");
						}else if((paramList.sourcePage).toLowerCase()=="formpanel"){
			
					value = Ext.getCmp("form_edit_sys_user_default_home_page_id").getValue();
					if("" == ""||value==""){
						Ext.getCmp("form_edit_sys_user_default_home_page_id").setValue(Ext.util.Format.htmlDecode(node.attributes.menu_key));
					}else{
						Ext.getCmp("form_edit_sys_user_default_home_page_id").setValue(Ext.util.Format.htmlDecode(value+""+node.attributes.menu_key));
					}
				
				var flag = 1;		
				var paramList1 = Ext.getCmp("picklist_form_edit_sys_user_default_home_page").paramList;
				var formValues = new Object();
				Ext.apply(formValues,paramList1);
			
					lookupbox.fireEvent("focus");
				}else if((paramList.sourcePage).toLowerCase()=="editgrid"){
					var myGrid,edi;
					if(typeof(paramList.editgrid_id)!="undefined"){
						myGrid = eval(Ext.getCmp(paramList.editgrid_id));
						myGrid.startEditing(paramList.editorrow,paramList.editorcol);
						editor =  myGrid.activeEditor;
			
					value = editor.getValue();
					if("" == ""||value==""){
						editor.setValue(Ext.util.Format.htmlDecode(node.attributes.menu_key));
					}else{
						editor.setValue(Ext.util.Format.htmlDecode(value+""+node.attributes.menu_key));
					}		
				
					}
				}
		
						if(paramList.sourcePage.toLowerCase()=="formpanel"){
							Ext.getCmp("form_edit_sys_user_form").form_edit_sys_user_setStyle();
						}
						Ext.getCmp("picklist_form_edit_sys_user_default_home_page").close();
			
				}
				}
			});
		


				picklist_gridpanel__dynamicPanelAdmin_dynamicPanel_offline_data_source = Ext.extend(Ext.Window,{
					operatorStore:null,
					picklist_search_store:null,
					filter_form:null,
					picklist_grid:null,
					paramList:null,
					hideLoadingMask:null,
					constructor:function(_cfg){
						if(_cfg==null){_cfg=={};this.paramList={}}else{this.paramList=_cfg.paramList;};
						if((this.paramList.sourcePage).toLowerCase()=='searchpanel'){
							if(typeof(Ext.getCmp('gridpanel__dynamicPanelAdmin_dynamicPanel'))!='undefined'){
								Ext.apply(this.paramList,Ext.getCmp('gridpanel__dynamicPanelAdmin_dynamicPanel').paramList);
							}
						}
						this.paramList.pname='gridpanel__dynamicPanelAdmin_dynamicPanel';
						this.paramList.fname='offline_data_source';	
						this.paramList.sql_where=' ';
						this.hideLoadingMask = true;
						var adv_grid_panel_gridpanel__dynamicPanelAdmin_dynamicPanel_offline_data_source_loadMask;	
					
						Ext.apply(this,_cfg);
			
						this.operatorStore = new Ext.data.JsonStore({
							remoteSort: true,
							root: 'query.data',
							autoLoad:'true',
							baseParams:this.paramList,
							totalProperty: 'totalcount',
							url: 'index.cfm?event=searchPanel.general.getPopupSearchOperator&date='+new Date(),
							fields: [{name: 'pkey', type: 'string'}, {name: 'pvalue', type: 'string'}]
						});
					
						this.picklist_search_store = new Ext.data.JsonStore({
							remoteSort: true,
							root: 'query.data',
							autoLoad:'true',
							baseParams:this.paramList,
							totalProperty: 'totalcount',
							url: 'index.cfm?event=picklist.general.picklistData&date='+new Date(),
							listeners: {
								beforeload:function() {
									if(typeof(Ext.getCmp('adv_grid_panel_gridpanel__dynamicPanelAdmin_dynamicPanel_offline_data_source'))!='undefined') {
									if(!Ext.getCmp('adv_grid_panel_gridpanel__dynamicPanelAdmin_dynamicPanel_offline_data_source').hideLoadingMask && typeof(adv_grid_panel_gridpanel__dynamicPanelAdmin_dynamicPanel_offline_data_source_loadMask)!='undefined') {
										adv_grid_panel_gridpanel__dynamicPanelAdmin_dynamicPanel_offline_data_source_loadMask.show();
									}}
								},
								load:function() {
									if(typeof(Ext.getCmp('adv_grid_panel_gridpanel__dynamicPanelAdmin_dynamicPanel_offline_data_source'))!='undefined') {
									Ext.getCmp('adv_grid_panel_gridpanel__dynamicPanelAdmin_dynamicPanel_offline_data_source').hideLoadingMask = false;
									if(typeof(adv_grid_panel_gridpanel__dynamicPanelAdmin_dynamicPanel_offline_data_source_loadMask) != 'undefined') {
										adv_grid_panel_gridpanel__dynamicPanelAdmin_dynamicPanel_offline_data_source_loadMask.hide();
									}}	
								}
							},
							fields: [
		
					        			"table_name"
					        	,
					        			"table_type"
					        	],
							dummy: true
						});
		
					this.filter_form = new Ext.form.FormPanel({
						frame:true,
						bodyBorder:false,
						buttonAlign:"left",
						id:"gridpanel__dynamicPanelAdmin_dynamicPanel_offline_data_source_picklistSerchForm",
						autoWidth:true,
						labelAlign:"left",
						border:false,
						labelWidth:90,
		
						keys:[{key:13,fn:function(){Ext.getCmp("picklist_gridpanel__dynamicPanelAdmin_dynamicPanel_offline_data_source").adv_search_event();}}],
			
						items : [
			
							{
								border : false,
								layout : "column",
								items:[{
									border : false,
									layout : "form",
									width : 200,
									items:[
										new Ext.form.ComboBox({
											allowBlank : true,
											displayField : "pvalue",
				
											fieldLabel : getResource("table_name","form_add_sys_panel_1"),
					
											forceSelection : true,
											hiddenName : "table_name_operator",
											id : "table_name_operator_desc",
											listeners : {
												render : this.comRender,
												scope:this
											},
											mode : "local",
											name : "table_name_operator",
											resizable : true,
											selectOnFocus : true,
											store : this.operatorStore,
											triggerAction : "all",
											typeAhead : true,
											valueField : "pkey",
											width : 100,
											dummy : true
										})		
					
									]
								},{
									border : false,
									layout : "form",
									width : 100,
									items : [new Ext.form.TextField({
										id:"table_name",
										name:"table_name",
										hideLabel:true,
										width:100
									})]
								}]
							}
				
						],
			
						buttons:[
		
						new Ext.Button({
							handler : this.adv_search_event,
							scope:this,
							id : "adv_search_btn_gridpanel__dynamicPanelAdmin_dynamicPanel_offline_data_source",
							style : "margin-top:-5px",
							text : getResource("adv_search_btn","searchPanel"),
							dummy : true
						}),
			
						new Ext.Button({
							handler : this.picklistRedirect,
							scope : this,
							id : "picklist_redirect_gridpanel__dynamicPanelAdmin_dynamicPanel_offline_data_source",
							style : "margin-top:-5px",
							text : getResource("picklist_redirect", "gridpanel__dynamicPanelAdmin_dynamicPanel"),
							dummy : true
						})	
						],
						listeners: {
							afterrender : function() {
								var privFlag = getPrivPicklistRedirect("");
								if(!privFlag){
									Ext.getCmp("picklist_redirect_gridpanel__dynamicPanelAdmin_dynamicPanel_offline_data_source").hide();
								}
		
							}
						}
					})
		
						this.picklist_grid = new Ext.grid.GridPanel({
							border : false,
							height : 300,
							id : 'adv_grid_panel_gridpanel__dynamicPanelAdmin_dynamicPanel_offline_data_source',
							store : this.picklist_search_store,
							stripeRows : true,	
							listeners : {
								rowclick:this.rowSelected,
								'render':function(){
									adv_grid_panel_gridpanel__dynamicPanelAdmin_dynamicPanel_offline_data_source_loadMask = new Ext.LoadMask(Ext.getCmp('adv_grid_panel_gridpanel__dynamicPanelAdmin_dynamicPanel_offline_data_source').getEl(), {msg:getResource('loading','')});
								},
								scope:this
							},
		
							columns:[
			
							{
			
									header:getResource("table_name","form_add_sys_panel_1"),
				
									width:125,
				
									dataIndex : "table_name",
									sortable:true
							}
			,
							{
			
									header:getResource("table_type","form_add_sys_panel_1"),
				
									width:300,
				
									dataIndex : "table_type",
									sortable:true
							}
			
							],
			
							bbar : new Ext.PagingToolbar({
								displayInfo : true,
								pageSize : 10,
								store : this.picklist_search_store,
								dummy : true
							})								
						})
							
						picklist_gridpanel__dynamicPanelAdmin_dynamicPanel_offline_data_source.superclass.constructor.call(this,{
							constrainHeader:true,
							id:'picklist_gridpanel__dynamicPanelAdmin_dynamicPanel_offline_data_source',
							manager:windows,
							width:(450 > window.parent.document.body.clientWidth ? window.parent.document.body.clientWidth : 450),
							height:(500 > window.parent.document.body.clientHeight ? window.parent.document.body.clientHeight : 500),
							title: getResource('offline_data_source','gridpanel__dynamicPanelAdmin_dynamicPanel_picklist'),
							maximizable:false,
							resizable:true,
							modal:true,
							items:[
		
							   this.filter_form,
		
							   this.picklist_grid
							],
							listeners:{
								afterrender:this.resizeContent,
								resize:this.resizeContent,
								scope:this
							}
						})
					},
					resizeContent:function(){
						if(Ext.getCmp("picklist_gridpanel__dynamicPanelAdmin_dynamicPanel_offline_data_source").filter_form != null){
							var formHeight = Ext.getCmp("picklist_gridpanel__dynamicPanelAdmin_dynamicPanel_offline_data_source").filter_form.getHeight();
							Ext.getCmp("picklist_gridpanel__dynamicPanelAdmin_dynamicPanel_offline_data_source").picklist_grid.setHeight(Ext.getCmp("picklist_gridpanel__dynamicPanelAdmin_dynamicPanel_offline_data_source").getHeight()-formHeight-29-_picklist_height_offset);
							Ext.getCmp("picklist_gridpanel__dynamicPanelAdmin_dynamicPanel_offline_data_source").picklist_grid.setWidth(Ext.getCmp("picklist_gridpanel__dynamicPanelAdmin_dynamicPanel_offline_data_source").getWidth()-14+_picklist_width_offset);
						}else{
							Ext.getCmp("picklist_gridpanel__dynamicPanelAdmin_dynamicPanel_offline_data_source").picklist_grid.setHeight(Ext.getCmp("picklist_gridpanel__dynamicPanelAdmin_dynamicPanel_offline_data_source").getHeight()-29-_picklist_height_offset);
							Ext.getCmp("picklist_gridpanel__dynamicPanelAdmin_dynamicPanel_offline_data_source").picklist_grid.setWidth(Ext.getCmp("picklist_gridpanel__dynamicPanelAdmin_dynamicPanel_offline_data_source").getWidth()-14+_picklist_width_offset);
						}
					},
					clearDestValue:function(){
		
				var paramList1 = Ext.getCmp("picklist_gridpanel__dynamicPanelAdmin_dynamicPanel_offline_data_source").paramList;
				var paramList = new Object();
				Ext.apply(paramList,paramList1);
		
					if((paramList.sourcePage).toLowerCase()=="searchpanel"){
						Ext.getCmp(paramList.cid).setValue("");
						Ext.getCmp(paramList.cid).fireEvent("keyUp");
					}else{
						Ext.getCmp("gridpanel__dynamicPanelAdmin_dynamicPanel_offline_data_source_id").setValue("");
						Ext.getCmp("gridpanel__dynamicPanelAdmin_dynamicPanel_offline_data_source_id").fireEvent("keyUp");
					}
						Ext.getCmp("picklist_gridpanel__dynamicPanelAdmin_dynamicPanel_offline_data_source").fireDynamicEvent("clear");
						
					},
					adv_search_event:function(){
						var sqlString = "";
						var valueField = "";
						var i=0;
						var operators="";
		
				valueField = Ext.getCmp("table_name").getValue();
				operators = Ext.getCmp("table_name_operator_desc").getValue();
				if(operators == "like"){
					valueField = "%"+valueField+"%";
				}
				if(valueField!="" && valueField!=null){
					sqlString = sqlString + " && [table_name] "+operators+' "'+valueField+'"';
				}
			
						Ext.getCmp("picklist_gridpanel__dynamicPanelAdmin_dynamicPanel_offline_data_source").picklist_search_store.baseParams.adv_search_where=sqlString;
						Ext.getCmp("picklist_gridpanel__dynamicPanelAdmin_dynamicPanel_offline_data_source").picklist_search_store.load();
					},
					rowSelected:function(){
						var lookupbox = Ext.getCmp("gridpanel__dynamicPanelAdmin_dynamicPanel_offline_data_source_id");
						var paramList1 = Ext.getCmp("picklist_gridpanel__dynamicPanelAdmin_dynamicPanel_offline_data_source").paramList;
						var paramList = new Object();
						Ext.apply(paramList,paramList1);
						if((paramList.sourcePage).toLowerCase()=="searchpanel"){
							lookupbox = Ext.getCmp(paramList.cid);
						}
						var value = lookupbox.getValue();
						if((paramList.sourcePage).toLowerCase()=="searchpanel"){
							if(paramList.needDelimiter==1 && value!=""){
								lookupbox.setValue(Ext.util.Format.htmlDecode(value+","+Ext.getCmp("adv_grid_panel_gridpanel__dynamicPanelAdmin_dynamicPanel_offline_data_source").getSelectionModel().getSelected().get("table_name")));	
							}else{
								lookupbox.setValue(Ext.util.Format.htmlDecode(Ext.getCmp("adv_grid_panel_gridpanel__dynamicPanelAdmin_dynamicPanel_offline_data_source").getSelectionModel().getSelected().get("table_name")));
							}
							lookupbox.focus();
							lookupbox.fireEvent("keyUp");
						}else if((paramList.sourcePage).toLowerCase()=="formpanel"){
		
						value = Ext.getCmp("gridpanel__dynamicPanelAdmin_dynamicPanel_offline_data_source_id").getValue();
						if("" == ""||value==""){
							Ext.getCmp("gridpanel__dynamicPanelAdmin_dynamicPanel_offline_data_source_id").setValue(Ext.util.Format.htmlDecode(Ext.getCmp("adv_grid_panel_gridpanel__dynamicPanelAdmin_dynamicPanel_offline_data_source").getSelectionModel().getSelected().get("table_name")));
						}else{
							Ext.getCmp("gridpanel__dynamicPanelAdmin_dynamicPanel_offline_data_source_id").setValue(Ext.util.Format.htmlDecode(value+""+Ext.getCmp("adv_grid_panel_gridpanel__dynamicPanelAdmin_dynamicPanel_offline_data_source").getSelectionModel().getSelected().get("table_name")));
						}
				
							lookupbox.fireEvent("focus");
							lookupbox.fireEvent("keyUp");	
						}else if((paramList.sourcePage).toLowerCase()=="editgrid"){
							var myGrid;
							var editor;
							if(typeof(paramList.editgrid_id)!="undefined"){
								myGrid = eval(Ext.getCmp(paramList.editgrid_id));
								myGrid.startEditing(paramList.editorrow,paramList.editorcol);
								editor =  myGrid.activeEditor;
							}
	    
									value = editor.getValue();
									if("" == ""||value==""){
										editor.setValue(Ext.util.Format.htmlDecode(Ext.getCmp("adv_grid_panel_gridpanel__dynamicPanelAdmin_dynamicPanel_offline_data_source").getSelectionModel().getSelected().get("table_name")));
									}else{
										editor.setValue(Ext.util.Format.htmlDecode(value+""+Ext.getCmp("adv_grid_panel_gridpanel__dynamicPanelAdmin_dynamicPanel_offline_data_source").getSelectionModel().getSelected().get("table_name")));
									}
		
							lookupbox.focus();
							lookupbox.fireEvent("keyUp");
						}
						Ext.getCmp("picklist_gridpanel__dynamicPanelAdmin_dynamicPanel_offline_data_source").fireDynamicEvent("rowclick");
				},
		
			fireDynamicEvent:function(eventFlag){
				var lookupbox = Ext.getCmp("gridpanel__dynamicPanelAdmin_dynamicPanel_offline_data_source_id");
				var paramList1 = Ext.getCmp("picklist_gridpanel__dynamicPanelAdmin_dynamicPanel_offline_data_source").paramList;
				var paramList = new Object();
				Ext.apply(paramList,paramList1);
		
						var flag = 1;
						var paramList1 = Ext.getCmp("picklist_gridpanel__dynamicPanelAdmin_dynamicPanel_offline_data_source").paramList;
						var formValues = new Object();
						Ext.apply(formValues,paramList1);
						if(paramList.sourcePage.toLowerCase()=="formpanel"&&typeof(Ext.getCmp("gridpanel__dynamicPanelAdmin_dynamicPanel_form").gridpanel__dynamicPanelAdmin_dynamicPanel_setStyle)!="undefined"){
							Ext.getCmp("gridpanel__dynamicPanelAdmin_dynamicPanel_form").gridpanel__dynamicPanelAdmin_dynamicPanel_setStyle();
						}
		
						if(eventFlag != "clear"){
						 	Ext.getCmp("picklist_gridpanel__dynamicPanelAdmin_dynamicPanel_offline_data_source").close();
						}
					},
					comRender:function(_combo){
						_combo.store.on("load",function(){
							_combo.setValue(_combo.store.getAt(0).get("pkey"));	
						})						
					},
					picklistRedirect :function(){
						createPicklistRedirect("gridpanel__dynamicPanelAdmin_dynamicPanel","offline_data_source","","","800","600",this.picklist_grid);
					}
				});
		

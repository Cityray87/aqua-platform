
				page_14100 = Ext.extend(Ext.Panel,{
					paramList:null,
					loadCounter:null,
		
					constructor:function(_cfg){
							if(_cfg==null){_cfg=={};this.paramList={}}else{this.paramList = _cfg.paramList;};
							Ext.apply(this,_cfg);
						page_14100.superclass.constructor.call(this,{
							border:false,
							autoScroll:false,	
							id:'page_14100',
							anchor:'100% 100%',
							layout:'anchor',
							items:[
								
		}]
						})
					},
					listeners:{
						beforerender:function(_grid){
							var winObj = eval(Ext.getCmp(Ext.getCmp('page_14100').paramList.win_id));
							if(typeof(winObj)!='undefined'){
								maskObj = new Ext.LoadMask(winObj.getEl(), {msg:getResource('loading','')});
								maskObj.show();
							}
						},
						render:function(_grid){
							Ext.getCmp('page_14100').loadCounter=0;
		
				if(Ext.getCmp('page_14100').loadCounter==0){
					maskObj.hide();	
					Ext.getCmp('page_14100').loadCounter=0;
				} 
		
						},
						afterrender:function(_grid){
		
					if(getAppPriv('gridpanel__system_menuMaintain_menuData','')==0){
				}},
					destroy:function(){
		
					}		
				
					}
				})
		

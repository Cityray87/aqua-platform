
								
				grid_sys_dyn_home_layout = Ext.extend(Ext.grid.EditorGridPanel,{paramList:null,hideLoadingMask:null,
		grid_sys_dyn_home_layout_win:null,
					rowIndex:null,columnIndex:null,is_allow_edit:null,
					myJSON_grid_sys_dyn_home_layout:null,
					grid_sys_dyn_home_layout_rowdblclick:null,
					grid_sys_dyn_home_layout_globalVariable:null,
					constructor:function(_cfg){if(_cfg==null){_cfg=={};this.paramList={}}else{this.paramList=_cfg.paramList;};var grid_sys_dyn_home_layout_jsonParams = new Object();
						Ext.apply(grid_sys_dyn_home_layout_jsonParams,this.paramList);grid_sys_dyn_home_layout_jsonParams.sql_where=" and 1=1";this.hideLoadingMask = true;var grid_sys_dyn_home_layout_loadMask;
						this.is_allow_edit=1;
						this.grid_sys_dyn_home_layout_globalVariable=new Array();
		this.grid_sys_dyn_home_layout_rowdblclick=function(e){
					if(!this.getColumnModel().isCellEditable(this.columnIndex,this.rowIndex)||this.is_allow_edit==0)
					{if(!Ext.getCmp("event_grid_sys_dyn_home_layout_edit_record_grid_sys_dyn_home_layout").disabled&&!Ext.getCmp("event_grid_sys_dyn_home_layout_edit_record_grid_sys_dyn_home_layout").hidden)this.event_grid_sys_dyn_home_layout_edit_record();}};
						this.grid_sys_dyn_home_layout_win = createAdvSearchPanel("grid_sys_dyn_home_layout","getResource('grid_title','grid_sys_dyn_home_layout')");	
						this.myJSON_grid_sys_dyn_home_layout = new Ext.data.JsonStore({
							autoLoad : false,remoteSort : true,id:"myJSON_grid_sys_dyn_home_layout",baseParams:grid_sys_dyn_home_layout_jsonParams,
							root : "query.data",totalProperty : "totalcount",
							listeners:{beforeload:function(_store){
									var globalVariables_grid_sys_dyn_home_layout=new Object();
									_store.baseParams.panel_name="grid_sys_dyn_home_layout";_store.baseParams.currentPanel="grid_sys_dyn_home_layout";
									if(!Ext.getCmp("grid_sys_dyn_home_layout").hideLoadingMask && typeof(grid_sys_dyn_home_layout_loadMask)!="undefined") {
										grid_sys_dyn_home_layout_loadMask.show();
									}},load:function(_store){
										if(Ext.getCmp("grid_sys_dyn_home_layout")){
										Ext.getCmp("grid_sys_dyn_home_layout").setingEditorGridStyle(_store);
		
									Ext.getCmp("grid_sys_dyn_home_layout").hideLoadingMask = false;
									if(typeof(grid_sys_dyn_home_layout_loadMask) != "undefined") {grid_sys_dyn_home_layout_loadMask.hide();}
									if(_store.baseParams.sql_where != null){Ext.getCmp("grid_sys_dyn_home_layout").paramList.sql_where = _store.baseParams.sql_where;
									}else{Ext.getCmp("grid_sys_dyn_home_layout").paramList.sql_where = " and 1=1";}Ext.apply(Ext.getCmp("grid_sys_dyn_home_layout").paramList,_store.baseParams);
									}},exception:function(misc){
										if(grid_sys_dyn_home_layout_loadMask){
											grid_sys_dyn_home_layout_loadMask.hide();
										}
										if(Ext.getCmp("page_sys_dyn_home_layout_main_page")){
											Ext.getCmp("page_sys_dyn_home_layout_main_page").loadCounter = Ext.getCmp("page_sys_dyn_home_layout_main_page").loadCounter - 1;
										}
										exceptionHandling("","P10002");
									}},
									 proxy: new Ext.data.HttpProxy({   
							              url:"index.cfm?event=dynamicEditGrid.editgrid.editgridData&datenow=" + new Date() + "&_rid=" + Math.random(),
							              timeout: ajaxTimeOut
							         }),
									fields:[
		"id","region","html_content","height","is_active","remark"]});var selectModel=new Ext.grid.RowSelectionModel({singleSelect: true});
						grid_sys_dyn_home_layout.superclass.constructor.call(this,{
							id:"grid_sys_dyn_home_layout",autoScroll:true,header:true,stripeRows:true,border:false,
							trackMouseOver:true,store:this.myJSON_grid_sys_dyn_home_layout,
				view : new Ext.ux.grid.LockingGridView({
					doRender : function(cs, rs, ds, startRow, colCount, stripe){
						var ts = this.templates, ct = ts.cell, rt = ts.row, last = colCount-1;
						var tstyle = "width:"+this.getTotalWidth()+";";
						var lstyle = "width:"+this.getLockedWidth()+";";
						var buf = [],lbuf = [], cb, lcb, c, p = {}, rp = {tstyle: tstyle}, r;
						for(var j = 0, len = rs.length; j < len; j++){
							r = rs[j]; cb = [];lcb = [];var rowIndex = (j+startRow);
							for(var i = 0; i < colCount; i++){c = cs[i];p.id = c.id;p.css = (i === 0 ? "x-grid3-cell-first " : (i == last ? "x-grid3-cell-last " : ""))+(this.cm.config[i].cellCls ? ""+ this.cm.config[i].cellCls : "");
								p.attr = p.cellAttr = "";p.value = c.renderer(r.data[c.name], p, r, rowIndex, i, ds);p.style = c.style;
		
								if(Ext.isEmpty(p.value)){p.value = " ";}if(this.markDirty && r.dirty && Ext.isDefined(r.modified[c.name])){p.css += " x-grid3-dirty-cell";}if(c.locked){lcb[lcb.length] = ct.apply(p);}else{cb[cb.length] = ct.apply(p);}
							}var alt = [];
							if(stripe && ((rowIndex+1) % 2 === 0)){alt[0] = "x-grid3-row-alt";}
							if(r.dirty){alt[1] = " x-grid3-dirty-row";}
							rp.cols = colCount;
							if(this.getRowClass){alt[2] = this.getRowClass(r, rowIndex, rp, ds);}
							rp.alt = alt.join(" ");rp.cells = cb.join("");rp.tstyle = tstyle;buf[buf.length] =  rt.apply(rp);rp.cells = lcb.join(" ");rp.tstyle = lstyle;lbuf[lbuf.length] = rt.apply(rp);}	return [buf.join(""), lbuf.join("")];	}}),
		title:getResource('grid_title','grid_sys_dyn_home_layout'),sm:selectModel,
							tbar:[new Ext.Panel({
									height:23,	border:false,bodyStyle:"padding: 0px; background:#D3E1F1",width:500,
									cls:"sim_search_panel_tbar",
									listeners:{
										"render":function(searchPanel){
											Ext.Ajax.request({method:"post",url: "index.cfm?event=searchPanel.general.generateSimpleSearch&panel_name=grid_sys_dyn_home_layout&now=" + new Date() + "&_rid=" + Math.random(),
												failure: function(response,options){Ext.MessageBox.alert(getResource("failure","grid_sys_dyn_home_layout"),"failure");},
												success: function(response,options){try{var responseText = Ext.util.JSON.decode(response.responseText)
													var paramList = new Object();paramList.panel_name="grid_sys_dyn_home_layout";paramList.simple_search_field=responseText.success_msg;
													paramList.simple_search_operator=responseText.external_params_1;paramList.criFieldList=responseText.external_params_2;paramList.fieldDataList=responseText.external_params_3;	
													searchPanel.add(new SimpleSearchPanel(paramList));searchPanel.doLayout();}catch(e){
														if(grid_sys_dyn_home_layout_loadMask){
															grid_sys_dyn_home_layout_loadMask.hide();
														}
														if(Ext.getCmp("page_sys_dyn_home_layout_main_page")){
															Ext.getCmp("page_sys_dyn_home_layout_main_page").loadCounter = Ext.getCmp("page_sys_dyn_home_layout_main_page").loadCounter - 1;
														}
														exceptionHandling(e,"P10003");
													}}});}}	
								}),"-",new Ext.Button({
									text:getResource("advanced_search","searchPanel"),
									icon:"../ext/resources/images/icons/zoom_in.png",
									cls:"adv_search_panel_btn",
									handler:function(){if(typeof(Ext.getCmp("grid_sys_dyn_home_layout_win"))!="undefined"){Ext.getCmp("grid_sys_dyn_home_layout_win").show();}}})
							
									//ss start
								,"-",
								new Ext.form.ComboBox({
									id:"grid_sys_dyn_home_layout_simplepanel_criteriadata_combo",
									width:120,
									forceSelection:true,
							        selectOnFocus:true,
							        typeAhead: true,
							        editable:false,
							        resizable:true,
									store: new Ext.data.JsonStore({
										autoLoad: false,
										remoteSort: true,
										root: "query.data",
										totalProperty: "totalcount",
										url: "index.cfm?event=searchPanel.general.criteriaDataOrderBy&panel_name=grid_sys_dyn_home_layout",
										fields: ["search_sql","description", "save_type", "default_search"],
										listeners: {
											load:function(store) {
												var private_default = "";
												var public_default = "";
												var str_public = getResource("save_type_public", "");
												for(var i=0;i<store.getCount(); i++) {
													store.getAt(i).set("description",Ext.util.Format.htmlDecode(store.getAt(i).get("description")));
													store.getAt(i).set("search_sql",Ext.util.Format.htmlDecode(store.getAt(i).get("search_sql")));
									        		if(store.getAt(i).get("save_type")=="public")	{
									        			store.getAt(i).set("description", store.getAt(i).get("description")+str_public);	
									        		}
									        		if(store.getAt(i).get("default_search")=="Y") {
									        			if(store.getAt(i).get("save_type")=="private")	{
									        				private_default = store.getAt(i).get("search_sql");
									        			}else if(store.getAt(i).get("save_type")=="public") {
									        				public_default = store.getAt(i).get("search_sql");
									        			}
									        		}			
								        		}
								        		var _sql = "";
								        		if(private_default == "") {
								        			if(public_default != "") {
								        				_sql =_sql + public_default;
								        			}
								        		}else {
								        			_sql =_sql + private_default;
								        		}
												//setValue start
								        		var counter = 0;
								        		for(var i=0;i<store.getCount();i++) {
								        			if(store.getAt(i).get("search_sql") == " ") {
								        				counter++;
								        			}
								        		}
								        		if(counter==0) {
								        			var _rs = new Ext.data.Record(["search_sql" , "description"]) ;
													_rs.set("search_sql" , " ") ;
													_rs.set("description" , getResource("show_all", "searchPanel")) ;
													store.insert(0,_rs);
								        		}
								        		var paramList = Ext.getCmp("grid_sys_dyn_home_layout").paramList;
								        		
								        		if(_sql == "") {
								        			_sql = " ";
								        		}
								        		_sql = Ext.util.Format.htmlDecode(_sql);
								        				
										        		Ext.getCmp("grid_sys_dyn_home_layout_simplepanel_criteriadata_combo").setValue(_sql);
										        		if(_sql.replace(/(^\s*)|(\s*$)/g, "") != "") {
										        			_sql = " && "+_sql;
										        		}
									        			Ext.getCmp("grid_sys_dyn_home_layout").store.setBaseParam("sql_where", " "+_sql);
									        			Ext.getCmp("grid_sys_dyn_home_layout").store.load();
									        		
											}
										}
									}),
							        displayField:"description",
							        valueField:"search_sql",
							        mode: "local",
							        forceSelection: true,
							        triggerAction: "all",
							        selectOnFocus:true,
							        listeners:{
							        	select:function(_combo, _record, _index) {
											var _ss_panel=Ext.getCmp("grid_sys_dyn_home_layout_simple_search_panel_id");
											_ss_panel.items.items[0].items.items[0].items.items[0].clearValue();
											_ss_panel.items.items[0].items.items[1].items.items[0].clearValue();
											var cf = new Ext.form.TextField({
												name: "value",
												anchor: "95%"
											});
											_ss_panel.items.items[0].items.items[2].remove(_ss_panel.items.items[0].items.items[2].items.items[0],true);
											_ss_panel.items.items[0].items.items[2].insert(0,cf);
											_ss_panel.items.items[0].items.items[2].render("grid_sys_dyn_home_layout_simple_search_panel_id");
											_ss_panel.items.items[0].items.items[2].doLayout();
											_ss_panel.render("grid_sys_dyn_home_layout_simple_search_panel_id");
											_ss_panel.doLayout();
							        		var _sql = " "+ _record.data.search_sql;
							        		_sql = Ext.util.Format.htmlDecode(_sql);
							        		if(_sql.replace(/(^\s*)|(\s*$)/g, "") != "") {
							        			_sql = " && "+_sql;
							        		}
											Ext.getCmp("grid_sys_dyn_home_layout").store.setBaseParam("sql_where", _sql);
											Ext.getCmp("grid_sys_dyn_home_layout").store.load();
							        	}
							       	}
								})
												],
							listeners:{
								"cellclick":function(grid,rowIndex,columnIndex,e){
									this.columnIndex=columnIndex;this.rowIndex=rowIndex;
								},
								"rowclick":function(_grid){
									var selectedRow = _grid.getSelectionModel().getSelections();
									if(selectedRow.length == 1){
							
								if(Ext.getCmp("grid_sys_dyn_home_layout_tbar_btn")){
									Ext.getCmp("grid_sys_dyn_home_layout_tbar_btn").doLayout();
								}
							}},"beforerender":function(){},"resize":function(){
				if(Ext.getCmp("grid_sys_dyn_home_layout_tbar_btn")){
					Ext.getCmp("grid_sys_dyn_home_layout_tbar_btn").doLayout();
				}
		},"render":function(_grid){grid_sys_dyn_home_layout_loadMask = new Ext.LoadMask(Ext.getCmp("grid_sys_dyn_home_layout").getEl(), {msg:getResource("loading","")});var tbar_grid_sys_dyn_home_layout = new Ext.Toolbar({enableOverflow : true,id:"grid_sys_dyn_home_layout_tbar_btn",items:[{ id:"event_grid_sys_dyn_home_layout_edit_record_grid_sys_dyn_home_layout",text:getResource('edit_record','grid_sys_dyn_home_layout'),icon:"../ext/resources/images/icons/cog_edit.png",handler:function(){this.event_grid_sys_dyn_home_layout_edit_record();},scope:this}]});tbar_grid_sys_dyn_home_layout.render(_grid.tbar);
				if(show_page_designer_shortcut == 1){
					var grid_sys_dyn_home_layout_pdBtn = dynmaicWebPageDesign("sys_dyn_home_layout_main_page","grid_sys_dyn_home_layout");
					if(typeof(tbar_grid_sys_dyn_home_layout)!="undefined"){
						tbar_grid_sys_dyn_home_layout.add("->");
						tbar_grid_sys_dyn_home_layout.add(grid_sys_dyn_home_layout_pdBtn);
						tbar_grid_sys_dyn_home_layout.doLayout();
					}else{
						_grid.getTopToolbar().add("->");
						_grid.getTopToolbar().add(grid_sys_dyn_home_layout_pdBtn);
					}
					_grid.getTopToolbar().doLayout();
				}else{
					if(_grid.getTopToolbar().items.length==0){
						_grid.getTopToolbar().hide();
					}
				}
			if(getAppPriv('grid_sys_dyn_home_layout','grid_sys_dyn_home_layout_edit_record')==0){Ext.getCmp('event_grid_sys_dyn_home_layout_edit_record_grid_sys_dyn_home_layout').hide();}
				if(getAppPriv('grid_sys_dyn_home_layout','grid_sys_dyn_home_layout_edit_record')==1){
					Ext.getCmp('grid_sys_dyn_home_layout').on('rowdblclick',Ext.getCmp('grid_sys_dyn_home_layout').grid_sys_dyn_home_layout_rowdblclick);
				}	
			
				if(typeof(tbar_grid_sys_dyn_home_layout)!="undefined"){
					tbar_grid_sys_dyn_home_layout.doLayout();
				}
			},"beforeedit":function(e){if(e.grid.is_allow_edit==0){
										e.grid.getColumnModel().setEditable(e.column,false);}else{var _value='';var flag;}if(typeof(e.record.data.allowedit) != 'undefined' && e.record.data.allowedit == 0){return false;}if(e.value){if(typeof(e.value)!= 'number' && typeof(e.value) != 'boolean'&& typeof(e.value) != 'object'){e.record.data[e.field]=e.value.replace(new RegExp('&lt;', 'g'),'<').replace(new RegExp('&gt;', 'g'),'>');}}}},bbar : new Ext.PagingToolbar({id:"grid_sys_dyn_home_layout_page_toolbar_id",
							displayInfo : true,pageSize : 20,store : this.myJSON_grid_sys_dyn_home_layout,dummy : true}),colModel:new Ext.ux.grid.LockingColumnModel([
							{header:getResource('id','grid_sys_dyn_home_layout'),width:0,hidden:true,
								resizable:false,sortable:false,hideable:true,
								menuDisabled:false,dataIndex:"id" },
					{header:getResource("region","grid_sys_dyn_home_layout"),
						hidden:false,sortable:true,dataIndex:"region"},
					{header:getResource("html_content","grid_sys_dyn_home_layout"),
						hidden:false,sortable:true,dataIndex:"html_content"},
					{header:getResource("height","grid_sys_dyn_home_layout"),
						hidden:false,sortable:true,dataIndex:"height"},
					{header:getResource("is_active","grid_sys_dyn_home_layout"),
						hidden:false,sortable:true,dataIndex:"is_active"},
					{header:getResource("remark","grid_sys_dyn_home_layout"),
						hidden:false,sortable:true,dataIndex:"remark"}])})},listeners: {afteredit:function(e) {
									if(typeof(e.value)=="object"){
											if(e.value instanceof Date){
												Ext.getCmp("grid_sys_dyn_home_layout").store.getAt(e.row).data[e.field] = e.value.format("Y-m-d");
											}
									}
									var _store = Ext.getCmp("grid_sys_dyn_home_layout").store;
									Ext.getCmp("grid_sys_dyn_home_layout").setingEditorGridStyle(_store);
									Ext.getCmp("grid_sys_dyn_home_layout").getSelectionModel().selectRow(e.row);
								},columnmove : function(oldIndex,newIndex){if(Ext.getCmp("grid_sys_dyn_home_layout")){Ext.getCmp("grid_sys_dyn_home_layout").setingEditorGridStyle(Ext.getCmp("grid_sys_dyn_home_layout").store)}},afterrender:function(g){var valueList = "";if(valueList!=""){var dataIndexArray = new Array();dataIndexArray = valueList.split(",");initLockGridColumn(g,dataIndexArray);}}},setingEditorGridStyle:function(_store) {
						},
				event_grid_sys_dyn_home_layout_edit_record:function(e){
					globalVariables_grid_sys_dyn_home_layout=new Object();
					panelActionData_grid_sys_dyn_home_layout=new Array();
				
						dynamicGridPanelEvent(e,"grid_sys_dyn_home_layout","grid_sys_dyn_home_layout_edit_record",{panelActionDataArray:panelActionData_grid_sys_dyn_home_layout,winHeight:400,winWidth:600,isRequireGridRowSelection:"1",columnList:"id,region,html_content,height,is_active,remark",handlerType:"POPUP",isUseDynamicPanel:"0",isRequireConfirmation:"0",isRequireReloadGrid:"1",confirmMessage:"",predefinedValues:"",gridPanelName:"",saveType:"EDITGRID",isCloseWindowAfterAction:"1",isRequireSuccessTip:"1",isWorkFlowStart:"0",workflowProcessKey:"",wfTable:"",dynPageName:"sys_dyn_home_layout_second_popup",actionHandlerEvent:"",isDestroyWin:"1",isNeedConfirmDirtyData:"0",titleI18nKey:"getResource('edit_record','form_edit_sys_dyn_home_layout')",afterSuccessJs:"",handlerJs:"",rptFormat:"",isHtmlXls:"0",rptNumber:"",rptPageType:"MAIN_PANEL",targetPanelName:"",targetPanelType:"",menuKey:"sys_dyn_home_layout_main_page",menuId:"0"},globalVariables_grid_sys_dyn_home_layout);
					}
				
				,URLencode:function(sStr){ return escape(sStr).replace(/\+/g, '%2B').replace(/\"/g,'%22').replace(/\'/g, '%27').replace(/\//g,'%2F');	},
				run_popReport:function(panel_name,rpt_format,rpt_number,width,height,formValues){var t_url = 'index.cfm?event=rpt.report.report.runReportPage';for(var i in formValues){t_url = t_url + '&'+ i + '='+URLencode(formValues[i]);}window.open (t_url) ;}	
								
				});
		
						
				page_sys_dyn_home_layout_main_page = Ext.extend(Ext.Panel,{
					paramList:null,
					loadCounter:null,
		
					constructor:function(_cfg){
							if(_cfg==null){_cfg=={};this.paramList={}}else{this.paramList = _cfg.paramList;};
							Ext.apply(this,_cfg);
						page_sys_dyn_home_layout_main_page.superclass.constructor.call(this,{
							border:false,
							autoScroll:false,	
							id:'page_sys_dyn_home_layout_main_page',
							anchor:'100% 100%',
							layout:'anchor',
							items:[
								
		
							{
								anchor:'100% 100%',flex:1,border:false,disabled:false,
								layout:"fit",
								panel_name:"grid_sys_dyn_home_layout",
								panel_type:"editorgridpanel",
								id:"grid_sys_dyn_home_layout_parentPanel",
								items:[new grid_sys_dyn_home_layout({paramList:this.paramList})]		
						}]
						})
					},
					listeners:{
						beforerender:function(_grid){
							var winObj = eval(Ext.getCmp(Ext.getCmp('page_sys_dyn_home_layout_main_page').paramList.win_id));
							if(typeof(winObj)!='undefined'){
								maskObj = new Ext.LoadMask(winObj.getEl(), {msg:getResource('loading','')});
								maskObj.show();
							}
						},
						render:function(_grid){
							Ext.getCmp('page_sys_dyn_home_layout_main_page').loadCounter=0;
		
									if(getAppPriv('grid_sys_dyn_home_layout','')){
										Ext.getCmp('page_sys_dyn_home_layout_main_page').loadCounter = Ext.getCmp('page_sys_dyn_home_layout_main_page').loadCounter+1;
									}
							
				if(Ext.getCmp('page_sys_dyn_home_layout_main_page').loadCounter==0){
					maskObj.hide();	
					Ext.getCmp('page_sys_dyn_home_layout_main_page').loadCounter=0;
				} 
		
							if(getAppPriv('grid_sys_dyn_home_layout','')){
					
							Ext.getCmp('grid_sys_dyn_home_layout').getStore().removeAll();
							var baseParams = Ext.getCmp('grid_sys_dyn_home_layout').getStore().baseParams;
							var paramList = Ext.getCmp('grid_sys_dyn_home_layout').paramList;
							Ext.apply(baseParams,paramList);
							baseParams.sql_where=' and 1=1';
							baseParams.currentPanel='grid_sys_dyn_home_layout';
							baseParams.panel_name='grid_sys_dyn_home_layout';
							baseParams.pname='grid_sys_dyn_home_layout';
							
								Ext.getCmp('grid_sys_dyn_home_layout').getStore().baseParams=baseParams;
									if(typeof(Ext.getCmp('grid_sys_dyn_home_layout_simplepanel_criteriadata_combo')) == 'undefined') {
							Ext.getCmp('grid_sys_dyn_home_layout').getStore().load();
										}else{
											Ext.getCmp('grid_sys_dyn_home_layout_simplepanel_criteriadata_combo').getStore().reload();
										}		
										Ext.getCmp('grid_sys_dyn_home_layout').getStore().on('load',function(){
												if(Ext.getCmp('page_sys_dyn_home_layout_main_page')){
												Ext.getCmp('page_sys_dyn_home_layout_main_page').loadCounter=Ext.getCmp('page_sys_dyn_home_layout_main_page').loadCounter-1;
												if(Ext.getCmp('page_sys_dyn_home_layout_main_page').loadCounter<=0){
													maskObj.hide();	
													Ext.getCmp('page_sys_dyn_home_layout_main_page').loadCounter=0;
												}
												}
										});
										
							
							}
					
						},
						afterrender:function(_grid){
		
					if(getAppPriv('grid_sys_dyn_home_layout','')==0){
				
						if(typeof(Ext.getCmp('grid_sys_dyn_home_layout'))!='undefined'){
							Ext.getCmp('grid_sys_dyn_home_layout').destroy();
							if(typeof(Ext.getCmp('grid_sys_dyn_home_layout_parentPanel'))!='undefined'){
								var parent = Ext.getCmp('grid_sys_dyn_home_layout_parentPanel').ownerCt;
								parent.remove(Ext.getCmp('grid_sys_dyn_home_layout_parentPanel'));
								parent.doLayout();
							}
						}
					}},
					destroy:function(){
		
					}		
				
					}
				})
		

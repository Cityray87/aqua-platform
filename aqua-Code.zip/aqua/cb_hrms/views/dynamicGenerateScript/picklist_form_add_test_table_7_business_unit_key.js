
			picklist_form_add_test_table_7_business_unit_key = Ext.extend(Ext.Window,{
				picklistTree:null,
				paramList:null,
				constructor:function(_cfg){
					if(_cfg==null){_cfg=={};this.paramList={}}else{this.paramList=_cfg.paramList;};
						if((this.paramList.sourcePage).toLowerCase()=="searchpanel"){
							if(typeof(Ext.getCmp("form_add_test_table_7"))!="undefined"){
								Ext.apply(this.paramList,Ext.getCmp("form_add_test_table_7").paramList);
							}
						}
						this.paramList.picklistPanel="form_add_test_table_7";
						this.paramList.field_name="business_unit_key";	
						this.paramList.sql_where=" and 1=1";
						Ext.apply(this,_cfg);	
					
					this.picklistTree = new Ext.ux.tree.FilterTreeGrid({
						id: "picklistTree_form_add_test_table_7_business_unit_key",
						width: 585,
						height: 568,
						enableDD: false,
						enableSort: false,
						cls:"picklistTree_cls",
						border: false,
						columns:[{
							header:getResource("title","PickListTree"),
							dataIndex: "text",
							width: 263
						}],
						loader: new Ext.tree.TreeLoader({
							url: "index.cfm?event=picklistTree.general.picklistTreeData&now=" + new Date(),
							baseParams:this.paramList
						}),
						listeners:{
							"click": this.onNodeClickEvent,
							"afterrender":function(){
								Ext.getCmp("picklistTree_form_add_test_table_7_business_unit_key").setWidth(Ext.getCmp("picklist_form_add_test_table_7_business_unit_key").getWidth()-14+_picklist_width_offset);
								Ext.getCmp("picklistTree_form_add_test_table_7_business_unit_key").setHeight(Ext.getCmp("picklist_form_add_test_table_7_business_unit_key").getHeight()-32-_picklist_height_offset);
		
							}
						}
					});
					picklist_form_add_test_table_7_business_unit_key.superclass.constructor.call(this,{
						constrainHeader:true,
						id:"picklist_form_add_test_table_7_business_unit_key",
						setZIndex:Ext.emptyFn,
						width:(600 > window.parent.document.body.clientWidth ? window.parent.document.body.clientWidth : 600),
						height:(600 > window.parent.document.body.clientHeight ? window.parent.document.body.clientHeight : 600),
						title: getResource("business_unit_key","form_add_test_table_7_picklist"),
						maximizable:false,
						resizable:true,
						modal:true,
						listeners:{
							resize:function(_w,_width,_height,_rawWidth,_rawHeight){
								Ext.getCmp("picklistTree_form_add_test_table_7_business_unit_key").setWidth(_width-14+_picklist_width_offset);
								Ext.getCmp("picklistTree_form_add_test_table_7_business_unit_key").setHeight(_height-32-_picklist_height_offset);
							},
							beforedestroy:function() {
								Ext.getCmp("picklistTree_form_add_test_table_7_business_unit_key").getSelectionModel().select = Ext.emptyFn;
							}
						},
						items:[this.picklistTree]
					})
				},
				onNodeClickEvent:function(node,e){
					var lookupbox = Ext.getCmp("form_add_test_table_7_business_unit_key_id");
					var paramList1 = Ext.getCmp("picklist_form_add_test_table_7_business_unit_key").paramList;
					var paramList = new Object();
					Ext.apply(paramList,paramList1);
					if((paramList.sourcePage).toLowerCase()=="searchpanel"){
						lookupbox = Ext.getCmp(paramList.cid);
					}
					var value = lookupbox.getValue();
					if(node.attributes.is_enable == "1"){
						if((paramList.sourcePage).toLowerCase()=="searchpanel"){
							if((paramList.needDelimiter)==1&&value!=""){
								lookupbox.setValue(Ext.util.Format.htmlDecode(lookupbox.getValue()+","+node.attributes.id));
							}else{
								lookupbox.setValue(Ext.util.Format.htmlDecode(node.attributes.id));
							}
							lookupbox.focus();
							lookupbox.fireEvent("keyUp");
						}else if((paramList.sourcePage).toLowerCase()=="formpanel"){
			
					value = Ext.getCmp("form_add_test_table_7_business_unit_key_id").getValue();
					if("" == ""||value==""){
						Ext.getCmp("form_add_test_table_7_business_unit_key_id").setValue(Ext.util.Format.htmlDecode(node.attributes.id));
					}else{
						Ext.getCmp("form_add_test_table_7_business_unit_key_id").setValue(Ext.util.Format.htmlDecode(value+""+node.attributes.id));
					}
				
				var flag = 1;		
				var paramList1 = Ext.getCmp("picklist_form_add_test_table_7_business_unit_key").paramList;
				var formValues = new Object();
				Ext.apply(formValues,paramList1);
			
					lookupbox.fireEvent("focus");
				}else if((paramList.sourcePage).toLowerCase()=="editgrid"){
					var myGrid,edi;
					if(typeof(paramList.editgrid_id)!="undefined"){
						myGrid = eval(Ext.getCmp(paramList.editgrid_id));
						myGrid.startEditing(paramList.editorrow,paramList.editorcol);
						editor =  myGrid.activeEditor;
			
					value = editor.getValue();
					if("" == ""||value==""){
						editor.setValue(Ext.util.Format.htmlDecode(node.attributes.id));
					}else{
						editor.setValue(Ext.util.Format.htmlDecode(value+""+node.attributes.id));
					}		
				
					}
				}
		
						if(paramList.sourcePage.toLowerCase()=="formpanel"){
							Ext.getCmp("form_add_test_table_7_form").form_add_test_table_7_setStyle();
						}
						Ext.getCmp("picklist_form_add_test_table_7_business_unit_key").close();
			
				}
				}
			});
		

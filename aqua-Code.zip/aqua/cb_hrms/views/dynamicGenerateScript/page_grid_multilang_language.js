
								
				grid_multilang_language = Ext.extend(Ext.grid.EditorGridPanel,{paramList:null,hideLoadingMask:null,
		grid_multilang_language_win:null,
					rowIndex:null,columnIndex:null,is_allow_edit:null,
					myJSON_grid_multilang_language:null,
					grid_multilang_language_rowdblclick:null,
					grid_multilang_language_globalVariable:null,
					constructor:function(_cfg){if(_cfg==null){_cfg=={};this.paramList={}}else{this.paramList=_cfg.paramList;};var grid_multilang_language_jsonParams = new Object();
						Ext.apply(grid_multilang_language_jsonParams,this.paramList);grid_multilang_language_jsonParams.sql_where=" and 1=1";this.hideLoadingMask = true;var grid_multilang_language_loadMask;
						this.is_allow_edit=1;
						this.grid_multilang_language_globalVariable=new Array();
		this.grid_multilang_language_rowdblclick=function(e){
					if(!this.getColumnModel().isCellEditable(this.columnIndex,this.rowIndex)||this.is_allow_edit==0)
					{if(!Ext.getCmp("event_edit_language_grid_multilang_language").disabled&&!Ext.getCmp("event_edit_language_grid_multilang_language").hidden)this.event_edit_language();}};
						this.grid_multilang_language_win = createAdvSearchPanel("grid_multilang_language","getResource('multi_lang','Language')");	
						this.myJSON_grid_multilang_language = new Ext.data.JsonStore({
							autoLoad : false,remoteSort : true,id:"myJSON_grid_multilang_language",baseParams:grid_multilang_language_jsonParams,
							root : "query.data",totalProperty : "totalcount",
							listeners:{beforeload:function(_store){
									var globalVariables_grid_multilang_language=new Object();
									_store.baseParams.panel_name="grid_multilang_language";_store.baseParams.currentPanel="grid_multilang_language";
									if(!Ext.getCmp("grid_multilang_language").hideLoadingMask && typeof(grid_multilang_language_loadMask)!="undefined") {
										grid_multilang_language_loadMask.show();
									}},load:function(_store){
										if(Ext.getCmp("grid_multilang_language")){
										Ext.getCmp("grid_multilang_language").setingEditorGridStyle(_store);
		
									Ext.getCmp("grid_multilang_language").hideLoadingMask = false;
									if(typeof(grid_multilang_language_loadMask) != "undefined") {grid_multilang_language_loadMask.hide();}
									if(_store.baseParams.sql_where != null){Ext.getCmp("grid_multilang_language").paramList.sql_where = _store.baseParams.sql_where;
									}else{Ext.getCmp("grid_multilang_language").paramList.sql_where = " and 1=1";}Ext.apply(Ext.getCmp("grid_multilang_language").paramList,_store.baseParams);
									}},exception:function(misc){
										if(grid_multilang_language_loadMask){
											grid_multilang_language_loadMask.hide();
										}
										if(Ext.getCmp("page_grid_multilang_language")){
											Ext.getCmp("page_grid_multilang_language").loadCounter = Ext.getCmp("page_grid_multilang_language").loadCounter - 1;
										}
										exceptionHandling("","P10002");
									}},
									 proxy: new Ext.data.HttpProxy({   
							              url:"index.cfm?event=dynamicEditGrid.editgrid.editgridData&datenow=" + new Date() + "&_rid=" + Math.random(),
							              timeout: ajaxTimeOut
							         }),
									fields:[
		"lang_id","lang","lang_name","is_active"]});var selectModel=new Ext.grid.RowSelectionModel({singleSelect: true});
						grid_multilang_language.superclass.constructor.call(this,{
							id:"grid_multilang_language",autoScroll:true,header:true,stripeRows:true,border:false,
							trackMouseOver:true,store:this.myJSON_grid_multilang_language,
				view : new Ext.ux.grid.LockingGridView({
					doRender : function(cs, rs, ds, startRow, colCount, stripe){
						var ts = this.templates, ct = ts.cell, rt = ts.row, last = colCount-1;
						var tstyle = "width:"+this.getTotalWidth()+";";
						var lstyle = "width:"+this.getLockedWidth()+";";
						var buf = [],lbuf = [], cb, lcb, c, p = {}, rp = {tstyle: tstyle}, r;
						for(var j = 0, len = rs.length; j < len; j++){
							r = rs[j]; cb = [];lcb = [];var rowIndex = (j+startRow);
							for(var i = 0; i < colCount; i++){c = cs[i];p.id = c.id;p.css = (i === 0 ? "x-grid3-cell-first " : (i == last ? "x-grid3-cell-last " : ""))+(this.cm.config[i].cellCls ? ""+ this.cm.config[i].cellCls : "");
								p.attr = p.cellAttr = "";p.value = c.renderer(r.data[c.name], p, r, rowIndex, i, ds);p.style = c.style;
		
								if(Ext.isEmpty(p.value)){p.value = " ";}if(this.markDirty && r.dirty && Ext.isDefined(r.modified[c.name])){p.css += " x-grid3-dirty-cell";}if(c.locked){lcb[lcb.length] = ct.apply(p);}else{cb[cb.length] = ct.apply(p);}
							}var alt = [];
							if(stripe && ((rowIndex+1) % 2 === 0)){alt[0] = "x-grid3-row-alt";}
							if(r.dirty){alt[1] = " x-grid3-dirty-row";}
							rp.cols = colCount;
							if(this.getRowClass){alt[2] = this.getRowClass(r, rowIndex, rp, ds);}
							rp.alt = alt.join(" ");rp.cells = cb.join("");rp.tstyle = tstyle;buf[buf.length] =  rt.apply(rp);rp.cells = lcb.join(" ");rp.tstyle = lstyle;lbuf[lbuf.length] = rt.apply(rp);}	return [buf.join(""), lbuf.join("")];	}}),
		title:getResource('multi_lang','Language'),sm:selectModel,
							tbar:[new Ext.Panel({
									height:23,	border:false,bodyStyle:"padding: 0px; background:#D3E1F1",width:500,
									cls:"sim_search_panel_tbar",
									listeners:{
										"render":function(searchPanel){
											Ext.Ajax.request({method:"post",url: "index.cfm?event=searchPanel.general.generateSimpleSearch&panel_name=grid_multilang_language&now=" + new Date() + "&_rid=" + Math.random(),
												failure: function(response,options){Ext.MessageBox.alert(getResource("failure","grid_multilang_language"),"failure");},
												success: function(response,options){try{var responseText = Ext.util.JSON.decode(response.responseText)
													var paramList = new Object();paramList.panel_name="grid_multilang_language";paramList.simple_search_field=responseText.success_msg;
													paramList.simple_search_operator=responseText.external_params_1;paramList.criFieldList=responseText.external_params_2;paramList.fieldDataList=responseText.external_params_3;	
													searchPanel.add(new SimpleSearchPanel(paramList));searchPanel.doLayout();}catch(e){
														if(grid_multilang_language_loadMask){
															grid_multilang_language_loadMask.hide();
														}
														if(Ext.getCmp("page_grid_multilang_language")){
															Ext.getCmp("page_grid_multilang_language").loadCounter = Ext.getCmp("page_grid_multilang_language").loadCounter - 1;
														}
														exceptionHandling(e,"P10003");
													}}});}}	
								}),"-",new Ext.Button({
									text:getResource("advanced_search","searchPanel"),
									icon:"../ext/resources/images/icons/zoom_in.png",
									cls:"adv_search_panel_btn",
									handler:function(){if(typeof(Ext.getCmp("grid_multilang_language_win"))!="undefined"){Ext.getCmp("grid_multilang_language_win").show();}}})
							
									//ss start
								,"-",
								new Ext.form.ComboBox({
									id:"grid_multilang_language_simplepanel_criteriadata_combo",
									width:120,
									forceSelection:true,
							        selectOnFocus:true,
							        typeAhead: true,
							        editable:false,
							        resizable:true,
									store: new Ext.data.JsonStore({
										autoLoad: false,
										remoteSort: true,
										root: "query.data",
										totalProperty: "totalcount",
										url: "index.cfm?event=searchPanel.general.criteriaDataOrderBy&panel_name=grid_multilang_language",
										fields: ["search_sql","description", "save_type", "default_search"],
										listeners: {
											load:function(store) {
												var private_default = "";
												var public_default = "";
												var str_public = getResource("save_type_public", "");
												for(var i=0;i<store.getCount(); i++) {
													store.getAt(i).set("description",Ext.util.Format.htmlDecode(store.getAt(i).get("description")));
													store.getAt(i).set("search_sql",Ext.util.Format.htmlDecode(store.getAt(i).get("search_sql")));
									        		if(store.getAt(i).get("save_type")=="public")	{
									        			store.getAt(i).set("description", store.getAt(i).get("description")+str_public);	
									        		}
									        		if(store.getAt(i).get("default_search")=="Y") {
									        			if(store.getAt(i).get("save_type")=="private")	{
									        				private_default = store.getAt(i).get("search_sql");
									        			}else if(store.getAt(i).get("save_type")=="public") {
									        				public_default = store.getAt(i).get("search_sql");
									        			}
									        		}			
								        		}
								        		var _sql = "";
								        		if(private_default == "") {
								        			if(public_default != "") {
								        				_sql =_sql + public_default;
								        			}
								        		}else {
								        			_sql =_sql + private_default;
								        		}
												//setValue start
								        		var counter = 0;
								        		for(var i=0;i<store.getCount();i++) {
								        			if(store.getAt(i).get("search_sql") == " ") {
								        				counter++;
								        			}
								        		}
								        		if(counter==0) {
								        			var _rs = new Ext.data.Record(["search_sql" , "description"]) ;
													_rs.set("search_sql" , " ") ;
													_rs.set("description" , getResource("show_all", "searchPanel")) ;
													store.insert(0,_rs);
								        		}
								        		var paramList = Ext.getCmp("grid_multilang_language").paramList;
								        		
								        		if(_sql == "") {
								        			_sql = " ";
								        		}
								        		_sql = Ext.util.Format.htmlDecode(_sql);
								        				
										        		Ext.getCmp("grid_multilang_language_simplepanel_criteriadata_combo").setValue(_sql);
										        		if(_sql.replace(/(^\s*)|(\s*$)/g, "") != "") {
										        			_sql = " && "+_sql;
										        		}
									        			Ext.getCmp("grid_multilang_language").store.setBaseParam("sql_where", " "+_sql);
									        			Ext.getCmp("grid_multilang_language").store.load();
									        		
											}
										}
									}),
							        displayField:"description",
							        valueField:"search_sql",
							        mode: "local",
							        forceSelection: true,
							        triggerAction: "all",
							        selectOnFocus:true,
							        listeners:{
							        	select:function(_combo, _record, _index) {
											var _ss_panel=Ext.getCmp("grid_multilang_language_simple_search_panel_id");
											_ss_panel.items.items[0].items.items[0].items.items[0].clearValue();
											_ss_panel.items.items[0].items.items[1].items.items[0].clearValue();
											var cf = new Ext.form.TextField({
												name: "value",
												anchor: "95%"
											});
											_ss_panel.items.items[0].items.items[2].remove(_ss_panel.items.items[0].items.items[2].items.items[0],true);
											_ss_panel.items.items[0].items.items[2].insert(0,cf);
											_ss_panel.items.items[0].items.items[2].render("grid_multilang_language_simple_search_panel_id");
											_ss_panel.items.items[0].items.items[2].doLayout();
											_ss_panel.render("grid_multilang_language_simple_search_panel_id");
											_ss_panel.doLayout();
							        		var _sql = " "+ _record.data.search_sql;
							        		_sql = Ext.util.Format.htmlDecode(_sql);
							        		if(_sql.replace(/(^\s*)|(\s*$)/g, "") != "") {
							        			_sql = " && "+_sql;
							        		}
											Ext.getCmp("grid_multilang_language").store.setBaseParam("sql_where", _sql);
											Ext.getCmp("grid_multilang_language").store.load();
							        	}
							       	}
								})
												],
							listeners:{
								"cellclick":function(grid,rowIndex,columnIndex,e){
									this.columnIndex=columnIndex;this.rowIndex=rowIndex;
								},
								"rowclick":function(_grid){
									var selectedRow = _grid.getSelectionModel().getSelections();
									if(selectedRow.length == 1){
							
								if(Ext.getCmp("grid_multilang_language_tbar_btn")){
									Ext.getCmp("grid_multilang_language_tbar_btn").doLayout();
								}
							}},"beforerender":function(){},"resize":function(){
				if(Ext.getCmp("grid_multilang_language_tbar_btn")){
					Ext.getCmp("grid_multilang_language_tbar_btn").doLayout();
				}
		},"render":function(_grid){grid_multilang_language_loadMask = new Ext.LoadMask(Ext.getCmp("grid_multilang_language").getEl(), {msg:getResource("loading","")});var tbar_grid_multilang_language = new Ext.Toolbar({enableOverflow : true,id:"grid_multilang_language_tbar_btn",items:[{ id:"event_add_language_grid_multilang_language",text:getResource('add_language','grid_multilang_language'),icon:"../ext/resources/images/icons/add.gif",handler:function(){this.event_add_language();},scope:this},{ id:"event_delete_language_grid_multilang_language",text:getResource('delete_language','grid_multilang_language'),icon:"../ext/resources/images/icons/delete.gif",handler:function(){this.event_delete_language();},scope:this},{ id:"event_edit_language_grid_multilang_language",text:getResource('edit_language','grid_multilang_language'),icon:"../ext/resources/images/icons/cog_edit.png",handler:function(){this.event_edit_language();},scope:this}]});tbar_grid_multilang_language.render(_grid.tbar);
				if(show_page_designer_shortcut == 1){
					var grid_multilang_language_pdBtn = dynmaicWebPageDesign("grid_multilang_language","grid_multilang_language");
					if(typeof(tbar_grid_multilang_language)!="undefined"){
						tbar_grid_multilang_language.add("->");
						tbar_grid_multilang_language.add(grid_multilang_language_pdBtn);
						tbar_grid_multilang_language.doLayout();
					}else{
						_grid.getTopToolbar().add("->");
						_grid.getTopToolbar().add(grid_multilang_language_pdBtn);
					}
					_grid.getTopToolbar().doLayout();
				}else{
					if(_grid.getTopToolbar().items.length==0){
						_grid.getTopToolbar().hide();
					}
				}
			if(getAppPriv('grid_multilang_language','add_language')==0){Ext.getCmp('event_add_language_grid_multilang_language').hide();}if(getAppPriv('grid_multilang_language','delete_language')==0){Ext.getCmp('event_delete_language_grid_multilang_language').hide();}if(getAppPriv('grid_multilang_language','edit_language')==0){Ext.getCmp('event_edit_language_grid_multilang_language').hide();}
				if(getAppPriv('grid_multilang_language','edit_language')==1){
					Ext.getCmp('grid_multilang_language').on('rowdblclick',Ext.getCmp('grid_multilang_language').grid_multilang_language_rowdblclick);
				}	
			
				if(typeof(tbar_grid_multilang_language)!="undefined"){
					tbar_grid_multilang_language.doLayout();
				}
			},"beforeedit":function(e){if(e.grid.is_allow_edit==0){
										e.grid.getColumnModel().setEditable(e.column,false);}else{var _value='';var flag;}if(typeof(e.record.data.allowedit) != 'undefined' && e.record.data.allowedit == 0){return false;}if(e.value){if(typeof(e.value)!= 'number' && typeof(e.value) != 'boolean'&& typeof(e.value) != 'object'){e.record.data[e.field]=e.value.replace(new RegExp('&lt;', 'g'),'<').replace(new RegExp('&gt;', 'g'),'>');}}}},bbar : new Ext.PagingToolbar({id:"grid_multilang_language_page_toolbar_id",
							displayInfo : true,pageSize : 20,store : this.myJSON_grid_multilang_language,dummy : true}),colModel:new Ext.ux.grid.LockingColumnModel([
					{header:getResource("lang_id","grid_multilang_language"),
						hidden:false,sortable:true,dataIndex:"lang_id"},
					{header:getResource("lang","grid_multilang_language"),
						hidden:false,sortable:true,dataIndex:"lang"},
					{header:getResource("lang_name","grid_multilang_language"),
						hidden:false,sortable:true,dataIndex:"lang_name"},
					{header:getResource("is_active","grid_multilang_language"),
						hidden:false,sortable:true,dataIndex:"is_active"}])})},listeners: {afteredit:function(e) {
									if(typeof(e.value)=="object"){
											if(e.value instanceof Date){
												Ext.getCmp("grid_multilang_language").store.getAt(e.row).data[e.field] = e.value.format("Y-m-d");
											}
									}
									var _store = Ext.getCmp("grid_multilang_language").store;
									Ext.getCmp("grid_multilang_language").setingEditorGridStyle(_store);
									Ext.getCmp("grid_multilang_language").getSelectionModel().selectRow(e.row);
								},columnmove : function(oldIndex,newIndex){if(Ext.getCmp("grid_multilang_language")){Ext.getCmp("grid_multilang_language").setingEditorGridStyle(Ext.getCmp("grid_multilang_language").store)}},afterrender:function(g){var valueList = "";if(valueList!=""){var dataIndexArray = new Array();dataIndexArray = valueList.split(",");initLockGridColumn(g,dataIndexArray);}}},setingEditorGridStyle:function(_store) {
						},
				event_add_language:function(e){
					globalVariables_grid_multilang_language=new Object();
					panelActionData_grid_multilang_language=new Array();
				
						dynamicGridPanelEvent(e,"grid_multilang_language","add_language",{panelActionDataArray:panelActionData_grid_multilang_language,winHeight:300,winWidth:600,isRequireGridRowSelection:"0",columnList:"lang_id,lang,lang_name,is_active",handlerType:"POPUP",isUseDynamicPanel:"0",isRequireConfirmation:"0",isRequireReloadGrid:"1",confirmMessage:"",predefinedValues:"",gridPanelName:"",saveType:"EDITGRID",isCloseWindowAfterAction:"1",isRequireSuccessTip:"1",isWorkFlowStart:"0",workflowProcessKey:"",wfTable:"",dynPageName:"add_multilang_language",actionHandlerEvent:"",isDestroyWin:"0",isNeedConfirmDirtyData:"0",titleI18nKey:"getResource('add_multilang','language')",afterSuccessJs:"",handlerJs:"",rptFormat:"",isHtmlXls:"0",rptNumber:"",rptPageType:"MAIN_PANEL",targetPanelName:"",targetPanelType:"",menuKey:"grid_multilang_language",menuId:"0"},globalVariables_grid_multilang_language);
					}
				,
				event_delete_language:function(e){
					globalVariables_grid_multilang_language=new Object();
					panelActionData_grid_multilang_language=new Array();
				
						dynamicGridPanelEvent(e,"grid_multilang_language","delete_language",{panelActionDataArray:panelActionData_grid_multilang_language,winHeight:0,winWidth:0,isRequireGridRowSelection:"1",columnList:"lang_id,lang,lang_name,is_active",handlerType:"BACKGROUND",isUseDynamicPanel:"0",isRequireConfirmation:"1",isRequireReloadGrid:"1",confirmMessage:"getResource('confirmDelete','language')",predefinedValues:"",gridPanelName:"",saveType:"EDITGRID",isCloseWindowAfterAction:"1",isRequireSuccessTip:"1",isWorkFlowStart:"0",workflowProcessKey:"",wfTable:"",dynPageName:"",actionHandlerEvent:"",isDestroyWin:"0",isNeedConfirmDirtyData:"0",titleI18nKey:"getResource('add_multilang','language')",afterSuccessJs:"",handlerJs:"",rptFormat:"",isHtmlXls:"0",rptNumber:"",rptPageType:"MAIN_PANEL",targetPanelName:"",targetPanelType:"",menuKey:"grid_multilang_language",menuId:"0"},globalVariables_grid_multilang_language);
					}
				,
				event_edit_language:function(e){
					globalVariables_grid_multilang_language=new Object();
					panelActionData_grid_multilang_language=new Array();
				
						dynamicGridPanelEvent(e,"grid_multilang_language","edit_language",{panelActionDataArray:panelActionData_grid_multilang_language,winHeight:600,winWidth:600,isRequireGridRowSelection:"1",columnList:"lang_id,lang,lang_name,is_active",handlerType:"POPUP",isUseDynamicPanel:"0",isRequireConfirmation:"0",isRequireReloadGrid:"1",confirmMessage:"getResource('confirmDelete','language')",predefinedValues:"",gridPanelName:"",saveType:"EDITGRID",isCloseWindowAfterAction:"1",isRequireSuccessTip:"1",isWorkFlowStart:"0",workflowProcessKey:"",wfTable:"",dynPageName:"edit_multilang_language",actionHandlerEvent:"",isDestroyWin:"0",isNeedConfirmDirtyData:"0",titleI18nKey:"getResource('edit_multilang','language')",afterSuccessJs:"",handlerJs:"",rptFormat:"",isHtmlXls:"0",rptNumber:"",rptPageType:"MAIN_PANEL",targetPanelName:"",targetPanelType:"",menuKey:"grid_multilang_language",menuId:"0"},globalVariables_grid_multilang_language);
					}
				
				,URLencode:function(sStr){ return escape(sStr).replace(/\+/g, '%2B').replace(/\"/g,'%22').replace(/\'/g, '%27').replace(/\//g,'%2F');	},
				run_popReport:function(panel_name,rpt_format,rpt_number,width,height,formValues){var t_url = 'index.cfm?event=rpt.report.report.runReportPage';for(var i in formValues){t_url = t_url + '&'+ i + '='+URLencode(formValues[i]);}window.open (t_url) ;}	
								
				});
		
						
				page_grid_multilang_language = Ext.extend(Ext.Panel,{
					paramList:null,
					loadCounter:null,
		
					constructor:function(_cfg){
							if(_cfg==null){_cfg=={};this.paramList={}}else{this.paramList = _cfg.paramList;};
							Ext.apply(this,_cfg);
						page_grid_multilang_language.superclass.constructor.call(this,{
							border:false,
							autoScroll:false,	
							id:'page_grid_multilang_language',
							anchor:'100% 100%',
							layout:'anchor',
							items:[
								
		
							{
								anchor:'100% 100%',border:false,
								layout:"fit",
								panel_name:"grid_multilang_language",
								panel_type:"editorgridpanel",
								id:"grid_multilang_language_parentPanel",
								items:[new grid_multilang_language({paramList:this.paramList})]		
						}]
						})
					},
					listeners:{
						beforerender:function(_grid){
							var winObj = eval(Ext.getCmp(Ext.getCmp('page_grid_multilang_language').paramList.win_id));
							if(typeof(winObj)!='undefined'){
								maskObj = new Ext.LoadMask(winObj.getEl(), {msg:getResource('loading','')});
								maskObj.show();
							}
						},
						render:function(_grid){
							Ext.getCmp('page_grid_multilang_language').loadCounter=0;
		
									if(getAppPriv('grid_multilang_language','')){
										Ext.getCmp('page_grid_multilang_language').loadCounter = Ext.getCmp('page_grid_multilang_language').loadCounter+1;
									}
							
				if(Ext.getCmp('page_grid_multilang_language').loadCounter==0){
					maskObj.hide();	
					Ext.getCmp('page_grid_multilang_language').loadCounter=0;
				} 
		
							if(getAppPriv('grid_multilang_language','')){
					
							Ext.getCmp('grid_multilang_language').getStore().removeAll();
							var baseParams = Ext.getCmp('grid_multilang_language').getStore().baseParams;
							var paramList = Ext.getCmp('grid_multilang_language').paramList;
							Ext.apply(baseParams,paramList);
							baseParams.sql_where=' and 1=1';
							baseParams.currentPanel='grid_multilang_language';
							baseParams.panel_name='grid_multilang_language';
							baseParams.pname='grid_multilang_language';
							
								Ext.getCmp('grid_multilang_language').getStore().baseParams=baseParams;
									if(typeof(Ext.getCmp('grid_multilang_language_simplepanel_criteriadata_combo')) == 'undefined') {
							Ext.getCmp('grid_multilang_language').getStore().load();
										}else{
											Ext.getCmp('grid_multilang_language_simplepanel_criteriadata_combo').getStore().reload();
										}		
										Ext.getCmp('grid_multilang_language').getStore().on('load',function(){
												if(Ext.getCmp('page_grid_multilang_language')){
												Ext.getCmp('page_grid_multilang_language').loadCounter=Ext.getCmp('page_grid_multilang_language').loadCounter-1;
												if(Ext.getCmp('page_grid_multilang_language').loadCounter<=0){
													maskObj.hide();	
													Ext.getCmp('page_grid_multilang_language').loadCounter=0;
												}
												}
										});
										
							
							}
					
						},
						afterrender:function(_grid){
		
					if(getAppPriv('grid_multilang_language','')==0){
				
						if(typeof(Ext.getCmp('grid_multilang_language'))!='undefined'){
							Ext.getCmp('grid_multilang_language').destroy();
							if(typeof(Ext.getCmp('grid_multilang_language_parentPanel'))!='undefined'){
								var parent = Ext.getCmp('grid_multilang_language_parentPanel').ownerCt;
								parent.remove(Ext.getCmp('grid_multilang_language_parentPanel'));
								parent.doLayout();
							}
						}
					}},
					destroy:function(){
		
					}		
				
					}
				})
		


								
				form_add_test_table_7 = Ext.extend(Ext.form.FormPanel,{
					paramList:null,
					form_add_test_table_7_globalVariable:null,
					constructor:function(_cfg){
						if(_cfg==null){_cfg=={};this.paramList={}}else{this.paramList=_cfg.paramList;};
						this.form_add_test_table_7_globalVariable=new Array();
		
					this.paramList.panel_name="form_add_test_table_7";
					form_add_test_table_7.superclass.constructor.call(this,{
						autoScroll:true,id:"form_add_test_table_7_form",
						labelAlign:"right",padding:10,
						labelWidth:100,fileUpload:true,enctype:"multipart/form-data",border:false,
						bodyBorder:false,anchor:"100% 100%",items:[
		{ xtype:'panel',layout:'form',border:false,items:[createPicklistCompoment("form_add_test_table_7","field1",{isVisibleRender:"1",picklistType:"TEXTFIELD",fieldI18nKey:getResource('field1','form_add_test_table_7'),fieldValue:"",comboboxKeyColumn:"",comboboxValueColumn:"",isNeedConfirmDirtyData:"0",editGridId:"",isNeedPicklistFilter:"0",isEditable:true,picklist_redirect_page:"",redirect_page_panel_list:"",redirect_page_title:"",redirect_page_height:"600",redirect_page_width:"800",edit_mode:"0",header_js:"",footer_js:""},this.form_add_test_table_7_globalVariable,"")]},{ xtype:'panel',layout:'form',border:false,items:[createPicklistCompoment("form_add_test_table_7","field2",{isVisibleRender:"1",picklistType:"NUMBERFIELD",fieldI18nKey:getResource('field2','form_add_test_table_7'),fieldValue:"",comboboxKeyColumn:"",comboboxValueColumn:"",isNeedConfirmDirtyData:"0",editGridId:"",isNeedPicklistFilter:"0",isEditable:true,picklist_redirect_page:"",redirect_page_panel_list:"",redirect_page_title:"",redirect_page_height:"600",redirect_page_width:"800",edit_mode:"0",header_js:"",footer_js:""},this.form_add_test_table_7_globalVariable,"")]},{ xtype:'panel',layout:'form',border:false,items:[{
					enableKeyEvents:true,
					name:'field3',id:'form_add_test_table_7_field3_id'
					,listeners:{},xtype:'datefield',format:web_platform_dateformat,fieldLabel:getResource('field3','form_add_test_table_7'),hiddenName:'field3'}]},{ xtype:'panel',layout:'form',border:false,items:[createPicklistCompoment("form_add_test_table_7","business_unit_id",{isVisibleRender:"1",picklistType:"NUMBERFIELD",fieldI18nKey:getResource('business_unit_id','form_add_test_table_7'),fieldValue:"",comboboxKeyColumn:"",comboboxValueColumn:"",isNeedConfirmDirtyData:"0",editGridId:"",isNeedPicklistFilter:"0",isEditable:true,picklist_redirect_page:"",redirect_page_panel_list:"",redirect_page_title:"",redirect_page_height:"600",redirect_page_width:"800",edit_mode:"0",header_js:"",footer_js:""},this.form_add_test_table_7_globalVariable,"")]}],tbar:new Ext.Toolbar({enableOverflow : true,id:'form_add_test_table_7_tbar_btn',items:[{ text:getResource('add_record','form_add_test_table_7'),icon:'../ext/resources/images/icons/add.gif',id:'form_add_test_table_7_form_add_test_table_7_add_record_id',scope:this,
								handler:function(){this.event_form_add_test_table_7_add_record();}}]}),listeners:{afterlayout:function(){},resize:function(){if(Ext.getCmp('form_add_test_table_7_tbar_btn')){Ext.getCmp('form_add_test_table_7_tbar_btn').doLayout()}},afterrender:function(){
					if(show_page_designer_shortcut == 1){
						var form_add_test_table_7_pdBtn = dynmaicWebPageDesign('test_table_first_popup_7','form_add_test_table_7');
						Ext.getCmp('form_add_test_table_7_form').getTopToolbar().add('->');
						Ext.getCmp('form_add_test_table_7_form').getTopToolbar().add(form_add_test_table_7_pdBtn);Ext.getCmp('form_add_test_table_7_form').getTopToolbar().doLayout();
					}else{
						if(Ext.getCmp('form_add_test_table_7_form').getTopToolbar().items.length==0){
							Ext.getCmp('form_add_test_table_7_form').getTopToolbar().hide();
						}
					}
				
						
						
			
						if(getAppPriv('form_add_test_table_7','form_add_test_table_7_add_record')==0){
							Ext.getCmp('form_add_test_table_7_form_add_test_table_7_add_record_id').hide();
						}
					},beforerender:function(){}}})},
						event_form_add_test_table_7_add_record:function(){
							var globalVariables_form_add_test_table_7=new Object();
							var panelActionData_form_add_test_table_7=new Array();
					
							dynamicFormPanelEvent("form_add_test_table_7","form_add_test_table_7_add_record",{panelActionDataArray:panelActionData_form_add_test_table_7,isRequireConfirmation:"0",confirmMessage:"",isRequireValidation:"0",predefinedValues:"",handlerType:"BACKGROUND",actionHandlerEvent:"",dynPageName:"",winWidth:"0",winHeight:"0",winTitleI18n:"",isNeedConfirmDirtyData:"0",gridPanelName:"",isRequireSuccessTip:"1",isCloseWindowAfterAction:"1",resetFormAfterSuccess:"0",isRequireReloadGrid:"1",afterSuccessJs:"",handlerJs:"",isWorkFlowStart:"0",workFlowProcessKey:"",wfTable:"",rptFormat:"",isHtmlXls:"0",rptNumber:"",rptPageType:"MAIN_PANEL",targetPanelName:"",targetPanelType:"",menuKey:"test_table_first_popup_7"},globalVariables_form_add_test_table_7);
						}	
					,form_add_test_table_7_setStyle:function() {
			try{
			var varStyleArray_form_add_test_table_7=new Array();
		
			}catch(e){
				exceptionHandling(e,'P10017');
			}
		
					},makeNode:function(name,value){
						var node = document.createElement("input");node.type="hidden";node.name=name;
						node.id=name;node.value=this.URLencode(value);return node;
					},
					insertWithin:function(nodeId, name,value) {
						var node = document.getElementById(nodeId);var newNode = this.makeNode(name,value);node.appendChild(newNode);	
					},
					URLencode:function(sStr) {
						return escape(sStr).replace(/\+/g, "%2B").replace(/\'/g,"%22").replace(/\"/g, "%27").replace(/\//g,"%2F");
					},					
					run_popReport:function(panel_name,rpt_format,rpt_number,width,height,formValues){
						var t_url = "index.cfm?event=rpt.report.report.runReportPage";
						for(var i in formValues){
							t_url = t_url + "&"+ i + "="+this.URLencode(formValues[i]);
						}window.open (t_url) ;
					},
					form_add_test_table_7_clientSideValidation:function(v_event_name){
						var validData = "";var error_msg = "";
						return formClientSideValidation("form_add_test_table_7",validData,v_event_name);
					}
					});
						
				page_test_table_first_popup_7 = Ext.extend(Ext.Panel,{
					paramList:null,
					loadCounter:null,
		
					constructor:function(_cfg){
							if(_cfg==null){_cfg=={};this.paramList={}}else{this.paramList = _cfg.paramList;};
							Ext.apply(this,_cfg);
						page_test_table_first_popup_7.superclass.constructor.call(this,{
							border:false,
							autoScroll:false,	
							id:'page_test_table_first_popup_7',
							anchor:'100% 100%',
							layout:'anchor',
							items:[
								
		
							{
								anchor:'100% 100%',border:false,
								layout:"fit",
								panel_name:"form_add_test_table_7",
								panel_type:"advformpanel",
								id:"form_add_test_table_7_parentPanel",
								items:[new form_add_test_table_7({paramList:this.paramList})]
						}]
						})
					},
					listeners:{
						beforerender:function(_grid){
							var winObj = eval(Ext.getCmp(Ext.getCmp('page_test_table_first_popup_7').paramList.win_id));
							if(typeof(winObj)!='undefined'){
								maskObj = new Ext.LoadMask(winObj.getEl(), {msg:getResource('loading','')});
								maskObj.show();
							}
						},
						render:function(_grid){
							Ext.getCmp('page_test_table_first_popup_7').loadCounter=0;
		
				if(Ext.getCmp('page_test_table_first_popup_7').loadCounter==0){
					maskObj.hide();	
					Ext.getCmp('page_test_table_first_popup_7').loadCounter=0;
				} 
		
									
						
											
						
							if(null!=maskObj&&maskObj!=undefined){
								if(Ext.getCmp('page_test_table_first_popup_7').loadCounter<=0){
									maskObj.hide();	
									Ext.getCmp('page_test_table_first_popup_7').loadCounter=0;
								}
							}	
						
						},
						afterrender:function(_grid){
		
					if(getAppPriv('form_add_test_table_7','')==0){
				
						if(typeof(Ext.getCmp('form_add_test_table_7_form'))!='undefined'){
							Ext.getCmp('form_add_test_table_7_form').destroy();
							if(typeof(Ext.getCmp('form_add_test_table_7_parentPanel'))!='undefined'){
								var parent = Ext.getCmp('form_add_test_table_7_parentPanel').ownerCt;
								parent.remove(Ext.getCmp('form_add_test_table_7_parentPanel'));
								parent.doLayout();
							}
						}
					}},
					destroy:function(){
		
					}		
				
					}
				})
		

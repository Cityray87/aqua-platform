
				picklist_gridpanel__dynamicPanelAdmin_dynamicPanel_ev_update_event = Ext.extend(Ext.Window,{
					operatorStore:null,
					picklist_search_store:null,
					filter_form:null,
					picklist_grid:null,
					paramList:null,
					hideLoadingMask:null,
					constructor:function(_cfg){
						if(_cfg==null){_cfg=={};this.paramList={}}else{this.paramList=_cfg.paramList;};
						if((this.paramList.sourcePage).toLowerCase()=='searchpanel'){
							if(typeof(Ext.getCmp('gridpanel__dynamicPanelAdmin_dynamicPanel'))!='undefined'){
								Ext.apply(this.paramList,Ext.getCmp('gridpanel__dynamicPanelAdmin_dynamicPanel').paramList);
							}
						}
						this.paramList.pname='gridpanel__dynamicPanelAdmin_dynamicPanel';
						this.paramList.fname='ev_update_event';	
						this.paramList.sql_where=' ';
						this.hideLoadingMask = true;
						var adv_grid_panel_gridpanel__dynamicPanelAdmin_dynamicPanel_ev_update_event_loadMask;	
					
						Ext.apply(this,_cfg);
				
						this.picklist_search_store = new Ext.data.JsonStore({
							remoteSort: true,
							root: 'query.data',
							autoLoad:'true',
							baseParams:this.paramList,
							totalProperty: 'totalcount',
							url: 'index.cfm?event=picklist.general.picklistData&date='+new Date(),
							listeners: {
								beforeload:function() {
									if(typeof(Ext.getCmp('adv_grid_panel_gridpanel__dynamicPanelAdmin_dynamicPanel_ev_update_event'))!='undefined') {
									if(!Ext.getCmp('adv_grid_panel_gridpanel__dynamicPanelAdmin_dynamicPanel_ev_update_event').hideLoadingMask && typeof(adv_grid_panel_gridpanel__dynamicPanelAdmin_dynamicPanel_ev_update_event_loadMask)!='undefined') {
										adv_grid_panel_gridpanel__dynamicPanelAdmin_dynamicPanel_ev_update_event_loadMask.show();
									}}
								},
								load:function() {
									if(typeof(Ext.getCmp('adv_grid_panel_gridpanel__dynamicPanelAdmin_dynamicPanel_ev_update_event'))!='undefined') {
									Ext.getCmp('adv_grid_panel_gridpanel__dynamicPanelAdmin_dynamicPanel_ev_update_event').hideLoadingMask = false;
									if(typeof(adv_grid_panel_gridpanel__dynamicPanelAdmin_dynamicPanel_ev_update_event_loadMask) != 'undefined') {
										adv_grid_panel_gridpanel__dynamicPanelAdmin_dynamicPanel_ev_update_event_loadMask.hide();
									}}	
								}
							},
							fields: [
		
					        			"event_desc"
					        	,
					        			"event_name"
					        	],
							dummy: true
						});
		
					this.filter_form = new Ext.form.FormPanel({
						frame:true,
						bodyBorder:false,
						buttonAlign:"left",
						id:"gridpanel__dynamicPanelAdmin_dynamicPanel_ev_update_event_picklistSerchForm",
						autoWidth:true,
						labelAlign:"left",
						border:false,
						labelWidth:90,
		
						buttons:[
		
				new Ext.Button({
						handler : function(){
							Ext.getCmp("picklist_gridpanel__dynamicPanelAdmin_dynamicPanel_ev_update_event").clearDestValue()	
						},
						id : "clearDestValue_gridpanel__dynamicPanelAdmin_dynamicPanel_ev_update_event",
						style : "margin-top:-5px",
						text : getResource("clearDestValue","searchPanel"),
						dummy : true
					}),
		
						new Ext.Button({
							handler : this.picklistRedirect,
							scope : this,
							id : "picklist_redirect_gridpanel__dynamicPanelAdmin_dynamicPanel_ev_update_event",
							style : "margin-top:-5px",
							text : getResource("picklist_redirect", "gridpanel__dynamicPanelAdmin_dynamicPanel"),
							dummy : true
						})	
						],
						listeners: {
							afterrender : function() {
								var privFlag = getPrivPicklistRedirect("");
								if(!privFlag){
									Ext.getCmp("picklist_redirect_gridpanel__dynamicPanelAdmin_dynamicPanel_ev_update_event").hide();
								}
		
							}
						}
					})
		
						this.picklist_grid = new Ext.grid.GridPanel({
							border : false,
							height : 300,
							id : 'adv_grid_panel_gridpanel__dynamicPanelAdmin_dynamicPanel_ev_update_event',
							store : this.picklist_search_store,
							stripeRows : true,	
							listeners : {
								rowclick:this.rowSelected,
								'render':function(){
									adv_grid_panel_gridpanel__dynamicPanelAdmin_dynamicPanel_ev_update_event_loadMask = new Ext.LoadMask(Ext.getCmp('adv_grid_panel_gridpanel__dynamicPanelAdmin_dynamicPanel_ev_update_event').getEl(), {msg:getResource('loading','')});
								},
								scope:this
							},
		
							columns:[
			
							{
			
									header:getResource("event_desc","gridpanel__dynamicPanelAdmin_dynamicPanel"),
				
									width:125,
				
									dataIndex : "event_desc",
									sortable:true
							}
			,
							{
			
									header:getResource("event_name","gridpanel__dynamicPanelAdmin_dynamicPanel"),
				
									width:300,
				
									dataIndex : "event_name",
									sortable:true
							}
			
							],
			
							bbar : new Ext.PagingToolbar({
								displayInfo : true,
								pageSize : 10,
								store : this.picklist_search_store,
								dummy : true
							})								
						})
							
						picklist_gridpanel__dynamicPanelAdmin_dynamicPanel_ev_update_event.superclass.constructor.call(this,{
							constrainHeader:true,
							id:'picklist_gridpanel__dynamicPanelAdmin_dynamicPanel_ev_update_event',
							manager:windows,
							width:(450 > window.parent.document.body.clientWidth ? window.parent.document.body.clientWidth : 450),
							height:(500 > window.parent.document.body.clientHeight ? window.parent.document.body.clientHeight : 500),
							title: getResource('ev_update_event','gridpanel__dynamicPanelAdmin_dynamicPanel_picklist'),
							maximizable:false,
							resizable:true,
							modal:true,
							items:[
		
							   this.filter_form,
		
							   this.picklist_grid
							],
							listeners:{
								afterrender:this.resizeContent,
								resize:this.resizeContent,
								scope:this
							}
						})
					},
					resizeContent:function(){
						if(Ext.getCmp("picklist_gridpanel__dynamicPanelAdmin_dynamicPanel_ev_update_event").filter_form != null){
							var formHeight = Ext.getCmp("picklist_gridpanel__dynamicPanelAdmin_dynamicPanel_ev_update_event").filter_form.getHeight();
							Ext.getCmp("picklist_gridpanel__dynamicPanelAdmin_dynamicPanel_ev_update_event").picklist_grid.setHeight(Ext.getCmp("picklist_gridpanel__dynamicPanelAdmin_dynamicPanel_ev_update_event").getHeight()-formHeight-29-_picklist_height_offset);
							Ext.getCmp("picklist_gridpanel__dynamicPanelAdmin_dynamicPanel_ev_update_event").picklist_grid.setWidth(Ext.getCmp("picklist_gridpanel__dynamicPanelAdmin_dynamicPanel_ev_update_event").getWidth()-14+_picklist_width_offset);
						}else{
							Ext.getCmp("picklist_gridpanel__dynamicPanelAdmin_dynamicPanel_ev_update_event").picklist_grid.setHeight(Ext.getCmp("picklist_gridpanel__dynamicPanelAdmin_dynamicPanel_ev_update_event").getHeight()-29-_picklist_height_offset);
							Ext.getCmp("picklist_gridpanel__dynamicPanelAdmin_dynamicPanel_ev_update_event").picklist_grid.setWidth(Ext.getCmp("picklist_gridpanel__dynamicPanelAdmin_dynamicPanel_ev_update_event").getWidth()-14+_picklist_width_offset);
						}
					},
					clearDestValue:function(){
		
				var paramList1 = Ext.getCmp("picklist_gridpanel__dynamicPanelAdmin_dynamicPanel_ev_update_event").paramList;
				var paramList = new Object();
				Ext.apply(paramList,paramList1);
		
					if((paramList.sourcePage).toLowerCase()=="searchpanel"){
						Ext.getCmp(paramList.cid).setValue("");
						Ext.getCmp(paramList.cid).fireEvent("keyUp");
					}else{
						Ext.getCmp("gridpanel__dynamicPanelAdmin_dynamicPanel_ev_update_event_id").setValue("");
						Ext.getCmp("gridpanel__dynamicPanelAdmin_dynamicPanel_ev_update_event_id").fireEvent("keyUp");
					}
						Ext.getCmp("picklist_gridpanel__dynamicPanelAdmin_dynamicPanel_ev_update_event").fireDynamicEvent("clear");
						
					},
					adv_search_event:function(){
						var sqlString = "";
						var valueField = "";
						var i=0;
						var operators="";
		
						Ext.getCmp("picklist_gridpanel__dynamicPanelAdmin_dynamicPanel_ev_update_event").picklist_search_store.baseParams.adv_search_where=sqlString;
						Ext.getCmp("picklist_gridpanel__dynamicPanelAdmin_dynamicPanel_ev_update_event").picklist_search_store.load();
					},
					rowSelected:function(){
						var lookupbox = Ext.getCmp("gridpanel__dynamicPanelAdmin_dynamicPanel_ev_update_event_id");
						var paramList1 = Ext.getCmp("picklist_gridpanel__dynamicPanelAdmin_dynamicPanel_ev_update_event").paramList;
						var paramList = new Object();
						Ext.apply(paramList,paramList1);
						if((paramList.sourcePage).toLowerCase()=="searchpanel"){
							lookupbox = Ext.getCmp(paramList.cid);
						}
						var value = lookupbox.getValue();
						if((paramList.sourcePage).toLowerCase()=="searchpanel"){
							if(paramList.needDelimiter==1 && value!=""){
								lookupbox.setValue(Ext.util.Format.htmlDecode(value+","+Ext.getCmp("adv_grid_panel_gridpanel__dynamicPanelAdmin_dynamicPanel_ev_update_event").getSelectionModel().getSelected().get("event_name")));	
							}else{
								lookupbox.setValue(Ext.util.Format.htmlDecode(Ext.getCmp("adv_grid_panel_gridpanel__dynamicPanelAdmin_dynamicPanel_ev_update_event").getSelectionModel().getSelected().get("event_name")));
							}
							lookupbox.focus();
							lookupbox.fireEvent("keyUp");
						}else if((paramList.sourcePage).toLowerCase()=="formpanel"){
		
						value = Ext.getCmp("gridpanel__dynamicPanelAdmin_dynamicPanel_ev_update_event_id").getValue();
						if("" == ""||value==""){
							Ext.getCmp("gridpanel__dynamicPanelAdmin_dynamicPanel_ev_update_event_id").setValue(Ext.util.Format.htmlDecode(Ext.getCmp("adv_grid_panel_gridpanel__dynamicPanelAdmin_dynamicPanel_ev_update_event").getSelectionModel().getSelected().get("event_name")));
						}else{
							Ext.getCmp("gridpanel__dynamicPanelAdmin_dynamicPanel_ev_update_event_id").setValue(Ext.util.Format.htmlDecode(value+""+Ext.getCmp("adv_grid_panel_gridpanel__dynamicPanelAdmin_dynamicPanel_ev_update_event").getSelectionModel().getSelected().get("event_name")));
						}
				
							lookupbox.fireEvent("focus");
							lookupbox.fireEvent("keyUp");	
						}else if((paramList.sourcePage).toLowerCase()=="editgrid"){
							var myGrid;
							var editor;
							if(typeof(paramList.editgrid_id)!="undefined"){
								myGrid = eval(Ext.getCmp(paramList.editgrid_id));
								myGrid.startEditing(paramList.editorrow,paramList.editorcol);
								editor =  myGrid.activeEditor;
							}
	    
									value = editor.getValue();
									if("" == ""||value==""){
										editor.setValue(Ext.util.Format.htmlDecode(Ext.getCmp("adv_grid_panel_gridpanel__dynamicPanelAdmin_dynamicPanel_ev_update_event").getSelectionModel().getSelected().get("event_name")));
									}else{
										editor.setValue(Ext.util.Format.htmlDecode(value+""+Ext.getCmp("adv_grid_panel_gridpanel__dynamicPanelAdmin_dynamicPanel_ev_update_event").getSelectionModel().getSelected().get("event_name")));
									}
		
							lookupbox.focus();
							lookupbox.fireEvent("keyUp");
						}
						Ext.getCmp("picklist_gridpanel__dynamicPanelAdmin_dynamicPanel_ev_update_event").fireDynamicEvent("rowclick");
				},
		
			fireDynamicEvent:function(eventFlag){
				var lookupbox = Ext.getCmp("gridpanel__dynamicPanelAdmin_dynamicPanel_ev_update_event_id");
				var paramList1 = Ext.getCmp("picklist_gridpanel__dynamicPanelAdmin_dynamicPanel_ev_update_event").paramList;
				var paramList = new Object();
				Ext.apply(paramList,paramList1);
		
						var flag = 1;
						var paramList1 = Ext.getCmp("picklist_gridpanel__dynamicPanelAdmin_dynamicPanel_ev_update_event").paramList;
						var formValues = new Object();
						Ext.apply(formValues,paramList1);
						if(paramList.sourcePage.toLowerCase()=="formpanel"&&typeof(Ext.getCmp("gridpanel__dynamicPanelAdmin_dynamicPanel_form").gridpanel__dynamicPanelAdmin_dynamicPanel_setStyle)!="undefined"){
							Ext.getCmp("gridpanel__dynamicPanelAdmin_dynamicPanel_form").gridpanel__dynamicPanelAdmin_dynamicPanel_setStyle();
						}
		
						if(eventFlag != "clear"){
						 	Ext.getCmp("picklist_gridpanel__dynamicPanelAdmin_dynamicPanel_ev_update_event").close();
						}
					},
					comRender:function(_combo){
						_combo.store.on("load",function(){
							_combo.setValue(_combo.store.getAt(0).get("pkey"));	
						})						
					},
					picklistRedirect :function(){
						createPicklistRedirect("gridpanel__dynamicPanelAdmin_dynamicPanel","ev_update_event","","","800","600",this.picklist_grid);
					}
				});
		

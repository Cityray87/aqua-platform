
								
				form_edit_sys_security_interceptor = Ext.extend(Ext.form.FormPanel,{
					paramList:null,
					form_edit_sys_security_interceptor_globalVariable:null,
					constructor:function(_cfg){
						if(_cfg==null){_cfg=={};this.paramList={}}else{this.paramList=_cfg.paramList;};
						this.form_edit_sys_security_interceptor_globalVariable=new Array();
		
					this.paramList.panel_name="form_edit_sys_security_interceptor";
					form_edit_sys_security_interceptor.superclass.constructor.call(this,{
						autoScroll:true,id:"form_edit_sys_security_interceptor_form",
						labelAlign:"right",padding:10,
						labelWidth:100,fileUpload:true,enctype:"multipart/form-data",border:false,
						bodyBorder:false,anchor:"100% 100%",items:[
		{ xtype:'panel',layout:'form',border:false,items:[{
					enableKeyEvents:true,
					name:'url_type',id:'form_edit_sys_security_interceptor_url_type_id'
					,xtype:'textfield',fieldLabel:getResource('url_type','form_edit_sys_security_interceptor'),hiddenName:'url_type',cls:'x-form-text-h',readOnly:true,width:350,style:{marginLeft:"0px",marginTop:"0px",marginRight:"0px",marginBottom:"0px"}}]},{ xtype:'panel',layout:'form',border:false,items:[{
					enableKeyEvents:true,
					name:'url',id:'form_edit_sys_security_interceptor_url_id'
					,listeners:{},xtype:'textarea',format:web_platform_dateformat,fieldLabel:getResource('url','form_edit_sys_security_interceptor'),hiddenName:'url', hideMode:'visibility',hidden:true,width:350,height:150,style:{marginLeft:"0px",marginTop:"0px",marginRight:"0px",marginBottom:"0px"},listeners:{render:function(){Ext.getCmp('form_edit_sys_security_interceptor_url_id').setVisible(false);Ext.getCmp('form_edit_sys_security_interceptor_form').doLayout();
											}}}]},{ xtype:'panel',layout:'form',border:false,items:[createPicklistCompoment("form_edit_sys_security_interceptor","exception_panel_name",{isVisibleRender:"1",picklistType:"TEXTFIELD",fieldI18nKey:getResource('exception_panel_name','form_edit_sys_security_interceptor'),fieldValue:"",comboboxKeyColumn:"",comboboxValueColumn:"",isNeedConfirmDirtyData:"0",editGridId:"",isNeedPicklistFilter:"0",isEditable:true,picklist_redirect_page:"",redirect_page_panel_list:"",redirect_page_title:"",redirect_page_height:"600",redirect_page_width:"800",edit_mode:"0",header_js:"",footer_js:""},this.form_edit_sys_security_interceptor_globalVariable,"width:350,style:{marginLeft:\"0px\",marginTop:\"0px\",marginRight:\"0px\",marginBottom:\"0px\"},hideMode:\'visibility\',hidden:true")]},{ xtype:'panel',layout:'form',border:false,items:[createPicklistCompoment("form_edit_sys_security_interceptor","exception_event_name",{isVisibleRender:"1",picklistType:"TEXTFIELD",fieldI18nKey:getResource('exception_event_name','form_edit_sys_security_interceptor'),fieldValue:"",comboboxKeyColumn:"",comboboxValueColumn:"",isNeedConfirmDirtyData:"0",editGridId:"",isNeedPicklistFilter:"0",isEditable:true,picklist_redirect_page:"",redirect_page_panel_list:"",redirect_page_title:"",redirect_page_height:"600",redirect_page_width:"800",edit_mode:"0",header_js:"",footer_js:""},this.form_edit_sys_security_interceptor_globalVariable,"width:350,style:{marginLeft:\"0px\",marginTop:\"0px\",marginRight:\"0px\",marginBottom:\"0px\"},hideMode:\'visibility\',hidden:true")]},{ xtype:'panel',layout:'form',border:false,items:[{
					enableKeyEvents:true,
					name:'is_active',id:'form_edit_sys_security_interceptor_is_active_id'
					,xtype:'checkbox',inputValue:'1',fieldLabel:getResource('is_active','form_edit_sys_security_interceptor'),hiddenName:'is_active',
							listeners:{
						
								check:function(check){
									if (this.readOnly === true) {
										this.el.dom.checked = this.originalValue;
										return false;
									}else{
										this.originalValue = this.el.dom.checked;
									}
						}	},width:150,style:{marginLeft:"0px",marginTop:"0px",marginRight:"0px",marginBottom:"0px"}}]},{ xtype:'panel',layout:'form',border:false,items:[{
					enableKeyEvents:true,
					name:'remark',id:'form_edit_sys_security_interceptor_remark_id'
					,listeners:{},xtype:'textarea',format:web_platform_dateformat,fieldLabel:getResource('remark','form_edit_sys_security_interceptor'),hiddenName:'remark',width:350,height:150,style:{marginLeft:"0px",marginTop:"0px",marginRight:"0px",marginBottom:"0px"}}]}],tbar:new Ext.Toolbar({enableOverflow : true,id:'form_edit_sys_security_interceptor_tbar_btn',items:[{ text:getResource('form_edit_sys_security_interceptor_edit_record','form_edit_sys_security_interceptor'),icon:'../ext/resources/images/icons/cog_edit.png',id:'form_edit_sys_security_interceptor_form_edit_sys_security_interceptor_edit_record_id',scope:this,
								handler:function(){this.event_form_edit_sys_security_interceptor_edit_record();}}]}),listeners:{afterlayout:function(){},resize:function(){if(Ext.getCmp('form_edit_sys_security_interceptor_tbar_btn')){Ext.getCmp('form_edit_sys_security_interceptor_tbar_btn').doLayout()}},afterrender:function(){
					if(show_page_designer_shortcut == 1){
						var form_edit_sys_security_interceptor_pdBtn = dynmaicWebPageDesign('sys_security_interceptor_second_popup','form_edit_sys_security_interceptor');
						Ext.getCmp('form_edit_sys_security_interceptor_form').getTopToolbar().add('->');
						Ext.getCmp('form_edit_sys_security_interceptor_form').getTopToolbar().add(form_edit_sys_security_interceptor_pdBtn);Ext.getCmp('form_edit_sys_security_interceptor_form').getTopToolbar().doLayout();
					}else{
						if(Ext.getCmp('form_edit_sys_security_interceptor_form').getTopToolbar().items.length==0){
							Ext.getCmp('form_edit_sys_security_interceptor_form').getTopToolbar().hide();
						}
					}
				
						
						
			
						if(getAppPriv('form_edit_sys_security_interceptor','form_edit_sys_security_interceptor_edit_record')==0){
							Ext.getCmp('form_edit_sys_security_interceptor_form_edit_sys_security_interceptor_edit_record_id').hide();
						}
					},beforerender:function(){}}})},
						event_form_edit_sys_security_interceptor_edit_record:function(){
							var globalVariables_form_edit_sys_security_interceptor=new Object();
							var panelActionData_form_edit_sys_security_interceptor=new Array();
					
							dynamicFormPanelEvent("form_edit_sys_security_interceptor","form_edit_sys_security_interceptor_edit_record",{panelActionDataArray:panelActionData_form_edit_sys_security_interceptor,isRequireConfirmation:"0",confirmMessage:"getResource('form_edit_sys_security_interceptor_edit_record','form_edit_sys_security_interceptor')",isRequireValidation:"1",predefinedValues:"",handlerType:"BACKGROUND",actionHandlerEvent:"",dynPageName:"",winWidth:"0",winHeight:"0",winTitleI18n:"",isNeedConfirmDirtyData:"0",gridPanelName:"",isRequireSuccessTip:"1",isCloseWindowAfterAction:"1",resetFormAfterSuccess:"0",isRequireReloadGrid:"1",afterSuccessJs:"",handlerJs:"",isWorkFlowStart:"0",workFlowProcessKey:"",wfTable:"",rptFormat:"",isHtmlXls:"0",rptNumber:"",rptPageType:"MAIN_PANEL",targetPanelName:"",targetPanelType:"",menuKey:"sys_security_interceptor_second_popup"},globalVariables_form_edit_sys_security_interceptor);
						}	
					,form_edit_sys_security_interceptor_setStyle:function() {
			try{
			var varStyleArray_form_edit_sys_security_interceptor=new Array();
		
			}catch(e){
				exceptionHandling(e,'P10017');
			}
		
					},makeNode:function(name,value){
						var node = document.createElement("input");node.type="hidden";node.name=name;
						node.id=name;node.value=this.URLencode(value);return node;
					},
					insertWithin:function(nodeId, name,value) {
						var node = document.getElementById(nodeId);var newNode = this.makeNode(name,value);node.appendChild(newNode);	
					},
					URLencode:function(sStr) {
						return escape(sStr).replace(/\+/g, "%2B").replace(/\'/g,"%22").replace(/\"/g, "%27").replace(/\//g,"%2F");
					},					
					run_popReport:function(panel_name,rpt_format,rpt_number,width,height,formValues){
						var t_url = "index.cfm?event=rpt.report.report.runReportPage";
						for(var i in formValues){
							t_url = t_url + "&"+ i + "="+this.URLencode(formValues[i]);
						}window.open (t_url) ;
					},
					form_edit_sys_security_interceptor_clientSideValidation:function(v_event_name){
						var validData = "";var error_msg = "";
						return formClientSideValidation("form_edit_sys_security_interceptor",validData,v_event_name);
					}
					});
						
				page_sys_security_interceptor_second_popup = Ext.extend(Ext.Panel,{
					paramList:null,
					loadCounter:null,
		
							form_edit_sys_security_interceptor_loadFormData:function(){
								var paramList = Ext.getCmp('form_edit_sys_security_interceptor_form').paramList;
							
								paramList.panel_name='form_edit_sys_security_interceptor';
								var action = arguments[0];
								Ext.Ajax.request({
					           		url:'index.cfm?event=dynamicGenerateScript.dynamicGenerateScript.dynamicGetAdvFormData&_dc='+new Date() + '&_rid=' + Math.random(),
					                method:'POST',
					                timeout : ajaxTimeOut,
					                params:paramList,
					                failure:function(response,options){
										if(Ext.getCmp('page_sys_security_interceptor_second_popup')){
											Ext.getCmp('page_sys_security_interceptor_second_popup').loadCounter = Ext.getCmp('page_sys_security_interceptor_second_popup').loadCounter - 1;
										}
										if(typeof(Ext.getCmp('form_edit_sys_security_interceptor_form'))!='undefined'){
											exceptionHandling('','P10013');
										}
					                },
					                success:function(response,options){
					                   if(typeof(Ext.getCmp('form_edit_sys_security_interceptor_form'))!='undefined'){
					                   try{
								           var responseText = Ext.util.JSON.decode(response.responseText).jsonObject;
								           var controlTypeList = Ext.util.JSON.decode(response.responseText).success_msg;
								           loadFormData('form_edit_sys_security_interceptor',action,responseText,controlTypeList);
						 			   Ext.getCmp('form_edit_sys_security_interceptor_form').form_edit_sys_security_interceptor_setStyle();
						 
							  		addPicklistFilterEvent('form_edit_sys_security_interceptor','',2);
						 	  
										if(null!=maskObj&&maskObj!=undefined){
											Ext.getCmp('page_sys_security_interceptor_second_popup').loadCounter=Ext.getCmp('page_sys_security_interceptor_second_popup').loadCounter-1;
											if(Ext.getCmp('page_sys_security_interceptor_second_popup').loadCounter<=0){
												maskObj.hide();	
												Ext.getCmp('page_sys_security_interceptor_second_popup').loadCounter=0;
											}
										}
										var globalVariables_form_edit_sys_security_interceptor=new Object();
										
										}catch(e){
					                       if(Ext.getCmp('page_sys_security_interceptor_second_popup')){
												Ext.getCmp('page_sys_security_interceptor_second_popup').loadCounter = Ext.getCmp('page_sys_security_interceptor_second_popup').loadCounter - 1;
										   }
										   exceptionHandling(e,'P10015');
					     			   }
					     			}
							 		}
						  		});
						  	},
					  	
					constructor:function(_cfg){
							if(_cfg==null){_cfg=={};this.paramList={}}else{this.paramList = _cfg.paramList;};
							Ext.apply(this,_cfg);
						page_sys_security_interceptor_second_popup.superclass.constructor.call(this,{
							border:false,
							autoScroll:false,	
							id:'page_sys_security_interceptor_second_popup',
							anchor:'100% 100%',
							layout:'anchor',
							items:[
								
		
							{
								anchor:'100% 100%',border:false,
								layout:"fit",
								panel_name:"form_edit_sys_security_interceptor",
								panel_type:"advformpanel",
								id:"form_edit_sys_security_interceptor_parentPanel",
								items:[new form_edit_sys_security_interceptor({paramList:this.paramList})]
						}]
						})
					},
					listeners:{
						beforerender:function(_grid){
							var winObj = eval(Ext.getCmp(Ext.getCmp('page_sys_security_interceptor_second_popup').paramList.win_id));
							if(typeof(winObj)!='undefined'){
								maskObj = new Ext.LoadMask(winObj.getEl(), {msg:getResource('loading','')});
								maskObj.show();
							}
						},
						render:function(_grid){
							Ext.getCmp('page_sys_security_interceptor_second_popup').loadCounter=0;
		
								if(getAppPriv('form_edit_sys_security_interceptor','')){
									Ext.getCmp('page_sys_security_interceptor_second_popup').loadCounter = Ext.getCmp('page_sys_security_interceptor_second_popup').loadCounter+1;
								}
							
				if(Ext.getCmp('page_sys_security_interceptor_second_popup').loadCounter==0){
					maskObj.hide();	
					Ext.getCmp('page_sys_security_interceptor_second_popup').loadCounter=0;
				} 
		
							if(getAppPriv('form_edit_sys_security_interceptor','')){
								Ext.getCmp('form_edit_sys_security_interceptor_form').getForm().reset();
								var baseParams = new Object();
								var paramList = Ext.getCmp('form_edit_sys_security_interceptor_form').paramList;
								Ext.apply(baseParams,paramList);
								baseParams.panel_name='form_edit_sys_security_interceptor';
								baseParams.currentPanel='form_edit_sys_security_interceptor';
								baseParams.pname='form_edit_sys_security_interceptor';
								Ext.Ajax.request({
									params:baseParams,
									method: 'POST',
									timeout:ajaxTimeOut,
									url: 'index.cfm?event=dynamicGenerateScript.dynamicGenerateScript.dynamicGetPanelComboData&datenow=' + new Date() + '&_rid=' + Math.random(),
									failure: function(response,options){
									   if(!Ext.Msg.isVisible()){
										   if (maskObj) {
										       maskObj.hide();
					                       }
					                       if(Ext.getCmp('page_sys_security_interceptor_second_popup')){
												Ext.getCmp('page_sys_security_interceptor_second_popup').loadCounter = Ext.getCmp('page_sys_security_interceptor_second_popup').loadCounter - 1;
										   }
										   if(typeof(Ext.getCmp('form_edit_sys_security_interceptor_form'))!='undefined'){
						                       Ext.Msg.show({
												   title : getResource('warning', ''),
												   msg : getResource('requestException', ''),
												   buttons : Ext.Msg.OK,
												   icon : Ext.MessageBox.WARNING
								               });
							               }
							           }
									},
									success: function(response,options){
										if(typeof(Ext.getCmp('form_edit_sys_security_interceptor_form'))!='undefined'){
										try {
										var responseText = Ext.util.JSON.decode(response.responseText);
										//Ext.MessageBox.hide();
						
									Ext.getCmp("form_edit_sys_security_interceptor_url_type_id").getStore().loadData(responseText.jsonObject.url_type);
								
								   	    Ext.getCmp('page_sys_security_interceptor_second_popup').form_edit_sys_security_interceptor_loadFormData();
							
										
				var actionFlag=1;
				var flag = 1;
				var varArray_form_edit_sys_security_interceptor=new Array();
			
							if(Ext.getCmp("form_edit_sys_security_interceptor_url_type_id")){
								Ext.getCmp("form_edit_sys_security_interceptor_url_type_id").on("select",function(){
									flag=1;
									dynamicDefaultDetail("form_edit_sys_security_interceptor","0","url_type","1","url",varArray_form_edit_sys_security_interceptor);	
								})
								Ext.getCmp("form_edit_sys_security_interceptor_url_type_id").on("change",function(){
									if(flag == 1){
										flag=0;
										return;
									}
									dynamicDefaultDetail("form_edit_sys_security_interceptor","0","url_type","1","url",varArray_form_edit_sys_security_interceptor);	
								})
							}	
						
										
										} catch (e) {
											if(Ext.getCmp('page_sys_security_interceptor_second_popup')){
												Ext.getCmp('page_sys_security_interceptor_second_popup').loadCounter = Ext.getCmp('page_sys_security_interceptor_second_popup').loadCounter - 1;
											}
											exceptionHandling(e,'P10016');
										}
										}
									 }
								});
							}
						
						},
						afterrender:function(_grid){
		
					if(getAppPriv('form_edit_sys_security_interceptor','')==0){
				
						if(typeof(Ext.getCmp('form_edit_sys_security_interceptor_form'))!='undefined'){
							Ext.getCmp('form_edit_sys_security_interceptor_form').destroy();
							if(typeof(Ext.getCmp('form_edit_sys_security_interceptor_parentPanel'))!='undefined'){
								var parent = Ext.getCmp('form_edit_sys_security_interceptor_parentPanel').ownerCt;
								parent.remove(Ext.getCmp('form_edit_sys_security_interceptor_parentPanel'));
								parent.doLayout();
							}
						}
					}},
					destroy:function(){
		
					}		
				
					}
				})
		

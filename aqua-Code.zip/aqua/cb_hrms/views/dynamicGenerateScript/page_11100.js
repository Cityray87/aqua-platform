
				page_11100 = Ext.extend(Ext.Panel,{
					paramList:null,
					loadCounter:null,
		
					constructor:function(_cfg){
							if(_cfg==null){_cfg=={};this.paramList={}}else{this.paramList = _cfg.paramList;};
							Ext.apply(this,_cfg);
						page_11100.superclass.constructor.call(this,{
							border:false,
							autoScroll:false,	
							id:'page_11100',
							anchor:'100% 100%',
							layout:'anchor',
							items:[
								
		},},}]
						})
					},
					listeners:{
						beforerender:function(_grid){
							var winObj = eval(Ext.getCmp(Ext.getCmp('page_11100').paramList.win_id));
							if(typeof(winObj)!='undefined'){
								maskObj = new Ext.LoadMask(winObj.getEl(), {msg:getResource('loading','')});
								maskObj.show();
							}
						},
						render:function(_grid){
							Ext.getCmp('page_11100').loadCounter=0;
		
				if(Ext.getCmp('page_11100').loadCounter==0){
					maskObj.hide();	
					Ext.getCmp('page_11100').loadCounter=0;
				} 
		
						},
						afterrender:function(_grid){
		
					if(getAppPriv('gridpanel__system_security_securityColSet_securityColSetData','')==0){
				}
					if(getAppPriv('gridpanel__system_security_securityColAccess_securityColAccessData','')==0){
				}
					if(getAppPriv('gridpanel__system_security_roleData','')==0){
				}},
					destroy:function(){
		
					}		
				
					}
				})
		

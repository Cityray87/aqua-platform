
								
				add_user_role_2 = Ext.extend(Ext.form.FormPanel,{
					paramList:null,
					add_user_role_2_globalVariable:null,
					constructor:function(_cfg){
						if(_cfg==null){_cfg=={};this.paramList={}}else{this.paramList=_cfg.paramList;};
						this.add_user_role_2_globalVariable=new Array();
		
					this.paramList.panel_name="add_user_role_2";
					add_user_role_2.superclass.constructor.call(this,{
						autoScroll:true,id:"add_user_role_2_form",
						labelAlign:"right",padding:10,
						labelWidth:100,fileUpload:true,enctype:"multipart/form-data",border:false,
						bodyBorder:false,anchor:"100% 100%",items:[
		{ xtype:'panel',layout:'form',border:false,items:[createPicklistCompoment("add_user_role_2","role_name",{isVisibleRender:"1",picklistType:"POPUP",fieldI18nKey:getResource('role_name','add_user_role'),fieldValue:"",comboboxKeyColumn:"",comboboxValueColumn:"",isNeedConfirmDirtyData:"0",editGridId:"",isNeedPicklistFilter:"0",isEditable:true,picklist_redirect_page:"",redirect_page_panel_list:"",redirect_page_title:"",redirect_page_height:"600",redirect_page_width:"800",edit_mode:"0",header_js:"",footer_js:""},this.add_user_role_2_globalVariable,"width:150,editable:false,style:{marginLeft:\"0px\",marginTop:\"0px\",marginRight:\"0px\",marginBottom:\"0px\"}")]},{ xtype:'panel',layout:'form',border:false,items:[{
					enableKeyEvents:true,
					name:'is_default_role',id:'add_user_role_2_is_default_role_id'
					,xtype:'checkbox',inputValue:'1',fieldLabel:getResource('is_default_role','add_user_role'),hiddenName:'is_default_role',
							listeners:{
						
								check:function(check){
									if (this.readOnly === true) {
										this.el.dom.checked = this.originalValue;
										return false;
									}else{
										this.originalValue = this.el.dom.checked;
									}
						}	},width:150,style:{marginLeft:"0px",marginTop:"0px",marginRight:"0px",marginBottom:"0px"}}]},{ xtype:'panel',layout:'form',border:false,items:[{
					enableKeyEvents:true,
					name:'user_name',id:'add_user_role_2_user_name_id'
					,xtype:'hidden',hiddenName:'user_name',width:150}]}],tbar:new Ext.Toolbar({enableOverflow : true,id:'add_user_role_2_tbar_btn',items:[{ text:getResource('save_new_user_role','add_user_role'),icon:'../ext/resources/images/icons/save.gif',id:'add_user_role_2_save_new_user_role_2_id',scope:this,
								handler:function(){this.event_save_new_user_role_2();}}]}),listeners:{afterlayout:function(){},resize:function(){if(Ext.getCmp('add_user_role_2_tbar_btn')){Ext.getCmp('add_user_role_2_tbar_btn').doLayout()}},afterrender:function(){
					if(show_page_designer_shortcut == 1){
						var add_user_role_2_pdBtn = dynmaicWebPageDesign('add_user_role_2','add_user_role_2');
						Ext.getCmp('add_user_role_2_form').getTopToolbar().add('->');
						Ext.getCmp('add_user_role_2_form').getTopToolbar().add(add_user_role_2_pdBtn);Ext.getCmp('add_user_role_2_form').getTopToolbar().doLayout();
					}else{
						if(Ext.getCmp('add_user_role_2_form').getTopToolbar().items.length==0){
							Ext.getCmp('add_user_role_2_form').getTopToolbar().hide();
						}
					}
				
						
						
			
						if(getAppPriv('add_user_role_2','save_new_user_role_2')==0){
							Ext.getCmp('add_user_role_2_save_new_user_role_2_id').hide();
						}
					},beforerender:function(){}}})},
						event_save_new_user_role_2:function(){
							var globalVariables_add_user_role_2=new Object();
							var panelActionData_add_user_role_2=new Array();
					
							dynamicFormPanelEvent("add_user_role_2","save_new_user_role_2",{panelActionDataArray:panelActionData_add_user_role_2,isRequireConfirmation:"0",confirmMessage:"",isRequireValidation:"1",predefinedValues:"",handlerType:"BACKGROUND",actionHandlerEvent:"",dynPageName:"",winWidth:"0",winHeight:"0",winTitleI18n:"",isNeedConfirmDirtyData:"0",gridPanelName:"",isRequireSuccessTip:"1",isCloseWindowAfterAction:"1",resetFormAfterSuccess:"0",isRequireReloadGrid:"1",afterSuccessJs:"",handlerJs:"",isWorkFlowStart:"0",workFlowProcessKey:"",wfTable:"",rptFormat:"",isHtmlXls:"0",rptNumber:"",rptPageType:"MAIN_PANEL",targetPanelName:"",targetPanelType:"",menuKey:"add_user_role_2"},globalVariables_add_user_role_2);
						}	
					,add_user_role_2_setStyle:function() {
			try{
			var varStyleArray_add_user_role_2=new Array();
		
			}catch(e){
				exceptionHandling(e,'P10017');
			}
		
					},makeNode:function(name,value){
						var node = document.createElement("input");node.type="hidden";node.name=name;
						node.id=name;node.value=this.URLencode(value);return node;
					},
					insertWithin:function(nodeId, name,value) {
						var node = document.getElementById(nodeId);var newNode = this.makeNode(name,value);node.appendChild(newNode);	
					},
					URLencode:function(sStr) {
						return escape(sStr).replace(/\+/g, "%2B").replace(/\'/g,"%22").replace(/\"/g, "%27").replace(/\//g,"%2F");
					},					
					run_popReport:function(panel_name,rpt_format,rpt_number,width,height,formValues){
						var t_url = "index.cfm?event=rpt.report.report.runReportPage";
						for(var i in formValues){
							t_url = t_url + "&"+ i + "="+this.URLencode(formValues[i]);
						}window.open (t_url) ;
					},
					add_user_role_2_clientSideValidation:function(v_event_name){
						var validData = "{[],[role_name],[if('this.role_name'==''||'this.role_name'==null) return false; return true;],[getResource('role_name_null','add_user_role_2')],[getResource('role_name_null','add_user_role_2')]}";var error_msg = "";
						return formClientSideValidation("add_user_role_2",validData,v_event_name);
					}
					});
						
				page_add_user_role_2 = Ext.extend(Ext.Panel,{
					paramList:null,
					loadCounter:null,
		
					constructor:function(_cfg){
							if(_cfg==null){_cfg=={};this.paramList={}}else{this.paramList = _cfg.paramList;};
							Ext.apply(this,_cfg);
						page_add_user_role_2.superclass.constructor.call(this,{
							border:false,
							autoScroll:false,	
							id:'page_add_user_role_2',
							anchor:'100% 100%',
							layout:'anchor',
							items:[
								
		
							{
								anchor:'100% 100%',border:false,
								layout:"fit",
								panel_name:"add_user_role_2",
								panel_type:"advformpanel",
								id:"add_user_role_2_parentPanel",
								items:[new add_user_role_2({paramList:this.paramList})]
						}]
						})
					},
					listeners:{
						beforerender:function(_grid){
							var winObj = eval(Ext.getCmp(Ext.getCmp('page_add_user_role_2').paramList.win_id));
							if(typeof(winObj)!='undefined'){
								maskObj = new Ext.LoadMask(winObj.getEl(), {msg:getResource('loading','')});
								maskObj.show();
							}
						},
						render:function(_grid){
							Ext.getCmp('page_add_user_role_2').loadCounter=0;
		
				if(Ext.getCmp('page_add_user_role_2').loadCounter==0){
					maskObj.hide();	
					Ext.getCmp('page_add_user_role_2').loadCounter=0;
				} 
		
									
						
											
						
							if(null!=maskObj&&maskObj!=undefined){
								if(Ext.getCmp('page_add_user_role_2').loadCounter<=0){
									maskObj.hide();	
									Ext.getCmp('page_add_user_role_2').loadCounter=0;
								}
							}	
						
						 			   try{
						 			   		Ext.getCmp('add_user_role_2_user_name_id').setValue(Ext.getCmp("form_add_sys_user_user_name_id").getValue());
						 			   }catch(e){
						 			   		exceptionHandling(e,'P10014');	
						 			   }
							 
						},
						afterrender:function(_grid){
		
					if(getAppPriv('add_user_role_2','')==0){
				
						if(typeof(Ext.getCmp('add_user_role_2_form'))!='undefined'){
							Ext.getCmp('add_user_role_2_form').destroy();
							if(typeof(Ext.getCmp('add_user_role_2_parentPanel'))!='undefined'){
								var parent = Ext.getCmp('add_user_role_2_parentPanel').ownerCt;
								parent.remove(Ext.getCmp('add_user_role_2_parentPanel'));
								parent.doLayout();
							}
						}
					}},
					destroy:function(){
		
					}		
				
					}
				})
		


				page_11300 = Ext.extend(Ext.Panel,{
					paramList:null,
					loadCounter:null,
		
					constructor:function(_cfg){
							if(_cfg==null){_cfg=={};this.paramList={}}else{this.paramList = _cfg.paramList;};
							Ext.apply(this,_cfg);
						page_11300.superclass.constructor.call(this,{
							border:false,
							autoScroll:false,	
							id:'page_11300',
							anchor:'100% 100%',
							layout:'anchor',
							items:[
								
		}]
						})
					},
					listeners:{
						beforerender:function(_grid){
							var winObj = eval(Ext.getCmp(Ext.getCmp('page_11300').paramList.win_id));
							if(typeof(winObj)!='undefined'){
								maskObj = new Ext.LoadMask(winObj.getEl(), {msg:getResource('loading','')});
								maskObj.show();
							}
						},
						render:function(_grid){
							Ext.getCmp('page_11300').loadCounter=0;
		
				if(Ext.getCmp('page_11300').loadCounter==0){
					maskObj.hide();	
					Ext.getCmp('page_11300').loadCounter=0;
				} 
		
						},
						afterrender:function(_grid){
		
					if(getAppPriv('frmpanel__system_security_superuser_editSuperuser','')==0){
				}},
					destroy:function(){
		
					}		
				
					}
				})
		

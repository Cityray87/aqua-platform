
								
				form_add_sys_agent = Ext.extend(Ext.form.FormPanel,{
					paramList:null,
					form_add_sys_agent_globalVariable:null,
					constructor:function(_cfg){
						if(_cfg==null){_cfg=={};this.paramList={}}else{this.paramList=_cfg.paramList;};
						this.form_add_sys_agent_globalVariable=new Array();
		
					this.paramList.panel_name="form_add_sys_agent";
					form_add_sys_agent.superclass.constructor.call(this,{
						autoScroll:true,id:"form_add_sys_agent_form",
						labelAlign:"right",padding:10,
						labelWidth:100,fileUpload:true,enctype:"multipart/form-data",border:false,
						bodyBorder:false,anchor:"100% 100%",items:[
		{ xtype:'panel',layout:'form',border:false,items:[createPicklistCompoment("form_add_sys_agent","agent_name",{isVisibleRender:"1",picklistType:"POPUP",fieldI18nKey:getResource('agent_name','form_add_sys_agent'),fieldValue:"",comboboxKeyColumn:"",comboboxValueColumn:"",isNeedConfirmDirtyData:"0",editGridId:"",isNeedPicklistFilter:"0",isEditable:false,picklist_redirect_page:"",redirect_page_panel_list:"",redirect_page_title:"",redirect_page_height:"600",redirect_page_width:"800",edit_mode:"0",header_js:"",footer_js:""},this.form_add_sys_agent_globalVariable,"width:150,style:{marginLeft:\"0px\",marginTop:\"0px\",marginRight:\"0px\",marginBottom:\"0px\"}")]},{ xtype:'panel',layout:'form',border:false,items:[{
					enableKeyEvents:true,
					name:'start_date',id:'form_add_sys_agent_start_date_id'
					,listeners:{},xtype:'datefield',format:web_platform_dateformat,fieldLabel:getResource('start_date','form_add_sys_agent'),hiddenName:'start_date',width:150}]},{ xtype:'panel',layout:'form',border:false,items:[{
					enableKeyEvents:true,
					name:'end_date',id:'form_add_sys_agent_end_date_id'
					,listeners:{},xtype:'datefield',format:web_platform_dateformat,fieldLabel:getResource('end_date','form_add_sys_agent'),hiddenName:'end_date',width:150}]},{ xtype:'panel',layout:'form',border:false,items:[{
					enableKeyEvents:true,
					name:'user_id',id:'form_add_sys_agent_user_id_id'
					,xtype:'hidden',hiddenName:'user_id',width:150}]},{ xtype:'panel',layout:'form',border:false,items:[{
					enableKeyEvents:true,
					name:'agent_user',id:'form_add_sys_agent_agent_user_id'
					,xtype:'hidden',hiddenName:'agent_user',width:150}]},{ xtype:'panel',layout:'form',border:false,items:[{
					enableKeyEvents:true,
					name:'agent_role',id:'form_add_sys_agent_agent_role_id'
					,xtype:'hidden',hiddenName:'agent_role',width:150}]}],tbar:new Ext.Toolbar({enableOverflow : true,id:'form_add_sys_agent_tbar_btn',items:[{ text:getResource('add_record','form_add_sys_agent'),icon:'../ext/resources/images/icons/add.gif',id:'form_add_sys_agent_form_add_sys_agent_add_record_id',scope:this,
								handler:function(){this.event_form_add_sys_agent_add_record();}}]}),listeners:{afterlayout:function(){},resize:function(){if(Ext.getCmp('form_add_sys_agent_tbar_btn')){Ext.getCmp('form_add_sys_agent_tbar_btn').doLayout()}},afterrender:function(){
					if(show_page_designer_shortcut == 1){
						var form_add_sys_agent_pdBtn = dynmaicWebPageDesign('sys_agent_first_popup','form_add_sys_agent');
						Ext.getCmp('form_add_sys_agent_form').getTopToolbar().add('->');
						Ext.getCmp('form_add_sys_agent_form').getTopToolbar().add(form_add_sys_agent_pdBtn);Ext.getCmp('form_add_sys_agent_form').getTopToolbar().doLayout();
					}else{
						if(Ext.getCmp('form_add_sys_agent_form').getTopToolbar().items.length==0){
							Ext.getCmp('form_add_sys_agent_form').getTopToolbar().hide();
						}
					}
				
						
						
			
						if(getAppPriv('form_add_sys_agent','form_add_sys_agent_add_record')==0){
							Ext.getCmp('form_add_sys_agent_form_add_sys_agent_add_record_id').hide();
						}
					},beforerender:function(){}}})},
						event_form_add_sys_agent_add_record:function(){
							var globalVariables_form_add_sys_agent=new Object();
							var panelActionData_form_add_sys_agent=new Array();
					
							dynamicFormPanelEvent("form_add_sys_agent","form_add_sys_agent_add_record",{panelActionDataArray:panelActionData_form_add_sys_agent,isRequireConfirmation:"0",confirmMessage:"getResource('form_add_sys_agent_add_record','form_add_sys_agent')",isRequireValidation:"1",predefinedValues:"",handlerType:"BACKGROUND",actionHandlerEvent:"",dynPageName:"",winWidth:"0",winHeight:"0",winTitleI18n:"",isNeedConfirmDirtyData:"0",gridPanelName:"",isRequireSuccessTip:"1",isCloseWindowAfterAction:"0",resetFormAfterSuccess:"0",isRequireReloadGrid:"1",afterSuccessJs:"Ext.getCmp(\"form_add_sys_agent_parentPanel\").disable();  \r\nExt.getCmp(\"grid_add_sys_agent_menu_parentPanel\").enable;  \r\nExt.getCmp(\"form_add_sys_agent_parentPanel\").findParentByType(\'tabpanel\').getItem(1).enable(); \r\nExt.getCmp(\"form_add_sys_agent_parentPanel\").findParentByType(\'tabpanel\').getItem(1).show(); \r\nExt.getCmp(\"form_add_sys_agent_parentPanel\").findParentByType(\'tabpanel\').getItem(0).hide(); \r\nExt.getCmp(\"form_add_sys_agent_parentPanel\").findParentByType(\'tabpanel\').getItem(0).disable(); ",handlerJs:"",isWorkFlowStart:"0",workFlowProcessKey:"",wfTable:"",rptFormat:"",isHtmlXls:"0",rptNumber:"",rptPageType:"MAIN_PANEL",targetPanelName:"",targetPanelType:"",menuKey:"sys_agent_first_popup"},globalVariables_form_add_sys_agent);
						}	
					,form_add_sys_agent_setStyle:function() {
			try{
			var varStyleArray_form_add_sys_agent=new Array();
		
			}catch(e){
				exceptionHandling(e,'P10017');
			}
		
					},makeNode:function(name,value){
						var node = document.createElement("input");node.type="hidden";node.name=name;
						node.id=name;node.value=this.URLencode(value);return node;
					},
					insertWithin:function(nodeId, name,value) {
						var node = document.getElementById(nodeId);var newNode = this.makeNode(name,value);node.appendChild(newNode);	
					},
					URLencode:function(sStr) {
						return escape(sStr).replace(/\+/g, "%2B").replace(/\'/g,"%22").replace(/\"/g, "%27").replace(/\//g,"%2F");
					},					
					run_popReport:function(panel_name,rpt_format,rpt_number,width,height,formValues){
						var t_url = "index.cfm?event=rpt.report.report.runReportPage";
						for(var i in formValues){
							t_url = t_url + "&"+ i + "="+this.URLencode(formValues[i]);
						}window.open (t_url) ;
					},
					form_add_sys_agent_clientSideValidation:function(v_event_name){
						var validData = "{[],[agent_user],[if ('this.agent_user' == '') return false;  else return true;],[getResource('agent_empty','form_add_sys_agent')],[getResource('agent_empty','form_add_sys_agent')]}{[],[start_date],[if ('this.start_date' == '') return false;  else return true;],[getResource('start_date_empty','form_add_sys_agent')],[getResource('start_date_empty','form_add_sys_agent')]}{[],[end_date],[if ('this.end_date' == '') return false;  else return true;],[getResource('end_date_empty','form_add_sys_agent')],[getResource('end_date_empty','form_add_sys_agent')]}{[],[start_date,end_date],[if ('this.start_date' == '' || 'this.end_date' == '') return true;  if (Ext.getCmp('form_add_sys_agent_start_date_id').getValue() > Ext.getCmp('form_add_sys_agent_end_date_id').getValue()) return false;  else return true;],[getResource('start_date_greater_than_end_date','form_add_sys_agent')],[getResource('start_date_greater_than_end_date','form_add_sys_agent')]}";var error_msg = "";
						return formClientSideValidation("form_add_sys_agent",validData,v_event_name);
					}
					});
						
								
				grid_add_sys_agent_menu = Ext.extend(Ext.grid.EditorGridPanel,{paramList:null,hideLoadingMask:null,
		
					rowIndex:null,columnIndex:null,is_allow_edit:null,
					myJSON_grid_add_sys_agent_menu:null,
					grid_add_sys_agent_menu_rowdblclick:null,
					grid_add_sys_agent_menu_globalVariable:null,
					constructor:function(_cfg){if(_cfg==null){_cfg=={};this.paramList={}}else{this.paramList=_cfg.paramList;};var grid_add_sys_agent_menu_jsonParams = new Object();
						Ext.apply(grid_add_sys_agent_menu_jsonParams,this.paramList);grid_add_sys_agent_menu_jsonParams.sql_where=" and 1=1";this.hideLoadingMask = true;var grid_add_sys_agent_menu_loadMask;
						this.is_allow_edit=1;
						this.grid_add_sys_agent_menu_globalVariable=new Array();
		
					var varArray_grid_add_sys_agent_menu=new Array();
			
					varArray_grid_add_sys_agent_menu[0]={};
					varArray_grid_add_sys_agent_menu[0].panelType='advformpanel';
					varArray_grid_add_sys_agent_menu[0].sourceFieldList='start_date,end_date,agent_user';
					varArray_grid_add_sys_agent_menu[0].varSourceFieldList='start_date,end_date,agent_user';
					varArray_grid_add_sys_agent_menu[0].sourcePanelName='form_add_sys_agent';
				
					this.grid_add_sys_agent_menu_globalVariable=varArray_grid_add_sys_agent_menu;	
				
						this.myJSON_grid_add_sys_agent_menu = new Ext.data.JsonStore({
							autoLoad : false,remoteSort : true,id:"myJSON_grid_add_sys_agent_menu",baseParams:grid_add_sys_agent_menu_jsonParams,
							root : "query.data",totalProperty : "totalcount",
							listeners:{beforeload:function(_store){
									var globalVariables_grid_add_sys_agent_menu=new Object();
						if(typeof(Ext.getCmp('grid_add_sys_agent_menu'))!='undefined'){
							var store = Ext.getCmp('grid_add_sys_agent_menu').store;
				
						if(Ext.getCmp('form_add_sys_agent_start_date_id')){
							if(Ext.getCmp('form_add_sys_agent_start_date_id').xtype=='combo'){
								globalVariables_grid_add_sys_agent_menu.start_date=Ext.getCmp('form_add_sys_agent_start_date_id').getValue();
							}else if(Ext.getCmp('form_add_sys_agent_start_date_id').xtype=='checkbox'){
								if(Ext.getCmp('form_add_sys_agent_start_date_id').checked){
									globalVariables_grid_add_sys_agent_menu.start_date=1;
								}else{
									globalVariables_grid_add_sys_agent_menu.start_date=0;
								}
							}else if(Ext.getCmp('form_add_sys_agent_start_date_id').xtype=='container'){
								if(Ext.getCmp('form_add_sys_agent_start_date_id').picklistType=='RADIOGROUP'){
									var radiogroup = document.getElementsByName('start_date');
									for (var g=0;g<radiogroup.length;g++) {
										if (radiogroup[g].checked) {
											globalVariables_grid_add_sys_agent_menu.start_date=radiogroup[g].value;
											break;
										}
									}	
								}else{
									globalVariables_grid_add_sys_agent_menu.start_date=getCheckboxGroupValues('form_add_sys_agent','start_date');
								}
							}else if(Ext.getCmp('form_add_sys_agent_start_date_id').xtype=='datefield'){
								if(Ext.get('form_add_sys_agent_start_date_id')){
									globalVariables_grid_add_sys_agent_menu.start_date=Ext.get('form_add_sys_agent_start_date_id').dom.value;
								}
							}else{
								globalVariables_grid_add_sys_agent_menu.start_date=Ext.getCmp('form_add_sys_agent_start_date_id').getValue();
							}
						}
					
						if(Ext.getCmp('form_add_sys_agent_end_date_id')){
							if(Ext.getCmp('form_add_sys_agent_end_date_id').xtype=='combo'){
								globalVariables_grid_add_sys_agent_menu.end_date=Ext.getCmp('form_add_sys_agent_end_date_id').getValue();
							}else if(Ext.getCmp('form_add_sys_agent_end_date_id').xtype=='checkbox'){
								if(Ext.getCmp('form_add_sys_agent_end_date_id').checked){
									globalVariables_grid_add_sys_agent_menu.end_date=1;
								}else{
									globalVariables_grid_add_sys_agent_menu.end_date=0;
								}
							}else if(Ext.getCmp('form_add_sys_agent_end_date_id').xtype=='container'){
								if(Ext.getCmp('form_add_sys_agent_end_date_id').picklistType=='RADIOGROUP'){
									var radiogroup = document.getElementsByName('end_date');
									for (var g=0;g<radiogroup.length;g++) {
										if (radiogroup[g].checked) {
											globalVariables_grid_add_sys_agent_menu.end_date=radiogroup[g].value;
											break;
										}
									}	
								}else{
									globalVariables_grid_add_sys_agent_menu.end_date=getCheckboxGroupValues('form_add_sys_agent','end_date');
								}
							}else if(Ext.getCmp('form_add_sys_agent_end_date_id').xtype=='datefield'){
								if(Ext.get('form_add_sys_agent_end_date_id')){
									globalVariables_grid_add_sys_agent_menu.end_date=Ext.get('form_add_sys_agent_end_date_id').dom.value;
								}
							}else{
								globalVariables_grid_add_sys_agent_menu.end_date=Ext.getCmp('form_add_sys_agent_end_date_id').getValue();
							}
						}
					
						if(Ext.getCmp('form_add_sys_agent_agent_user_id')){
							if(Ext.getCmp('form_add_sys_agent_agent_user_id').xtype=='combo'){
								globalVariables_grid_add_sys_agent_menu.agent_user=Ext.getCmp('form_add_sys_agent_agent_user_id').getValue();
							}else if(Ext.getCmp('form_add_sys_agent_agent_user_id').xtype=='checkbox'){
								if(Ext.getCmp('form_add_sys_agent_agent_user_id').checked){
									globalVariables_grid_add_sys_agent_menu.agent_user=1;
								}else{
									globalVariables_grid_add_sys_agent_menu.agent_user=0;
								}
							}else if(Ext.getCmp('form_add_sys_agent_agent_user_id').xtype=='container'){
								if(Ext.getCmp('form_add_sys_agent_agent_user_id').picklistType=='RADIOGROUP'){
									var radiogroup = document.getElementsByName('agent_user');
									for (var g=0;g<radiogroup.length;g++) {
										if (radiogroup[g].checked) {
											globalVariables_grid_add_sys_agent_menu.agent_user=radiogroup[g].value;
											break;
										}
									}	
								}else{
									globalVariables_grid_add_sys_agent_menu.agent_user=getCheckboxGroupValues('form_add_sys_agent','agent_user');
								}
							}else if(Ext.getCmp('form_add_sys_agent_agent_user_id').xtype=='datefield'){
								if(Ext.get('form_add_sys_agent_agent_user_id')){
									globalVariables_grid_add_sys_agent_menu.agent_user=Ext.get('form_add_sys_agent_agent_user_id').dom.value;
								}
							}else{
								globalVariables_grid_add_sys_agent_menu.agent_user=Ext.getCmp('form_add_sys_agent_agent_user_id').getValue();
							}
						}
					
						Ext.apply(store.baseParams,globalVariables_grid_add_sys_agent_menu);
				}
									_store.baseParams.panel_name="grid_add_sys_agent_menu";_store.baseParams.currentPanel="grid_add_sys_agent_menu";
									if(!Ext.getCmp("grid_add_sys_agent_menu").hideLoadingMask && typeof(grid_add_sys_agent_menu_loadMask)!="undefined") {
										grid_add_sys_agent_menu_loadMask.show();
									}},load:function(_store){
										if(Ext.getCmp("grid_add_sys_agent_menu")){
										Ext.getCmp("grid_add_sys_agent_menu").setingEditorGridStyle(_store);
		
									Ext.getCmp("grid_add_sys_agent_menu").hideLoadingMask = false;
									if(typeof(grid_add_sys_agent_menu_loadMask) != "undefined") {grid_add_sys_agent_menu_loadMask.hide();}
									if(_store.baseParams.sql_where != null){Ext.getCmp("grid_add_sys_agent_menu").paramList.sql_where = _store.baseParams.sql_where;
									}else{Ext.getCmp("grid_add_sys_agent_menu").paramList.sql_where = " and 1=1";}Ext.apply(Ext.getCmp("grid_add_sys_agent_menu").paramList,_store.baseParams);
									}},exception:function(misc){
										if(grid_add_sys_agent_menu_loadMask){
											grid_add_sys_agent_menu_loadMask.hide();
										}
										if(Ext.getCmp("page_sys_agent_first_popup")){
											Ext.getCmp("page_sys_agent_first_popup").loadCounter = Ext.getCmp("page_sys_agent_first_popup").loadCounter - 1;
										}
										exceptionHandling("","P10002");
									}},
									 proxy: new Ext.data.HttpProxy({   
							              url:"index.cfm?event=dynamicEditGrid.editgrid.editgridData&datenow=" + new Date() + "&_rid=" + Math.random(),
							              timeout: ajaxTimeOut
							         }),
									fields:[
		"id","menu_key"]});var selectModel=new Ext.grid.RowSelectionModel({singleSelect: true});
						grid_add_sys_agent_menu.superclass.constructor.call(this,{
							id:"grid_add_sys_agent_menu",autoScroll:true,header:false,stripeRows:true,border:false,
							trackMouseOver:true,store:this.myJSON_grid_add_sys_agent_menu,
				view : new Ext.ux.grid.LockingGridView({
					doRender : function(cs, rs, ds, startRow, colCount, stripe){
						var ts = this.templates, ct = ts.cell, rt = ts.row, last = colCount-1;
						var tstyle = "width:"+this.getTotalWidth()+";";
						var lstyle = "width:"+this.getLockedWidth()+";";
						var buf = [],lbuf = [], cb, lcb, c, p = {}, rp = {tstyle: tstyle}, r;
						for(var j = 0, len = rs.length; j < len; j++){
							r = rs[j]; cb = [];lcb = [];var rowIndex = (j+startRow);
							for(var i = 0; i < colCount; i++){c = cs[i];p.id = c.id;p.css = (i === 0 ? "x-grid3-cell-first " : (i == last ? "x-grid3-cell-last " : ""))+(this.cm.config[i].cellCls ? ""+ this.cm.config[i].cellCls : "");
								p.attr = p.cellAttr = "";p.value = c.renderer(r.data[c.name], p, r, rowIndex, i, ds);p.style = c.style;
		
								if(Ext.isEmpty(p.value)){p.value = " ";}if(this.markDirty && r.dirty && Ext.isDefined(r.modified[c.name])){p.css += " x-grid3-dirty-cell";}if(c.locked){lcb[lcb.length] = ct.apply(p);}else{cb[cb.length] = ct.apply(p);}
							}var alt = [];
							if(stripe && ((rowIndex+1) % 2 === 0)){alt[0] = "x-grid3-row-alt";}
							if(r.dirty){alt[1] = " x-grid3-dirty-row";}
							rp.cols = colCount;
							if(this.getRowClass){alt[2] = this.getRowClass(r, rowIndex, rp, ds);}
							rp.alt = alt.join(" ");rp.cells = cb.join("");rp.tstyle = tstyle;buf[buf.length] =  rt.apply(rp);rp.cells = lcb.join(" ");rp.tstyle = lstyle;lbuf[lbuf.length] = rt.apply(rp);}	return [buf.join(""), lbuf.join("")];	}}),
		sm:selectModel,
								tbar:new Ext.Toolbar({enableOverflow : true,id:"grid_add_sys_agent_menu_tbar_btn",items:[	
				{ id:"event_add_single_menu_grid_add_sys_agent_menu",text:getResource('add_single_menu','grid_add_sys_agent_menu'),icon:"../ext/resources/images/icons/add.gif",handler:function(){this.event_add_single_menu();},scope:this},{ id:"event_add_all_menu_grid_add_sys_agent_menu",text:getResource('add_all_menu','grid_add_sys_agent_menu'),icon:"../ext/resources/images/icons/disk_multiple.png",handler:function(){this.event_add_all_menu();},scope:this},{ id:"event_delete_single_menu_grid_add_sys_agent_menu",text:getResource('delete_single_menu','grid_add_sys_agent_menu'),icon:"../ext/resources/images/icons/delete.gif",handler:function(){this.event_delete_single_menu();},scope:this},{ id:"event_delete_all_menu_grid_add_sys_agent_menu",text:getResource('delete_all_menu','grid_add_sys_agent_menu'),icon:"../ext/resources/images/icons/cross.gif",handler:function(){this.event_delete_all_menu();},scope:this}]}),
							listeners:{
								"cellclick":function(grid,rowIndex,columnIndex,e){
									this.columnIndex=columnIndex;this.rowIndex=rowIndex;
								},
								"rowclick":function(_grid){
									var selectedRow = _grid.getSelectionModel().getSelections();
									if(selectedRow.length == 1){
							
								if(Ext.getCmp("grid_add_sys_agent_menu_tbar_btn")){
									Ext.getCmp("grid_add_sys_agent_menu_tbar_btn").doLayout();
								}
							}},"beforerender":function(){},"resize":function(){
				if(Ext.getCmp("grid_add_sys_agent_menu_tbar_btn")){
					Ext.getCmp("grid_add_sys_agent_menu_tbar_btn").doLayout();
				}
		},"render":function(_grid){grid_add_sys_agent_menu_loadMask = new Ext.LoadMask(Ext.getCmp("grid_add_sys_agent_menu").getEl(), {msg:getResource("loading","")});
				if(show_page_designer_shortcut == 1){
					var grid_add_sys_agent_menu_pdBtn = dynmaicWebPageDesign("sys_agent_first_popup","grid_add_sys_agent_menu");
					if(typeof(tbar_grid_add_sys_agent_menu)!="undefined"){
						tbar_grid_add_sys_agent_menu.add("->");
						tbar_grid_add_sys_agent_menu.add(grid_add_sys_agent_menu_pdBtn);
						tbar_grid_add_sys_agent_menu.doLayout();
					}else{
						_grid.getTopToolbar().add("->");
						_grid.getTopToolbar().add(grid_add_sys_agent_menu_pdBtn);
					}
					_grid.getTopToolbar().doLayout();
				}else{
					if(_grid.getTopToolbar().items.length==0){
						_grid.getTopToolbar().hide();
					}
				}
			if(getAppPriv('grid_add_sys_agent_menu','add_single_menu')==0){Ext.getCmp('event_add_single_menu_grid_add_sys_agent_menu').hide();}if(getAppPriv('grid_add_sys_agent_menu','add_all_menu')==0){Ext.getCmp('event_add_all_menu_grid_add_sys_agent_menu').hide();}if(getAppPriv('grid_add_sys_agent_menu','delete_single_menu')==0){Ext.getCmp('event_delete_single_menu_grid_add_sys_agent_menu').hide();}if(getAppPriv('grid_add_sys_agent_menu','delete_all_menu')==0){Ext.getCmp('event_delete_all_menu_grid_add_sys_agent_menu').hide();}
				try{var agent_start_date = Ext.getCmp("form_add_sys_agent_start_date_id").getValue(); var start_date_year = agent_start_date.getFullYear(); var start_date_month = agent_start_date.getMonth(); start_date_month++; var start_date_day = agent_start_date.getDate();  var start_date_full = start_date_year + '-' + start_date_month + '-' + start_date_day; var agent_end_date = Ext.getCmp("form_add_sys_agent_end_date_id").getValue(); var end_date_year = agent_end_date.getFullYear(); var end_date_month = agent_end_date.getMonth(); end_date_month++; var end_date_day = agent_end_date.getDate();  var end_date_full = end_date_year + '-' + end_date_month + '-' + end_date_day; Ext.getCmp("grid_add_sys_agent_menu").getStore().baseParams=new Object({agent_user:Ext.getCmp("form_add_sys_agent_agent_user_id").getValue(),start_date:start_date_full,end_date:end_date_full});
Ext.getCmp("grid_sys_agent_grid_sys_agent_add_record_win_popUp_parent").on("hide",function(p){Ext.getCmp("grid_sys_agent_grid_sys_agent_add_record_win_popUp_parent").destroy();});}catch(e){
					exceptionHandling(e,'P10005');
				}
			
				if(typeof(tbar_grid_add_sys_agent_menu)!="undefined"){
					tbar_grid_add_sys_agent_menu.doLayout();
				}
			},"beforeedit":function(e){if(e.grid.is_allow_edit==0){
										e.grid.getColumnModel().setEditable(e.column,false);}else{var _value='';var flag;}if(typeof(e.record.data.allowedit) != 'undefined' && e.record.data.allowedit == 0){return false;}if(e.value){if(typeof(e.value)!= 'number' && typeof(e.value) != 'boolean'&& typeof(e.value) != 'object'){e.record.data[e.field]=e.value.replace(new RegExp('&lt;', 'g'),'<').replace(new RegExp('&gt;', 'g'),'>');}}}},bbar : new Ext.PagingToolbar({id:"grid_add_sys_agent_menu_page_toolbar_id",
							displayInfo : true,pageSize : 20,store : this.myJSON_grid_add_sys_agent_menu,dummy : true}),colModel:new Ext.ux.grid.LockingColumnModel([
							{header:getResource('id','grid_add_sys_agent_menu'),width:0,hidden:true,
								resizable:false,sortable:false,hideable:false,
								menuDisabled:true,dataIndex:"id" },
							{header:getResource('menu_key','grid_add_sys_agent_menu'),width:500,hidden:false,
								resizable:true,sortable:true,hideable:true,
								menuDisabled:true,dataIndex:"menu_key" }])})},listeners: {afteredit:function(e) {
									if(typeof(e.value)=="object"){
											if(e.value instanceof Date){
												Ext.getCmp("grid_add_sys_agent_menu").store.getAt(e.row).data[e.field] = e.value.format("Y-m-d");
											}
									}
									var _store = Ext.getCmp("grid_add_sys_agent_menu").store;
									Ext.getCmp("grid_add_sys_agent_menu").setingEditorGridStyle(_store);
									Ext.getCmp("grid_add_sys_agent_menu").getSelectionModel().selectRow(e.row);
								},columnmove : function(oldIndex,newIndex){if(Ext.getCmp("grid_add_sys_agent_menu")){Ext.getCmp("grid_add_sys_agent_menu").setingEditorGridStyle(Ext.getCmp("grid_add_sys_agent_menu").store)}},afterrender:function(g){var valueList = "";if(valueList!=""){var dataIndexArray = new Array();dataIndexArray = valueList.split(",");initLockGridColumn(g,dataIndexArray);}}},setingEditorGridStyle:function(_store) {
						},
				event_add_single_menu:function(e){
					globalVariables_grid_add_sys_agent_menu=new Object();
					panelActionData_grid_add_sys_agent_menu=new Array();
				
							globalVariables_grid_add_sys_agent_menu=getPanelVariable('grid_add_sys_agent_menu',Ext.getCmp('grid_add_sys_agent_menu').grid_add_sys_agent_menu_globalVariable);
					
						dynamicGridPanelEvent(e,"grid_add_sys_agent_menu","add_single_menu",{panelActionDataArray:panelActionData_grid_add_sys_agent_menu,winHeight:240,winWidth:450,isRequireGridRowSelection:"0",columnList:"id,menu_key",handlerType:"POPUP",isUseDynamicPanel:"0",isRequireConfirmation:"0",isRequireReloadGrid:"0",confirmMessage:"getResource('add_single_menu','grid_add_sys_agent_menu')",predefinedValues:"",gridPanelName:"",saveType:"EDITGRID",isCloseWindowAfterAction:"0",isRequireSuccessTip:"1",isWorkFlowStart:"0",workflowProcessKey:"",wfTable:"",dynPageName:"form_add_sys_agent_menu_single",actionHandlerEvent:"",isDestroyWin:"0",isNeedConfirmDirtyData:"0",titleI18nKey:"getResource('add_single_menu','grid_add_sys_agent_menu')",afterSuccessJs:"",handlerJs:"",rptFormat:"",isHtmlXls:"0",rptNumber:"",rptPageType:"MAIN_PANEL",targetPanelName:"",targetPanelType:"",menuKey:"sys_agent_first_popup",menuId:"0"},globalVariables_grid_add_sys_agent_menu);
					}
				,
				event_add_all_menu:function(e){
					globalVariables_grid_add_sys_agent_menu=new Object();
					panelActionData_grid_add_sys_agent_menu=new Array();
				
							globalVariables_grid_add_sys_agent_menu=getPanelVariable('grid_add_sys_agent_menu',Ext.getCmp('grid_add_sys_agent_menu').grid_add_sys_agent_menu_globalVariable);
					
						dynamicGridPanelEvent(e,"grid_add_sys_agent_menu","add_all_menu",{panelActionDataArray:panelActionData_grid_add_sys_agent_menu,winHeight:0,winWidth:0,isRequireGridRowSelection:"0",columnList:"id,menu_key",handlerType:"BACKGROUND",isUseDynamicPanel:"0",isRequireConfirmation:"1",isRequireReloadGrid:"1",confirmMessage:"getResource('confirm_add_all_menu','grid_add_sys_agent_menu')",predefinedValues:"",gridPanelName:"",saveType:"EDITGRID",isCloseWindowAfterAction:"0",isRequireSuccessTip:"1",isWorkFlowStart:"0",workflowProcessKey:"",wfTable:"",dynPageName:"",actionHandlerEvent:"",isDestroyWin:"0",isNeedConfirmDirtyData:"0",titleI18nKey:"getResource('add_single_menu','grid_add_sys_agent_menu')",afterSuccessJs:"",handlerJs:"",rptFormat:"",isHtmlXls:"0",rptNumber:"",rptPageType:"MAIN_PANEL",targetPanelName:"",targetPanelType:"",menuKey:"sys_agent_first_popup",menuId:"0"},globalVariables_grid_add_sys_agent_menu);
					}
				,
				event_delete_single_menu:function(e){
					globalVariables_grid_add_sys_agent_menu=new Object();
					panelActionData_grid_add_sys_agent_menu=new Array();
				
							globalVariables_grid_add_sys_agent_menu=getPanelVariable('grid_add_sys_agent_menu',Ext.getCmp('grid_add_sys_agent_menu').grid_add_sys_agent_menu_globalVariable);
					
						dynamicGridPanelEvent(e,"grid_add_sys_agent_menu","delete_single_menu",{panelActionDataArray:panelActionData_grid_add_sys_agent_menu,winHeight:0,winWidth:0,isRequireGridRowSelection:"1",columnList:"id,menu_key",handlerType:"BACKGROUND",isUseDynamicPanel:"0",isRequireConfirmation:"1",isRequireReloadGrid:"1",confirmMessage:"getResource('confirm_delete_single_menu','grid_add_sys_agent_menu')",predefinedValues:"",gridPanelName:"",saveType:"EDITGRID",isCloseWindowAfterAction:"0",isRequireSuccessTip:"1",isWorkFlowStart:"0",workflowProcessKey:"",wfTable:"",dynPageName:"",actionHandlerEvent:"",isDestroyWin:"0",isNeedConfirmDirtyData:"0",titleI18nKey:"getResource('add_single_menu','grid_add_sys_agent_menu')",afterSuccessJs:"",handlerJs:"",rptFormat:"",isHtmlXls:"0",rptNumber:"",rptPageType:"MAIN_PANEL",targetPanelName:"",targetPanelType:"",menuKey:"sys_agent_first_popup",menuId:"0"},globalVariables_grid_add_sys_agent_menu);
					}
				,
				event_delete_all_menu:function(e){
					globalVariables_grid_add_sys_agent_menu=new Object();
					panelActionData_grid_add_sys_agent_menu=new Array();
				
							globalVariables_grid_add_sys_agent_menu=getPanelVariable('grid_add_sys_agent_menu',Ext.getCmp('grid_add_sys_agent_menu').grid_add_sys_agent_menu_globalVariable);
					
						dynamicGridPanelEvent(e,"grid_add_sys_agent_menu","delete_all_menu",{panelActionDataArray:panelActionData_grid_add_sys_agent_menu,winHeight:0,winWidth:0,isRequireGridRowSelection:"0",columnList:"id,menu_key",handlerType:"BACKGROUND",isUseDynamicPanel:"0",isRequireConfirmation:"1",isRequireReloadGrid:"1",confirmMessage:"getResource('delete_all_menu','grid_add_sys_agent_menu')",predefinedValues:"",gridPanelName:"",saveType:"EDITGRID",isCloseWindowAfterAction:"0",isRequireSuccessTip:"1",isWorkFlowStart:"0",workflowProcessKey:"",wfTable:"",dynPageName:"",actionHandlerEvent:"",isDestroyWin:"0",isNeedConfirmDirtyData:"0",titleI18nKey:"getResource('add_single_menu','grid_add_sys_agent_menu')",afterSuccessJs:"",handlerJs:"",rptFormat:"",isHtmlXls:"0",rptNumber:"",rptPageType:"MAIN_PANEL",targetPanelName:"",targetPanelType:"",menuKey:"sys_agent_first_popup",menuId:"0"},globalVariables_grid_add_sys_agent_menu);
					}
				
				,URLencode:function(sStr){ return escape(sStr).replace(/\+/g, '%2B').replace(/\"/g,'%22').replace(/\'/g, '%27').replace(/\//g,'%2F');	},
				run_popReport:function(panel_name,rpt_format,rpt_number,width,height,formValues){var t_url = 'index.cfm?event=rpt.report.report.runReportPage';for(var i in formValues){t_url = t_url + '&'+ i + '='+URLencode(formValues[i]);}window.open (t_url) ;}	
								
				});
		
						
				page_sys_agent_first_popup = Ext.extend(Ext.Panel,{
					paramList:null,
					loadCounter:null,
		
							form_add_sys_agent_loadFormData:function(){
								var paramList = Ext.getCmp('form_add_sys_agent_form').paramList;
							
								paramList.panel_name='form_add_sys_agent';
								var action = arguments[0];
								Ext.Ajax.request({
					           		url:'index.cfm?event=dynamicGenerateScript.dynamicGenerateScript.dynamicGetAdvFormData&_dc='+new Date() + '&_rid=' + Math.random(),
					                method:'POST',
					                timeout : ajaxTimeOut,
					                params:paramList,
					                failure:function(response,options){
										if(Ext.getCmp('page_sys_agent_first_popup')){
											Ext.getCmp('page_sys_agent_first_popup').loadCounter = Ext.getCmp('page_sys_agent_first_popup').loadCounter - 1;
										}
										if(typeof(Ext.getCmp('form_add_sys_agent_form'))!='undefined'){
											exceptionHandling('','P10013');
										}
					                },
					                success:function(response,options){
					                   if(typeof(Ext.getCmp('form_add_sys_agent_form'))!='undefined'){
					                   try{
								           var responseText = Ext.util.JSON.decode(response.responseText).jsonObject;
								           var controlTypeList = Ext.util.JSON.decode(response.responseText).success_msg;
								           loadFormData('form_add_sys_agent',action,responseText,controlTypeList);
						 			   Ext.getCmp('form_add_sys_agent_form').form_add_sys_agent_setStyle();
						 
						 			   try{
						 			   		Ext.getCmp("grid_add_sys_agent_menu_parentPanel").disable();
						 			   }catch(e){
						 			   		exceptionHandling(e,'P10014');
						 			   }
							 
										if(null!=maskObj&&maskObj!=undefined){
											Ext.getCmp('page_sys_agent_first_popup').loadCounter=Ext.getCmp('page_sys_agent_first_popup').loadCounter-1;
											if(Ext.getCmp('page_sys_agent_first_popup').loadCounter<=0){
												maskObj.hide();	
												Ext.getCmp('page_sys_agent_first_popup').loadCounter=0;
											}
										}
										var globalVariables_form_add_sys_agent=new Object();
										
										}catch(e){
					                       if(Ext.getCmp('page_sys_agent_first_popup')){
												Ext.getCmp('page_sys_agent_first_popup').loadCounter = Ext.getCmp('page_sys_agent_first_popup').loadCounter - 1;
										   }
										   exceptionHandling(e,'P10015');
					     			   }
					     			}
							 		}
						  		});
						  	},
					  	
							form_add_sys_agent:function(){
						
								
						
									if(getAppPriv('form_add_sys_agent','')){
										var winObj = eval(Ext.getCmp(Ext.getCmp('page_sys_agent_first_popup').paramList.win_id));
										if(typeof(winObj)!='undefined'){
											maskObj = new Ext.LoadMask(winObj.getEl(), {msg:getResource('loading','')});
										}else{
											maskObj = new Ext.LoadMask(Ext.getBody(), {msg:getResource('loading','')});	
										}
										maskObj.show();
										 Ext.getCmp('page_sys_agent_first_popup').form_add_sys_agent_loadFormData();
									}
							
								
						},
							grid_add_sys_agent_menu:function(){
						
							if(getAppPriv('grid_add_sys_agent_menu','')){
					
							var winObj = eval(Ext.getCmp(Ext.getCmp('page_sys_agent_first_popup').paramList.win_id));
							if(typeof(winObj)!='undefined'){
								maskObj = new Ext.LoadMask(winObj.getEl(), {msg:getResource('loading','')});
							}else{
								maskObj = new Ext.LoadMask(Ext.getBody(), {msg:getResource('loading','')});	
							}
							maskObj.show();
							Ext.getCmp('grid_add_sys_agent_menu').getStore().removeAll();
					
							var baseParams = Ext.getCmp('grid_add_sys_agent_menu').getStore().baseParams;
							var paramList = Ext.getCmp('grid_add_sys_agent_menu').paramList;
							Ext.apply(baseParams,paramList);
							baseParams.panel_name='grid_add_sys_agent_menu';
							baseParams.pname='grid_add_sys_agent_menu';
					
									Ext.apply(baseParams,paramList);
									baseParams.currentPanel='grid_add_sys_agent_menu';
									baseParams.panel_name='grid_add_sys_agent_menu';
									if(typeof(paramList.win_id)!='undefined' || (typeof(Ext.getCmp('grid_add_sys_agent_menu_parentPanel'))!='undefined'&&Ext.getCmp('grid_add_sys_agent_menu_parentPanel').ownerCt.xtype=='tabpanel')) {
										Ext.getCmp('grid_add_sys_agent_menu').hideLoadingMask = true;	
									}									
									if(typeof(Ext.getCmp('grid_add_sys_agent_menu_simplepanel_criteriadata_combo'))!='undefined') {
										var _sql = Ext.getCmp('grid_add_sys_agent_menu_simplepanel_criteriadata_combo').getValue()+'';
										if(_sql.replace(/(^\s*)|(\s*$)/g, '') != '') {
											Ext.getCmp('grid_add_sys_agent_menu').store.setBaseParam('sql_where', ' && '+_sql);
										}else {
											baseParams.sql_where=' and 1=1';
										}			
									}else {
										baseParams.sql_where=' and 1=1';
									}
									Ext.getCmp('grid_add_sys_agent_menu').getStore().baseParams=baseParams;
									Ext.getCmp('grid_add_sys_agent_menu').store.load();	
									if(typeof(Ext.getCmp('grid_add_sys_agent_menu_simplepanel_criteriadata_combo')) == 'undefined') {
							
									}else {
										if(Ext.getCmp('grid_add_sys_agent_menu_simplepanel_criteriadata_combo').getStore().getCount()==0) {
											Ext.getCmp('grid_add_sys_agent_menu_simplepanel_criteriadata_combo').getStore().reload();
										}
									}
									Ext.getCmp('grid_add_sys_agent_menu').getStore().on('load',function() {
										if(null!=maskObj&&maskObj!=undefined){
											if(Ext.getCmp('page_sys_agent_first_popup')){
												Ext.getCmp('page_sys_agent_first_popup').loadCounter=Ext.getCmp('page_sys_agent_first_popup').loadCounter-1;
												if(Ext.getCmp('page_sys_agent_first_popup').loadCounter<=0){
													maskObj.hide();	
													Ext.getCmp('page_sys_agent_first_popup').loadCounter=0;
												}
											}
										}
									});
							
							}
					},
					constructor:function(_cfg){
							if(_cfg==null){_cfg=={};this.paramList={}}else{this.paramList = _cfg.paramList;};
							Ext.apply(this,_cfg);
						page_sys_agent_first_popup.superclass.constructor.call(this,{
							border:false,
							autoScroll:false,	
							id:'page_sys_agent_first_popup',
							anchor:'100% 100%',
							layout:'anchor',
							items:[
								
		{
								anchor:'100% 100%',flex:1,activeTab:0,title:getResource('main_info',''),
								id:'delegate_tab1_tabpanel',
								enableTabScroll : true,
								listeners:{
									beforetabchange:function(_tab,_new,_old){
										if (validateDataFlag == 1) {			
											Ext.Msg.confirm(getResource('confirm_title',''),getResource('confirm_msg','confirm_modify_data'),function(_btn){
												if(_btn=='no'){
													return false;
												}else{
													validateDataFlag = 0;
													_tab.setActiveTab(_new);
												}
											},this);
											
											return false;
										}
									},
									tabchange:function(_tab, _pan) {
										if(_pan.panel_type=='advformpanel'||_pan.panel_type=='gridpanel'||_pan.panel_type=='editorgridpanel'||_pan.panel_type=='treegridpanel'||_pan.panel_type=='chartpanel'){
											Ext.getCmp('page_sys_agent_first_popup').loadCounter = Ext.getCmp('page_sys_agent_first_popup').loadCounter+1;
											eval('this.'+_pan.panel_name+'()');
										}
										_pan.doLayout();
									},
									scope:this
								},
								xtype:'tabpanel'
						,items:[
							{
								anchor:'100% 100%',flex:1,border:false,title:getResource('sys_agent_tab1',''),
								layout:"fit",
								panel_name:"form_add_sys_agent",
								panel_type:"advformpanel",
								id:"form_add_sys_agent_parentPanel",
								items:[new form_add_sys_agent({paramList:this.paramList})]
						},
							{
								anchor:'100% 100%',flex:1,title:getResource('sys_agent_tab2',''),
								layout:"fit",
								panel_name:"grid_add_sys_agent_menu",
								panel_type:"editorgridpanel",
								id:"grid_add_sys_agent_menu_parentPanel",
								items:[new grid_add_sys_agent_menu({paramList:this.paramList})]		
						}]}]
						})
					},
					listeners:{
						beforerender:function(_grid){
							var winObj = eval(Ext.getCmp(Ext.getCmp('page_sys_agent_first_popup').paramList.win_id));
							if(typeof(winObj)!='undefined'){
								maskObj = new Ext.LoadMask(winObj.getEl(), {msg:getResource('loading','')});
								maskObj.show();
							}
						},
						render:function(_grid){
							Ext.getCmp('page_sys_agent_first_popup').loadCounter=0;
		
				if(Ext.getCmp('page_sys_agent_first_popup').loadCounter==0){
					maskObj.hide();	
					Ext.getCmp('page_sys_agent_first_popup').loadCounter=0;
				} 
		
							if('undefined'!=typeof(Ext.getCmp('delegate_tab1_tabpanel'))&&(Ext.getCmp('delegate_tab1_tabpanel').items.getCount()>0&&null!=Ext.getCmp('delegate_tab1_tabpanel').getActiveTab()||Ext.getCmp('delegate_tab1_tabpanel').getActiveTab()!=undefined)){
								var _panel_type = Ext.getCmp('delegate_tab1_tabpanel').getActiveTab().panel_type;
								if((_panel_type=='gridpanel' || _panel_type=='editorgridpanel') && typeof(win_obj)!='undefined') {
									Ext.getCmp(Ext.getCmp('delegate_tab1_tabpanel').getActiveTab().panel_name).hideLoadingMask = true;
								}
								Ext.getCmp('delegate_tab1_tabpanel').fireEvent('tabchange',Ext.getCmp('delegate_tab1_tabpanel'),Ext.getCmp('delegate_tab1_tabpanel').getItem(Ext.getCmp('delegate_tab1_tabpanel').getActiveTab()));
							}
						
						},
						afterrender:function(_grid){
		
					if(getAppPriv('delegate_tab1','')==0){
				}
					if(getAppPriv('form_add_sys_agent','')==0){
				
						if(typeof(Ext.getCmp('form_add_sys_agent_form'))!='undefined'){
							Ext.getCmp('form_add_sys_agent_form').destroy();
							if(typeof(Ext.getCmp('form_add_sys_agent_parentPanel'))!='undefined'){
								var parent = Ext.getCmp('form_add_sys_agent_parentPanel').ownerCt;
								parent.remove(Ext.getCmp('form_add_sys_agent_parentPanel'));
								parent.doLayout();
							}
						}
					}
					if(getAppPriv('grid_add_sys_agent_menu','')==0){
				
						if(typeof(Ext.getCmp('grid_add_sys_agent_menu'))!='undefined'){
							Ext.getCmp('grid_add_sys_agent_menu').destroy();
							if(typeof(Ext.getCmp('grid_add_sys_agent_menu_parentPanel'))!='undefined'){
								var parent = Ext.getCmp('grid_add_sys_agent_menu_parentPanel').ownerCt;
								parent.remove(Ext.getCmp('grid_add_sys_agent_menu_parentPanel'));
								parent.doLayout();
							}
						}
					}
					if(typeof(Ext.getCmp('delegate_tab1_tabpanel'))!='undefined'){
						if(Ext.getCmp('delegate_tab1_tabpanel').items.getCount()==0){
							var parent = Ext.getCmp('delegate_tab1_tabpanel').ownerCt;
							parent.remove(Ext.getCmp('delegate_tab1_tabpanel'));	
							parent.doLayout();
						}
					}
				},
					destroy:function(){
		
					}		
				
					}
				})
		


								
				add_multilang_calendar_view_type = Ext.extend(Ext.form.FormPanel,{
					paramList:null,
					add_multilang_calendar_view_type_globalVariable:null,
					constructor:function(_cfg){
						if(_cfg==null){_cfg=={};this.paramList={}}else{this.paramList=_cfg.paramList;};
						this.add_multilang_calendar_view_type_globalVariable=new Array();
		
					this.paramList.panel_name="add_multilang_calendar_view_type";
					add_multilang_calendar_view_type.superclass.constructor.call(this,{
						autoScroll:true,id:"add_multilang_calendar_view_type_form",
						labelAlign:"right",padding:10,
						labelWidth:100,fileUpload:true,enctype:"multipart/form-data",border:false,
						bodyBorder:false,anchor:"100% 100%",items:[
		{ xtype:'panel',layout:'form',border:false,items:[createPicklistCompoment("add_multilang_calendar_view_type","calendar_view_type_key",{isVisibleRender:"1",picklistType:"TEXTFIELD",fieldI18nKey:getResource('calendar_view_type_key','add_multilang_calendar_view_type'),fieldValue:"",comboboxKeyColumn:"",comboboxValueColumn:"",isNeedConfirmDirtyData:"0",editGridId:"",isNeedPicklistFilter:"0",isEditable:true,picklist_redirect_page:"",redirect_page_panel_list:"",redirect_page_title:"",redirect_page_height:"600",redirect_page_width:"800",edit_mode:"0",header_js:"",footer_js:""},this.add_multilang_calendar_view_type_globalVariable,"")]},{ xtype:'panel',layout:'form',border:false,items:[createPicklistCompoment("add_multilang_calendar_view_type","calendar_view_type_name",{isVisibleRender:"1",picklistType:"TEXTFIELD",fieldI18nKey:getResource('calendar_view_type_name','add_multilang_calendar_view_type'),fieldValue:"",comboboxKeyColumn:"",comboboxValueColumn:"",isNeedConfirmDirtyData:"0",editGridId:"",isNeedPicklistFilter:"0",isEditable:true,picklist_redirect_page:"",redirect_page_panel_list:"",redirect_page_title:"",redirect_page_height:"600",redirect_page_width:"800",edit_mode:"0",header_js:"",footer_js:""},this.add_multilang_calendar_view_type_globalVariable,"")]},{ xtype:'panel',layout:'form',border:false,items:[createPicklistCompoment("add_multilang_calendar_view_type","display_seq",{isVisibleRender:"1",picklistType:"NUMBERFIELD",fieldI18nKey:getResource('display_seq','add_multilang_calendar_view_type'),fieldValue:"",comboboxKeyColumn:"",comboboxValueColumn:"",isNeedConfirmDirtyData:"0",editGridId:"",isNeedPicklistFilter:"0",isEditable:true,picklist_redirect_page:"",redirect_page_panel_list:"",redirect_page_title:"",redirect_page_height:"600",redirect_page_width:"800",edit_mode:"0",header_js:"",footer_js:""},this.add_multilang_calendar_view_type_globalVariable,"")]},{ xtype:'panel',layout:'form',border:false,items:[createPicklistCompoment("add_multilang_calendar_view_type","business_unit_key",{isVisibleRender:"1",picklistType:"TREE",fieldI18nKey:getResource('business_unit_key','add_multilang_calendar_view_type'),fieldValue:"",comboboxKeyColumn:"",comboboxValueColumn:"",isNeedConfirmDirtyData:"0",editGridId:"",isNeedPicklistFilter:"0",isEditable:true,picklist_redirect_page:"",redirect_page_panel_list:"",redirect_page_title:"",redirect_page_height:"600",redirect_page_width:"800",edit_mode:"0",header_js:"",footer_js:""},this.add_multilang_calendar_view_type_globalVariable,"")]}],tbar:new Ext.Toolbar({enableOverflow : true,id:'add_multilang_calendar_view_type_tbar_btn',items:[{ text:getResource('save','add_multilang_calendar_view_type'),icon:'../ext/resources/images/icons/cog_edit.png',id:'add_multilang_calendar_view_type_add_data_calendar_view_type_id',scope:this,
								handler:function(){this.event_add_data_calendar_view_type();}}]}),listeners:{afterlayout:function(){},resize:function(){if(Ext.getCmp('add_multilang_calendar_view_type_tbar_btn')){Ext.getCmp('add_multilang_calendar_view_type_tbar_btn').doLayout()}},afterrender:function(){
							if(_platform_current_bu_list.length==_platform_current_bu.length+2){
								Ext.getCmp('add_multilang_calendar_view_type_business_unit_key_id').readOnly=true;	
								Ext.getCmp('add_multilang_calendar_view_type_business_unit_key_id').setValue(_platform_current_bu);
							}
					
					if(show_page_designer_shortcut == 1){
						var add_multilang_calendar_view_type_pdBtn = dynmaicWebPageDesign('add_form_multilang_calendar_view_type','add_multilang_calendar_view_type');
						Ext.getCmp('add_multilang_calendar_view_type_form').getTopToolbar().add('->');
						Ext.getCmp('add_multilang_calendar_view_type_form').getTopToolbar().add(add_multilang_calendar_view_type_pdBtn);Ext.getCmp('add_multilang_calendar_view_type_form').getTopToolbar().doLayout();
					}else{
						if(Ext.getCmp('add_multilang_calendar_view_type_form').getTopToolbar().items.length==0){
							Ext.getCmp('add_multilang_calendar_view_type_form').getTopToolbar().hide();
						}
					}
				
						
						
			
						if(getAppPriv('add_multilang_calendar_view_type','add_data_calendar_view_type')==0){
							Ext.getCmp('add_multilang_calendar_view_type_add_data_calendar_view_type_id').hide();
						}
					},beforerender:function(){}}})},
						event_add_data_calendar_view_type:function(){
							var globalVariables_add_multilang_calendar_view_type=new Object();
							var panelActionData_add_multilang_calendar_view_type=new Array();
					
							dynamicFormPanelEvent("add_multilang_calendar_view_type","add_data_calendar_view_type",{panelActionDataArray:panelActionData_add_multilang_calendar_view_type,isRequireConfirmation:"0",confirmMessage:"",isRequireValidation:"1",predefinedValues:"",handlerType:"BACKGROUND",actionHandlerEvent:"",dynPageName:"",winWidth:"0",winHeight:"0",winTitleI18n:"",isNeedConfirmDirtyData:"0",gridPanelName:"",isRequireSuccessTip:"1",isCloseWindowAfterAction:"1",resetFormAfterSuccess:"0",isRequireReloadGrid:"1",afterSuccessJs:"",handlerJs:"",isWorkFlowStart:"0",workFlowProcessKey:"",wfTable:"",rptFormat:"",isHtmlXls:"0",rptNumber:"",rptPageType:"MAIN_PANEL",targetPanelName:"",targetPanelType:"",menuKey:"add_form_multilang_calendar_view_type"},globalVariables_add_multilang_calendar_view_type);
						}	
					,add_multilang_calendar_view_type_setStyle:function() {
			try{
			var varStyleArray_add_multilang_calendar_view_type=new Array();
		
			}catch(e){
				exceptionHandling(e,'P10017');
			}
		
					},makeNode:function(name,value){
						var node = document.createElement("input");node.type="hidden";node.name=name;
						node.id=name;node.value=this.URLencode(value);return node;
					},
					insertWithin:function(nodeId, name,value) {
						var node = document.getElementById(nodeId);var newNode = this.makeNode(name,value);node.appendChild(newNode);	
					},
					URLencode:function(sStr) {
						return escape(sStr).replace(/\+/g, "%2B").replace(/\'/g,"%22").replace(/\"/g, "%27").replace(/\//g,"%2F");
					},					
					run_popReport:function(panel_name,rpt_format,rpt_number,width,height,formValues){
						var t_url = "index.cfm?event=rpt.report.report.runReportPage";
						for(var i in formValues){
							t_url = t_url + "&"+ i + "="+this.URLencode(formValues[i]);
						}window.open (t_url) ;
					},
					add_multilang_calendar_view_type_clientSideValidation:function(v_event_name){
						var validData = "{[],[calendar_view_type_key],[if(Ext.util.Format.trim('this.calendar_view_type_key')==''||Ext.util.Format.trim('this.calendar_view_type_key')==null) return false; return true;],[getResource('key_is_null','add_multilang_calendar_view_type')],[getResource('key_is_null','add_multilang_calendar_view_type')]}{[],[business_unit_key],[if('this.business_unit_key'==''||'this.business_unit_key'==null) return false; return true;],[getResource('business_unit_key_null','add_multilang_calendar_view_type')],[getResource('business_unit_key_null','add_multilang_calendar_view_type')]}";var error_msg = "";
						return formClientSideValidation("add_multilang_calendar_view_type",validData,v_event_name);
					}
					});
						
				page_add_form_multilang_calendar_view_type = Ext.extend(Ext.Panel,{
					paramList:null,
					loadCounter:null,
		
					constructor:function(_cfg){
							if(_cfg==null){_cfg=={};this.paramList={}}else{this.paramList = _cfg.paramList;};
							Ext.apply(this,_cfg);
						page_add_form_multilang_calendar_view_type.superclass.constructor.call(this,{
							border:false,
							autoScroll:false,	
							id:'page_add_form_multilang_calendar_view_type',
							anchor:'100% 100%',
							layout:'anchor',
							items:[
								
		
							{
								anchor:'100% 100%',border:false,
								layout:"fit",
								panel_name:"add_multilang_calendar_view_type",
								panel_type:"advformpanel",
								id:"add_multilang_calendar_view_type_parentPanel",
								items:[new add_multilang_calendar_view_type({paramList:this.paramList})]
						}]
						})
					},
					listeners:{
						beforerender:function(_grid){
							var winObj = eval(Ext.getCmp(Ext.getCmp('page_add_form_multilang_calendar_view_type').paramList.win_id));
							if(typeof(winObj)!='undefined'){
								maskObj = new Ext.LoadMask(winObj.getEl(), {msg:getResource('loading','')});
								maskObj.show();
							}
						},
						render:function(_grid){
							Ext.getCmp('page_add_form_multilang_calendar_view_type').loadCounter=0;
		
				if(Ext.getCmp('page_add_form_multilang_calendar_view_type').loadCounter==0){
					maskObj.hide();	
					Ext.getCmp('page_add_form_multilang_calendar_view_type').loadCounter=0;
				} 
		
									
						
											
						
							if(null!=maskObj&&maskObj!=undefined){
								if(Ext.getCmp('page_add_form_multilang_calendar_view_type').loadCounter<=0){
									maskObj.hide();	
									Ext.getCmp('page_add_form_multilang_calendar_view_type').loadCounter=0;
								}
							}	
						
						},
						afterrender:function(_grid){
		
					if(getAppPriv('add_multilang_calendar_view_type','')==0){
				
						if(typeof(Ext.getCmp('add_multilang_calendar_view_type_form'))!='undefined'){
							Ext.getCmp('add_multilang_calendar_view_type_form').destroy();
							if(typeof(Ext.getCmp('add_multilang_calendar_view_type_parentPanel'))!='undefined'){
								var parent = Ext.getCmp('add_multilang_calendar_view_type_parentPanel').ownerCt;
								parent.remove(Ext.getCmp('add_multilang_calendar_view_type_parentPanel'));
								parent.doLayout();
							}
						}
					}},
					destroy:function(){
		
					}		
				
					}
				})
		


								
				edit_form_multilang_calendar_view_type = Ext.extend(Ext.form.FormPanel,{
					paramList:null,
					edit_form_multilang_calendar_view_type_globalVariable:null,
					constructor:function(_cfg){
						if(_cfg==null){_cfg=={};this.paramList={}}else{this.paramList=_cfg.paramList;};
						this.edit_form_multilang_calendar_view_type_globalVariable=new Array();
		
					this.paramList.panel_name="edit_form_multilang_calendar_view_type";
					edit_form_multilang_calendar_view_type.superclass.constructor.call(this,{
						autoScroll:true,id:"edit_form_multilang_calendar_view_type_form",
						labelAlign:"right",padding:10,
						labelWidth:100,fileUpload:true,enctype:"multipart/form-data",border:false,
						bodyBorder:false,anchor:"100% 100%",items:[
		{ xtype:'panel',layout:'form',border:false,items:[{
					enableKeyEvents:true,
					name:'calendar_view_type_key',id:'edit_form_multilang_calendar_view_type_calendar_view_type_key_id'
					,xtype:'textfield',fieldLabel:getResource('calendar_view_type_key','edit_form_multilang_calendar_view_type'),hiddenName:'calendar_view_type_key',cls:'x-form-text-h',readOnly:true}]},{ xtype:'panel',layout:'form',border:false,items:[createPicklistCompoment("edit_form_multilang_calendar_view_type","calendar_view_type_name",{isVisibleRender:"1",picklistType:"TEXTFIELD",fieldI18nKey:getResource('calendar_view_type_name','edit_form_multilang_calendar_view_type'),fieldValue:"",comboboxKeyColumn:"",comboboxValueColumn:"",isNeedConfirmDirtyData:"0",editGridId:"",isNeedPicklistFilter:"0",isEditable:true,picklist_redirect_page:"",redirect_page_panel_list:"",redirect_page_title:"",redirect_page_height:"600",redirect_page_width:"800",edit_mode:"0",header_js:"",footer_js:""},this.edit_form_multilang_calendar_view_type_globalVariable,"")]},{ xtype:'panel',layout:'form',border:false,items:[createPicklistCompoment("edit_form_multilang_calendar_view_type","display_seq",{isVisibleRender:"1",picklistType:"NUMBERFIELD",fieldI18nKey:getResource('display_seq','edit_form_multilang_calendar_view_type'),fieldValue:"",comboboxKeyColumn:"",comboboxValueColumn:"",isNeedConfirmDirtyData:"0",editGridId:"",isNeedPicklistFilter:"0",isEditable:true,picklist_redirect_page:"",redirect_page_panel_list:"",redirect_page_title:"",redirect_page_height:"600",redirect_page_width:"800",edit_mode:"0",header_js:"",footer_js:""},this.edit_form_multilang_calendar_view_type_globalVariable,"")]},{ xtype:'panel',layout:'form',border:false,items:[createPicklistCompoment("edit_form_multilang_calendar_view_type","business_unit_key",{isVisibleRender:"1",picklistType:"TREE",fieldI18nKey:getResource('business_unit_key','edit_form_multilang_calendar_view_type'),fieldValue:"",comboboxKeyColumn:"",comboboxValueColumn:"",isNeedConfirmDirtyData:"0",editGridId:"",isNeedPicklistFilter:"0",isEditable:true,picklist_redirect_page:"",redirect_page_panel_list:"",redirect_page_title:"",redirect_page_height:"600",redirect_page_width:"800",edit_mode:"0",header_js:"",footer_js:""},this.edit_form_multilang_calendar_view_type_globalVariable,"")]}],tbar:new Ext.Toolbar({enableOverflow : true,id:'edit_form_multilang_calendar_view_type_tbar_btn',items:[{ text:getResource('save','edit_form_multilang_calendar_view_type'),icon:'../ext/resources/images/icons/cog_edit.png',id:'edit_form_multilang_calendar_view_type_edit_data_calendar_view_type_id',scope:this,
								handler:function(){this.event_edit_data_calendar_view_type();}}]}),listeners:{afterlayout:function(){},resize:function(){if(Ext.getCmp('edit_form_multilang_calendar_view_type_tbar_btn')){Ext.getCmp('edit_form_multilang_calendar_view_type_tbar_btn').doLayout()}},afterrender:function(){
							if(_platform_current_bu_list.length==_platform_current_bu.length+2){
								Ext.getCmp('edit_form_multilang_calendar_view_type_business_unit_key_id').readOnly=true;	
								Ext.getCmp('edit_form_multilang_calendar_view_type_business_unit_key_id').setValue(_platform_current_bu);
							}
					
					if(show_page_designer_shortcut == 1){
						var edit_form_multilang_calendar_view_type_pdBtn = dynmaicWebPageDesign('edit_multilang_calendar_view_type','edit_form_multilang_calendar_view_type');
						Ext.getCmp('edit_form_multilang_calendar_view_type_form').getTopToolbar().add('->');
						Ext.getCmp('edit_form_multilang_calendar_view_type_form').getTopToolbar().add(edit_form_multilang_calendar_view_type_pdBtn);Ext.getCmp('edit_form_multilang_calendar_view_type_form').getTopToolbar().doLayout();
					}else{
						if(Ext.getCmp('edit_form_multilang_calendar_view_type_form').getTopToolbar().items.length==0){
							Ext.getCmp('edit_form_multilang_calendar_view_type_form').getTopToolbar().hide();
						}
					}
				
						
						
			
						if(getAppPriv('edit_form_multilang_calendar_view_type','edit_data_calendar_view_type')==0){
							Ext.getCmp('edit_form_multilang_calendar_view_type_edit_data_calendar_view_type_id').hide();
						}
					},beforerender:function(){}}})},
						event_edit_data_calendar_view_type:function(){
							var globalVariables_edit_form_multilang_calendar_view_type=new Object();
							var panelActionData_edit_form_multilang_calendar_view_type=new Array();
					
							dynamicFormPanelEvent("edit_form_multilang_calendar_view_type","edit_data_calendar_view_type",{panelActionDataArray:panelActionData_edit_form_multilang_calendar_view_type,isRequireConfirmation:"0",confirmMessage:"",isRequireValidation:"1",predefinedValues:"",handlerType:"BACKGROUND",actionHandlerEvent:"",dynPageName:"",winWidth:"0",winHeight:"0",winTitleI18n:"",isNeedConfirmDirtyData:"0",gridPanelName:"",isRequireSuccessTip:"1",isCloseWindowAfterAction:"1",resetFormAfterSuccess:"0",isRequireReloadGrid:"1",afterSuccessJs:"",handlerJs:"",isWorkFlowStart:"0",workFlowProcessKey:"",wfTable:"",rptFormat:"",isHtmlXls:"0",rptNumber:"",rptPageType:"MAIN_PANEL",targetPanelName:"",targetPanelType:"",menuKey:"edit_multilang_calendar_view_type"},globalVariables_edit_form_multilang_calendar_view_type);
						}	
					,edit_form_multilang_calendar_view_type_setStyle:function() {
			try{
			var varStyleArray_edit_form_multilang_calendar_view_type=new Array();
		
			}catch(e){
				exceptionHandling(e,'P10017');
			}
		
					},makeNode:function(name,value){
						var node = document.createElement("input");node.type="hidden";node.name=name;
						node.id=name;node.value=this.URLencode(value);return node;
					},
					insertWithin:function(nodeId, name,value) {
						var node = document.getElementById(nodeId);var newNode = this.makeNode(name,value);node.appendChild(newNode);	
					},
					URLencode:function(sStr) {
						return escape(sStr).replace(/\+/g, "%2B").replace(/\'/g,"%22").replace(/\"/g, "%27").replace(/\//g,"%2F");
					},					
					run_popReport:function(panel_name,rpt_format,rpt_number,width,height,formValues){
						var t_url = "index.cfm?event=rpt.report.report.runReportPage";
						for(var i in formValues){
							t_url = t_url + "&"+ i + "="+this.URLencode(formValues[i]);
						}window.open (t_url) ;
					},
					edit_form_multilang_calendar_view_type_clientSideValidation:function(v_event_name){
						var validData = "{[],[business_unit_key],[if('this.business_unit_key'==''||'this.business_unit_key'==null) return false; return true;],[getResource('business_unit_key_null','edit_form_multilang_calendar_view_type')],[getResource('business_unit_key_null','edit_form_multilang_calendar_view_type')]}";var error_msg = "";
						return formClientSideValidation("edit_form_multilang_calendar_view_type",validData,v_event_name);
					}
					});
						
								
				edit_grid_multilang_calendar_view_type = Ext.extend(Ext.grid.EditorGridPanel,{paramList:null,hideLoadingMask:null,
		
					rowIndex:null,columnIndex:null,is_allow_edit:null,
					myJSON_edit_grid_multilang_calendar_view_type:null,
					edit_grid_multilang_calendar_view_type_rowdblclick:null,
					edit_grid_multilang_calendar_view_type_globalVariable:null,
					constructor:function(_cfg){if(_cfg==null){_cfg=={};this.paramList={}}else{this.paramList=_cfg.paramList;};var edit_grid_multilang_calendar_view_type_jsonParams = new Object();
						Ext.apply(edit_grid_multilang_calendar_view_type_jsonParams,this.paramList);edit_grid_multilang_calendar_view_type_jsonParams.sql_where=" and 1=1";this.hideLoadingMask = true;var edit_grid_multilang_calendar_view_type_loadMask;
						this.is_allow_edit=1;
						this.edit_grid_multilang_calendar_view_type_globalVariable=new Array();
			
						this.myJSON_edit_grid_multilang_calendar_view_type = new Ext.data.JsonStore({
							autoLoad : false,remoteSort : true,id:"myJSON_edit_grid_multilang_calendar_view_type",baseParams:edit_grid_multilang_calendar_view_type_jsonParams,
							root : "query.data",totalProperty : "totalcount",
							listeners:{beforeload:function(_store){
									var globalVariables_edit_grid_multilang_calendar_view_type=new Object();
									_store.baseParams.panel_name="edit_grid_multilang_calendar_view_type";_store.baseParams.currentPanel="edit_grid_multilang_calendar_view_type";
									if(!Ext.getCmp("edit_grid_multilang_calendar_view_type").hideLoadingMask && typeof(edit_grid_multilang_calendar_view_type_loadMask)!="undefined") {
										edit_grid_multilang_calendar_view_type_loadMask.show();
									}},load:function(_store){
										if(Ext.getCmp("edit_grid_multilang_calendar_view_type")){
										Ext.getCmp("edit_grid_multilang_calendar_view_type").setingEditorGridStyle(_store);
		
									Ext.getCmp("edit_grid_multilang_calendar_view_type").hideLoadingMask = false;
									if(typeof(edit_grid_multilang_calendar_view_type_loadMask) != "undefined") {edit_grid_multilang_calendar_view_type_loadMask.hide();}
									if(_store.baseParams.sql_where != null){Ext.getCmp("edit_grid_multilang_calendar_view_type").paramList.sql_where = _store.baseParams.sql_where;
									}else{Ext.getCmp("edit_grid_multilang_calendar_view_type").paramList.sql_where = " and 1=1";}Ext.apply(Ext.getCmp("edit_grid_multilang_calendar_view_type").paramList,_store.baseParams);
									}},exception:function(misc){
										if(edit_grid_multilang_calendar_view_type_loadMask){
											edit_grid_multilang_calendar_view_type_loadMask.hide();
										}
										if(Ext.getCmp("page_edit_multilang_calendar_view_type")){
											Ext.getCmp("page_edit_multilang_calendar_view_type").loadCounter = Ext.getCmp("page_edit_multilang_calendar_view_type").loadCounter - 1;
										}
										exceptionHandling("","P10002");
									}},
									 proxy: new Ext.data.HttpProxy({   
							              url:"index.cfm?event=dynamicEditGrid.editgrid.editgridData&datenow=" + new Date() + "&_rid=" + Math.random(),
							              timeout: ajaxTimeOut
							         }),
									fields:[
		"calendar_view_type_lang_id","calendar_view_type_key","lang_id","lang_name","calendar_view_type_name"]});var selectModel=new Ext.grid.RowSelectionModel({singleSelect: true});
						edit_grid_multilang_calendar_view_type.superclass.constructor.call(this,{
							id:"edit_grid_multilang_calendar_view_type",autoScroll:true,header:true,stripeRows:true,border:false,
							trackMouseOver:true,store:this.myJSON_edit_grid_multilang_calendar_view_type,
				view : new Ext.ux.grid.LockingGridView({
					doRender : function(cs, rs, ds, startRow, colCount, stripe){
						var ts = this.templates, ct = ts.cell, rt = ts.row, last = colCount-1;
						var tstyle = "width:"+this.getTotalWidth()+";";
						var lstyle = "width:"+this.getLockedWidth()+";";
						var buf = [],lbuf = [], cb, lcb, c, p = {}, rp = {tstyle: tstyle}, r;
						for(var j = 0, len = rs.length; j < len; j++){
							r = rs[j]; cb = [];lcb = [];var rowIndex = (j+startRow);
							for(var i = 0; i < colCount; i++){c = cs[i];p.id = c.id;p.css = (i === 0 ? "x-grid3-cell-first " : (i == last ? "x-grid3-cell-last " : ""))+(this.cm.config[i].cellCls ? ""+ this.cm.config[i].cellCls : "");
								p.attr = p.cellAttr = "";p.value = c.renderer(r.data[c.name], p, r, rowIndex, i, ds);p.style = c.style;
		if( c.name == 'calendar_view_type_lang_id' || c.name == 'lang_id' || c.name == 'calendar_view_type_name'){p.css += " x_editorgrid_do_render "; }
								if(Ext.isEmpty(p.value)){p.value = " ";}if(this.markDirty && r.dirty && Ext.isDefined(r.modified[c.name])){p.css += " x-grid3-dirty-cell";}if(c.locked){lcb[lcb.length] = ct.apply(p);}else{cb[cb.length] = ct.apply(p);}
							}var alt = [];
							if(stripe && ((rowIndex+1) % 2 === 0)){alt[0] = "x-grid3-row-alt";}
							if(r.dirty){alt[1] = " x-grid3-dirty-row";}
							rp.cols = colCount;
							if(this.getRowClass){alt[2] = this.getRowClass(r, rowIndex, rp, ds);}
							rp.alt = alt.join(" ");rp.cells = cb.join("");rp.tstyle = tstyle;buf[buf.length] =  rt.apply(rp);rp.cells = lcb.join(" ");rp.tstyle = lstyle;lbuf[lbuf.length] = rt.apply(rp);}	return [buf.join(""), lbuf.join("")];	}}),
		title:getResource('edit_multilang','calendar_view_type'),sm:selectModel,
								tbar:new Ext.Toolbar({enableOverflow : true,id:"edit_grid_multilang_calendar_view_type_tbar_btn",items:[	
				]}),
							listeners:{
								"cellclick":function(grid,rowIndex,columnIndex,e){
									this.columnIndex=columnIndex;this.rowIndex=rowIndex;
								},
								"rowclick":function(_grid){
									var selectedRow = _grid.getSelectionModel().getSelections();
									if(selectedRow.length == 1){
							
								if(Ext.getCmp("edit_grid_multilang_calendar_view_type_tbar_btn")){
									Ext.getCmp("edit_grid_multilang_calendar_view_type_tbar_btn").doLayout();
								}
							}},"beforerender":function(){},"resize":function(){
				if(Ext.getCmp("edit_grid_multilang_calendar_view_type_tbar_btn")){
					Ext.getCmp("edit_grid_multilang_calendar_view_type_tbar_btn").doLayout();
				}
		},"render":function(_grid){edit_grid_multilang_calendar_view_type_loadMask = new Ext.LoadMask(Ext.getCmp("edit_grid_multilang_calendar_view_type").getEl(), {msg:getResource("loading","")});
				if(show_page_designer_shortcut == 1){
					var edit_grid_multilang_calendar_view_type_pdBtn = dynmaicWebPageDesign("edit_multilang_calendar_view_type","edit_grid_multilang_calendar_view_type");
					if(typeof(tbar_edit_grid_multilang_calendar_view_type)!="undefined"){
						tbar_edit_grid_multilang_calendar_view_type.add("->");
						tbar_edit_grid_multilang_calendar_view_type.add(edit_grid_multilang_calendar_view_type_pdBtn);
						tbar_edit_grid_multilang_calendar_view_type.doLayout();
					}else{
						_grid.getTopToolbar().add("->");
						_grid.getTopToolbar().add(edit_grid_multilang_calendar_view_type_pdBtn);
					}
					_grid.getTopToolbar().doLayout();
				}else{
					if(_grid.getTopToolbar().items.length==0){
						_grid.getTopToolbar().hide();
					}
				}
			if(getAppPriv('edit_grid_multilang_calendar_view_type','save')==0){
								Ext.getCmp('edit_grid_multilang_calendar_view_type').is_allow_edit=0;
					}
				if(typeof(tbar_edit_grid_multilang_calendar_view_type)!="undefined"){
					tbar_edit_grid_multilang_calendar_view_type.doLayout();
				}
			},"beforeedit":function(e){if(e.grid.is_allow_edit==0){
										e.grid.getColumnModel().setEditable(e.column,false);}else{var _value='';var flag;}if(typeof(e.record.data.allowedit) != 'undefined' && e.record.data.allowedit == 0){return false;}if(e.value){if(typeof(e.value)!= 'number' && typeof(e.value) != 'boolean'&& typeof(e.value) != 'object'){e.record.data[e.field]=e.value.replace(new RegExp('&lt;', 'g'),'<').replace(new RegExp('&gt;', 'g'),'>');}}},"afteredit":this.event_save},bbar : new Ext.PagingToolbar({id:"edit_grid_multilang_calendar_view_type_page_toolbar_id",
							displayInfo : true,pageSize : 10,store : this.myJSON_edit_grid_multilang_calendar_view_type,dummy : true}),colModel:new Ext.ux.grid.LockingColumnModel([
							{header:getResource('calendar_view_type_lang_id','edit_grid_multilang_calendar_view_type'),width:120,hidden:true,
								resizable:false,sortable:false,hideable:true,
								menuDisabled:false,dataIndex:"calendar_view_type_lang_id" ,editor: new Ext.form.TextField({xtype:"textfield",allowBlank: true,dummy: true})},
							{header:getResource('calendar_view_type_key','edit_grid_multilang_calendar_view_type'),width:120,hidden:true,
								resizable:false,sortable:false,hideable:true,
								menuDisabled:false,dataIndex:"calendar_view_type_key" },
							{header:getResource('lang_id','edit_grid_multilang_calendar_view_type'),width:120,hidden:true,
								resizable:false,sortable:false,hideable:true,
								menuDisabled:false,dataIndex:"lang_id" ,editor: new Ext.form.TextField({xtype:"textfield",allowBlank: true,dummy: true})},
							{header:getResource('lang_name','edit_grid_multilang_calendar_view_type'),width:120,hidden:false,
								resizable:false,sortable:false,hideable:true,
								menuDisabled:false,dataIndex:"lang_name" },
							{header:getResource('calendar_view_type_name','edit_grid_multilang_calendar_view_type'),width:120,hidden:false,
								resizable:false,sortable:false,hideable:true,
								menuDisabled:false,dataIndex:"calendar_view_type_name" ,editor: new Ext.form.TextField({xtype:"textfield",allowBlank: true,dummy: true})}])})},listeners: {afteredit:function(e) {
									if(typeof(e.value)=="object"){
											if(e.value instanceof Date){
												Ext.getCmp("edit_grid_multilang_calendar_view_type").store.getAt(e.row).data[e.field] = e.value.format("Y-m-d");
											}
									}
									var _store = Ext.getCmp("edit_grid_multilang_calendar_view_type").store;
									Ext.getCmp("edit_grid_multilang_calendar_view_type").setingEditorGridStyle(_store);
									Ext.getCmp("edit_grid_multilang_calendar_view_type").getSelectionModel().selectRow(e.row);
								},columnmove : function(oldIndex,newIndex){if(Ext.getCmp("edit_grid_multilang_calendar_view_type")){Ext.getCmp("edit_grid_multilang_calendar_view_type").setingEditorGridStyle(Ext.getCmp("edit_grid_multilang_calendar_view_type").store)}},afterrender:function(g){var valueList = "";if(valueList!=""){var dataIndexArray = new Array();dataIndexArray = valueList.split(",");initLockGridColumn(g,dataIndexArray);}}},setingEditorGridStyle:function(_store) {
						},
				event_save:function(e){
					globalVariables_edit_grid_multilang_calendar_view_type=new Object();
					panelActionData_edit_grid_multilang_calendar_view_type=new Array();
				
						dynamicGridPanelEvent(e,"edit_grid_multilang_calendar_view_type","save",{panelActionDataArray:panelActionData_edit_grid_multilang_calendar_view_type,winHeight:0,winWidth:0,isRequireGridRowSelection:"0",columnList:"calendar_view_type_lang_id,calendar_view_type_key,lang_id,lang_name,calendar_view_type_name",handlerType:"EDITGRID_SAVE",isUseDynamicPanel:"0",isRequireConfirmation:"0",isRequireReloadGrid:"0",confirmMessage:"",predefinedValues:"",gridPanelName:"",saveType:"EDITGRID",isCloseWindowAfterAction:"0",isRequireSuccessTip:"1",isWorkFlowStart:"0",workflowProcessKey:"",wfTable:"",dynPageName:"",actionHandlerEvent:"",isDestroyWin:"1",isNeedConfirmDirtyData:"0",titleI18nKey:"",afterSuccessJs:"",handlerJs:"",rptFormat:"",isHtmlXls:"0",rptNumber:"",rptPageType:"MAIN_PANEL",targetPanelName:"",targetPanelType:"",menuKey:"edit_multilang_calendar_view_type",menuId:"0"},globalVariables_edit_grid_multilang_calendar_view_type);
					}
				
				,URLencode:function(sStr){ return escape(sStr).replace(/\+/g, '%2B').replace(/\"/g,'%22').replace(/\'/g, '%27').replace(/\//g,'%2F');	},
				run_popReport:function(panel_name,rpt_format,rpt_number,width,height,formValues){var t_url = 'index.cfm?event=rpt.report.report.runReportPage';for(var i in formValues){t_url = t_url + '&'+ i + '='+URLencode(formValues[i]);}window.open (t_url) ;}	
								
				});
		
						
				page_edit_multilang_calendar_view_type = Ext.extend(Ext.Panel,{
					paramList:null,
					loadCounter:null,
		
							edit_form_multilang_calendar_view_type_loadFormData:function(){
								var paramList = Ext.getCmp('edit_form_multilang_calendar_view_type_form').paramList;
							
								paramList.panel_name='edit_form_multilang_calendar_view_type';
								var action = arguments[0];
								Ext.Ajax.request({
					           		url:'index.cfm?event=dynamicGenerateScript.dynamicGenerateScript.dynamicGetAdvFormData&_dc='+new Date() + '&_rid=' + Math.random(),
					                method:'POST',
					                timeout : ajaxTimeOut,
					                params:paramList,
					                failure:function(response,options){
										if(Ext.getCmp('page_edit_multilang_calendar_view_type')){
											Ext.getCmp('page_edit_multilang_calendar_view_type').loadCounter = Ext.getCmp('page_edit_multilang_calendar_view_type').loadCounter - 1;
										}
										if(typeof(Ext.getCmp('edit_form_multilang_calendar_view_type_form'))!='undefined'){
											exceptionHandling('','P10013');
										}
					                },
					                success:function(response,options){
					                   if(typeof(Ext.getCmp('edit_form_multilang_calendar_view_type_form'))!='undefined'){
					                   try{
								           var responseText = Ext.util.JSON.decode(response.responseText).jsonObject;
								           var controlTypeList = Ext.util.JSON.decode(response.responseText).success_msg;
								           loadFormData('edit_form_multilang_calendar_view_type',action,responseText,controlTypeList);
						 			   Ext.getCmp('edit_form_multilang_calendar_view_type_form').edit_form_multilang_calendar_view_type_setStyle();
						 
										if(null!=maskObj&&maskObj!=undefined){
											Ext.getCmp('page_edit_multilang_calendar_view_type').loadCounter=Ext.getCmp('page_edit_multilang_calendar_view_type').loadCounter-1;
											if(Ext.getCmp('page_edit_multilang_calendar_view_type').loadCounter<=0){
												maskObj.hide();	
												Ext.getCmp('page_edit_multilang_calendar_view_type').loadCounter=0;
											}
										}
										var globalVariables_edit_form_multilang_calendar_view_type=new Object();
										
										}catch(e){
					                       if(Ext.getCmp('page_edit_multilang_calendar_view_type')){
												Ext.getCmp('page_edit_multilang_calendar_view_type').loadCounter = Ext.getCmp('page_edit_multilang_calendar_view_type').loadCounter - 1;
										   }
										   exceptionHandling(e,'P10015');
					     			   }
					     			}
							 		}
						  		});
						  	},
					  	
					constructor:function(_cfg){
							if(_cfg==null){_cfg=={};this.paramList={}}else{this.paramList = _cfg.paramList;};
							Ext.apply(this,_cfg);
						page_edit_multilang_calendar_view_type.superclass.constructor.call(this,{
							border:false,
							autoScroll:false,	
							id:'page_edit_multilang_calendar_view_type',
							anchor:'100% 100%',
							layout:'anchor',
							items:[
								
		
							{
								anchor:'100% 50%',border:false,
								layout:"fit",
								panel_name:"edit_form_multilang_calendar_view_type",
								panel_type:"advformpanel",
								id:"edit_form_multilang_calendar_view_type_parentPanel",
								items:[new edit_form_multilang_calendar_view_type({paramList:this.paramList})]
						},
							{
								anchor:'100% 50%',border:false,
								layout:"fit",
								panel_name:"edit_grid_multilang_calendar_view_type",
								panel_type:"editorgridpanel",
								id:"edit_grid_multilang_calendar_view_type_parentPanel",
								items:[new edit_grid_multilang_calendar_view_type({paramList:this.paramList})]		
						}]
						})
					},
					listeners:{
						beforerender:function(_grid){
							var winObj = eval(Ext.getCmp(Ext.getCmp('page_edit_multilang_calendar_view_type').paramList.win_id));
							if(typeof(winObj)!='undefined'){
								maskObj = new Ext.LoadMask(winObj.getEl(), {msg:getResource('loading','')});
								maskObj.show();
							}
						},
						render:function(_grid){
							Ext.getCmp('page_edit_multilang_calendar_view_type').loadCounter=0;
		
								if(getAppPriv('edit_form_multilang_calendar_view_type','')){
									Ext.getCmp('page_edit_multilang_calendar_view_type').loadCounter = Ext.getCmp('page_edit_multilang_calendar_view_type').loadCounter+1;
								}
							
									if(getAppPriv('edit_grid_multilang_calendar_view_type','')){
										Ext.getCmp('page_edit_multilang_calendar_view_type').loadCounter = Ext.getCmp('page_edit_multilang_calendar_view_type').loadCounter+1;
									}
							
				if(Ext.getCmp('page_edit_multilang_calendar_view_type').loadCounter==0){
					maskObj.hide();	
					Ext.getCmp('page_edit_multilang_calendar_view_type').loadCounter=0;
				} 
		
									
						
									if(getAppPriv('edit_form_multilang_calendar_view_type','')){
										 Ext.getCmp('page_edit_multilang_calendar_view_type').edit_form_multilang_calendar_view_type_loadFormData();
									}
							
											
						
							if(getAppPriv('edit_grid_multilang_calendar_view_type','')){
					
							Ext.getCmp('edit_grid_multilang_calendar_view_type').getStore().removeAll();
							var baseParams = Ext.getCmp('edit_grid_multilang_calendar_view_type').getStore().baseParams;
							var paramList = Ext.getCmp('edit_grid_multilang_calendar_view_type').paramList;
							Ext.apply(baseParams,paramList);
							baseParams.sql_where=' and 1=1';
							baseParams.currentPanel='edit_grid_multilang_calendar_view_type';
							baseParams.panel_name='edit_grid_multilang_calendar_view_type';
							baseParams.pname='edit_grid_multilang_calendar_view_type';
							
								Ext.getCmp('edit_grid_multilang_calendar_view_type').getStore().baseParams=baseParams;
									if(typeof(Ext.getCmp('edit_grid_multilang_calendar_view_type_simplepanel_criteriadata_combo')) == 'undefined') {
							Ext.getCmp('edit_grid_multilang_calendar_view_type').getStore().load();
										}else{
											Ext.getCmp('edit_grid_multilang_calendar_view_type_simplepanel_criteriadata_combo').getStore().reload();
										}		
										Ext.getCmp('edit_grid_multilang_calendar_view_type').getStore().on('load',function(){
												if(Ext.getCmp('page_edit_multilang_calendar_view_type')){
												Ext.getCmp('page_edit_multilang_calendar_view_type').loadCounter=Ext.getCmp('page_edit_multilang_calendar_view_type').loadCounter-1;
												if(Ext.getCmp('page_edit_multilang_calendar_view_type').loadCounter<=0){
													maskObj.hide();	
													Ext.getCmp('page_edit_multilang_calendar_view_type').loadCounter=0;
												}
												}
										});
										
							
							}
					
						},
						afterrender:function(_grid){
		
					if(getAppPriv('edit_form_multilang_calendar_view_type','')==0){
				
						if(typeof(Ext.getCmp('edit_form_multilang_calendar_view_type_form'))!='undefined'){
							Ext.getCmp('edit_form_multilang_calendar_view_type_form').destroy();
							if(typeof(Ext.getCmp('edit_form_multilang_calendar_view_type_parentPanel'))!='undefined'){
								var parent = Ext.getCmp('edit_form_multilang_calendar_view_type_parentPanel').ownerCt;
								parent.remove(Ext.getCmp('edit_form_multilang_calendar_view_type_parentPanel'));
								parent.doLayout();
							}
						}
					}
					if(getAppPriv('edit_grid_multilang_calendar_view_type','')==0){
				
						if(typeof(Ext.getCmp('edit_grid_multilang_calendar_view_type'))!='undefined'){
							Ext.getCmp('edit_grid_multilang_calendar_view_type').destroy();
							if(typeof(Ext.getCmp('edit_grid_multilang_calendar_view_type_parentPanel'))!='undefined'){
								var parent = Ext.getCmp('edit_grid_multilang_calendar_view_type_parentPanel').ownerCt;
								parent.remove(Ext.getCmp('edit_grid_multilang_calendar_view_type_parentPanel'));
								parent.doLayout();
							}
						}
					}},
					destroy:function(){
		
					}		
				
					}
				})
		


			picklist_form_panel_edit_sys_agent_menu_single_menu_name = Ext.extend(Ext.Window,{
				picklistTree:null,
				paramList:null,
				constructor:function(_cfg){
					if(_cfg==null){_cfg=={};this.paramList={}}else{this.paramList=_cfg.paramList;};
						if((this.paramList.sourcePage).toLowerCase()=="searchpanel"){
							if(typeof(Ext.getCmp("form_panel_edit_sys_agent_menu_single"))!="undefined"){
								Ext.apply(this.paramList,Ext.getCmp("form_panel_edit_sys_agent_menu_single").paramList);
							}
						}
						this.paramList.picklistPanel="form_panel_edit_sys_agent_menu_single";
						this.paramList.field_name="menu_name";	
						this.paramList.sql_where=" and 1=1";
						Ext.apply(this,_cfg);	
					
					this.picklistTree = new Ext.ux.tree.FilterTreeGrid({
						id: "picklistTree_form_panel_edit_sys_agent_menu_single_menu_name",
						width: 585,
						height: 568,
						enableDD: false,
						enableSort: false,
						cls:"picklistTree_cls",
						border: false,
						columns:[{
							header:getResource("title","PickListTree"),
							dataIndex: "text",
							width: 263
						}],
						loader: new Ext.tree.TreeLoader({
							url: "index.cfm?event=picklistTree.general.picklistTreeData&now=" + new Date(),
							baseParams:this.paramList
						}),
						listeners:{
							"click": this.onNodeClickEvent,
							"afterrender":function(){
								Ext.getCmp("picklistTree_form_panel_edit_sys_agent_menu_single_menu_name").setWidth(Ext.getCmp("picklist_form_panel_edit_sys_agent_menu_single_menu_name").getWidth()-14+_picklist_width_offset);
								Ext.getCmp("picklistTree_form_panel_edit_sys_agent_menu_single_menu_name").setHeight(Ext.getCmp("picklist_form_panel_edit_sys_agent_menu_single_menu_name").getHeight()-32-_picklist_height_offset);
		
							}
						}
					});
					picklist_form_panel_edit_sys_agent_menu_single_menu_name.superclass.constructor.call(this,{
						constrainHeader:true,
						id:"picklist_form_panel_edit_sys_agent_menu_single_menu_name",
						setZIndex:Ext.emptyFn,
						width:(600 > window.parent.document.body.clientWidth ? window.parent.document.body.clientWidth : 600),
						height:(600 > window.parent.document.body.clientHeight ? window.parent.document.body.clientHeight : 600),
						title: getResource("menu_name","form_panel_edit_sys_agent_menu_single_picklist"),
						maximizable:false,
						resizable:true,
						modal:true,
						listeners:{
							resize:function(_w,_width,_height,_rawWidth,_rawHeight){
								Ext.getCmp("picklistTree_form_panel_edit_sys_agent_menu_single_menu_name").setWidth(_width-14+_picklist_width_offset);
								Ext.getCmp("picklistTree_form_panel_edit_sys_agent_menu_single_menu_name").setHeight(_height-32-_picklist_height_offset);
							},
							beforedestroy:function() {
								Ext.getCmp("picklistTree_form_panel_edit_sys_agent_menu_single_menu_name").getSelectionModel().select = Ext.emptyFn;
							}
						},
						items:[this.picklistTree]
					})
				},
				onNodeClickEvent:function(node,e){
					var lookupbox = Ext.getCmp("form_panel_edit_sys_agent_menu_single_menu_name_id");
					var paramList1 = Ext.getCmp("picklist_form_panel_edit_sys_agent_menu_single_menu_name").paramList;
					var paramList = new Object();
					Ext.apply(paramList,paramList1);
					if((paramList.sourcePage).toLowerCase()=="searchpanel"){
						lookupbox = Ext.getCmp(paramList.cid);
					}
					var value = lookupbox.getValue();
					if(node.attributes.is_enable == "1"){
						if((paramList.sourcePage).toLowerCase()=="searchpanel"){
							if((paramList.needDelimiter)==1&&value!=""){
								lookupbox.setValue(Ext.util.Format.htmlDecode(lookupbox.getValue()+","+node.attributes.menu_key,text));
							}else{
								lookupbox.setValue(Ext.util.Format.htmlDecode(node.attributes.menu_key,text));
							}
							lookupbox.focus();
							lookupbox.fireEvent("keyUp");
						}else if((paramList.sourcePage).toLowerCase()=="formpanel"){
			
					value = Ext.getCmp("form_panel_edit_sys_agent_menu_single__menu_key_id").getValue();
					if("" == ""||value==""){
						Ext.getCmp("form_panel_edit_sys_agent_menu_single__menu_key_id").setValue(Ext.util.Format.htmlDecode(node.attributes.menu_key));
					}else{
						Ext.getCmp("form_panel_edit_sys_agent_menu_single__menu_key_id").setValue(Ext.util.Format.htmlDecode(value+""+node.attributes.menu_key));
					}
				
					value = Ext.getCmp("form_panel_edit_sys_agent_menu_single_menu_name_id").getValue();
					if("" == ""||value==""){
						Ext.getCmp("form_panel_edit_sys_agent_menu_single_menu_name_id").setValue(Ext.util.Format.htmlDecode(node.attributes.text));
					}else{
						Ext.getCmp("form_panel_edit_sys_agent_menu_single_menu_name_id").setValue(Ext.util.Format.htmlDecode(value+""+node.attributes.text));
					}
				
				var flag = 1;		
				var paramList1 = Ext.getCmp("picklist_form_panel_edit_sys_agent_menu_single_menu_name").paramList;
				var formValues = new Object();
				Ext.apply(formValues,paramList1);
			
					lookupbox.fireEvent("focus");
				}else if((paramList.sourcePage).toLowerCase()=="editgrid"){
					var myGrid,edi;
					if(typeof(paramList.editgrid_id)!="undefined"){
						myGrid = eval(Ext.getCmp(paramList.editgrid_id));
						myGrid.startEditing(paramList.editorrow,paramList.editorcol);
						editor =  myGrid.activeEditor;
			
					value = editor.getValue();
					if("" == ""||value==""){
						editor.setValue(Ext.util.Format.htmlDecode(node.attributes.menu_key));
					}else{
						editor.setValue(Ext.util.Format.htmlDecode(value+""+node.attributes.menu_key));
					}		
				
					value = editor.getValue();
					if("" == ""||value==""){
						editor.setValue(Ext.util.Format.htmlDecode(node.attributes.text));
					}else{
						editor.setValue(Ext.util.Format.htmlDecode(value+""+node.attributes.text));
					}		
				
					}
				}
		
						if(paramList.sourcePage.toLowerCase()=="formpanel"){
							Ext.getCmp("form_panel_edit_sys_agent_menu_single_form").form_panel_edit_sys_agent_menu_single_setStyle();
						}
						Ext.getCmp("picklist_form_panel_edit_sys_agent_menu_single_menu_name").close();
			
				}
				}
			});
		

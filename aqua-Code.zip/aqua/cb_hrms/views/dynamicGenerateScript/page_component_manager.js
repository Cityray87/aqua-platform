
								
				component_manager_panel = Ext.extend(Ext.form.FormPanel,{
					paramList:null,
					component_manager_panel_globalVariable:null,
					constructor:function(_cfg){
						if(_cfg==null){_cfg=={};this.paramList={}}else{this.paramList=_cfg.paramList;};
						this.component_manager_panel_globalVariable=new Array();
		
					this.paramList.panel_name="component_manager_panel";
					component_manager_panel.superclass.constructor.call(this,{
						autoScroll:true,id:"component_manager_panel_form",
						labelAlign:"right",padding:10,
						labelWidth:100,fileUpload:true,enctype:"multipart/form-data",border:false,
						bodyBorder:false,anchor:"100% 100%",items:[
		{ xtype:'panel',layout:'form',border:false,items:[createPicklistCompoment("component_manager_panel","target_table",{isVisibleRender:"1",picklistType:"COMBOBOX",fieldI18nKey:getResource('target_table','component_manager_panel'),fieldValue:"",comboboxKeyColumn:"table_name",comboboxValueColumn:"table_name",isNeedConfirmDirtyData:"0",editGridId:"",isNeedPicklistFilter:"0",isEditable:true,picklist_redirect_page:"",redirect_page_panel_list:"",redirect_page_title:"",redirect_page_height:"600",redirect_page_width:"800",edit_mode:"0",header_js:"",footer_js:""},this.component_manager_panel_globalVariable,"")]}],tbar:new Ext.Toolbar({enableOverflow : true,id:'component_manager_panel_tbar_btn',items:[{ text:getResource('component_manager_panel_i18n','component_manager_panel'),icon:'../ext/resources/images/icons/add.gif',id:'component_manager_panel_component_manager_generate_id',scope:this,
								handler:function(){this.event_component_manager_generate();}}]}),listeners:{afterlayout:function(){},resize:function(){if(Ext.getCmp('component_manager_panel_tbar_btn')){Ext.getCmp('component_manager_panel_tbar_btn').doLayout()}},afterrender:function(){
					if(show_page_designer_shortcut == 1){
						var component_manager_panel_pdBtn = dynmaicWebPageDesign('component_manager','component_manager_panel');
						Ext.getCmp('component_manager_panel_form').getTopToolbar().add('->');
						Ext.getCmp('component_manager_panel_form').getTopToolbar().add(component_manager_panel_pdBtn);Ext.getCmp('component_manager_panel_form').getTopToolbar().doLayout();
					}else{
						if(Ext.getCmp('component_manager_panel_form').getTopToolbar().items.length==0){
							Ext.getCmp('component_manager_panel_form').getTopToolbar().hide();
						}
					}
				
						
						
			
						if(getAppPriv('component_manager_panel','component_manager_generate')==0){
							Ext.getCmp('component_manager_panel_component_manager_generate_id').hide();
						}
					},beforerender:function(){}}})},
						event_component_manager_generate:function(){
							var globalVariables_component_manager_panel=new Object();
							var panelActionData_component_manager_panel=new Array();
					
							dynamicFormPanelEvent("component_manager_panel","component_manager_generate",{panelActionDataArray:panelActionData_component_manager_panel,isRequireConfirmation:"0",confirmMessage:"getResource('component_manager_comfirm_i18n','')",isRequireValidation:"1",predefinedValues:"",handlerType:"BACKGROUND",actionHandlerEvent:"dynamicGenerateScript.dynamicGenerateScript.dynamicComponentManager",dynPageName:"",winWidth:"0",winHeight:"0",winTitleI18n:"",isNeedConfirmDirtyData:"0",gridPanelName:"",isRequireSuccessTip:"1",isCloseWindowAfterAction:"0",resetFormAfterSuccess:"0",isRequireReloadGrid:"0",afterSuccessJs:"",handlerJs:"",isWorkFlowStart:"0",workFlowProcessKey:"",wfTable:"",rptFormat:"",isHtmlXls:"0",rptNumber:"",rptPageType:"MAIN_PANEL",targetPanelName:"",targetPanelType:"",menuKey:"component_manager"},globalVariables_component_manager_panel);
						}	
					,component_manager_panel_setStyle:function() {
			try{
			var varStyleArray_component_manager_panel=new Array();
		
			}catch(e){
				exceptionHandling(e,'P10017');
			}
		
					},makeNode:function(name,value){
						var node = document.createElement("input");node.type="hidden";node.name=name;
						node.id=name;node.value=this.URLencode(value);return node;
					},
					insertWithin:function(nodeId, name,value) {
						var node = document.getElementById(nodeId);var newNode = this.makeNode(name,value);node.appendChild(newNode);	
					},
					URLencode:function(sStr) {
						return escape(sStr).replace(/\+/g, "%2B").replace(/\'/g,"%22").replace(/\"/g, "%27").replace(/\//g,"%2F");
					},					
					run_popReport:function(panel_name,rpt_format,rpt_number,width,height,formValues){
						var t_url = "index.cfm?event=rpt.report.report.runReportPage";
						for(var i in formValues){
							t_url = t_url + "&"+ i + "="+this.URLencode(formValues[i]);
						}window.open (t_url) ;
					},
					component_manager_panel_clientSideValidation:function(v_event_name){
						var validData = "";var error_msg = "";
						return formClientSideValidation("component_manager_panel",validData,v_event_name);
					}
					});
						
				page_component_manager = Ext.extend(Ext.Panel,{
					paramList:null,
					loadCounter:null,
		
					constructor:function(_cfg){
							if(_cfg==null){_cfg=={};this.paramList={}}else{this.paramList = _cfg.paramList;};
							Ext.apply(this,_cfg);
						page_component_manager.superclass.constructor.call(this,{
							border:false,
							autoScroll:false,	
							id:'page_component_manager',
							anchor:'100% 100%',
							layout:'anchor',
							items:[
								
		
							{
								anchor:'100% 100%',border:false,
								layout:"fit",
								panel_name:"component_manager_panel",
								panel_type:"advformpanel",
								id:"component_manager_panel_parentPanel",
								items:[new component_manager_panel({paramList:this.paramList})]
						}]
						})
					},
					listeners:{
						beforerender:function(_grid){
							var winObj = eval(Ext.getCmp(Ext.getCmp('page_component_manager').paramList.win_id));
							if(typeof(winObj)!='undefined'){
								maskObj = new Ext.LoadMask(winObj.getEl(), {msg:getResource('loading','')});
								maskObj.show();
							}
						},
						render:function(_grid){
							Ext.getCmp('page_component_manager').loadCounter=0;
		
				if(Ext.getCmp('page_component_manager').loadCounter==0){
					maskObj.hide();	
					Ext.getCmp('page_component_manager').loadCounter=0;
				} 
		
							if(getAppPriv('component_manager_panel','')){
								Ext.getCmp('component_manager_panel_form').getForm().reset();
								var baseParams = new Object();
								var paramList = Ext.getCmp('component_manager_panel_form').paramList;
								Ext.apply(baseParams,paramList);
								baseParams.panel_name='component_manager_panel';
								baseParams.currentPanel='component_manager_panel';
								baseParams.pname='component_manager_panel';
								Ext.Ajax.request({
									params:baseParams,
									method: 'POST',
									timeout:ajaxTimeOut,
									url: 'index.cfm?event=dynamicGenerateScript.dynamicGenerateScript.dynamicGetPanelComboData&datenow=' + new Date() + '&_rid=' + Math.random(),
									failure: function(response,options){
									   if(!Ext.Msg.isVisible()){
										   if (maskObj) {
										       maskObj.hide();
					                       }
					                       if(Ext.getCmp('page_component_manager')){
												Ext.getCmp('page_component_manager').loadCounter = Ext.getCmp('page_component_manager').loadCounter - 1;
										   }
										   if(typeof(Ext.getCmp('component_manager_panel_form'))!='undefined'){
						                       Ext.Msg.show({
												   title : getResource('warning', ''),
												   msg : getResource('requestException', ''),
												   buttons : Ext.Msg.OK,
												   icon : Ext.MessageBox.WARNING
								               });
							               }
							           }
									},
									success: function(response,options){
										if(typeof(Ext.getCmp('component_manager_panel_form'))!='undefined'){
										try {
										var responseText = Ext.util.JSON.decode(response.responseText);
										//Ext.MessageBox.hide();
						
									Ext.getCmp("component_manager_panel_target_table_id").getStore().loadData(responseText.jsonObject.target_table);
								
								   Ext.getCmp('component_manager_panel_form').doLayout();
							
										
										
										} catch (e) {
											if(Ext.getCmp('page_component_manager')){
												Ext.getCmp('page_component_manager').loadCounter = Ext.getCmp('page_component_manager').loadCounter - 1;
											}
											exceptionHandling(e,'P10016');
										}
										}
									 }
								});
							}
						
							if(null!=maskObj&&maskObj!=undefined){
								if(Ext.getCmp('page_component_manager').loadCounter<=0){
									maskObj.hide();	
									Ext.getCmp('page_component_manager').loadCounter=0;
								}
							}	
						
						},
						afterrender:function(_grid){
		
					if(getAppPriv('component_manager_panel','')==0){
				
						if(typeof(Ext.getCmp('component_manager_panel_form'))!='undefined'){
							Ext.getCmp('component_manager_panel_form').destroy();
							if(typeof(Ext.getCmp('component_manager_panel_parentPanel'))!='undefined'){
								var parent = Ext.getCmp('component_manager_panel_parentPanel').ownerCt;
								parent.remove(Ext.getCmp('component_manager_panel_parentPanel'));
								parent.doLayout();
							}
						}
					}},
					destroy:function(){
		
					}		
				
					}
				})
		

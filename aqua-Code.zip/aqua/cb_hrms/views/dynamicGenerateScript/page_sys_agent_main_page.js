
								
				grid_sys_agent = Ext.extend(Ext.grid.EditorGridPanel,{paramList:null,hideLoadingMask:null,
		
					rowIndex:null,columnIndex:null,is_allow_edit:null,
					myJSON_grid_sys_agent:null,
					grid_sys_agent_rowdblclick:null,
					grid_sys_agent_globalVariable:null,
					constructor:function(_cfg){if(_cfg==null){_cfg=={};this.paramList={}}else{this.paramList=_cfg.paramList;};var grid_sys_agent_jsonParams = new Object();
						Ext.apply(grid_sys_agent_jsonParams,this.paramList);grid_sys_agent_jsonParams.sql_where=" and 1=1";this.hideLoadingMask = true;var grid_sys_agent_loadMask;
						this.is_allow_edit=1;
						this.grid_sys_agent_globalVariable=new Array();
		this.grid_sys_agent_rowdblclick=function(e){
					if(!this.getColumnModel().isCellEditable(this.columnIndex,this.rowIndex)||this.is_allow_edit==0)
					{if(!Ext.getCmp("event_grid_sys_agent_edit_record_grid_sys_agent").disabled&&!Ext.getCmp("event_grid_sys_agent_edit_record_grid_sys_agent").hidden)this.event_grid_sys_agent_edit_record();}};	
						this.myJSON_grid_sys_agent = new Ext.data.JsonStore({
							autoLoad : false,remoteSort : true,id:"myJSON_grid_sys_agent",baseParams:grid_sys_agent_jsonParams,
							root : "query.data",totalProperty : "totalcount",
							listeners:{beforeload:function(_store){
									var globalVariables_grid_sys_agent=new Object();
									_store.baseParams.panel_name="grid_sys_agent";_store.baseParams.currentPanel="grid_sys_agent";
									if(!Ext.getCmp("grid_sys_agent").hideLoadingMask && typeof(grid_sys_agent_loadMask)!="undefined") {
										grid_sys_agent_loadMask.show();
									}},load:function(_store){
										if(Ext.getCmp("grid_sys_agent")){
										Ext.getCmp("grid_sys_agent").setingEditorGridStyle(_store);
		
									Ext.getCmp("grid_sys_agent").hideLoadingMask = false;
									if(typeof(grid_sys_agent_loadMask) != "undefined") {grid_sys_agent_loadMask.hide();}
									if(_store.baseParams.sql_where != null){Ext.getCmp("grid_sys_agent").paramList.sql_where = _store.baseParams.sql_where;
									}else{Ext.getCmp("grid_sys_agent").paramList.sql_where = " and 1=1";}Ext.apply(Ext.getCmp("grid_sys_agent").paramList,_store.baseParams);
									}},exception:function(misc){
										if(grid_sys_agent_loadMask){
											grid_sys_agent_loadMask.hide();
										}
										if(Ext.getCmp("page_sys_agent_main_page")){
											Ext.getCmp("page_sys_agent_main_page").loadCounter = Ext.getCmp("page_sys_agent_main_page").loadCounter - 1;
										}
										exceptionHandling("","P10002");
									}},
									 proxy: new Ext.data.HttpProxy({   
							              url:"index.cfm?event=dynamicEditGrid.editgrid.editgridData&datenow=" + new Date() + "&_rid=" + Math.random(),
							              timeout: ajaxTimeOut
							         }),
									fields:[
		"id","agent_user","start_date","end_date"]});var selectModel=new Ext.grid.RowSelectionModel({singleSelect: true});
						grid_sys_agent.superclass.constructor.call(this,{
							id:"grid_sys_agent",autoScroll:true,header:true,stripeRows:true,border:false,
							trackMouseOver:true,store:this.myJSON_grid_sys_agent,
				view : new Ext.ux.grid.LockingGridView({
					doRender : function(cs, rs, ds, startRow, colCount, stripe){
						var ts = this.templates, ct = ts.cell, rt = ts.row, last = colCount-1;
						var tstyle = "width:"+this.getTotalWidth()+";";
						var lstyle = "width:"+this.getLockedWidth()+";";
						var buf = [],lbuf = [], cb, lcb, c, p = {}, rp = {tstyle: tstyle}, r;
						for(var j = 0, len = rs.length; j < len; j++){
							r = rs[j]; cb = [];lcb = [];var rowIndex = (j+startRow);
							for(var i = 0; i < colCount; i++){c = cs[i];p.id = c.id;p.css = (i === 0 ? "x-grid3-cell-first " : (i == last ? "x-grid3-cell-last " : ""))+(this.cm.config[i].cellCls ? ""+ this.cm.config[i].cellCls : "");
								p.attr = p.cellAttr = "";p.value = c.renderer(r.data[c.name], p, r, rowIndex, i, ds);p.style = c.style;
		
								if(Ext.isEmpty(p.value)){p.value = " ";}if(this.markDirty && r.dirty && Ext.isDefined(r.modified[c.name])){p.css += " x-grid3-dirty-cell";}if(c.locked){lcb[lcb.length] = ct.apply(p);}else{cb[cb.length] = ct.apply(p);}
							}var alt = [];
							if(stripe && ((rowIndex+1) % 2 === 0)){alt[0] = "x-grid3-row-alt";}
							if(r.dirty){alt[1] = " x-grid3-dirty-row";}
							rp.cols = colCount;
							if(this.getRowClass){alt[2] = this.getRowClass(r, rowIndex, rp, ds);}
							rp.alt = alt.join(" ");rp.cells = cb.join("");rp.tstyle = tstyle;buf[buf.length] =  rt.apply(rp);rp.cells = lcb.join(" ");rp.tstyle = lstyle;lbuf[lbuf.length] = rt.apply(rp);}	return [buf.join(""), lbuf.join("")];	}}),
		title:getResource('grid_title','grid_sys_agent'),sm:selectModel,
								tbar:new Ext.Toolbar({enableOverflow : true,id:"grid_sys_agent_tbar_btn",items:[	
				{ id:"event_grid_sys_agent_add_record_grid_sys_agent",text:getResource('add_record','grid_sys_agent'),icon:"../ext/resources/images/icons/add.gif",handler:function(){this.event_grid_sys_agent_add_record();},scope:this},{ id:"event_grid_sys_agent_edit_record_grid_sys_agent",text:getResource('edit_record','grid_sys_agent'),icon:"../ext/resources/images/icons/cog_edit.png",handler:function(){this.event_grid_sys_agent_edit_record();},scope:this},{ id:"event_grid_sys_agent_delete_record_grid_sys_agent",text:getResource('delete_record','grid_sys_agent'),icon:"../ext/resources/images/icons/delete.gif",handler:function(){this.event_grid_sys_agent_delete_record();},scope:this}]}),
							listeners:{
								"cellclick":function(grid,rowIndex,columnIndex,e){
									this.columnIndex=columnIndex;this.rowIndex=rowIndex;
								},
								"rowclick":function(_grid){
									var selectedRow = _grid.getSelectionModel().getSelections();
									if(selectedRow.length == 1){
							
								if(Ext.getCmp("grid_sys_agent_tbar_btn")){
									Ext.getCmp("grid_sys_agent_tbar_btn").doLayout();
								}
							}},"beforerender":function(){},"resize":function(){
				if(Ext.getCmp("grid_sys_agent_tbar_btn")){
					Ext.getCmp("grid_sys_agent_tbar_btn").doLayout();
				}
		},"render":function(_grid){grid_sys_agent_loadMask = new Ext.LoadMask(Ext.getCmp("grid_sys_agent").getEl(), {msg:getResource("loading","")});
				if(show_page_designer_shortcut == 1){
					var grid_sys_agent_pdBtn = dynmaicWebPageDesign("sys_agent_main_page","grid_sys_agent");
					if(typeof(tbar_grid_sys_agent)!="undefined"){
						tbar_grid_sys_agent.add("->");
						tbar_grid_sys_agent.add(grid_sys_agent_pdBtn);
						tbar_grid_sys_agent.doLayout();
					}else{
						_grid.getTopToolbar().add("->");
						_grid.getTopToolbar().add(grid_sys_agent_pdBtn);
					}
					_grid.getTopToolbar().doLayout();
				}else{
					if(_grid.getTopToolbar().items.length==0){
						_grid.getTopToolbar().hide();
					}
				}
			if(getAppPriv('grid_sys_agent','grid_sys_agent_add_record')==0){Ext.getCmp('event_grid_sys_agent_add_record_grid_sys_agent').hide();}if(getAppPriv('grid_sys_agent','grid_sys_agent_edit_record')==0){Ext.getCmp('event_grid_sys_agent_edit_record_grid_sys_agent').hide();}if(getAppPriv('grid_sys_agent','grid_sys_agent_delete_record')==0){Ext.getCmp('event_grid_sys_agent_delete_record_grid_sys_agent').hide();}
				if(getAppPriv('grid_sys_agent','grid_sys_agent_edit_record')==1){
					Ext.getCmp('grid_sys_agent').on('rowdblclick',Ext.getCmp('grid_sys_agent').grid_sys_agent_rowdblclick);
				}	
			
				if(typeof(tbar_grid_sys_agent)!="undefined"){
					tbar_grid_sys_agent.doLayout();
				}
			},"beforeedit":function(e){if(e.grid.is_allow_edit==0){
										e.grid.getColumnModel().setEditable(e.column,false);}else{var _value='';var flag;}if(typeof(e.record.data.allowedit) != 'undefined' && e.record.data.allowedit == 0){return false;}if(e.value){if(typeof(e.value)!= 'number' && typeof(e.value) != 'boolean'&& typeof(e.value) != 'object'){e.record.data[e.field]=e.value.replace(new RegExp('&lt;', 'g'),'<').replace(new RegExp('&gt;', 'g'),'>');}}}},bbar : new Ext.PagingToolbar({id:"grid_sys_agent_page_toolbar_id",
							displayInfo : true,pageSize : 20,store : this.myJSON_grid_sys_agent,dummy : true}),colModel:new Ext.ux.grid.LockingColumnModel([
							{header:getResource('id','grid_sys_agent'),width:0,hidden:true,
								resizable:false,sortable:false,hideable:false,
								menuDisabled:false,dataIndex:"id" },
							{header:getResource('agent_user','grid_sys_agent'),width:200,hidden:false,
								resizable:true,sortable:true,hideable:true,
								menuDisabled:false,dataIndex:"agent_user" },
					{header:getResource("start_date","grid_sys_agent"),
						hidden:false,sortable:true,dataIndex:"start_date"},
					{header:getResource("end_date","grid_sys_agent"),
						hidden:false,sortable:true,dataIndex:"end_date"}])})},listeners: {afteredit:function(e) {
									if(typeof(e.value)=="object"){
											if(e.value instanceof Date){
												Ext.getCmp("grid_sys_agent").store.getAt(e.row).data[e.field] = e.value.format("Y-m-d");
											}
									}
									var _store = Ext.getCmp("grid_sys_agent").store;
									Ext.getCmp("grid_sys_agent").setingEditorGridStyle(_store);
									Ext.getCmp("grid_sys_agent").getSelectionModel().selectRow(e.row);
								},columnmove : function(oldIndex,newIndex){if(Ext.getCmp("grid_sys_agent")){Ext.getCmp("grid_sys_agent").setingEditorGridStyle(Ext.getCmp("grid_sys_agent").store)}},afterrender:function(g){var valueList = "";if(valueList!=""){var dataIndexArray = new Array();dataIndexArray = valueList.split(",");initLockGridColumn(g,dataIndexArray);}}},setingEditorGridStyle:function(_store) {
						},
				event_grid_sys_agent_add_record:function(e){
					globalVariables_grid_sys_agent=new Object();
					panelActionData_grid_sys_agent=new Array();
				
						dynamicGridPanelEvent(e,"grid_sys_agent","grid_sys_agent_add_record",{panelActionDataArray:panelActionData_grid_sys_agent,winHeight:400,winWidth:600,isRequireGridRowSelection:"0",columnList:"id,agent_user,start_date,end_date",handlerType:"POPUP",isUseDynamicPanel:"0",isRequireConfirmation:"0",isRequireReloadGrid:"1",confirmMessage:"getResource('grid_sys_agent_add_record','grid_sys_agent')",predefinedValues:"",gridPanelName:"",saveType:"EDITGRID",isCloseWindowAfterAction:"1",isRequireSuccessTip:"1",isWorkFlowStart:"0",workflowProcessKey:"",wfTable:"",dynPageName:"sys_agent_first_popup",actionHandlerEvent:"",isDestroyWin:"1",isNeedConfirmDirtyData:"0",titleI18nKey:"getResource('add_record','grid_sys_agent')",afterSuccessJs:"",handlerJs:"",rptFormat:"",isHtmlXls:"0",rptNumber:"",rptPageType:"MAIN_PANEL",targetPanelName:"",targetPanelType:"",menuKey:"sys_agent_main_page",menuId:"0"},globalVariables_grid_sys_agent);
					}
				,
				event_grid_sys_agent_edit_record:function(e){
					globalVariables_grid_sys_agent=new Object();
					panelActionData_grid_sys_agent=new Array();
				
						dynamicGridPanelEvent(e,"grid_sys_agent","grid_sys_agent_edit_record",{panelActionDataArray:panelActionData_grid_sys_agent,winHeight:400,winWidth:600,isRequireGridRowSelection:"1",columnList:"id,agent_user,start_date,end_date",handlerType:"POPUP",isUseDynamicPanel:"0",isRequireConfirmation:"0",isRequireReloadGrid:"1",confirmMessage:"getResource('grid_sys_agent_edit_record','grid_sys_agent')",predefinedValues:"",gridPanelName:"",saveType:"EDITGRID",isCloseWindowAfterAction:"1",isRequireSuccessTip:"1",isWorkFlowStart:"0",workflowProcessKey:"",wfTable:"",dynPageName:"sys_agent_second_popup",actionHandlerEvent:"",isDestroyWin:"1",isNeedConfirmDirtyData:"0",titleI18nKey:"getResource('edit_record','grid_sys_agent')",afterSuccessJs:"",handlerJs:"",rptFormat:"",isHtmlXls:"0",rptNumber:"",rptPageType:"MAIN_PANEL",targetPanelName:"",targetPanelType:"",menuKey:"sys_agent_main_page",menuId:"0"},globalVariables_grid_sys_agent);
					}
				,
				event_grid_sys_agent_delete_record:function(e){
					globalVariables_grid_sys_agent=new Object();
					panelActionData_grid_sys_agent=new Array();
				
						dynamicGridPanelEvent(e,"grid_sys_agent","grid_sys_agent_delete_record",{panelActionDataArray:panelActionData_grid_sys_agent,winHeight:0,winWidth:0,isRequireGridRowSelection:"1",columnList:"id,agent_user,start_date,end_date",handlerType:"BACKGROUND",isUseDynamicPanel:"0",isRequireConfirmation:"1",isRequireReloadGrid:"1",confirmMessage:"getResource('delete_message','grid_sys_agent')",predefinedValues:"",gridPanelName:"",saveType:"EDITGRID",isCloseWindowAfterAction:"1",isRequireSuccessTip:"1",isWorkFlowStart:"0",workflowProcessKey:"",wfTable:"",dynPageName:"",actionHandlerEvent:"",isDestroyWin:"0",isNeedConfirmDirtyData:"0",titleI18nKey:"getResource('edit_record','grid_sys_agent')",afterSuccessJs:"",handlerJs:"",rptFormat:"",isHtmlXls:"0",rptNumber:"",rptPageType:"MAIN_PANEL",targetPanelName:"",targetPanelType:"",menuKey:"sys_agent_main_page",menuId:"0"},globalVariables_grid_sys_agent);
					}
				
				,URLencode:function(sStr){ return escape(sStr).replace(/\+/g, '%2B').replace(/\"/g,'%22').replace(/\'/g, '%27').replace(/\//g,'%2F');	},
				run_popReport:function(panel_name,rpt_format,rpt_number,width,height,formValues){var t_url = 'index.cfm?event=rpt.report.report.runReportPage';for(var i in formValues){t_url = t_url + '&'+ i + '='+URLencode(formValues[i]);}window.open (t_url) ;}	
								
				});
		
						
				page_sys_agent_main_page = Ext.extend(Ext.Panel,{
					paramList:null,
					loadCounter:null,
		
					constructor:function(_cfg){
							if(_cfg==null){_cfg=={};this.paramList={}}else{this.paramList = _cfg.paramList;};
							Ext.apply(this,_cfg);
						page_sys_agent_main_page.superclass.constructor.call(this,{
							border:false,
							autoScroll:false,	
							id:'page_sys_agent_main_page',
							anchor:'100% 100%',
							layout:'anchor',
							items:[
								
		
							{
								anchor:'100% 100%',flex:1,border:false,
								layout:"fit",
								panel_name:"grid_sys_agent",
								panel_type:"editorgridpanel",
								id:"grid_sys_agent_parentPanel",
								items:[new grid_sys_agent({paramList:this.paramList})]		
						}]
						})
					},
					listeners:{
						beforerender:function(_grid){
							var winObj = eval(Ext.getCmp(Ext.getCmp('page_sys_agent_main_page').paramList.win_id));
							if(typeof(winObj)!='undefined'){
								maskObj = new Ext.LoadMask(winObj.getEl(), {msg:getResource('loading','')});
								maskObj.show();
							}
						},
						render:function(_grid){
							Ext.getCmp('page_sys_agent_main_page').loadCounter=0;
		
									if(getAppPriv('grid_sys_agent','')){
										Ext.getCmp('page_sys_agent_main_page').loadCounter = Ext.getCmp('page_sys_agent_main_page').loadCounter+1;
									}
							
				if(Ext.getCmp('page_sys_agent_main_page').loadCounter==0){
					maskObj.hide();	
					Ext.getCmp('page_sys_agent_main_page').loadCounter=0;
				} 
		
							if(getAppPriv('grid_sys_agent','')){
					
							Ext.getCmp('grid_sys_agent').getStore().removeAll();
							var baseParams = Ext.getCmp('grid_sys_agent').getStore().baseParams;
							var paramList = Ext.getCmp('grid_sys_agent').paramList;
							Ext.apply(baseParams,paramList);
							baseParams.sql_where=' and 1=1';
							baseParams.currentPanel='grid_sys_agent';
							baseParams.panel_name='grid_sys_agent';
							baseParams.pname='grid_sys_agent';
							
								Ext.getCmp('grid_sys_agent').getStore().baseParams=baseParams;
									if(typeof(Ext.getCmp('grid_sys_agent_simplepanel_criteriadata_combo')) == 'undefined') {
							Ext.getCmp('grid_sys_agent').getStore().load();
										}else{
											Ext.getCmp('grid_sys_agent_simplepanel_criteriadata_combo').getStore().reload();
										}		
										Ext.getCmp('grid_sys_agent').getStore().on('load',function(){
												if(Ext.getCmp('page_sys_agent_main_page')){
												Ext.getCmp('page_sys_agent_main_page').loadCounter=Ext.getCmp('page_sys_agent_main_page').loadCounter-1;
												if(Ext.getCmp('page_sys_agent_main_page').loadCounter<=0){
													maskObj.hide();	
													Ext.getCmp('page_sys_agent_main_page').loadCounter=0;
												}
												}
										});
										
							
							}
					
						},
						afterrender:function(_grid){
		
					if(getAppPriv('grid_sys_agent','')==0){
				
						if(typeof(Ext.getCmp('grid_sys_agent'))!='undefined'){
							Ext.getCmp('grid_sys_agent').destroy();
							if(typeof(Ext.getCmp('grid_sys_agent_parentPanel'))!='undefined'){
								var parent = Ext.getCmp('grid_sys_agent_parentPanel').ownerCt;
								parent.remove(Ext.getCmp('grid_sys_agent_parentPanel'));
								parent.doLayout();
							}
						}
					}},
					destroy:function(){
		
					}		
				
					}
				})
		

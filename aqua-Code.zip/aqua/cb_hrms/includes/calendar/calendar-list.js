/*!
 * Ext JS Library 3.3.0
 * Copyright(c) 2006-2010 Ext JS, Inc.
 * licensing@extjs.com
 * http://www.extjs.com/license
 */
var calendarList = {
    "calendars":[{
        "id":1,
        "title":"Home",
        "color":"#306da6"
    },{
        "id":2,
        "title":"Work",
        "color":"#29527A"
    },{
        "id":3,
        "title":"School",
        "color":"#86a723"
    },{
    	"id":4,
        "title":"Office",
        "color":"red"
    },{
    	"id":5,
        "title":"Factory",
        "color":"green"
    },{
    	"id":6,
        "title":"Shop",
        "color":"orange"
    }]
};

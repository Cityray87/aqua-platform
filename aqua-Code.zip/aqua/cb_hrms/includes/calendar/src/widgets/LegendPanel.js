/*!
 * Ext JS Library 3.3.0
 * Copyright(c) 2010 Cityray, Inc.
 * colan.guo@gmail.com
 * http://www.cityray.com/
 */
/**
 * @class Ext.calendar.LegendPanel
 * @extends Ext.Panel
 * @constructor
 * @param {Object} config The config object
 */
Ext.calendar.LegendPanel = Ext.extend(Ext.Panel, {
	
	calendarElIdDelimiter: '-legend-',
	
    //calendarSelector: '.ext-cal-evt',
    calendarSelector: '.ext-cal-evr-leg',

	legendTpl : new Ext.XTemplate(
		'<tpl for=".">',
			'<div style="padding:1px 2px 1px 3px">',
				'<div style="background: {color};" id="calendar-legend-{calendarId}" class="ext-cal-evr-leg ext-cal-evt ext-cal-evr" title="{title}">{title}</div>',
			'</div>',
		'</tpl>').compile(),
	
	initLegend : function(container) {
		var cs = this.store;
		container.dom.innerHTML = "";
		for(var i=cs.getCount()-1;i>=0;i--){
			var data = cs.getAt(i).get("Title");
			var html = this.legendTpl.apply({
				title : cs.getAt(i).get("Title"),
				calendarId : cs.getAt(i).get("CalendarId"),
				color : cs.getAt(i).get("Color")
			});
			
			Ext.DomHelper.insertHtml("afterBegin",container.dom,html);
		}
	},
	
	initComponent: function() {
        Ext.calendar.LegendPanel.superclass.initComponent.call(this);
        
        this.addEvents({
            calendarclick: true
        });
    },

	afterRender: function() {
        Ext.calendar.LegendPanel.superclass.afterRender.call(this);
        
        this.el.on({
            'click': this.onClick,
            scope: this
        });
        
        this.initLegend(this.body);
    },
    
    reInit: function(){
        this.initLegend(this.body);
    },
    
    getCalendarRecord: function(id) {
        var idx = this.store.find('CalendarId', id);
        return this.store.getAt(idx);
    },
    
    getCalendarIdFromEl: function(el) {
        el = Ext.get(el);
        var id = el.id.split(this.calendarElIdDelimiter)[1];
        if (id.indexOf('-') > -1) {
            id = id.split('-')[0];
        }
        return id;
    },
    
    onClick: function(e, t) {
        var el = e.getTarget(this.calendarSelector, 5);
        if (el) {
            var id = this.getCalendarIdFromEl(el);        
            this.fireEvent('calendarclick', this, this.getCalendarRecord(id), el);
            return true;
        }
    }
});

Ext.reg('calendarlegend', Ext.calendar.LegendPanel);
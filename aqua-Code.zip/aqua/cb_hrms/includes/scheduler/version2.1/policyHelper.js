//v.2.0 build 90722
/*
Copyright DHTMLX LTD. http://www.dhtmlx.com
You allowed to use this component or parts of it under GPL terms
To use it on other terms or get Professional edition of the component please contact us at sales@dhtmlx.com
*/
/*$Rev$*/


scheduler._edit_stop_event=function(ev,mode){
	if (this._new_event){
		//if (!mode) this.deleteEvent(ev.id,true);	
		if (!mode);
		else this.callEvent("onEventAdded",[ev.id,ev]);
		this._new_event=null;
		// newly added
		this.render_view_data();		
	} else {
		if (mode) this.callEvent("onEventChanged",[ev.id,ev]);
		this.render_view_data();
	}
}

scheduler.deleteEvent=function(id,silent){ 
	deleteSchedulerEvents(id);
	var ev=this._events[id];
	if (!silent && !this.callEvent("onBeforeEventDelete",[id,ev]))
	{
		return;
	}
	if (ev){
		delete this._events[id];
		this.unselect(id);
		this.event_updated(ev);
	}
}
   
scheduler._on_mouse_up=function(e){
	if (this._drag_mode && this._drag_id){
		this._els["dhx_cal_data"][0].style.cursor="default";
		//drop
		var ev=this.getEvent(this._drag_id);
		if (!this._drag_event.start_date || ev.start_date.valueOf()!=this._drag_event.start_date.valueOf() || ev.end_date.valueOf()!=this._drag_event.end_date.valueOf()){
			var is_new=(this._drag_mode=="new-size");
			if (is_new && this.config.edit_on_create){
				this.unselect();
				this._new_event=new Date();//timestamp of creation
				if (this._table_view || this.config.details_on_create) {
					this._drag_mode=null;
					return this.showLightbox(this._drag_id);
				}
				this._drag_pos=true; //set flag to trigger full redraw
				this._select_id=this._edit_id=this._drag_id;
			}else
			{
				this.callEvent(is_new?"onEventAdded":"onEventChanged",[this._drag_id,this.getEvent(this._drag_id)]);
				var scheduler_id = getQuerystring('scheduler_id');
				updateSchedulerEvents(scheduler_id,ev.start_date,ev.end_date,ev.text,ev.id,ev.details);
			}
			this.render_view_data();
		}
		if (this._drag_pos) this.render_view_data(); //redraw even if there is no real changes - necessary for correct positioning item after drag
	}
	this._drag_mode=null;
	this._drag_pos=null;
}	

scheduler.editStop=function(mode,id){
	if (id && this._edit_id!=id) return;
	var ev=this.getEvent(this._edit_id);
	if (ev){
		if (mode)
		{
			ev.text=this._editor.value;
			//alert(ev.text);
			var scheduler_id = getQuerystring('scheduler_id');
			updateSchedulerEvents(scheduler_id,ev.start_date,ev.end_date,ev.text,ev.id,ev.details);
		}
		this._edit_id=null;
		this._editor=null;	
		this.updateEvent(ev.id);
		this._edit_stop_event(ev,mode);		
	}
}

scheduler.showLightbox=function(id){
	scheduler._lightbox_id=id;
	showlightbox();
	/*	
	if (!id) return;
	if (!this.callEvent("onBeforeLightbox",[id])) return;
	var box = this._get_lightbox();
	this.showCover(box);
	this._fill_lightbox(id,box);
	*/
}

function deleteSchedulerEvents(id) {
	shift_policy = getQuerystring('shift_policy');
	evt = scheduler._events[id];
	
	Ext.Ajax.request({
		waitMsg: "Please wait ... ",
		url: "/cb_hrms/index.cfm?event=HR_Attendance.shiftPolicy.deleteShiftPolicy",
		method: "POST",
		params: {
			id: id,
			shift_policy_id: evt.shift_policy_id,
			event_type: evt.event_type,
			is_validate: 1
		},	
        failure: function(response,options){
            var responseText = Ext.util.JSON.decode(options.response.responseText);
            Ext.MessageBox.alert("Error",responseText.success_msg);
    	},
		success: function(response,options){
			var responseText = Ext.util.JSON.decode(response.responseText);
			scheduler.clearAll();
			scheduler.load("?event=HR_Attendance.shiftPolicy.getSchedulerXML&shift_policy=" + shift_policy + "&datenow=" + new Date());	      		
		}                                    
    });	
}


function updateSchedulerEvents(scheduler_id,start_date,end_date,text,id,details) {
	shift_policy = getQuerystring('shift_policy');
	var startMin = start_date.getMinutes();
	var startHour = start_date.getHours();
	var startDay = start_date.getDate() + "";
	var startMonth = (start_date.getMonth()+1) + "";
	var startYear = start_date.getFullYear();

	var endMin = end_date.getMinutes();
	var endHour = end_date.getHours();
	var endDay = end_date.getDate() + "";
	var endMonth = (end_date.getMonth()+1) + "";
	var endYear = end_date.getFullYear();	
	if (details == null)
		details = '';
	
	var evt = scheduler._events[id];
	var time_in = evt.time_in; //2000-01-08 09:00:00.0
	var time_out = evt.time_out;
	
	var in_date = time_in.substring(0,10);
	var in_time = time_in.substring(11,16);
	
	var out_date = time_out.substring(0,10);
	var out_time = time_out.substring(11,16);
	
	startMonth = startMonth < 10 ? '0' + startMonth : startMonth;
	startDay = startDay < 10 ? '0' + startDay : startDay;
	startHour = startHour < 10 ? '0' + startHour : startHour;
	startMin = startMin < 10 ? '0' + startMin : startMin;
	
	endMonth = endMonth < 10 ? '0' + endMonth : endMonth;
	endDay = endDay < 10 ? '0' + endDay : endDay;
	endHour = endHour < 10 ? '0' + endHour : endHour;
	endMin = endMin < 10 ? '0' + endMin : endMin;
	
	
	var start_date_ = startYear + '-' + startMonth + '-' + startDay;
	var end_date_ = endYear + '-' + endMonth + '-' + endDay;
	
	var start_time_ = startHour + ':' + startMin;
	var end_time_ = endHour + ':' + endMin;
	
	if(start_date_ != in_date){
		//Ext.MessageBox.alert("Error","This event can't move to other day");
		scheduler.load("?event=HR_Attendance.shiftPolicy.getSchedulerXML&shift_policy=" + shift_policy + "&datenow=" + new Date());
		return;
	} 
	
	var it = in_time.length == 0 ? 0 : parseInt(in_time.replace(/:/g, ''),10);
	var st = start_time_.length == 0 ? 0 : parseInt(start_time_.replace(/:/g, ''),10);
	var et = end_time_.length == 0 ? 0 : parseInt(end_time_.replace(/:/g, ''),10);
	var ot = out_time.length == 0 ? 0 : parseInt(out_time.replace(/:/g, ''),10);
		
	if(evt.event_type > 0) {
		if(st < it || et > ot || et == 0) {
			//Ext.MessageBox.alert("Error","This break time out of bounds");
			scheduler.load("?event=HR_Attendance.shiftPolicy.getSchedulerXML&shift_policy=" + shift_policy + "&datenow=" + new Date());
			return;
		}
	} else {
		if(et == 0) {
			//Ext.MessageBox.alert("Error","Shift policy time must not 24:00");
			scheduler.load("?event=HR_Attendance.shiftPolicy.getSchedulerXML&shift_policy=" + shift_policy + "&datenow=" + new Date());
			return;
		}
	}
		
	Ext.Ajax.request({
		waitMsg: "Please wait ... ",
		
		url: "/cb_hrms/index.cfm?event=HR_Attendance.shiftPolicy.updateEventByAjax",
		method: "POST",
		params: {
			shift_policy_id: evt.shift_policy_id,
			start_date: start_date_ + ' ' + start_time_,
			end_date: end_date_ + ' ' + end_time_,
			event_type: evt.event_type
		},	
        failure: function(response,options){
            var responseText = Ext.util.JSON.decode(options.response.responseText);
			//Ext.MessageBox.hide();
            Ext.MessageBox.alert("Error",responseText.success_msg);
    	},
		success: function(response,options){
			var responseText = Ext.util.JSON.decode(response.responseText);
			//Ext.MessageBox.hide();
			scheduler.clearAll();
			scheduler.load("?event=HR_Attendance.shiftPolicy.getSchedulerXML&shift_policy=" + shift_policy + "&datenow=" + new Date());	      		
		}                                    
    });		
}

function getMonthNumber(monthString) {
	if (monthString == 'January')
		return '1';
	else if (monthString == 'February')
		return '2';
	else if (monthString == 'March')
		return '3';
	else if (monthString == 'April')
		return '4';
	else if (monthString == 'May')
		return '5';
	else if (monthString == 'June')
		return '6';
	else if (monthString == 'July')
		return '7';
	else if (monthString == 'Augest')
		return '8';
	else if (monthString == 'September')
		return '9';
	else if (monthString == 'October')
		return '10';
	else if (monthString == 'November')
		return '11';
	else if (monthString == 'December')
		return '12';
	return 'undefined';
}

function getTimeHour(HHMM) {
	var hour=HHMM.split(":");
	return hour[0];
}

function getTimeMinute(HHMM) {
	var minute=HHMM.split(":");
	return minute[1];
}

function getQuerystring(key, default_) {
  if (default_==null) default_=""; 
  key = key.replace(/[\[]/,"\\\[").replace(/[\]]/,"\\\]");
  var regex = new RegExp("[\\?&]"+key+"=([^&#]*)");
  var qs = regex.exec(window.location.href);
  if(qs == null)
    return default_;
  else
    return qs[1];
}

function showlightbox() {
	var now = new Date();
	var evt = scheduler.getEvent(scheduler._lightbox_id);
	var startDay = evt.start_date.getDate() + "";
	var startMonth = (evt.start_date.getMonth()+1) + "";
	var startYear = evt.start_date.getFullYear();
	var endDay = evt.end_date.getDate() + "";
	var endMonth = (evt.end_date.getMonth()+1) + "";
	var endYear = evt.end_date.getFullYear();	
	var is_new = scheduler._new_event;
	var fromTimeHour = evt.start_date.getHours();
	var fromTimeMinute = evt.start_date.getMinutes();
	var toTimeHour = evt.end_date.getHours();
	var toTimeMinute = evt.end_date.getMinutes();	
	var day = evt.start_date.getDay();
	if(day == 0) day = 7;
	var shift_policy_id = evt.shift_policy_id;
	if(shift_policy_id == null){
		shift_policy_id = 0;
	}
	var shift_policy = getQuerystring('shift_policy');

	var is_new = scheduler._new_event;
	if (is_new){
		mode = 'new';
		formTitle = 'Add New Shift Policy';
		event_type = 0;
	} else{
		mode = 'edit';
		formTitle = 'Edit Shift Policy';
		event_type = evt.event_type;
	}
		
	win = new Ext.Window({
		renderTo : Ext.getBody(),
		width : 450,
		minWidth:450,
		height : 460,
		minHeight:460,
		title : formTitle,
		maximizable : true,
		resizable : true,
		modal : true,
		autoscroll: true,
		bodyStyle : "background: #fff;",
		autoLoad : {
			params: {
				shift_policy_id: shift_policy_id,
				shift_policy: shift_policy,
				event_num: evt.id,
				event_type:event_type,
				startDay: startDay,
				startMonth: startMonth, 
				startYear: startYear,
				endDay: endDay,
				endMonth: endMonth, 
				endYear: endYear,
				uid: now,
				mode: mode,
				day: day,		
				fromTimeHour: fromTimeHour,
				fromTimeMinute: fromTimeMinute,
				toTimeHour: toTimeHour,
				toTimeMinute: toTimeMinute
			},
			url: '/cb_hrms/index.cfm?event=HR_Attendance.shiftPolicy.editShiftPolicy',
			scripts: true
		},
		listeners : {
			beforeclose : function(){	
				cancelLightBox();
			},
			close: function (){
				if 	(Ext.getCmp('shiftPolicyForm') != null)
				{
					Ext.getCmp('shiftPolicyForm').destroy();
				}
			},			
			resize : function(window, width, height) {
				if 	(Ext.getCmp('shiftPolicyForm') != null){
					Ext.getCmp('shiftPolicyForm').setWidth( width-15 );
					Ext.getCmp('shiftPolicyForm').setHeight( height-33 );
				}
			},
			maximize : function(window){
				if 	(Ext.getCmp('shiftPolicyForm') != null){
					Ext.getCmp('shiftPolicyForm').setWidth(Ext.getCmp('shiftPolicyForm').getInnerWidth()+15);
				}
			}
		}

	});
	win.show();	
} 

function deleteLightBox() {
	/*
	var a = document.getElementById("lightbox-iframe");
	//alert (a.contentWindow.document.getElementById("eventName").value);
	

	document.getElementById('lightbox-content').style.display='none'; 
	document.getElementById('lightbox-bg').style.display='none'; 
	document.getElementById('lightbox-iframe').src='about:blank';
	*/
	var evt = scheduler.getEvent(scheduler._lightbox_id);
	scheduler._edit_stop_event(evt,false);	
	scheduler.deleteEvent(evt.id,true);
}
function cancelLightBox(){
	shift_policy = getQuerystring('shift_policy');
	var evt = scheduler.getEvent(scheduler._lightbox_id);
	scheduler._edit_stop_event(evt,false);

	scheduler.clearAll();
	scheduler.load("?event=HR_Attendance.shiftPolicy.getSchedulerXML&shift_policy=" + shift_policy + "&datenow=" + new Date());	
}

function closelightbox(evts) { 
	
	/*
	var a = document.getElementById("lightbox-iframe");
	document.getElementById('lightbox-content').style.display='none'; 
	document.getElementById('lightbox-bg').style.display='none'; 
	document.getElementById('lightbox-iframe').src='about:blank';
	*/

	var events = scheduler.getEvent(scheduler._lightbox_id);
	events.text = evts.event_name;
	startDate = new Date(evts.start_date);
	startDate.setHours(getTimeHour(evts.fromTime));
	startDate.setMinutes(getTimeMinute(evts.fromTime));
	endDate = new Date(evts.end_date);
	endDate.setHours(getTimeHour(evts.toTime));
	endDate.setMinutes(getTimeMinute(evts.toTime));
	
	//fromDate = new Date(evts.fromYear,getMonthNumber(evts.fromMonth)-1,evts.fromDay,getTimeHour(evts.fromTime),getTimeMinute(evts.fromTime));

	//toDate = new Date(evts.toYear,getMonthNumber(evts.toMonth)-1,evts.toDay,getTimeHour(evts.toTime),getTimeMinute(evts.toTime));
	//events.start_date = fromDate;
	//events.end_date = toDate;
	events.start_date = startDate;
	events.end_date = endDate;
	events._timed=scheduler.is_one_day_event(events);
	//alert(evt.text);
	//alert(evt._timed);
	//alert ('closelightbox event2');
	
	scheduler._edit_stop_event(events,true);
	
}



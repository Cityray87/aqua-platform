﻿
function changeLocale(lang){
	switch (lang){
		case '100':
			localeEN();
			break;
		case '101':
			localeCN();
			break;			
	}
}

function localeCN(){
		scheduler_locale = 'CN';
		scheduler.locale = {
		date : {
			month_full : [ "一月", "二月", "三月", "四月", "五月", "六月", "七月", "八月", "九月", "十月", "十一月", "十二月" ],
			month_short : [ "1月", "2月", "3月", "4月", "5月", "6月", "7月", "8月", "9月", "10月", "11月", "12月" ],
			day_full : [ "星期日", "星期一", "星期二", "星期三", "星期四", "星期五", "星期六" ],
			day_short : [ "周日", "周一", "周二", "周三", "周四", "周五", "周六" ]
		},
		labels : {
			dhx_cal_today_button : "今日",
			day_tab : "日视图",
			week_tab : "周视图",
			month_tab : "月视图",
			new_event : "新事件",
			icon_save : "保存",
			icon_cancel : "取消",
			icon_details : "详细",
			icon_edit : "编辑",
			icon_delete : "删除",
			confirm_closing : "",
			confirm_deleting : "你确定要永久删除该事件吗?",
			section_description : "描述",
			section_time : "时间范围"
		}
	}	
}
function localeEN(){}

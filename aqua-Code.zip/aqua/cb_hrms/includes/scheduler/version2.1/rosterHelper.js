//v.2.0 build 90722
/*
Copyright DHTMLX LTD. http://www.dhtmlx.com
You allowed to use this component or parts of it under GPL terms
To use it on other terms or get Professional edition of the component please contact us at sales@dhtmlx.com
*/
/*$Rev$*/

Date.prototype.format = function(mask) {
	var d = this;
	var zeroize = function (value, length) {
		if (!length) length = 2;
		value = String(value);
		for (var i = 0, zeros = ''; i < (length - value.length); i++) {
			zeros += '0';
		}
		return zeros + value;
	};

	return mask.replace(/"[^"]*"|'[^']*'|\b(?:d{1,4}|m{1,4}|yy(?:yy)?|([hHMstT])\1?|[lLZ])\b/g, function($0) {
		switch($0) {
			case 'd':   return d.getDate();
			case 'dd':  return zeroize(d.getDate());
			case 'ddd': return ['Sun','Mon','Tue','Wed','Thr','Fri','Sat'][d.getDay()];
			case 'dddd':	return ['Sunday','Monday','Tuesday','Wednesday','Thursday','Friday','Saturday'][d.getDay()];
			case 'M':   return d.getMonth() + 1;
			case 'MM':  return zeroize(d.getMonth() + 1);
			case 'MMM': return ['Jan','Feb','Mar','Apr','May','Jun','Jul','Aug','Sep','Oct','Nov','Dec'][d.getMonth()];
			case 'MMMM':	return ['January','February','March','April','May','June','July','August','September','October','November','December'][d.getMonth()];
			case 'yy':  return String(d.getFullYear()).substr(2);
			case 'yyyy':	return d.getFullYear();
			case 'h':   return d.getHours() % 12 || 12;
			case 'hh':  return zeroize(d.getHours() % 12 || 12);
			case 'H':   return d.getHours();
			case 'HH':  return zeroize(d.getHours());
			case 'm':   return d.getMinutes();
			case 'mm':  return zeroize(d.getMinutes());
			case 's':   return d.getSeconds();
			case 'ss':  return zeroize(d.getSeconds());
			case 'l':   return zeroize(d.getMilliseconds(), 3);
			case 'L':   var m = d.getMilliseconds();
					if (m > 99) m = Math.round(m / 10);
					return zeroize(m);
			case 'tt':  return d.getHours() < 12 ? 'am' : 'pm';
			case 'TT':  return d.getHours() < 12 ? 'AM' : 'PM';
			case 'Z':   return d.toUTCString().match(/[A-Z]+$/);
			// Return quoted strings with the surrounding quotes removed
			default:	return $0.substr(1, $0.length - 2);
		}
	});
};

scheduler._edit_stop_event=function(ev,mode){
	if (this._new_event){
		//if (!mode) this.deleteEvent(ev.id,true);	
		if (!mode);
		else this.callEvent("onEventAdded",[ev.id,ev]);
		this._new_event=null;
		// newly added
		this.render_view_data();		
	} else {
		if (mode) this.callEvent("onEventChanged",[ev.id,ev]);
		this.render_view_data();
	}
}

scheduler.deleteEvent=function(id,silent){ 
	deleteSchedulerEvents(id);
	var ev=this._events[id];
	if (!silent && !this.callEvent("onBeforeEventDelete",[id,ev]))
	{
		return;
	}
	if (ev){
		delete this._events[id];
		this.unselect(id);
		this.event_updated(ev);
	}
}
   
scheduler._on_mouse_up=function(e){
	if (this._drag_mode && this._drag_id){
		this._els["dhx_cal_data"][0].style.cursor="default";
		//drop
		var ev=this.getEvent(this._drag_id);
		if (!this._drag_event.start_date || ev.start_date.valueOf()!=this._drag_event.start_date.valueOf() || ev.end_date.valueOf()!=this._drag_event.end_date.valueOf()){
			var is_new=(this._drag_mode=="new-size");
			if (is_new && this.config.edit_on_create){
				this.unselect();
				this._new_event=new Date();//timestamp of creation
				if (this._table_view || this.config.details_on_create) {
					this._drag_mode=null;
					return this.showLightbox(this._drag_id);
				}
				this._drag_pos=true; //set flag to trigger full redraw
				this._select_id=this._edit_id=this._drag_id;
			}else
			{
				this.callEvent(is_new?"onEventAdded":"onEventChanged",[this._drag_id,this.getEvent(this._drag_id)]);
				var scheduler_id = getQuerystring('scheduler_id');
				updateSchedulerEvents(scheduler_id,ev.start_date,ev.end_date,ev.text,ev.id,ev.details);
			}
			this.render_view_data();
		}
		if (this._drag_pos) this.render_view_data(); //redraw even if there is no real changes - necessary for correct positioning item after drag
	}
	this._drag_mode=null;
	this._drag_pos=null;
}	

scheduler.editStop=function(mode,id){
	if (id && this._edit_id!=id) return;
	var ev=this.getEvent(this._edit_id);
	if (ev){
		if (mode) {
			ev.text=this._editor.value;
			//alert(ev.text);
			var scheduler_id = getQuerystring('scheduler_id');
			updateSchedulerEvents(scheduler_id,ev.start_date,ev.end_date,ev.text,ev.id,ev.details);
		}
		this._edit_id=null;
		this._editor=null;	
		this.updateEvent(ev.id);
		this._edit_stop_event(ev,mode);		
	}
}

scheduler.showLightbox=function(id){
	scheduler._lightbox_id=id;
	showlightbox();
	/*	
	if (!id) return;
	if (!this.callEvent("onBeforeLightbox",[id])) return;
	var box = this._get_lightbox();
	this.showCover(box);
	this._fill_lightbox(id,box);
	*/
}

	function deleteSchedulerEvents(id) {
		evt = scheduler._events[id];
		var eeid = getQuerystring('eeid');
		
		Ext.Ajax.request({
			waitMsg: "Please wait ... ",
			url: "/cb_hrms/index.cfm?event=HR_Attendance.roster.deleteRoster",
			method: "POST",
			params: {
				roster_id: evt.roster_id,
				event_type: evt.event_type,
				is_validate: 1
			},	
	        failure: function(response,options){
	            var responseText = Ext.util.JSON.decode(options.response.responseText);
	            Ext.MessageBox.alert("Error",responseText.success_msg);
	    	},
			success: function(response,options){
				var responseText = Ext.util.JSON.decode(response.responseText);
				scheduler.clearAll();
				scheduler.load("?event=HR_Attendance.roster.getSchedulerXML&eeid=" + eeid + "&datenow=" + evt.start_date.toGMTString());	      		
			}                                    
	    });	
	}


	function updateSchedulerEvents(scheduler_id,start_date,end_date,text,id,details) {
		var eeid = getQuerystring('eeid');
		var evt = scheduler._events[id];
		var time_in = evt.time_in; //2000-01-08 09:00:00.0
		var time_out = evt.time_out;
		
		var event_start = start_date.format('yyyy-MM-dd HH:mm:ss');
		var event_end = end_date.format('yyyy-MM-dd HH:mm:ss');
	
		if(event_start.substr(0,10) !== time_in.substr(0,10)){
			//Ext.MessageBox.alert("Error","This event can't move to other day");
			scheduler.load("?event=HR_Attendance.roster.getSchedulerXML&eeid=" + eeid + "&datenow=" + start_date.toGMTString());
			return;
		} 
	
		if(evt.event_type > 0) {
			if(event_start < time_in || event_end > time_out || event_end.substr(11,5) < '1') {
				//Ext.MessageBox.alert("Error","This break time out of bounds");
				scheduler.load("?event=HR_Attendance.roster.getSchedulerXML&eeid=" + eeid + "&datenow=" + start_date.toGMTString());
				return;
			}
		} else {
			if(event_end.substr(11,5) === '00:00') {
				//Ext.MessageBox.alert("Error","Roster time out must not 24:00");
				scheduler.load("?event=HR_Attendance.roster.getSchedulerXML&eeid=" + eeid + "&datenow=" + start_date.toGMTString());
				return;
			}
		}
		
		Ext.Ajax.request({
			waitMsg: "Please wait ... ",
			
			url: "/cb_hrms/index.cfm?event=HR_Attendance.roster.updateEvent",
			method: "POST",
			params: {
				roster_id: evt.roster_id,
				start_date: event_start,
				end_date: event_end,
				event_type: evt.event_type,
				eeid: eeid
			},	
	        failure: function(response,options){
	            var responseText = Ext.util.JSON.decode(options.response.responseText);
				//Ext.MessageBox.hide();
	            Ext.MessageBox.alert("Error",responseText.success_msg);
	    	},
			success: function(response,options){
				var responseText = Ext.util.JSON.decode(response.responseText);
				//Ext.MessageBox.hide();
				scheduler.clearAll();
				scheduler.load("?event=HR_Attendance.roster.getSchedulerXML&eeid=" + eeid + "&datenow=" + start_date.toGMTString());	      		
			}                                    
	    });		
	}

function getMonthNumber(monthString) {
	if (monthString == 'January')
		return '1';
	else if (monthString == 'February')
		return '2';
	else if (monthString == 'March')
		return '3';
	else if (monthString == 'April')
		return '4';
	else if (monthString == 'May')
		return '5';
	else if (monthString == 'June')
		return '6';
	else if (monthString == 'July')
		return '7';
	else if (monthString == 'Augest')
		return '8';
	else if (monthString == 'September')
		return '9';
	else if (monthString == 'October')
		return '10';
	else if (monthString == 'November')
		return '11';
	else if (monthString == 'December')
		return '12';
	return 'undefined';
}

function getTimeHour(HHMM) {
	var hour=HHMM.split(":");
	return hour[0];
}

function getTimeMinute(HHMM) {
	var minute=HHMM.split(":");
	return minute[1];
}

	function getQuerystring(key, default_) {
		if (default_==null) default_=""; 
		key = key.replace(/[\[]/,"\\\[").replace(/[\]]/,"\\\]");
		var regex = new RegExp("[\\?&]"+key+"=([^&#]*)");
		var qs = regex.exec(window.location.href);
		if(qs == null)
			return default_;
		else
			return qs[1];
	}

	function showlightbox() {
		var evt = scheduler.getEvent(scheduler._lightbox_id);
		var time_in = evt.start_date.format('yyyy/MM/dd HH:mm');
		var time_out = evt.end_date.format('yyyy/MM/dd HH:mm');
	
		var day = evt.start_date.getDay();
		if(day == 0) day = 7;
		
		var roster_id = evt.roster_id;
		if(roster_id == null){
			roster_id = 0;
		}
		var eeid = getQuerystring('eeid');
	
		var is_new = scheduler._new_event;
		if (is_new){
			mode = 'new';
			formTitle = scheduler_locale=='CN'?'新增排班':'Add New Roster';
			event_type = 0;
		} else{
			mode = 'edit';
			formTitle = scheduler_locale=='CN'?'编辑排班':'Edit Roster';
			event_type = evt.event_type;
		}
			
		win = new Ext.Window({
			renderTo : Ext.getBody(),
			width : 450,
			minWidth:450,
			height : 460,
			minHeight:460,
			title : formTitle,
			maximizable : true,
			resizable : true,
			modal : true,
			autoscroll: true,
			bodyStyle : "background: #fff;",
			autoLoad : {
				params: {
					roster_id: roster_id,
					eeid: eeid,
					event_num: evt.id,
					event_type:event_type,
					time_in: time_in,
					time_out: time_out, 
					mode: mode,
					day: day
				},
				url: '/cb_hrms/index.cfm?event=HR_Attendance.roster.editRoster',
				scripts: true
			},
			listeners : {
				beforeclose : function(){	
					cancelLightBox();
				},
				close: function (){
					if 	(Ext.getCmp('rosterForm') != null)
					{
						Ext.getCmp('rosterForm').destroy();
					}
				},			
				resize : function(window, width, height) {
					if 	(Ext.getCmp('rosterForm') != null){
						Ext.getCmp('rosterForm').setWidth( width-15 );
						Ext.getCmp('rosterForm').setHeight( height-33 );
					}
				},
				maximize : function(window){
					if 	(Ext.getCmp('rosterForm') != null){
						Ext.getCmp('rosterForm').setWidth(Ext.getCmp('rosterForm').getInnerWidth()+15);
					}
				}
			}
		});
		win.show();	
	} 

function deleteLightBox() {
	/*
	var a = document.getElementById("lightbox-iframe");
	//alert (a.contentWindow.document.getElementById("eventName").value);
	

	document.getElementById('lightbox-content').style.display='none'; 
	document.getElementById('lightbox-bg').style.display='none'; 
	document.getElementById('lightbox-iframe').src='about:blank';
	*/
	var evt = scheduler.getEvent(scheduler._lightbox_id);
	scheduler._edit_stop_event(evt,false);	
	scheduler.deleteEvent(evt.id,true);
}

	function cancelLightBox(){
		eeid = getQuerystring('eeid');
		var evt = scheduler.getEvent(scheduler._lightbox_id);
		scheduler._edit_stop_event(evt,false);
		scheduler.clearAll();
		scheduler.load("?event=HR_Attendance.roster.getSchedulerXML&eeid=" + eeid + "&datenow=" + evt.start_date.toGMTString());	
	}

function closelightbox(evts) { 
	
	/*
	var a = document.getElementById("lightbox-iframe");
	document.getElementById('lightbox-content').style.display='none'; 
	document.getElementById('lightbox-bg').style.display='none'; 
	document.getElementById('lightbox-iframe').src='about:blank';
	*/

	var events = scheduler.getEvent(scheduler._lightbox_id);
	events.text = evts.event_name;
	startDate = new Date(evts.start_date);
	startDate.setHours(getTimeHour(evts.fromTime));
	startDate.setMinutes(getTimeMinute(evts.fromTime));
	endDate = new Date(evts.end_date);
	endDate.setHours(getTimeHour(evts.toTime));
	endDate.setMinutes(getTimeMinute(evts.toTime));
	
	//fromDate = new Date(evts.fromYear,getMonthNumber(evts.fromMonth)-1,evts.fromDay,getTimeHour(evts.fromTime),getTimeMinute(evts.fromTime));

	//toDate = new Date(evts.toYear,getMonthNumber(evts.toMonth)-1,evts.toDay,getTimeHour(evts.toTime),getTimeMinute(evts.toTime));
	//events.start_date = fromDate;
	//events.end_date = toDate;
	events.start_date = startDate;
	events.end_date = endDate;
	events._timed=scheduler.is_one_day_event(events);
	//alert(evt.text);
	//alert(evt._timed);
	//alert ('closelightbox event2');
	
	scheduler._edit_stop_event(events,true);
}
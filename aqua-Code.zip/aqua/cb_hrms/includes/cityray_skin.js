_picklist_width_offset=10;
_picklist_height_offset=12;
Ext.override(Ext.form.TriggerField,{
	defaultTriggerWidth:24,
    getTriggerWidth: function(){
        var tw = this.trigger.getWidth();
        if(!this.hideTrigger && !this.readOnly && tw === 0){
            tw = 24;
        }
        return tw;
    }
});

Ext.override(Ext.ux.tree.FilterTreeGrid,{
	initComponent: function(){
		this.hiddenPkgs = [];
		this.showPkgs = [];
		if(this.id== "undefined"){
			this.id = "";
		}
		Ext.apply(this, {
			tbar: new Ext.Toolbar({
				id:"filterTreeGridToolbar"+"_"+this.id,
				cls:"filter_tree_cls",
				items:[
				{xtype:"box", width:"5",height:"23"},
				{
					iconCls:"toolbar_expand_all",
					tooltip: typeof(getResource)!="undefined"?getResource("expand_all", this.id):"Expand All",
					handler: function(){this.root.expand(true); },
					scope: this
				}, 
				'-', 
				{
					iconCls:"toolbar_collapse_all",
					tooltip: typeof(getResource)!="undefined"?getResource("collapse_all", this.id):"Collapse All",
					handler: function(){this.root.collapse(true);},
					scope: this
				},
				{xtype:"box", width:"5",height:"23"},
				new Ext.form.TextField({
					width: 200,
					height:"25",
					emptyText:typeof(getResource)!="undefined"?getResource("search_tree", this.id):"Search",
					id:'filterTreeGrid_text'+"_"+this.id,
					cls: 'search-icon',
					enableKeyEvents: true,
					listeners:{
						render: function(f){
							this.filter = new Ext.tree.TreeFilter(this, {
								clearBlank: true,
								autoClear: true
							});
						},
						keydown: {
							fn: this.filterTree,
							buffer: 350,
							scope: this
						},
						scope: this
					}
				})
			]
		})
		})
		Ext.ux.tree.FilterTreeGrid.superclass.initComponent.call(this);
	}
});

var my_win_lock = Ext.extend(Ext.Window, {
	paramList : null,
	constructor : function(_cfg) {
		if (_cfg == null) {
			_cfg == {};
			this.paramList = {}
		} else {
			this.paramList = _cfg.paramList;
		};
		Ext.apply(this, _cfg);
		my_win_lock.superclass.constructor.call(this, {
			id:"win_lock_id",
			layout : 'fit',
			width : 300,
			height : 130,
			bodyStyle:{
				padding:'10px',
				background: "#fff"
			},
			resizable : false,
			draggable : false,
			closeAction : 'close',
			modal : true,
			title : getResource('input_password','home'),
			maximizable : false,
			buttonAlign : 'right',
			iconCls :"icon_menu_lock",
			border : false,
			animCollapse : true,
			animateTarget : Ext.getBody(),
			constrain : true,
			plain:true,  
			keys:[
				{key:13,fn:function(){
					menu_password_valid(Ext.getCmp("win_lock_id").paramList);
				}}
			],
			items:[  
	            new Ext.form.TextField({
							id : "menu_password_id",
							inputType:'password',
							name : "menu_password",
							hideLabel : true
						})
	        ], 
			buttons : [{
						text : getResource('sure','home'),
						cls:"cancel_yes",
						handler : function() {
							menu_password_valid(Ext.getCmp("win_lock_id").paramList);
						}
					},{
						text : getResource('cancle','home'),
						cls:"cancel_lock",
						handler : function() {
							Ext.getCmp('menu_password_id').setValue("");
							Ext.getCmp("win_lock_id").close();
						}
			}]
			
		})
	},
	listeners : {
		hide:function(_win) {
			Ext.getCmp('menu_password_id').setValue("");
		}
	}
})




Ext.MessageBox = function(){
    var dlg, opt, mask, waitTimer,
        bodyEl, msgEl, textboxEl, textareaEl, progressBar, pp, iconEl, spacerEl,
        buttons, activeTextEl, bwidth, bufferIcon = '', iconCls = '',
        buttonNames = ['ok', 'yes', 'no', 'cancel'];

    
    var handleButton = function(button){
        buttons[button].blur();
        if(dlg.isVisible()){
            dlg.hide();
            handleHide();
            Ext.callback(opt.fn, opt.scope||window, [button, activeTextEl.dom.value, opt], 1);
        }
    };

    
    var handleHide = function(){
        if(opt && opt.cls){
            dlg.el.removeClass(opt.cls);
        }
        progressBar.reset();        
    };

    
    var handleEsc = function(d, k, e){
        if(opt && opt.closable !== false){
            dlg.hide();
            handleHide();
        }
        if(e){
            e.stopEvent();
        }
    };

    
    var updateButtons = function(b){
        var width = 0,
            cfg;
        if(!b){
            Ext.each(buttonNames, function(name){
                buttons[name].hide();
            });
            return width;
        }
        dlg.footer.dom.style.display = '';
        Ext.iterate(buttons, function(name, btn){
            cfg = b[name];
            if(cfg){
                btn.show();
                btn.getEl().dom.className = btn.getEl().dom.className + " " +name+"_class";
                btn.setText(Ext.isString(cfg) ? cfg : Ext.MessageBox.buttonText[name]);
                width += btn.getEl().getWidth() + 15;
            }else{
                btn.hide();
            }
        });
        return width;
    };

    return {
        
        getDialog : function(titleText){
           if(!dlg){
                var btns = [];
                
                buttons = {};
                Ext.each(buttonNames, function(name){
                    btns.push(buttons[name] = new Ext.Button({
                        text: this.buttonText[name],
                        handler: handleButton.createCallback(name),
                        hideMode: 'offsets'
                    }));
                }, this);
                dlg = new Ext.Window({
                    autoCreate : true,
                    title:titleText,
                    resizable:false,
                    constrain:true,
                    constrainHeader:true,
                    minimizable : false,
                    maximizable : false,
                    stateful: false,
                    modal: true,
                    shim:true,
                    buttonAlign:"center",
                    width:400,
                    height:100,
                    minHeight: 80,
                    plain:true,
                    footer:true,
                    closable:true,
                    close : function(){
                        if(opt && opt.buttons && opt.buttons.no && !opt.buttons.cancel){
                            handleButton("no");
                        }else{
                            handleButton("cancel");
                        }
                    },
                    fbar: new Ext.Toolbar({
                        items: btns,
                        enableOverflow: false
                    })
                });
                dlg.render(document.body);
                dlg.getEl().addClass('x-window-dlg');
                mask = dlg.mask;
                bodyEl = dlg.body.createChild({
                    html:'<div class="ext-mb-icon"></div><div class="ext-mb-content"><span class="ext-mb-text"></span><br /><div class="ext-mb-fix-cursor"><input type="text" class="ext-mb-input" /><textarea class="ext-mb-textarea"></textarea></div></div>'
                });
                iconEl = Ext.get(bodyEl.dom.firstChild);
                var contentEl = bodyEl.dom.childNodes[1];
                msgEl = Ext.get(contentEl.firstChild);
                textboxEl = Ext.get(contentEl.childNodes[2].firstChild);
                textboxEl.enableDisplayMode();
                textboxEl.addKeyListener([10,13], function(){
                    if(dlg.isVisible() && opt && opt.buttons){
                        if(opt.buttons.ok){
                            handleButton("ok");
                        }else if(opt.buttons.yes){
                            handleButton("yes");
                        }
                    }
                });
                textareaEl = Ext.get(contentEl.childNodes[2].childNodes[1]);
                textareaEl.enableDisplayMode();
                progressBar = new Ext.ProgressBar({
                    renderTo:bodyEl
                });
               bodyEl.createChild({cls:'x-clear'});
            }
            return dlg;
        },

        
        updateText : function(text){
            if(!dlg.isVisible() && !opt.width){
                dlg.setSize(this.maxWidth, 100); 
            }
            
            msgEl.update(text ? text + ' ' : '&#160;');

            var iw = iconCls != '' ? (iconEl.getWidth() + iconEl.getMargins('lr')) : 0,
                mw = msgEl.getWidth() + msgEl.getMargins('lr'),
                fw = dlg.getFrameWidth('lr'),
                bw = dlg.body.getFrameWidth('lr'),
                w;
                
            w = Math.max(Math.min(opt.width || iw+mw+fw+bw, opt.maxWidth || this.maxWidth),
                    Math.max(opt.minWidth || this.minWidth, bwidth || 0));

            if(opt.prompt === true){
                activeTextEl.setWidth(w-iw-fw-bw);
            }
            if(opt.progress === true || opt.wait === true){
                progressBar.setSize(w-iw-fw-bw);
            }
            if(Ext.isIE && w == bwidth){
                w += 4; 
            }
            msgEl.update(text || '&#160;');
            dlg.setSize(w, 'auto').center();
            return this;
        },

        
        updateProgress : function(value, progressText, msg){
            progressBar.updateProgress(value, progressText);
            if(msg){
                this.updateText(msg);
            }
            return this;
        },

        
        isVisible : function(){
            return dlg && dlg.isVisible();
        },

        
        hide : function(){
            var proxy = dlg ? dlg.activeGhost : null;
            if(this.isVisible() || proxy){
                dlg.hide();
                handleHide();
                if (proxy){
                    
                    
                    dlg.unghost(false, false);
                } 
            }
            return this;
        },

        
        show : function(options){
            if(this.isVisible()){
                this.hide();
            }
            opt = options;
            var d = this.getDialog(opt.title || "&#160;");

            d.setTitle(opt.title || "&#160;");
            var allowClose = (opt.closable !== false && opt.progress !== true && opt.wait !== true);
            d.tools.close.setDisplayed(allowClose);
            activeTextEl = textboxEl;
            opt.prompt = opt.prompt || (opt.multiline ? true : false);
            if(opt.prompt){
                if(opt.multiline){
                    textboxEl.hide();
                    textareaEl.show();
                    textareaEl.setHeight(Ext.isNumber(opt.multiline) ? opt.multiline : this.defaultTextHeight);
                    activeTextEl = textareaEl;
                }else{
                    textboxEl.show();
                    textareaEl.hide();
                }
            }else{
                textboxEl.hide();
                textareaEl.hide();
            }
            activeTextEl.dom.value = opt.value || "";
            if(opt.prompt){
                d.focusEl = activeTextEl;
            }else{
                var bs = opt.buttons;
                var db = null;
                if(bs && bs.ok){
                    db = buttons["ok"];
                }else if(bs && bs.yes){
                    db = buttons["yes"];
                }
                if (db){
                    d.focusEl = db;
                }
            }
            if(Ext.isDefined(opt.iconCls)){
              d.setIconClass(opt.iconCls);
            }
            this.setIcon(Ext.isDefined(opt.icon) ? opt.icon : bufferIcon);
            bwidth = updateButtons(opt.buttons);
            progressBar.setVisible(opt.progress === true || opt.wait === true);
            this.updateProgress(0, opt.progressText);
            this.updateText(opt.msg);
            if(opt.cls){
                d.el.addClass(opt.cls);
            }
            d.proxyDrag = opt.proxyDrag === true;
            d.modal = opt.modal !== false;
            d.mask = opt.modal !== false ? mask : false;
            if(!d.isVisible()){
                
                document.body.appendChild(dlg.el.dom);
                d.setAnimateTarget(opt.animEl);
                
                d.on('show', function(){
                    if(allowClose === true){
                        d.keyMap.enable();
                    }else{
                        d.keyMap.disable();
                    }
                }, this, {single:true});
                d.show(opt.animEl);
            }
            if(opt.wait === true){
                progressBar.wait(opt.waitConfig);
            }
            return this;
        },

        
        setIcon : function(icon){
            if(!dlg){
                bufferIcon = icon;
                return;
            }
            bufferIcon = undefined;
            if(icon && icon != ''){
                iconEl.removeClass('x-hidden');
                iconEl.replaceClass(iconCls, icon);
                bodyEl.addClass('x-dlg-icon');
                iconCls = icon;
            }else{
                iconEl.replaceClass(iconCls, 'x-hidden');
                bodyEl.removeClass('x-dlg-icon');
                iconCls = '';
            }
            return this;
        },

        
        progress : function(title, msg, progressText){
            this.show({
                title : title,
                msg : msg,
                buttons: false,
                progress:true,
                closable:false,
                minWidth: this.minProgressWidth,
                progressText: progressText
            });
            return this;
        },

        
        wait : function(msg, title, config){
            this.show({
                title : title,
                msg : msg,
                buttons: false,
                closable:false,
                wait:true,
                modal:true,
                minWidth: this.minProgressWidth,
                waitConfig: config
            });
            return this;
        },

        
        alert : function(title, msg, fn, scope){
            this.show({
                title : title,
                msg : msg,
                buttons: this.OK,
                fn: fn,
                scope : scope,
                minWidth: this.minWidth
            });
            return this;
        },

        
        confirm : function(title, msg, fn, scope){
            this.show({
                title : title,
                msg : msg,
                buttons: this.YESNO,
                fn: fn,
                scope : scope,
                icon: this.QUESTION,
                minWidth: this.minWidth
            });
            return this;
        },

        
        prompt : function(title, msg, fn, scope, multiline, value){
            this.show({
                title : title,
                msg : msg,
                buttons: this.OKCANCEL,
                fn: fn,
                minWidth: this.minPromptWidth,
                scope : scope,
                prompt:true,
                multiline: multiline,
                value: value
            });
            return this;
        },

        
        OK : {ok:true},
        
        CANCEL : {cancel:true},
        
        OKCANCEL : {ok:true, cancel:true},
        
        YESNO : {yes:true, no:true},
        
        YESNOCANCEL : {yes:true, no:true, cancel:true},
        
        INFO : 'ext-mb-info',
        
        WARNING : 'ext-mb-warning',
        
        QUESTION : 'ext-mb-question',
        
        ERROR : 'ext-mb-error',

        
        defaultTextHeight : 75,
        
        maxWidth : 600,
        
        minWidth : 100,
        
        minProgressWidth : 250,
        
        minPromptWidth: 250,
        
        buttonText : {
            ok : "OK",
            cancel : "Cancel",
            yes : "Yes",
            no : "No"
        }
    };
}();
Ext.Msg = Ext.MessageBox;


function createAdvSearchPanel(panelName,titleI18nKey){
	if(Ext.getCmp(panelName+"_win")){
		Ext.getCmp(panelName+"_win").destroy();
	}
	var title = titleI18nKey==""?"":eval(titleI18nKey);
	return new Ext.Window({
		id : panelName+"_win",
		manager : windows,
		title : "" + getResource("search", "searchPanel") + " "
				+ title,
		width : 965,
		minWidth : 720,
		height : 270,
		minheight : 270,
		closeAction : "hide",
		autoscroll : false,
		modal : true,
		listeners : {
			"render" : function(w) {
				Ext.Ajax.request({
					method : "post",
					url : "index.cfm?event=searchPanel.general.generateAdvanceSearch&panel_name="+panelName+"&now="
							+ new Date(),
					failure : function(response, options) {
						Ext.MessageBox.alert(getResource("failure",
										panelName), "failure");
					},
					success : function(response, options) {
						var responseText = Ext.util.JSON
								.decode(response.responseText)
						var paramList = new Object();
						paramList.panel_name = panelName;
						paramList.simple_search_field = responseText.success_msg;
						paramList.simple_search_operator = responseText.external_params_1;
						paramList.criFieldList = responseText.external_params_2;
						paramList.fieldDataList = responseText.external_params_3;
						paramList._sql_sys_public = responseText.jsonObject._sql_sys_public;
						paramList._is_admin_user = responseText.jsonObject._is_admin_user;
						w.add(new AdvSearchPanel(paramList));
						w.doLayout();
					}
				});
			}
		}
	});
}


/*******************<script type="text/javascript" src="includes/searchPanel/adv_search_panel.js"></script>******************/ 
AdvSearchPanel = Ext.extend(Ext.form.FormPanel, {
	_global_para:null,
	criteriaFieldJSON:null,
	bitStore:null,
	criteriaOperatorJSON:null,
	linkStore:null,
	criteriaJSON:null, //db_store
	criFieldArray:null,
	fieldDataJsonArray:null,
	fieldDataArray:null,
	searchName:null,
	cls:"adv_searchpanel_component_cls",
	constructor:function(_cfg) {
		//Data
		if(_cfg == null && _cfg == "")_cfg={};
		Ext.apply(this, _cfg);
		if(Ext.getCmp(this.panel_name+"_adv_search_panel_id")){
			Ext.getCmp(this.panel_name+"_adv_search_panel_id").destroy();
		}
		
		this.fieldDataJsonArray = new Array();
		this.fieldDataArray = new Array();
		var tempArray;
		this.criteriaFieldJSON = new Ext.data.ArrayStore({
			fields: [
				{name: 'pkey', type: 'string'},
				{name: 'pvalue', type: 'string'},
				{name: 'fieldType', type: 'string'},
				{name: 'default_search_field', type: 'string'},
				{name: 'default_search_field_operator', type: 'string'}
			],
			data : Ext.decode(this.simple_search_field)
		});
		this.criteriaOperatorJSON = new Ext.data.ArrayStore({
			fields: [{name: 'pkey', type: 'string'}, {name: 'pvalue', type: 'string'}],
			data : Ext.decode(this.simple_search_operator)      
		});
		
		this.bitStore = new Ext.data.ArrayStore({
			fields: [
				{name: 'pvalue', type: 'string'},
				{name: 'pkey', type: 'string'}
			],
			data : [[getResource('yes','searchPanel'),'1'],
				[getResource('no','searchPanel'),'0']]
		});
		
		this.linkStore = new Ext.data.SimpleStore({
			data: [
			    [getResource('AndOperator','searchPanel'),' && '],
				[getResource('OrOperator','searchPanel'),' || ']
			], 
			fields: [ "pvalue" ,"pkey" ]
		});
		
		this._global_para = this;
		
		if(this.criFieldList.length > 0){
			this.criFieldArray = this.criFieldList.split(')~~~(');
		}
		if(this.fieldDataList.length > 0){
			this.fieldDataJsonArray = this.fieldDataList.split(')~~~(');
		}
		if(this.fieldDataJsonArray!=null){
			for (i=0;i < this.fieldDataJsonArray.length;i++){
				tempArray = new Array();
				decodedFieldData = Ext.decode(this.fieldDataJsonArray[i]);
				for (j=0;j < decodedFieldData.data.length; j++){
					tempArray[j] = new Array();
					tempArray[j][0] = decodedFieldData.data[j]['pkey'];
					tempArray[j][1] = decodedFieldData.data[j]['pvalue'];
				}
				this.fieldDataArray[i] = tempArray;
			}
		}
		
		AdvSearchPanel.superclass.constructor.call(this, {
			id:this.panel_name+'_sp_panel',
			bodyStyle: "padding: 3px 10px 3px 10px; ",
			labelAlign:'right',
			autoWidth:true,
			border:false,
			frame:true,
			items: [
				{
					id:this.panel_name+'_sp_show_sql_condition',
					name : 'sql_condition',
					fieldLabel: getResource('sql_condition','searchPanel'),
					xtype:'checkbox',
					allowBlank:true,
					listeners:{
						"check":{
							fn:function(_cmp, _value) {
								this.showSqlSatement(_cmp, _value);
							}
						},scope:this
					}
				},{
					xtype : 'fieldset',
					id : this.panel_name+'fs',
					title: getResource('Criteria','searchPanel'),scope:this,
					labelAlign: 'top',
					dynamic : true,
					maxOccurs:100,
					layout:'column',
					collapsible: false,
					nameSpace:'searchPanel',
					autoHeight:true,
					width:915,
					listeners : {
						'afterClone' : {
							fn: function(fieldset) {
								var fieldsets = Ext.getCmp(this.panel_name+'fs');
								var fslength = fieldsets.items.items[7].items.length;
								
								fieldsets.items.items[2].remove(fieldsets.items.items[2].items.items[fslength-1],true);
								var cf_value = new Ext.form.TextField({
									disabled:true,
									clone: true,				
									width:100,
									hideLabel: true,
									fieldLabel: getResource('Value','searchPanel'),
									name: 'value',
									enableKeyEvents:true,
									listeners:{
										'keyUp':this.keyUpAction,
										scope:this
									}
								});
								fieldsets.items.items[2].insert(fslength-1,cf_value);
								
								fieldsets.items.items[3].remove(fieldsets.items.items[3].items.items[fslength-1],true);
								var cf_from = new Ext.form.TextField({
									disabled:true,
									clone: true,
									width:100,
									hideLabel: true,
									fieldLabel: getResource('Value_from','searchPanel'),
									name: 'value_from',
									enableKeyEvents:true,
									listeners:{
										'keyUp':this.keyUpAction,
										scope:this
									}
								});
								fieldsets.items.items[3].insert(fslength-1,cf_from);
								
								fieldsets.items.items[4].remove(fieldsets.items.items[4].items.items[fslength-1],true);
								var cf_to = new Ext.form.TextField({
									disabled:true,
									clone: true,				
									width:100,
									hideLabel: true,
									fieldLabel: getResource('Value_to','searchPanel'),
									name: 'value_to',
									enableKeyEvents:true,
									listeners:{
										'keyUp':this.keyUpAction,
										scope:this
									}
								});
								fieldsets.items.items[4].insert(fslength-1,cf_to);
								
								fieldsets.items.items[5].remove(fieldsets.items.items[5].items.items[fslength-1],true);
								var cf_include = new Ext.form.TextField({
									disabled:true,
									clone: true,
									width:100,
									hideLabel: true,
									fieldLabel: getResource('Value_include','searchPanel'),
									name: 'value_include',
									enableKeyEvents:true,
									listeners:{
										'keyUp':this.keyUpAction,
										scope:this
									}
								});
								fieldsets.items.items[5].insert(fslength-1,cf_include);
								
								fieldsets.items.items[6].remove(fieldsets.items.items[6].items.items[fslength-1],true);
								var cf_uninclude = new Ext.form.TextField({
									disabled:true,
									clone: true,
									width:100,
									hideLabel: true,
									fieldLabel: getResource('Value_uninclude','searchPanel'),
									name: 'value_uninclude',
									enableKeyEvents:true,
									listeners:{
										'keyUp':this.keyUpAction,
										scope:this
									}
								});
								fieldsets.items.items[6].insert(fslength-1,cf_uninclude);
								
								fieldsets.items.items[7].remove(fieldsets.items.items[7].items.items[fslength-1],true);
								var cf = new Ext.form.ComboBox({
									hideLabel: true,
									name:'link_operator_id',
									mode:'local',
									value:'',
									editable:false,
									displayField:'pvalue',
									valueField:'pkey',
									forceSelection: true,
									clone: true,
									disabled:true,
									selectOnFocus: true,
									typeAhead: true,
									store:this._global_para.linkStore,
									triggerAction: 'all',
									width:50,
									minListWidth:50,
									resizable:true,
									iconCfg : {cls:'x-tool x-tool-minus',clsOnOver:'x-tool-minus-over'},
									listeners :{
										'onIcon' : {
											fn: function(field) {
												this.deleteRow(field);
											}
										},
										'beforeselect':this.cloneField,
										'select' :function(){
											this.keyUpAction();
										},
										scope:this
									},
									scope:this
								});
								
								fieldsets.items.items[7].insert(fslength-1,cf);
								fieldsets.doLayout();
								this.ownerCt.setHeight(this._global_para.ownerCt.getHeight()+40);
								
								this.setDefaultSearchField(fieldsets.items.items[0].items.items[fslength-1]);
							}
						},
						scope:this
					},
					items :[{
						layout:'form',
						columnWidth:.14,
						defaultType: 'combo',
						items:[{
							xtype:'combo',
							id:this.panel_name+'_sp_criteria_field_desc',
							name:'cri_field',
							fieldLabel: getResource('Field','searchPanel'),
							hiddenName:'cri_field',
							mode:'local',
							value:'',
							displayField:'pvalue',
							valueField:'pkey',
							store: this._global_para.criteriaFieldJSON,
							forceSelection: true,
							selectOnFocus: true,
							typeAhead: true,
							triggerAction: 'all',
							minListWidth: 110,
							width:110,
							resizable:true,
							listeners : { //Field Event
								'select' : {
									fn: function(combo, record, index ){
										var fieldsets = Ext.getCmp(this.panel_name+'fs');
										var row = 0;
										for(; row < fieldsets.items.items[0].items.length ; row++) {
											if (fieldsets.items.items[0].items.items[row].id == combo.id)
												break;
										}
										fieldsets.items.items[1].items.items[row].setDisabled(false);
										if(this._global_para.criteriaFieldJSON.getAt(0).data.default_search_field!=""&&this._global_para.criteriaFieldJSON.getAt(0).data.default_search_field==combo.getValue()&&this._global_para.criteriaFieldJSON.getAt(0).data.default_search_field_operator!=""){
											fieldsets.items.items[1].items.items[row].setValue(this._global_para.criteriaFieldJSON.getAt(0).get('default_search_field_operator'));
										}else{
											fieldsets.items.items[1].items.items[row].setValue(this._global_para.criteriaOperatorJSON.getAt(0).get('pkey'));
										}
										this.populateRow(row,"","");
										fieldsets.items.items[7].doLayout();
										this.keyUpAction();
									}
								},
								'afterrender':{
									fn:function(_combo) {
										this._global_para.setDefaultSearchField(_combo);
									}
								},
								scope:this
							}
						}]
					}, {
						layout:'form',
						columnWidth:.13,
						defaultType: 'combo',
						items:[{
							xtype:'combo',
							id:this.panel_name+'_sp_operator_id_desc',
							name:'operator_id',
							fieldLabel: getResource('Operator','searchPanel'),
							mode:'local',
							value:'',
							store:this.criteriaOperatorJSON,
							editable:false,
							displayField:'pvalue',
							valueField:'pkey',
							forceSelection: true,
							selectOnFocus: true,
							typeAhead: true,
							triggerAction: 'all',
							minListWidth: 100,
							width:100,
							resizable:true,
							listeners : {
								'select' : this.keyUpAction,
								scope:this
							}
						}]
					},{
						layout:'form',
						columnWidth:.13,
						defaultType: 'textfield',
						items:[{
							xtype:'textfield',
							id:this.panel_name+'_sp_value',
							width:100,
							fieldLabel: getResource('Value','searchPanel'),
							name:'value',
							mode:'local',
							triggerAction: 'all',
							disabled:true,
							clone: true,
							enableKeyEvents:true				
						}]
					},{
						layout:'form',
						columnWidth:.13,
						defaultType: 'textfield',
						items:[{
							fieldLabel: getResource('Value_from','searchPanel'),
							width:100,
							xtype:'textfield',
							id:this.panel_name+'_sp_value_from',
							name:'value_from',
							mode:'local',
							triggerAction: 'all',
							enableKeyEvents:true,
							disabled:true,
							clone: true								
						}]
					},{
						layout:'form',
						columnWidth:.13,
						defaultType: 'textfield',
						items:[{
							xtype:'textfield',
							id:this.panel_name+'_sp_value_to',
							name:'value_to',
							fieldLabel: getResource('Value_to','searchPanel'),
							width:100,
							mode:'local',
							triggerAction: 'all',
							disabled:true,
							clone: true,
							enableKeyEvents:true						
						}]
					},{
						layout:'form',
						columnWidth:.13,
						defaultType: 'textfield',
						items:[{
							xtype:'textfield',
							id:this.panel_name+'_sp_value_include',
							name:'value_include',
							fieldLabel: getResource('Value_include','searchPanel'),
							width:100,
							mode:'local',
							enableKeyEvents:true,
							triggerAction: 'all',
							disabled:true,
							clone: true							
						}]
					},{
						layout:'form',
						columnWidth:.13,
						defaultType: 'textfield',
						items:[{
							xtype:'textfield',
							id:this.panel_name+'_sp_value_uninclude',
							name:'value_uninclude',
							fieldLabel: getResource('Value_uninclude','searchPanel'),
							width:100,
							mode:'local',
							triggerAction: 'all',
							disabled:true,
							clone: true,
							enableKeyEvents:true							
						}]
					},{
						layout:'form',
						columnWidth:.08,
						defaultType: 'textfield',
						items:[{
							xtype:'combo',
							id:this.panel_name+'_sp_link_operator_id_desc',
							name:'link_operator_id',
							fieldLabel: getResource('Link_operator','searchPanel'),
							mode:'local',
							value:'',
							editable:false,
							displayField:'pvalue',
							valueField:'pkey',
							forceSelection: true,
							clone: true,
							disabled:true,
							selectOnFocus: true,
							typeAhead: true,
							store:this.linkStore,
							triggerAction: 'all',
							width:50,
							minListWidth:50,
							resizable:true,
							iconCfg : {cls:'x-tool x-tool-minus',clsOnOver:'x-tool-minus-over'},
							listeners :{
								'onIcon' : {
									fn: function(field) {
										this.deleteRow(field);
									}
								},
								'beforeselect' :this.cloneField,        
								'select' :function(){
									this.keyUpAction();
								},
								scope:this
							}
						}]
					}]
				},{
					hideLabel:true,
					hidden:true,
					id:this.panel_name+'_real_condition_value',
					name : '_real_condition_value',
					width:915,
					height:95,
					xtype:'textarea'
				}
			],
			buttons: [{
				id: this.panel_name+'_sp_search_button',
				text: getResource('Search','searchPanel'),
				handler:this.search,scope:this
			},{
				id: this.panel_name+"_sp_searchClose_button",
				text: getResource('SearchAndClose','searchPanel'),
				handler:this.searchClose,scope:this
			},{
				id: this.panel_name+"_sp_clear_search",
				text: getResource('Clear','searchPanel'),
				handler : function(b,e) {
					this.clearSearchPanel();
				},scope:this
			}, {
				id: this.panel_name+'_sp_save_search',
				text: getResource('Save_Search_Criteria','searchPanel'),
				hidden:true,
				handler : this.saveSearchCriteria,
				scope:this
			}, {
				id: this.panel_name+'_sp_load_search',
				text: getResource('Load_Search_Criteria','searchPanel'),
				handler: this.loadSearchCriteria,
				scope:this,
				hidden:true
			}],
			buttonAlign: 'left'
		});
	},
	cloneField:function (_combo){
		if(_combo.getValue()=="" ||_combo.getValue()==null){
			var fieldset = Ext.getCmp(this.panel_name+"fs");
			var numOfClones = fieldset.clones();
			
		    if ( !Ext.isEmpty(fieldset.maxOccurs) ) {
				if ( fieldset.maxOccurs  <= numOfClones + 1) {
					fieldset.fireEvent('maxoccurs',fieldset);
					return;													   
				}
		    }
			var panel = fieldset.ownerCt;	
			fieldset.clones(numOfClones+1);
			panel.doLayout();																								   										
			fieldset.fireEvent('afterClone',fieldset);
		}
	},
	
	
	clearSearchPanel:function (){
		is_load_search=0;
		Ext.getCmp(this.panel_name+"_real_condition_value").setValue("");
		var fieldsets = Ext.getCmp(this.panel_name+'fs');
		//iterate through fieldsets and remove clones
		if (fieldsets.items.items[0].items.length > 1){
			for (var col = 0; col < fieldsets.items.length ; col++){
				for(var i = fieldsets.items.items[col].items.length-1; i > 0 ; i--){
					if (fieldsets.items.items[col].items.items[i].clone != null){
						if (fieldsets.items.items[col].items.items[i].clone == true){
							var field = fieldsets.items.items[col].items.items[i];
							var form = field.ownerCt;
							var fieldset = form.ownerCt;
							var rowNum = form.items.indexOf(field);
							//remove every field in row(n) for each form
							//forms only contain one column
							fieldset.items.each(function(item,index,length){
								var form = item;
								var fieldset = form.ownerCt;
								field = form.items.itemAt(rowNum);
								form.remove(field);
								form.doLayout();
							},this);
						}
					}
				}
			}
		}
		fieldsets.items.items[0].items.items[0].clearValue();
		fieldsets.items.items[1].items.items[0].clearValue();
		fieldsets.items.items[1].items.items[0].setDisabled(false);
		var fslength = fieldsets.items.items[7].items.length;
		fieldsets.items.items[2].remove(fieldsets.items.items[2].items.items[fslength-1],true);
		var cf_value = new Ext.form.TextField({
			disabled:true,
			clone: true,				
			width:100,
			hideLabel: false,
			fieldLabel: getResource('Value','searchPanel'),
			labelAlign:"top",
			name: 'value'
		});
		fieldsets.items.items[2].insert(fslength-1,cf_value);
		
		fieldsets.items.items[3].remove(fieldsets.items.items[3].items.items[fslength-1],true);
		var cf_from = new Ext.form.TextField({
			disabled:true,
			clone: true,
			width:100,
			labelAlign:"top",
			hideLabel: false,
			enableKeyEvents:true,
			fieldLabel: getResource('Value_from','searchPanel'),
			name: 'value_from',
			listeners:{
				'keyUp':this._global_para.keyUpAction,
				scope:this
			}
			
		});
		fieldsets.items.items[3].insert(fslength-1,cf_from);
		
		fieldsets.items.items[4].remove(fieldsets.items.items[4].items.items[fslength-1],true);
		var cf_to = new Ext.form.TextField({
			disabled:true,
			clone: true,				
			enableKeyEvents:true,
			width:100,
			labelAlign:"top",
			hideLabel: false,
			fieldLabel: getResource('Value_to','searchPanel'),
			name: 'value_to',
			listeners:{
				'keyUp':this._global_para.keyUpAction,
				scope:this
			}
		});
		fieldsets.items.items[4].insert(fslength-1,cf_to);
		
		fieldsets.items.items[5].remove(fieldsets.items.items[5].items.items[fslength-1],true);
		var cf_include = new Ext.form.TextField({
			disabled:true,
			clone: true,
			enableKeyEvents:true,
			labelAlign:"top",
			width:100,
			hideLabel: false,
			fieldLabel: getResource('Value_include','searchPanel'),
			name: 'value_include',
			listeners:{
				'keyUp':this._global_para.keyUpAction,
				scope:this
			}
		});
		fieldsets.items.items[5].insert(fslength-1,cf_include);
		
		fieldsets.items.items[6].remove(fieldsets.items.items[6].items.items[fslength-1],true);
		var cf_uninclude = new Ext.form.TextField({
			disabled:true,
			clone: true,
			enableKeyEvents:true,
			width:100,
			hideLabel: false,
			labelAlign:"top",
			fieldLabel: getResource('Value_uninclude','searchPanel'),
			name: 'value_uninclude',
			listeners:{
				'keyUp':this._global_para.keyUpAction,
				scope:this
			}
		});
		fieldsets.items.items[6].insert(fslength-1,cf_uninclude);
		
		fieldsets.items.items[7].remove(fieldsets.items.items[7].items.items[fslength-1],true);
		var cf = new Ext.form.ComboBox({
			hideLabel: false,
			labelAlign:"top",
			name:'link_operator_id',
			fieldLabel: getResource('Link_operator','searchPanel'),
			mode:'local',
			value:'',
			editable:false,
			displayField:'pvalue',
			valueField:'pkey',
			forceSelection: true,
			clone: true,
			disabled:true,
			selectOnFocus: true,
			typeAhead: true,
			store:this._global_para.linkStore,
			triggerAction: 'all',
			width:50,
			minListWidth:50,
			resizable:true,
			iconCfg : {cls:'x-tool x-tool-minus',clsOnOver:'x-tool-minus-over'},
			listeners :{
				'onIcon' : {
					fn: function(field) {
						this._global_para.deleteRow(field);
					}
				},
				'beforeselect':this._global_para.cloneField,///???
				'select' :function(){
					this._global_para.keyUpAction();
				},
				scope:this
			}
		});
		fieldsets.items.items[7].insert(fslength-1,cf);
		fieldsets.doLayout();
		if(Ext.getCmp(this.panel_name+"_sp_show_sql_condition").getValue()==true){
			this.ownerCt.setHeight(370);
		}else{
			this.ownerCt.setHeight(270);
		}
		Ext.getCmp(this.panel_name+'_sp_panel').searchName = "";
	},
	saveSearchCriteria:function (){
		_checkPanel = this;
		if(typeof(Ext.getCmp(this.panel_name+"criteria_win_pop"))!="undefined"){
			Ext.getCmp(this.panel_name+"criteria_win_pop").show();
		}else{
			var win = new Ext.Window({
				title:getResource('save_criteria_title','searchPanel'),
				width:300,
				height:150,
				id:this.panel_name+"criteria_win_pop",
				resizable:false,
				items:[new Ext.form.FormPanel({
					autoWidth:true,
					height:130,
					labelWidth:100,
					labelAlign:"right",
					id:this.panel_name+"search_criteria_win",
					border:false,
					bodyBorder:false,
					bodyStyle:'padding-top:5px',
					items:[{
						xtype:"textfield",
						width:150,
						id:this.panel_name+"criteria_desc",
						name:"description",
						fieldLabel:getResource('save_criteria_desc','searchPanel'),
						listeners: {
							"afterrender":function(o){
								if(Ext.getCmp(this.panel_name+'_sp_panel').searchName!=null&&Ext.getCmp(this.panel_name+'_sp_panel').searchName!=""){
									o.setValue(Ext.util.Format.htmlDecode(Ext.getCmp(this.panel_name+'_sp_panel').searchName));
								}
							},scope:this
						},
						allowBlank:false
					},{
						xtype:"checkbox",
						width:150,
						id:this.panel_name+"criteria_search_default",
						checked:true,
						name:"check_default",
						fieldLabel:getResource('save_criteria_default','searchPanel'),
						listeners: {
							"afterrender":function(_check) {
								if(typeof(Ext.getCmp(_checkPanel.panel_name+"_simplepanel_criteriadata_combo")) == "undefined") {
									if(_check) {
										_check.setVisible(false);
									}
								}
							}
						}	
					},{
						xtype:"checkbox",
						width:150,
						id:this.panel_name+"save_criteria_type",
						checked:false,
						name:"save_type",
						fieldLabel:getResource('is_public','searchPanel'),	
						listeners: {
							"afterrender":function(_check) {
								if(typeof(Ext.getCmp(_checkPanel.panel_name+"_simplepanel_criteriadata_combo"))=="undefined") {
									if(_check) {
										_check.setVisible(false);
									}
								}else{
									if(_checkPanel._sql_sys_public == 1)
									{
										if(_checkPanel._is_admin_user != 1) {
											if(_check) {
												_check.setVisible(false);
											}
										}
									}
								}
							}
						}
					}],
					tbar:[{
						text:getResource('save_criteria','searchPanel'),
						icon:"../ext/resources/images/icons/save.gif",
						handler:this.saveCriteriaWin,
						scope:this
					}]
				})]
			}).show();
		}
	},
	saveCriteriaByNameSql:function(_notHasSqlFlag, _notHasValueFlag,_realCondition,_str_sql,description,search_default,save_type) {
		var _global = this;
		if(_notHasSqlFlag) {
			if(_notHasValueFlag) {
				Ext.MessageBox.wait(getResource('waitMsg','searchPanel'), getResource('Saving','searchPanel'), '');
				Ext.Ajax.request({
					url:"index.cfm?event=searchPanel.general.save&action=A&datenow=" + new Date(),
					params: {
				        search_sql:_realCondition,
				        //zzt criteria_type_public:criteria_type_public,
				        search_defalut:search_default,
				        save_type:save_type,
				        panel_name:this.panel_name,
				        description:description
				    },
					success: function(response,options) {
					  Ext.MessageBox.hide();
				      var responseText = Ext.util.JSON.decode(response.responseText);
				      if(responseText.flag=='S'){
				     	 Ext.Msg.alert(getResource('Success','searchPanel'),responseText.success_msg,function(){
				     	 	Ext.getCmp(_global.panel_name+"criteria_win_pop").close();
				     	 });
				     	if(typeof(Ext.getCmp(_global.panel_name+"_simplepanel_criteriadata_combo")) != "undefined") {
				     		Ext.getCmp(_global.panel_name+"_simplepanel_criteriadata_combo").getStore().reload();
				     	 }
				      }
				      if(responseText.flag=='C'){
				      	Ext.Msg.confirm(getResource('confirm','searchPanel'),responseText.confirm_msg,function(_btn){
				      		if(_btn == "yes"){
				      			Ext.MessageBox.wait(getResource('waitMsg','searchPanel'), getResource('Saving','searchPanel'), '');
				      			Ext.Ajax.request({
									url:"index.cfm?event=searchPanel.general.save&action=E&datenow=" + new Date(),
									params: {
								        search_sql:_realCondition,
								        save_type:save_type,
								        panel_name:_global.panel_name,
								        description:description
								    },
									success: function(response,options) {
									  Ext.MessageBox.hide();
								      var responseText = Ext.util.JSON.decode(response.responseText);
								      if(responseText.flag=='S'){
								     	 Ext.Msg.alert(getResource('Success','searchPanel'),responseText.success_msg,function(){
								     	 	Ext.getCmp(_global.panel_name+"criteria_win_pop").close();
								     	 });
								      }
								    },
								    failure: function(response,options) {
								    	Ext.MessageBox.hide();
								    	var responseText = Ext.util.JSON.decode(response.responseText);
								    	Ext.Msg.alert(getResource('error','searchPanel'),responseText.error_msg);
								    }
								});
				      		}
				      	});
				      }
				      Ext.getCmp(this.panel_name+'_sp_panel').searchName = "";
				    },
				    failure: function(response,options) {
				    	Ext.MessageBox.hide();
				    	var responseText = Ext.util.JSON.decode(response.responseText);
				    	Ext.Msg.alert(getResource('error','searchPanel'),responseText.error_msg);
				    },
				    scope:this
				});
			}else {
				//
				var _global2 = this;
				Ext.Msg.confirm(getResource('load_criteria_tishi','searchPanel'),getResource('load_criteria_alert','searchPanel'),function(_btn) {
					if(_btn == "yes") {
						Ext.MessageBox.wait(getResource('waitMsg','searchPanel'), getResource('Saving','searchPanel'), '');
					Ext.Ajax.request({
						url:"index.cfm?event=searchPanel.general.save&action=E&datenow=" + new Date(),
						params: {
					        search_sql:_realCondition,
					        //zzt criteria_type_public:criteria_type_public,
					        save_type:save_type,
					        panel_name:_global2.panel_name,
					        description:description
					    },
						success: function(response,options) {
						  Ext.MessageBox.hide();
					      var responseText = Ext.util.JSON.decode(response.responseText);
					      if(responseText.flag=='S'){
					     	 Ext.Msg.alert(getResource('Success','searchPanel'),responseText.success_msg,function(){
					     	 	Ext.getCmp(_global.panel_name+"criteria_win_pop").close();
					     	 });
					     	if(typeof(Ext.getCmp(_global.panel_name+"_simplepanel_criteriadata_combo")) != "undefined") {
					     		Ext.getCmp(_global.panel_name+"_simplepanel_criteriadata_combo").getStore().reload();
					     	 }
					      }
					      if(responseText.flag=='C'){
					      	Ext.Msg.confirm(getResource('confirm','searchPanel'),responseText.confirm_msg,function(_btn){
					      		if(_btn == "yes"){
					      			Ext.MessageBox.wait(getResource('waitMsg','searchPanel'), getResource('Saving','searchPanel'), '');
					      			Ext.Ajax.request({
										url:"index.cfm?event=searchPanel.general.save&action=E&datenow=" + new Date(),
										params: {
									        search_sql:_realCondition,
									        save_type:save_type,
									        panel_name:_global.panel_name,
									        description:description
									    },
										success: function(response,options) {
										  Ext.MessageBox.hide();
									      var responseText = Ext.util.JSON.decode(response.responseText);
									      if(responseText.flag=='S'){
									     	 Ext.Msg.alert(getResource('Success','searchPanel'),responseText.success_msg,function(){
									     	 	Ext.getCmp(_global.panel_name+"criteria_win_pop").close();
									     	 });
									      }
									    },
									    failure: function(response,options) {
									    	Ext.MessageBox.hide();
									    	var responseText = Ext.util.JSON.decode(response.responseText);
									    	Ext.Msg.alert(getResource('error','searchPanel'),responseText.error_msg);
									    }
									});
					      		}
					      	});
					      }
					      Ext.getCmp(_global2.panel_name+'_sp_panel').searchName = "";
					    },
					    failure: function(response,options) {
					    	Ext.MessageBox.hide();
					    	var responseText = Ext.util.JSON.decode(response.responseText);
					    	Ext.Msg.alert(getResource('error','searchPanel'),responseText.error_msg);
					    },
					    scope:this
					});
						
					}
					
				});
				
				//
			}//end
		}else {
			Ext.Msg.alert(getResource('load_criteria_tishi','searchPanel'),getResource('has_same_sql','searchPanel'));
		}
	},
	saveCriteriaWin:function (){
		var _global = this;
		
		
		if(Ext.getCmp(this.panel_name+"search_criteria_win").getForm().isValid()){
			var _realCondition = Ext.getCmp(this.panel_name+"_real_condition_value").getValue();
			if(_realCondition=="" || _realCondition==null){
				 Ext.Msg.alert(getResource('condition_empty_title','searchPanel'), getResource('condition_empty_msg','searchPanel'));
				 return ;
			}
			//zzt var criteria_type_public = Ext.getCmp(this.panel_name+"criteria_type_public").getValue();
			var search_default;
			if(typeof(Ext.getCmp(_global.panel_name+"_simplepanel_criteriadata_combo"))=="undefined") {
				search_default =false;
			}else {
				search_default = Ext.getCmp(this.panel_name+"criteria_search_default").getValue();
			}
			var save_type;
			if(typeof(Ext.getCmp(_global.panel_name+"_simplepanel_criteriadata_combo"))=="undefined") {
				save_type =false;
			}else {
				save_type = Ext.getCmp(this.panel_name+"save_criteria_type").getValue();
			}
			var description = Ext.getCmp(this.panel_name+"criteria_desc").getValue();
			var _str_sql = Ext.getCmp(this.panel_name+"_real_condition_value").getValue();
			//_simplepanel_criteriadata_combo
			var _simplepanel_criteriadata_combo = Ext.getCmp(this.panel_name+"_simplepanel_criteriadata_combo");
			var _notHasValueFlag = true;
			var _notHasSqlFlag = true;
			if(typeof(_simplepanel_criteriadata_combo) != "undefined") {
				var _s_store = _simplepanel_criteriadata_combo.getStore();
				var _s_count = _s_store.getCount();
				for(var i=0;i<_s_count;i++) {
					if(_s_store.getAt(i).get('description') == description) {
						_notHasValueFlag = false;
					}
					if(_s_store.getAt(i).get('search_sql') == _str_sql) {
						_notHasSqlFlag = false;
					}
				}
				this.saveCriteriaByNameSql(_notHasSqlFlag, _notHasValueFlag,_realCondition,_str_sql,description,search_default,save_type);
			}else {
				Ext.Ajax.request({
					url:"index.cfm?event=searchPanel.general.criteriaDataOrderBy&panel_name="+this.panel_name,
					success: function(response,options) {
						var responseText = Ext.util.JSON.decode(response.responseText);
						var _data = responseText.query.data;
						for(var i=0; i<_data.length;i++) {
							if(description==_data[i].description){
								_notHasValueFlag = false;
							} 
							if(_str_sql == _data[i].search_sql) {
								_notHasSqlFlag = false;
							}
						}
						this.saveCriteriaByNameSql(_notHasSqlFlag, _notHasValueFlag,_realCondition,_str_sql,description,search_default,save_type);
					},
				    failure: function(response,options) {
				    	Ext.MessageBox.hide();
				    	var responseText = Ext.util.JSON.decode(response.responseText);
				    	Ext.Msg.alert(getResource('error','searchPanel'),responseText.error_msg);
				    },
				    scope:this
				});
				
			}
		}
	},
	
	deleteRow:function (field){
		var fsLength = Ext.getCmp(this.panel_name+'fs').items.items[0].items.length;
		if (fsLength == 1){
			this._global_para.clearSearchPanel();
			return;
		}
		
		var form = field.ownerCt;
		var fieldset = form.ownerCt;
		var rowNum = form.items.indexOf(field);
		if (rowNum == 0 && fsLength > 1){
			Ext.getCmp(this.panel_name+'fs').items.items[0].items.items[1].getEl().up('.x-form-item', 10, true).removeClass('x-hide-label');
			Ext.getCmp(this.panel_name+'fs').items.items[0].items.items[1].getEl().up('.x-form-item', 10, true).child('.x-form-item-label').update(getResource('Field','searchPanel')+":");
			Ext.getCmp(this.panel_name+'fs').items.items[1].items.items[1].getEl().up('.x-form-item', 10, true).removeClass('x-hide-label');
			Ext.getCmp(this.panel_name+'fs').items.items[1].items.items[1].getEl().up('.x-form-item', 10, true).child('.x-form-item-label').update(getResource('Operator','searchPanel')+":");
			Ext.getCmp(this.panel_name+'fs').items.items[2].items.items[1].getEl().up('.x-form-item', 10, true).removeClass('x-hide-label');
			Ext.getCmp(this.panel_name+'fs').items.items[2].items.items[1].getEl().up('.x-form-item', 10, true).child('.x-form-item-label').update(getResource('Value','searchPanel')+":");
			Ext.getCmp(this.panel_name+'fs').items.items[3].items.items[1].getEl().up('.x-form-item', 10, true).removeClass('x-hide-label');
			Ext.getCmp(this.panel_name+'fs').items.items[3].items.items[1].getEl().up('.x-form-item', 10, true).child('.x-form-item-label').update(getResource('Value_from','searchPanel')+":");
			Ext.getCmp(this.panel_name+'fs').items.items[4].items.items[1].getEl().up('.x-form-item', 10, true).removeClass('x-hide-label');
			Ext.getCmp(this.panel_name+'fs').items.items[4].items.items[1].getEl().up('.x-form-item', 10, true).child('.x-form-item-label').update(getResource('Value_to','searchPanel')+":");
			Ext.getCmp(this.panel_name+'fs').items.items[5].items.items[1].getEl().up('.x-form-item', 10, true).removeClass('x-hide-label');
			Ext.getCmp(this.panel_name+'fs').items.items[5].items.items[1].getEl().up('.x-form-item', 10, true).child('.x-form-item-label').update(getResource('Value_include','searchPanel')+":");
			Ext.getCmp(this.panel_name+'fs').items.items[6].items.items[1].getEl().up('.x-form-item', 10, true).removeClass('x-hide-label');
			Ext.getCmp(this.panel_name+'fs').items.items[6].items.items[1].getEl().up('.x-form-item', 10, true).child('.x-form-item-label').update(getResource('Value_uninclude','searchPanel')+":");
			Ext.getCmp(this.panel_name+'fs').items.items[7].items.items[1].getEl().up('.x-form-item', 10, true).removeClass('x-hide-label');
			Ext.getCmp(this.panel_name+'fs').items.items[7].items.items[1].getEl().up('.x-form-item', 10, true).child('.x-form-item-label').update(getResource('Link_operator','searchPanel')+":");
		}
		//remove every field in row(n) for each form
		//forms only contain one column
		fieldset.items.each(function(item,index,length){
			var form = item;
			var fieldset = form.ownerCt;
			field = form.items.itemAt(rowNum);
			var item = Ext.get(field.el.findParent('.x-form-item'));
			//item.remove();
			form.remove(field);
			form.doLayout();
			
		},this);
		this.ownerCt.setHeight(this.ownerCt.getHeight()-40);
		Ext.getCmp(this.panel_name+'fs').items.items[7].items.items[fieldset.items.items[0].items.length-1].setValue("");
		this._global_para.keyUpAction();
	},
	
	loadSearchCriteria:function (){
		this.criteriaJSON = new Ext.data.JsonStore({
			autoLoad: true,
			remoteSort: true,
			root: "query.data",
			totalProperty: "totalcount",
			url: "index.cfm?event=searchPanel.general.CriteriaData&panel_name="+this.panel_name,
			fields: ["criteria_id","panel_name","userID","search_sql","save_type","description", "default_search"]
		});
		if(typeof(Ext.getCmp(this.panel_name+"criteria_win_load"))!="undefined"){
			Ext.getCmp(this.panel_name+"criteria_win_load").show();
		}else{
			var _checkPanel = this;
			var winLoad = new Ext.Window({
				modal:true,
				title:getResource('load_criteria_title','searchPanel'),
				width: 600,
				height: 410,
				id:this.panel_name+"criteria_win_load",
				items:[
					new Ext.grid.GridPanel({
						stripeRows:true,
						border:false,
						store:this.criteriaJSON,
						height:370,
						id:this.panel_name+"criteriaGrid",
						columns: [
					        {header: getResource('criteria_id','searchPanel'), width: 200, sortable: true, dataIndex: 'criteria_id',hidden:true, menuDisabled:true},
					        {header: getResource('panel_name','searchPanel'), width: 120, sortable: true, dataIndex: 'panel_name',hidden:true, menuDisabled:true},
					        {header: getResource('userID','searchPanel'), width: 120, sortable: true, dataIndex: 'userID',hidden:true, menuDisabled:true},
					        {header: getResource('description','searchPanel'), width: 135, sortable: true, dataIndex: 'description', menuDisabled:true},
					        {header: getResource('search_sql','searchPanel'), width: 120, sortable: true, dataIndex: 'search_sql', menuDisabled:true},
					        {header: getResource('save_type','searchPanel'), width: 135, sortable: true, dataIndex: 'save_type', menuDisabled:true},
					        {header: getResource('default_search','searchPanel'), width: 135, sortable: true, dataIndex: 'default_search', menuDisabled:true}
					    ],
					    bbar: new Ext.PagingToolbar({
					        store: this.criteriaJSON,
					        displayInfo: true,
					        displayInfo:true,
					        pageSize: 20
					    }),
					    sm: new Ext.grid.RowSelectionModel({singleSelect:true}),
					    tbar:[{
					    	text:getResource('load_criteria','searchPanel'),
					    	icon:"../ext/resources/images/icons/load_criteria.png",
					    	height:30,
					    	handler:this.loadCriteriaEvent,
					    	scope:this
					    },{
					    	text:getResource('delete_criteria','searchPanel'),
					    	icon:"../ext/resources/images/icons/delete_criteria.png",
					    	handler:this.deleteCriteriaEvent,
					    	height:30,
					    	scope:this
					    },{
					    	text:getResource('default_criteria','searchPanel'),
					    	icon:"../ext/resources/images/icons/example.gif",
					    	handler:this.defaultCriteriaEvent,
					    	height:30,
					    	listeners: {
					    		"afterrender":function(_btn) {
									if(typeof(Ext.getCmp(_checkPanel.panel_name+"_simplepanel_criteriadata_combo")) == "undefined") {
										if(_btn) {
											_btn.setVisible(false);
										}
									}
								}
					    	},
					    	scope:this
					    }],
					    listeners:{
					    	rowdblclick:this.loadCriteriaEvent,
					    	"afterrender":function(_gridpanel) {
					    		if(typeof(Ext.getCmp(_checkPanel.panel_name+"_simplepanel_criteriadata_combo")) == "undefined") { 
					    			_gridpanel.getColumnModel().setHidden(6, true);
					    			_gridpanel.getColumnModel().isMenuDisabled(6);
					    		}
					    	},
					    	scope:this
					    }
					})
				]
			}).show();
		}
	},
	
	defaultCriteriaEvent:function() {
		var _global = this;
		var selectRecord = Ext.getCmp(this.panel_name+"criteriaGrid").getSelectionModel().getSelections();
		if(selectRecord.length>0){
			Ext.Msg.confirm(getResource('tip','searchPanel'),getResource('confirm_default_msg','searchPanel'),function(_btn){
				if(_btn == 'yes'){
					selectRecord = Ext.getCmp(_global.panel_name+"criteriaGrid").getSelectionModel().getSelected();
					var criteria_id = selectRecord.get("criteria_id");
					Ext.MessageBox.wait(getResource('waitMsg','searchPanel'), getResource('defaluting','searchPanel'), '');
					Ext.Ajax.request({
						url:"index.cfm?event=searchPanel.general.defalut&datenow=" + new Date(),
						params: {
					        criteria_id:criteria_id,
					  		is_validate:1
					    },
						success: function(response,options) {
						  Ext.MessageBox.hide();
					      var responseText = Ext.util.JSON.decode(response.responseText);
					      if(responseText.flag == "E"){
					      		Ext.Msg.alert(getResource('error','searchPanel'),responseText.error_msg);
					      }
					      else{
					     	  Ext.Msg.alert(getResource('Success','searchPanel'),responseText.success_msg,function(){
					     		 _global.criteriaJSON.reload();
					     		if(typeof(Ext.getCmp(_global.panel_name+"_simplepanel_criteriadata_combo")) != "undefined") {
						     		Ext.getCmp(_global.panel_name+"_simplepanel_criteriadata_combo").getStore().reload();
						     	}
					     	  });
					      }
					    },
					    failure: function(response,options) {
					    	Ext.MessageBox.hide();
					    	var responseText = Ext.util.JSON.decode(response.responseText);
					    	Ext.Msg.alert(getResource('error','searchPanel'),responseText.error_msg);
					    }
					});
				}
			});
		}else{
			Ext.Msg.alert(getResource('load_criteria','searchPanel'),getResource('noRecordSelect','searchPanel'));
		}
	},
	deleteCriteriaEvent:function (){
		var _global = this;
		var selectRecord = Ext.getCmp(this.panel_name+"criteriaGrid").getSelectionModel().getSelections();
		if(selectRecord.length>0){
			Ext.Msg.confirm(getResource('confirm_del','searchPanel'),getResource('confirm_del_msg','searchPanel'),function(_btn){
				if(_btn == 'yes'){
					selectRecord = Ext.getCmp(_global.panel_name+"criteriaGrid").getSelectionModel().getSelected();
					var criteria_id = selectRecord.get("criteria_id");
					Ext.MessageBox.wait(getResource('waitMsg','searchPanel'), getResource('Deleting','searchPanel'), '');
					Ext.Ajax.request({
						url:"index.cfm?event=searchPanel.general.delete&datenow=" + new Date(),
						params: {
					        criteria_id:criteria_id,
					        is_validate:1
					    },
						success: function(response,options) {
						  Ext.MessageBox.hide();
					      var responseText = Ext.util.JSON.decode(response.responseText);
					      if(responseText.flag == "E"){
					      		Ext.Msg.alert(getResource('error','searchPanel'),responseText.error_msg);
					      }else{
					     	  Ext.Msg.alert(getResource('Success','searchPanel'),responseText.success_msg,function(){
					     		 _global.criteriaJSON.reload();
					     		if(typeof(Ext.getCmp(_global.panel_name+"_simplepanel_criteriadata_combo")) != "undefined") {
						     		Ext.getCmp(_global.panel_name+"_simplepanel_criteriadata_combo").getStore().reload();
						     	}
					     	  });
					      }
					    },
					    failure: function(response,options) {
					    	Ext.MessageBox.hide();
					    	var responseText = Ext.util.JSON.decode(response.responseText);
					    	Ext.Msg.alert(getResource('error','searchPanel'),responseText.error_msg);
					    }
					});
				}
			});
		}else{
			Ext.Msg.alert(getResource('load_criteria','searchPanel'),getResource('noRecordSelect','searchPanel'));
		}
	},
	
	loadCriteriaEvent:function (){
		var selectRecord = Ext.getCmp(this.panel_name+"criteriaGrid").getSelectionModel().getSelections();
		if(selectRecord.length>0){
			this._global_para.clearSearchPanel();
			is_load_search=1;
			selectRecord = Ext.getCmp(this.panel_name+"criteriaGrid").getSelectionModel().getSelected();
			var searchSql = selectRecord.get("search_sql");
			Ext.getCmp(this.panel_name+'_sp_panel').searchName = selectRecord.get("description");
			Ext.getCmp(this.panel_name+"_real_condition_value").setValue(Ext.util.Format.htmlDecode(searchSql));
			Ext.getCmp(this.panel_name+"criteria_win_load").close();
		}else{
			Ext.Msg.alert(getResource('load_criteria','searchPanel'),getResource('noRecordSelect','searchPanel'));
		}
	},
	showSqlSatement:function(_cmp,_value) {
		if(_value == true){
			Ext.getCmp(this.panel_name+"_sp_load_search").show();
			Ext.getCmp(this.panel_name+"_sp_save_search").show();
			Ext.getCmp(this.panel_name+"_real_condition_value").show();
			this.ownerCt.setHeight(this.ownerCt.getHeight()+100);
		}else{
			Ext.getCmp(this.panel_name+"_sp_load_search").hide();
			Ext.getCmp(this.panel_name+"_sp_save_search").hide();
			Ext.getCmp(this.panel_name+"_real_condition_value").hide();
			this.ownerCt.setHeight(this.ownerCt.getHeight()-100);
		}
	},
	
	keyUpAction:function (){
		is_load_search=0;
		var fieldsets = Ext.getCmp(this.panel_name+'fs');
		var value="";
		var fsLength = fieldsets.items.items[0].items.length;
		var operator = "=";
		var andOrOperator = "";
		for (var row = 0; row < fsLength ; row++){
			var field0 = fieldsets.items.items[0].items.items[row];
			var field1 = fieldsets.items.items[1].items.items[row];
			var field2 = fieldsets.items.items[2].items.items[row];
			var field3 = fieldsets.items.items[3].items.items[row];
			var field4 = fieldsets.items.items[4].items.items[row];
			var field5 = fieldsets.items.items[5].items.items[row];
			var field6 = fieldsets.items.items[6].items.items[row];
			var field7 = fieldsets.items.items[7].items.items[row];
			var field0Value,field1Value,field2Value,field3Value,field4Value,field5Value,field6Value;
			var criVal = fieldsets.items.items[0].items.items[row];
			var criFieldComVal = criVal.getValue();
			var fieldType = criVal.store.query('pkey',criFieldComVal).get(0).get('fieldType');
			
			if(fieldType.toLowerCase()=='datefield'){
				field0Value = field0.getValue();
				field1Value = field1.getValue();
				field2Value = Ext.get(field2.id).dom.value;
				field3Value = Ext.get(field3.id).dom.value;
				field4Value = Ext.get(field4.id).dom.value;
				field5Value = Ext.get(field5.id).dom.value;
				field6Value = Ext.get(field6.id).dom.value;
			}else{
				field0Value = field0.getValue();
				field1Value = field1.getValue();
				field2Value = field2.getValue();
				field3Value = field3.getValue();
				field4Value = field4.getValue();
				field5Value = field5.getValue();
				field6Value = field6.getValue();
			}
			
			if(row>0 && value!="" && value!=null && field0Value !="" && field0Value != null){
				value = value + " "+andOrOperator+" ";
			}
			
			if(field2Value !="" && field2Value!=null && field3Value==""&&field4Value==""&&field5Value==""&&field6Value==""){
				field3.setDisabled(true);
				field4.setDisabled(true);
				field5.setDisabled(true);
				field6.setDisabled(true);
				field1.setDisabled(false);
				field2.setDisabled(false);
				field2Value = field2Value+"";
				field2Value = field2Value.replace(/\"/g, "~char(34)~"); 
				field2Value = field2Value.replace(/\&/g, "~char(38)~");  
				field2Value = field2Value.replace(/\|/g, "~char(124)~");  
				if(field1Value.toLowerCase() == 'like'){
					if(fieldType.toLowerCase()=='datefield'){
						value = value + "([" + field0Value+"] "+"="+' "'+field2Value+'"';
					}else{
						value = value + "([" + field0Value+"] "+field1Value+' "%'+field2Value+'%"';
					}
				}else{
					value = value + "([" + field0Value+"] "+field1Value+' "'+field2Value+'"';
				}
			}else if(field3Value!=""||field4Value!=""||field5Value!=""||field6Value!=""){
				field3.setDisabled(false);
				field4.setDisabled(false);
				field5.setDisabled(false);
				field6.setDisabled(false);
				field1.setDisabled(true);
				field2.setDisabled(true);
				var value_string = "";
				var include_string="";
				var link_string="";
				
				if(field3Value!=""&&field3Value!=null){
					value_string = " || ";
					link_string = " && ";
					include_string = " && ";
					var reg_field3 = field3Value+"";
					reg_field3 = reg_field3.replace(/\"/g, "~char(34)~"); 
					reg_field3 = reg_field3.replace(/\&/g, "~char(38)~");  
					reg_field3 = reg_field3.replace(/\|/g, "~char(124)~");  
					value = value + "([" + field0Value + '] >= "' +reg_field3+'"';
				}
				if(field4Value!=""&&field4Value!=null){
					include_string = " && ";
					value_string = " || ";
					if(link_string==""){
						value = value + "(";
					}
					var reg_field4 = field4Value+"";
					reg_field4 = reg_field4.replace(/\"/g, "~char(34)~"); 
					reg_field4 = reg_field4.replace(/\&/g, "~char(38)~");  
					reg_field4 = reg_field4.replace(/\|/g, "~char(124)~");  
					value = value + link_string +"["+ field0Value +'] <= "' + reg_field4 + '"';
				}
				
				if(field6Value!=null&&field6Value!=""){
					value_string = " || ";
					if(include_string == ""){
						value = value + "(";
					}
					var fieldArray = new Array();
					fieldArray = field6Value.toString().split(',');
					field6Value = "";
					for(var v=0;v<fieldArray.length;v++){
						if(v>0){
							field6Value = field6Value+" && ";
						}
						var reg_filedvalue6 = fieldArray[v]+"";
						reg_filedvalue6 = reg_filedvalue6.replace(/\"/g, "~char(34)~"); 
						reg_filedvalue6 = reg_filedvalue6.replace(/\&/g, "~char(38)~");  
						reg_filedvalue6 = reg_filedvalue6.replace(/\|/g, "~char(124)~");  
						field6Value = field6Value+"["+field0Value+'] <> "' +reg_filedvalue6+'"';
					}
					value = value + include_string + "(" + field6Value+")";
				}
				
				if(field5Value!=null&&field5Value!=""){
					if(value_string == ""){
						value = value + " (";
					}
					var fieldArray = new Array();
					fieldArray = field5Value.toString().split(',');
					field5Value = "";
					for(var y=0;y<fieldArray.length;y++){
						if(y>0){
							field5Value = field5Value+" || ";
						}
						var reg_filedvalue5 = fieldArray[y]+"";
						reg_filedvalue5 = reg_filedvalue5.replace(/\"/g, "~char(34)~"); 
						reg_filedvalue5 = reg_filedvalue5.replace(/\&/g, "~char(38)~");  
						reg_filedvalue5 = reg_filedvalue5.replace(/\|/g, "~char(124)~");  
						field5Value = field5Value+"["+field0Value+'] = "' +reg_filedvalue5+'"';
					}
					value = value + value_string + "(" + field5Value+")";
				}
				
			}else{
				if(field0Value!=""&&field0Value){
					field3.setDisabled(false);
					field4.setDisabled(false);
					field5.setDisabled(false);
					field6.setDisabled(false);
					field1.setDisabled(false);
					field2.setDisabled(false);
					if(field0Value!=""&&field1Value!=""&&field2Value==""&&field3Value==""&&field4Value==""&&field5Value==""&&field6Value==""){
						value = value + "([" + field0Value+"] "+field1Value+' "'+field2Value+'"';
					}
				}
			}
			if(field0Value!=""&&field0Value){
				value = value + ")";
			}
			if(field7.getValue()!=""&&field7.getValue()!=null){
				andOrOperator = field7.getValue();
			}
		}
		if(value==""){
			Ext.getCmp(this.panel_name+"_real_condition_value").setValue("");
		}else{
			Ext.getCmp(this.panel_name+"_real_condition_value").setValue("("+value+")");
		}
	},
	
	
	setDefaultSearchField:function(combo) {
		if(this._global_para.criteriaFieldJSON.getCount()>0 && this.criteriaFieldJSON.getAt(0).data.default_search_field!=""&&this.criteriaFieldJSON.getAt(0).data.default_search_field!="blur_search"){
			combo.setValue(this._global_para.criteriaFieldJSON.getAt(0).data.default_search_field);
			
			var fieldsets = Ext.getCmp(this.panel_name+'fs');
			var row = 0;
			for(; row < fieldsets.items.items[0].items.length ; row++) {
				if (fieldsets.items.items[0].items.items[row].id == combo.id)
					break;
			}
			fieldsets.items.items[1].items.items[row].setDisabled(false);
			
			if(this._global_para.criteriaFieldJSON.getAt(0).data.default_search_field_operator!=""){
				fieldsets.items.items[1].items.items[row].setValue(this._global_para.criteriaFieldJSON.getAt(0).data.default_search_field_operator);
			}else{
				fieldsets.items.items[1].items.items[row].setValue(this._global_para.criteriaOperatorJSON.getAt(0).get('pkey'));
			}				
			this.populateRow(row,"","");
			fieldsets.items.items[7].doLayout();
			this._global_para.keyUpAction();
		}
		
		
	},
	
	populateSearchPanel:function (data) {
		var decodedData = Ext.decode(data);
		var emptyArray = '[';
		for (var a=0; a < decodedData.length ; a++){
			emptyArray += '{}';
			if (a < decodedData.length-1)
				emptyArray += ',';
		}
		emptyArray += ']';
		var searchPanel = Ext.getCmp(this.panel_name+'_sp_panel');
		searchPanel.populate(Ext.decode(emptyArray),'searchPanel','fieldset');
		searchPanel.doLayout();
		if (decodedData.length < 1)
			return;
		var fieldsets = Ext.getCmp(this.panel_name+'fs');
		Ext.getCmp(this.panel_name+'_sp_search_button').setDisabled(true);
		Ext.getCmp(this.panel_name+'_sp_searchClose_button').setDisabled(true);
		Ext.getCmp(this.panel_name+'_sp_clear_search').setDisabled(true);
		Ext.getCmp(this.panel_name+'_sp_save_search').setDisabled(true);
		for (var b=0; b < decodedData.length; b++){
			fieldsets.items.items[0].items.items[b].setValue( decodedData[b]['cri_field'] );
			this.populateRow(b, decodedData[b]['operator_id'], decodedData[b]['value'] );
		}
		Ext.getCmp(this.panel_name+'_sp_search_button').setDisabled(false);
		Ext.getCmp(this.panel_name+'_sp_searchClose_button').setDisabled(false);
		Ext.getCmp(this.panel_name+'_sp_clear_search').setDisabled(false);
		Ext.getCmp(this.panel_name+'_sp_save_search').setDisabled(false);
	},

	searchClose:function (){
		this._global_para.search();
		Ext.getCmp(this.panel_name+'_sp_panel').searchName = "";
		Ext.getCmp(this.panel_name+"_win").hide();
	},
	search:function (){
		if(typeof(Ext.getCmp(this.panel_name+"_simplepanel_criteriadata_combo"))!="undefined") {
			Ext.getCmp(this.panel_name+"_simplepanel_criteriadata_combo").clearValue();
		}
		var _real_condition_value = Ext.getCmp(this.panel_name+"_real_condition_value").getValue();
		if(_real_condition_value=="" ||_real_condition_value==null){
			_real_condition_value = " "
		}
		_real_condition_value = _real_condition_value+"";
		if(_real_condition_value.replace(/(^\s*)|(\s*$)/g, "") != "") {
			_real_condition_value = " && "+_real_condition_value;
		}
		if(this._global_para.panel_type != undefined){
			if(this._global_para.panel_type == "TreeGridPanel") {
				Ext.getCmp(this.panel_name).getLoader().baseParams.sql_where= _real_condition_value;
				 Ext.getCmp(this.panel_name).getLoader().load_type='search';
				 Ext.getCmp(this.panel_name).getRootNode().reload();
			}
		}else {
			Ext.getCmp(this.panel_name).store.setBaseParam('sql_where', _real_condition_value);
			Ext.getCmp(this.panel_name).store.load();
		}
		
	},
	
	cloneField:function (_combo){
		if(_combo.getValue()=="" ||_combo.getValue()==null){
			var fieldset = Ext.getCmp(this.panel_name+"fs");  
			var numOfClones = fieldset.clones();
			
		    if ( !Ext.isEmpty(fieldset.maxOccurs) ) {
				if ( fieldset.maxOccurs  <= numOfClones + 1) {
					fieldset.fireEvent('maxoccurs',fieldset);
					return;													   
				}
		    }
			var panel = fieldset.ownerCt;	
			fieldset.clones(numOfClones+1);
			panel.doLayout();																								   										
			fieldset.fireEvent('afterClone',fieldset);
		}
	},
	getIndexByCriFieldId:function(CriFieldId){
		for (i=0;i<this._global_para.criFieldArray.length;i++){
			if (this._global_para.criFieldArray[i] == CriFieldId){
				return i;
			}
		}
	},	
	triggerClickAction:function (v, id) {
		var field_id = id;
		if(Ext.getCmp(id).disabled)return false;		
		
		var fieldsets = Ext.getCmp(v.panel_name+'fs');
		var row = 0;
		var needDelimiter = 0;
		for(; row < fieldsets.items.items[0].items.length ; row++) {
			if (fieldsets.items.items[2].items.items[row].id == field_id||
			fieldsets.items.items[3].items.items[row].id == field_id||
			fieldsets.items.items[4].items.items[row].id == field_id||
			fieldsets.items.items[5].items.items[row].id == field_id||
			fieldsets.items.items[6].items.items[row].id == field_id){
				if(fieldsets.items.items[5].items.items[row].id == field_id||
					fieldsets.items.items[6].items.items[row].id == field_id){
					needDelimiter = 1;
				}
				break;
			}
		}
		var criVal = fieldsets.items.items[0].items.items[row];
		var criFieldComVal = criVal.getValue();
		var fieldname = criVal.store.query('pkey',criFieldComVal).get(0).get('pkey');
		
		if(typeof(Ext.getCmp("picklist_"+v.panel_name+"_"+fieldname))!="undefined"){
			Ext.getCmp("picklist_"+v.panel_name+"_"+fieldname).show();
		}else{
			try{
				var jsFile = "views/dynamicGenerateScript/picklist_"+v.panel_name+"_"+fieldname+".js";
				myLoader.require(jsFile,function(){
					var popupString = "var win = new picklist_"+v.panel_name+"_"+fieldname+"({paramList:{cid:'"+field_id+"',fname:'"+fieldname+"',pname:'"+v.panel_name+"',sourcePage:'searchPanel',needDelimiter:0}}).show();";
					eval(popupString);				
				},this,true);
			}catch(e){
					exceptionHandling(e,'P10009');
			}
		}
		return false;
	},
	triggerTreeAction:function(_global, id){
		var field_id =id;
		if(Ext.getCmp(id).disabled)return false;		
		
		var fieldsets = Ext.getCmp(_global.panel_name+'fs');
		var row = 0;
		var needDelimiter = 0;
			
		for(; row < fieldsets.items.items[0].items.length ; row++) {
			if (fieldsets.items.items[2].items.items[row].id == field_id||
			fieldsets.items.items[3].items.items[row].id == field_id||
			fieldsets.items.items[4].items.items[row].id == field_id||
			fieldsets.items.items[5].items.items[row].id == field_id||
			fieldsets.items.items[6].items.items[row].id == field_id){
				if(fieldsets.items.items[5].items.items[row].id == field_id||
					fieldsets.items.items[6].items.items[row].id == field_id){
					needDelimiter = 1;
				}
				break;
			}
		} 
		var criVal = fieldsets.items.items[0].items.items[row];
		var criFieldComVal = criVal.getValue();
		var fieldname = criVal.store.query('pkey',criFieldComVal).get(0).get('pkey');
		
		if(typeof(Ext.getCmp("picklist_"+_global.panel_name+"_"+fieldname))!="undefined"){
			Ext.getCmp("picklist_"+_global.panel_name+"_"+fieldname).show();
		}else{
			try{
				var jsFile = "views/dynamicGenerateScript/picklist_"+_global.panel_name+"_"+fieldname+".js";
				myLoader.require(jsFile,function(){
					var popupString= "if(Ext.getCmp('picklist_"+_global.panel_name+"_"+fieldname+"_v')!=undefined){Ext.getCmp('picklist_"+_global.panel_name+"_"+fieldname+"_v').destroy();}else{ var picklist_"+_global.panel_name+"_"+fieldname+"_v = new picklist_"+_global.panel_name+"_"+fieldname+"({paramList:{cid:'"+field_id+"',fname:'"+fieldname+"',pname:'"+_global.panel_name+"',sourcePage:'searchPanel',needDelimiter:0}}).show();}";
					eval(popupString);	
				},this,true);
			}catch(e){
					exceptionHandling(e,'P10009');
			}
		}
		return false;
	},
	
	populateRow:function (row, operatorField, valueField) {
		var v_call = this;
		var i = row;
		var fieldsets = Ext.getCmp(this.panel_name+'fs');
		// filter the operator combobox depending on the search type:
		criFieldCom = fieldsets.items.items[0].items.items[i];
		criFieldComValue = criFieldCom.getValue();
		var criFieldType = "";			
		for(var v=0;v<criFieldCom.store.getCount();v++){
			if(criFieldCom.store.getAt(v).get("pkey")==criFieldComValue){
				criFieldType=criFieldCom.store.getAt(v).get("fieldType");
				break;
			}
		}
		var criVal = fieldsets.items.items[0].items.items[row];
		var criFieldComVal = criVal.getValue();
		var fieldname = criVal.store.query('pkey',criFieldComVal).get(0).get('pkey');
		fieldsets.items.items[2].remove(fieldsets.items.items[2].items.items[i],true);
		fieldsets.items.items[3].remove(fieldsets.items.items[3].items.items[i],true);
		fieldsets.items.items[4].remove(fieldsets.items.items[4].items.items[i],true);
		fieldsets.items.items[5].remove(fieldsets.items.items[5].items.items[i],true);
		fieldsets.items.items[6].remove(fieldsets.items.items[6].items.items[i],true);
		switch(criFieldType){
			case 'DATEFIELD':
				if (i == 0){
					var cf = new Ext.form.DateField({
						id:this.panel_name+'_sp_value',
						fieldLabel: getResource('Value','searchPanel'),
						name: 'value',
						width:100,
						format:web_platform_dateformat,
						hideLabel:false,
						editable:false,
						labelAlign:"top",
						enableKeyEvents:true,
						listeners : {
							'keyUp':this._global_para.keyUpAction,
							'select':this._global_para.keyUpAction,
							'change':this._global_para.keyUpAction,
							scope:this
						}
					});
					var cf_from = new Ext.form.DateField({
						fieldLabel: getResource('Value_from','searchPanel'),
						id:this.panel_name+'_sp_value_from',
						name:'value_from',
						width:100,
						format:web_platform_dateformat,
						hideLabel:false,
						editable:false,
						labelAlign:"top",
						enableKeyEvents:true,
						listeners : {
							'keyUp':this._global_para.keyUpAction,
							'select':this._global_para.keyUpAction,
							'change':this._global_para.keyUpAction,
							scope:this
						}
					});	
					var cf_to = new Ext.form.DateField({
						fieldLabel: getResource('Value_to','searchPanel'),
						id:this.panel_name+'_sp_value_to',
						name:'value_to',
						width:100,
						format:web_platform_dateformat,
						editable:false,
						enableKeyEvents:true,
						hideLabel:false,
						labelAlign:"top",
						listeners : {
							'keyUp':this._global_para.keyUpAction,
							'select':this._global_para.keyUpAction,
							'change':this._global_para.keyUpAction,
							scope:this
						}
					});	
					var cf_include = new Ext.form.DateField({
						fieldLabel: getResource('Value_include','searchPanel'),
						id:this.panel_name+'_sp_value_include',
						name:'value_include',
						width:100,
						editable:false,
						enableKeyEvents:true,
						format:web_platform_dateformat,
						hideLabel:false,
						labelAlign:"top",
						listeners : {
							'keyUp':this._global_para.keyUpAction,
							'select':this._global_para.keyUpAction,
							scope:this
						}
					});	
					var cf_uninclude = new Ext.form.DateField({
						fieldLabel: getResource('Value_uninclude','searchPanel'),
						id:this.panel_name+'_sp_value_uninclude',
						name:'value_uninclude',
						width:100,
						editable:false,
						format:web_platform_dateformat,
						hideLabel:false,
						enableKeyEvents:true,
						labelAlign:"top",
						listeners : {
							'keyUp':this._global_para.keyUpAction,
							'select':this._global_para.keyUpAction,
							'change':this._global_para.keyUpAction,
							scope:this
						}
					});			
				} else {
					var cf = new Ext.form.DateField({
						name: 'value',
						hideLabel: true,
						width:100,
						editable:false,
						enableKeyEvents:true,
						format:web_platform_dateformat,
						clone: true,
						listeners : {
							'keyUp':this._global_para.keyUpAction,
							'select':this._global_para.keyUpAction,
							'change':this._global_para.keyUpAction,
							scope:this
						}
					});
					var cf_from = new Ext.form.DateField({
						name: 'value_from',
						width:100,
						format:web_platform_dateformat,
						editable:false,
						hideLabel: true,
						enableKeyEvents:true,
						clone: true,
						listeners : {
							'keyUp' :this._global_para.keyUpAction,
							'select':this._global_para.keyUpAction,
							'change':this._global_para.keyUpAction,
							scope:this
						}
					});
					var cf_to = new Ext.form.DateField({
						name: 'value_to',
						width:100,
						format:web_platform_dateformat,
						editable:false,
						enableKeyEvents:true,
						hideLabel: true,
						clone: true,
						listeners : {
							'keyUp' :this._global_para.keyUpAction,
							'select':this._global_para.keyUpAction,
							'change':this._global_para.keyUpAction,
							scope:this
						}
					});
					var cf_include = new Ext.form.DateField({
						name: 'value_include',
						hideLabel: true,
						width:100,
						editable:false,
						format:web_platform_dateformat,
						enableKeyEvents:true,
						clone: true,
						listeners : {
							'keyUp' :this._global_para.keyUpAction,
							'select':this._global_para.keyUpAction,
							'change':this._global_para.keyUpAction,
							scope:this
						}
					});
					var cf_uninclude = new Ext.form.DateField({
						name: 'value_uninclude',
						hideLabel: true,
						width:100,
						format:web_platform_dateformat,
						editable:false,
						enableKeyEvents:true,
						clone: true,
						listeners : {
							'keyUp' :this._global_para.keyUpAction,
							'select':this._global_para.keyUpAction,
							'change':this._global_para.keyUpAction,
							scope:this
						}
					});
				}
				break;
			case 'POPUP':
					if (i == 0) {
						var cf = new Ext.form.TriggerField({
							id:this.panel_name+'_sp_value',
							fieldLabel: getResource('Value','searchPanel'),
							name:'value',
							width:100,
							triggerClass: 'x-form-search-trigger',
							resizable:true,
							enableKeyEvents:true,
							hideLabel: false,
							labelAlign: 'top',
							'onTriggerClick': function(){
								v_call.triggerClickAction(v_call, this.id);
							},
							listeners : {
								'keyUp' :this.keyUpAction,
								'change':this.keyUpAction,
								scope:this
							}
						});
						var cf_from = new Ext.form.TriggerField({
							id:this.panel_name+'_sp_value_from',
							fieldLabel: getResource('Value_from','searchPanel'),
							name:'value_from',
							width:100,
							triggerClass: 'x-form-search-trigger',
							enableKeyEvents:true,
							resizable:true,
							hideLabel: false,
							labelAlign: 'top',
							'onTriggerClick': function(){
								v_call.triggerClickAction(v_call, this.id);
							},
							listeners:{
								'keyUp':this.keyUpAction,
								'change':this.keyUpAction,
								scope:this
							}							
						});
						var cf_to = new Ext.form.TriggerField({
							id:this.panel_name+'_sp_value_to',
							fieldLabel: getResource('Value_to','searchPanel'),
							name:'value_to',
							width:100,
							enableKeyEvents:true,
							triggerAction:'all',
							resizable:true,
							triggerClass: 'x-form-search-trigger',
							hideLabel: false,
							labelAlign: 'top',
							'onTriggerClick': function(){
								v_call.triggerClickAction(v_call, this.id);
							},
							listeners:{
								'keyUp':this.keyUpAction,
								'change':this.keyUpAction,
								scope:this
							}
						});
						var cf_include = new Ext.form.TriggerField({
							id:this.panel_name+'_sp_value_include',
							fieldLabel: getResource('Value_include','searchPanel'),
							name:'value_include',
							width:100,
							triggerClass: 'x-form-search-trigger',
							resizable:true,
							enableKeyEvents:true,
							hideLabel: false,
							labelAlign: 'top',
							'onTriggerClick': function(){
								v_call.triggerClickAction(v_call, this.id);
							},
							listeners:{
								'keyUp':this.keyUpAction,
								'change':this.keyUpAction,
								scope:this
							}
						});
						var cf_uninclude = new Ext.form.TriggerField({
							id:this.panel_name+'_sp_value_uninclude',
							fieldLabel: getResource('Value_uninclude','searchPanel'),
							name:'value_uninclude',
							enableKeyEvents:true,
							width:100,
							triggerClass: 'x-form-search-trigger',
							resizable:true,
							hideLabel: false,
							labelAlign: 'top',
							'onTriggerClick': function(){
								v_call.triggerClickAction(v_call, this.id);
							},
							listeners:{
								'keyUp':this.keyUpAction,
								'change':this.keyUpAction,
								scope:this
							}
						});
					} else {
						var cf = new Ext.form.TriggerField({
							hideLabel: true,
							name:'value',
							clone:true,
							enableKeyEvents:true,
							width:100,
							triggerClass: 'x-form-search-trigger',
							resizable:true,
							'onTriggerClick': function(){
								v_call.triggerClickAction(v_call, this.id);
							},
							listeners:{
								'keyUp':this.keyUpAction,
								'change':this.keyUpAction,
								scope:this
							}
						});
						var cf_from = new Ext.form.TriggerField({
							hideLabel: true,
							name:'value_from',
							width:100,
							enableKeyEvents:true,
							triggerAction:'all',
							resizable:true,
							triggerClass: 'x-form-search-trigger',
							'onTriggerClick': function(){
								v_call.triggerClickAction(v_call, this.id);
							},
							listeners:{
								'keyUp':this.keyUpAction,
								'change':this.keyUpAction,
								scope:this
							}
						});
						var cf_to =  new Ext.form.TriggerField({
							hideLabel: true,
							name:'value_to',
							width:100,
							enableKeyEvents:true,
							resizable:true,
							triggerClass: 'x-form-search-trigger',
							'onTriggerClick': function(){
								v_call.triggerClickAction(v_call, this.id);
							},
							listeners:{
								'keyUp':this.keyUpAction,
								'change':this.keyUpAction,
								scope:this
							}
						});
						var cf_include =  new Ext.form.TriggerField({
							hideLabel: true,
							name:'value_include',
							width:100,
							enableKeyEvents:true,
							triggerClass: 'x-form-search-trigger',
							resizable:true,
							'onTriggerClick': function(){
								v_call.triggerClickAction(v_call, this.id);
							},
							listeners:{
								'keyUp':this.keyUpAction,
								'change':this.keyUpAction,
								scope:this
							}
						});
						var cf_uninclude =  new Ext.form.TriggerField({
							hideLabel: true,
							name:'value_uninclude',
							enableKeyEvents:true,
							width:100,
							triggerClass: 'x-form-search-trigger',
							resizable:true,
							'onTriggerClick': function(){
								v_call.triggerClickAction(v_call, this.id);
							},
							listeners:{
								'keyUp':this.keyUpAction,
								'change':this.keyUpAction,
								scope:this
							}
						});
					}
				break;
			case 'TREE':
					if (i == 0) {
						var cf = new Ext.form.TriggerField({
							id:this.panel_name+'_sp_value',
							fieldLabel: getResource('Value','searchPanel'),
							name:'value',
							width:100,
							triggerClass: 'x-form-search-trigger',
							resizable:true,
							enableKeyEvents:true,
							hideLabel: false,
							labelAlign: 'top',
							'onTriggerClick': function(){
								v_call.triggerTreeAction(v_call, this.id);
							},
							listeners : {
								'keyUp' :this.keyUpAction,
								'change':this.keyUpAction,
								scope:this
							}
						});
						var cf_from = new Ext.form.TriggerField({
							id:this.panel_name+'_sp_value_from',
							fieldLabel: getResource('Value_from','searchPanel'),
							name:'value_from',
							width:100,
							triggerClass: 'x-form-search-trigger',
							enableKeyEvents:true,
							resizable:true,
							hideLabel: false,
							labelAlign: 'top',
							'onTriggerClick': function(){
								v_call.triggerTreeAction(v_call, this.id);
							},
							listeners:{
								'keyUp':this.keyUpAction,
								'change':this.keyUpAction,
								scope:this
							}							
						});
						var cf_to = new Ext.form.TriggerField({
							id:this.panel_name+'_sp_value_to',
							fieldLabel: getResource('Value_to','searchPanel'),
							name:'value_to',
							width:100,
							enableKeyEvents:true,
							triggerAction:'all',
							resizable:true,
							triggerClass: 'x-form-search-trigger',
							hideLabel: false,
							labelAlign: 'top',
							'onTriggerClick': function(){
								v_call.triggerTreeAction(v_call, this.id);
							},
							listeners:{
								'keyUp':this.keyUpAction,
								'change':this.keyUpAction,
								scope:this
							}
						});
						var cf_include = new Ext.form.TriggerField({
							id:this.panel_name+'_sp_value_include',
							fieldLabel: getResource('Value_include','searchPanel'),
							name:'value_include',
							width:100,
							triggerClass: 'x-form-search-trigger',
							resizable:true,
							enableKeyEvents:true,
							hideLabel: false,
							labelAlign: 'top',
							'onTriggerClick': function(){
								v_call.triggerTreeAction(v_call, this.id);
							},	
							listeners:{
								'keyUp':this.keyUpAction,
								'change':this.keyUpAction,
								scope:this
							}
						});
						var cf_uninclude = new Ext.form.TriggerField({
							id:this.panel_name+'_sp_value_uninclude',
							fieldLabel: getResource('Value_uninclude','searchPanel'),
							name:'value_uninclude',
							enableKeyEvents:true,
							width:100,
							triggerClass: 'x-form-search-trigger',
							resizable:true,
							hideLabel: false,
							labelAlign: 'top',
							'onTriggerClick': function(){
								v_call.triggerTreeAction(v_call, this.id);
							},
							listeners:{
								'keyUp':this.keyUpAction,
								'change':this.keyUpAction,
								scope:this
							}
						});
					} else {
						var cf = new Ext.form.TriggerField({
							hideLabel: true,
							name:'value',
							clone:true,
							enableKeyEvents:true,
							width:100,
							triggerClass: 'x-form-search-trigger',
							resizable:true,
							'onTriggerClick': function(){
								v_call.triggerTreeAction(v_call, this.id);
							},
							listeners:{
								'keyUp':this.keyUpAction,
								'change':this.keyUpAction,
								scope:this
							}
						});
						var cf_from = new Ext.form.TriggerField({
							hideLabel: true,
							name:'value_from',
							width:100,
							enableKeyEvents:true,
							triggerAction:'all',
							resizable:true,
							triggerClass: 'x-form-search-trigger',
							'onTriggerClick': function(){
								v_call.triggerTreeAction(v_call, this.id);
							},
							listeners:{
								'keyUp':this.keyUpAction,
								'change':this.keyUpAction,
								scope:this
							}
						});
						var cf_to =  new Ext.form.TriggerField({
							hideLabel: true,
							name:'value_to',
							width:100,
							enableKeyEvents:true,
							resizable:true,
							triggerClass: 'x-form-search-trigger',
							'onTriggerClick': function(){
								v_call.triggerTreeAction(v_call, this.id);
							},
							listeners:{
								'keyUp':this.keyUpAction,
								'change':this.keyUpAction,
								scope:this
							}
						});
						var cf_include =  new Ext.form.TriggerField({
							hideLabel: true,
							name:'value_include',
							width:100,
							enableKeyEvents:true,
							triggerClass: 'x-form-search-trigger',
							resizable:true,
							'onTriggerClick': function(){
								v_call.triggerTreeAction(v_call, this.id);
							},
							listeners:{
								'keyUp':this.keyUpAction,
								'change':this.keyUpAction,
								scope:this
							}
						});
						var cf_uninclude =  new Ext.form.TriggerField({
							hideLabel: true,
							name:'value_uninclude',
							enableKeyEvents:true,
							width:100,
							triggerClass: 'x-form-search-trigger',
							resizable:true,
							'onTriggerClick': function(){
								v_call.triggerTreeAction(v_call, this.id);
							},
							listeners:{
								'keyUp':this.keyUpAction,
								'change':this.keyUpAction,
								scope:this
							}
						});
					}
				break;

			case 'NUMBERFIELD':
					if (i == 0){
						var cf = new Ext.form.NumberField({
							id:this.panel_name+'_sp_value',
							width:100,
							allowNegative:false,
							hideLabel: false,
							enableKeyEvents:true,
							fieldLabel: getResource('Value','searchPanel'),
							labelAlign: 'top',
							name: 'value',	
							listeners:{
								'keyUp':this._global_para.keyUpAction,
								'change':this._global_para.keyUpAction,
								scope:this
							}
						});
						var cf_from = new Ext.form.NumberField({
							id:this.panel_name+'_sp_value_from',
							width:100,
							hideLabel: false,
							allowNegative:false,
							fieldLabel: getResource('Value_from','searchPanel'),
							enableKeyEvents:true,
							labelAlign: 'top',
							name: 'value_from',	
							listeners:{
								'keyUp':this._global_para.keyUpAction,
								'change':this._global_para.keyUpAction,
								scope:this
							}
						});
						var cf_to = new Ext.form.NumberField({
							id:this.panel_name+'_sp_value_to',
							width:100,
							allowNegative:false,
							enableKeyEvents:true,
							hideLabel: false,
							fieldLabel: getResource('Value_to','searchPanel'),
							labelAlign: 'top',
							name: 'value_to',	
							listeners:{
								'keyUp':this._global_para.keyUpAction,
								'change':this._global_para.keyUpAction,
								scope:this
							}
						});
						var cf_include = new Ext.form.NumberField({
							id:this.panel_name+'_sp_value_include',
							width:100,
							hideLabel: false,
							allowNegative:false,
							fieldLabel: getResource('Value_include','searchPanel'),
							labelAlign: 'top',
							name: 'value_include',	
							enableKeyEvents:true,
							listeners:{
								'keyUp':this._global_para.keyUpAction,
								'change':this._global_para.keyUpAction,
								scope:this
							}
						});
						var cf_uninclude = new Ext.form.NumberField({
							id:this.panel_name+'_sp_value_uninclude',
							width:100,
							hideLabel: false,
							allowNegative:false,
							fieldLabel: getResource('Value_uninclude','searchPanel'),
							labelAlign: 'top',
							name: 'value_uninclude',	
							enableKeyEvents:true,
							listeners:{
								'keyUp':this._global_para.keyUpAction,
								'change':this._global_para.keyUpAction,
								scope:this
							}
						});
					} else {
						var cf = new Ext.form.NumberField({
							width:100,
							hideLabel: true,
							clone: true,
							allowNegative:false,
							enableKeyEvents:true,
							name: 'value',	
							listeners:{
								'keyUp':this._global_para.keyUpAction,
								'change':this._global_para.keyUpAction,
								scope:this
							}
						});
						var cf_from = new Ext.form.NumberField({
							width:100,
							hideLabel: true,
							enableKeyEvents:true,
							clone: true,
							allowNegative:false,
							name: 'value_from',	
							listeners:{
								'keyUp':this._global_para.keyUpAction,
								'change':this._global_para.keyUpAction,
								scope:this
							}
						});
						var cf_to = new Ext.form.NumberField({
							width:100,
							hideLabel: true,
							clone: true,
							allowNegative:false,
							name: 'value_to',	
							enableKeyEvents:true,
							listeners:{
								'keyUp':this._global_para.keyUpAction,
								'change':this._global_para.keyUpAction,
								scope:this
							}
						});
						var cf_include = new Ext.form.NumberField({
							width:100,
							hideLabel: true,
							clone: true,
							allowNegative:false,
							enableKeyEvents:true,
							name: 'value_include',	
							listeners:{
								'keyUp':this._global_para.keyUpAction,
								'change':this._global_para.keyUpAction,
								scope:this
							}
						});
						var cf_uninclude = new Ext.form.NumberField({
							width:100,
							hideLabel: true,
							clone: true,
							allowNegative:false,
							enableKeyEvents:true,
							name: 'value_uninclude',	
							listeners:{
								'keyUp':this._global_para.keyUpAction,
								'change':this._global_para.keyUpAction,
								scope:this
							}
						});
					}
				break;
			case 'TEXT':
				if (i == 0) {
					var cf = new Ext.form.TextField({
						id:this.panel_name+'_sp_value',
						width:100,
						enableKeyEvents:true,
						hideLabel: false,
						fieldLabel: getResource('Value','searchPanel'),
						labelAlign: 'top',
						name: 'value',	
						listeners:{
							'keyUp':this._global_para.keyUpAction,
							'change':this._global_para.keyUpAction,
							scope:this
						}
					});
					
					var cf_from = new Ext.form.TextField({
						id:this.panel_name+'_sp_value_from',
						width:100,
						hideLabel: false,
						enableKeyEvents:true,
						fieldLabel: getResource('Value_from','searchPanel'),
						labelAlign: 'top',
						name: 'value_from',	
						listeners:{
							'keyUp':this._global_para.keyUpAction,
							'change':this._global_para.keyUpAction,
							scope:this
						}
					});
					
					var cf_to = new Ext.form.TextField({
						id:this.panel_name+'_sp_value_to',
						width:100,
						hideLabel: false,
						enableKeyEvents:true,
						fieldLabel: getResource('Value_to','searchPanel'),
						labelAlign: 'top',
						name: 'value_to',	
						listeners:{
							'keyUp':this._global_para.keyUpAction,
							'change':this._global_para.keyUpAction,
							scope:this
						}
					});
					
					var cf_include = new Ext.form.TextField({
						id:this.panel_name+'_sp_value_include',
						width:100,
						hideLabel: false,
						enableKeyEvents:true,
						fieldLabel: getResource('Value_include','searchPanel'),
						labelAlign: 'top',
						name: 'value_include',	
						listeners:{
							'keyUp':this._global_para.keyUpAction,
							'change':this._global_para.keyUpAction,
							scope:this
						}
					});
					
					var cf_uninclude = new Ext.form.TextField({
						id:this.panel_name+'_sp_value_uninclude',
						width:100,
						hideLabel: false,
						enableKeyEvents:true,
						fieldLabel: getResource('Value_uninclude','searchPanel'),
						labelAlign: 'top',
						name: 'value_uninclude',	
						listeners:{
							'keyUp':this._global_para.keyUpAction,
							'change':this._global_para.keyUpAction,
							scope:this
						}
					});
				} else {
					var cf = new Ext.form.TextField({
						width:100,
						hideLabel: true,
						enableKeyEvents:true,
						clone: true,
						name: 'value',	
						listeners:{
							'keyUp':this._global_para.keyUpAction,
							'change':this._global_para.keyUpAction,
							scope:this
						}
					});
					var cf_from = new Ext.form.TextField({
						width:100,
						hideLabel: true,
						clone: true,
						name: 'value_from',	
						enableKeyEvents:true,
						listeners:{
							'keyUp':this._global_para.keyUpAction,
							'change':this._global_para.keyUpAction,
							scope:this
						}
					});
					var cf_to = new Ext.form.TextField({
						width:100,
						hideLabel: true,
						clone: true,
						enableKeyEvents:true,
						name: 'value_to',	
						listeners:{
							'keyUp':this._global_para.keyUpAction,
							'change':this._global_para.keyUpAction,
							scope:this
						}
					});
					var cf_include = new Ext.form.TextField({
						width:100,
						hideLabel: true,
						clone: true,
						name: 'value_include',	
						enableKeyEvents:true,
						listeners:{
							'keyUp':this._global_para.keyUpAction,
							'change':this._global_para.keyUpAction,
							scope:this
						}
					});
					var cf_uninclude = new Ext.form.TextField({
						width:100,
						hideLabel: true,
						clone: true,
						enableKeyEvents:true,
						name: 'value_uninclude',	
						listeners:{
							'keyUp':this._global_para.keyUpAction,
							'change':this._global_para.keyUpAction,
							scope:this
						}
					});
				}
				break;
				
				case 'BIT':
					if (i == 0) {
						var cf = new Ext.form.ComboBox({
							id:this.panel_name+'_sp_value',
							width:100,
							enableKeyEvents:true,
							hideLabel: false,
							store:this._global_para.bitStore,
							fieldLabel: getResource('Value','searchPanel'),
							labelAlign: 'top',
							mode:"local",
							
							triggerAction:'all',
							valueField:'pkey',
							displayField:'pvalue',
							name: 'value',
							editable:false,
							listeners:{
								'keyUp':this._global_para.keyUpAction,
								'select':this._global_para.keyUpAction,
								'change':this._global_para.keyUpAction,
								scope:this
							}
						});
						
						var cf_from = new Ext.form.ComboBox({
							id:this.panel_name+'_sp_value_from',
							width:100,
							hideLabel: false,
							
							enableKeyEvents:true,
							store:this._global_para.bitStore,
							editable:false,
							mode:"local",
							valueField:'pkey',
							displayField:'pvalue',
							triggerAction:'all',
							fieldLabel: getResource('Value_from','searchPanel'),
							labelAlign: 'top',
							name: 'value_from',	
							listeners:{
								'keyUp':this._global_para.keyUpAction,
								'select':this._global_para.keyUpAction,
								'change':this._global_para.keyUpAction,
								scope:this
							}
						});
						var cf_to = new Ext.form.ComboBox({
							id:this.panel_name+'_sp_value_to',
							width:100,
							hideLabel: false,
							editable:false,
							store:this._global_para.bitStore,
							
							mode:"local",
							valueField:'pkey',
							displayField:'pvalue',
							triggerAction:'all',
							enableKeyEvents:true,
							fieldLabel: getResource('Value_to','searchPanel'),
							labelAlign: 'top',
							name: 'value_to',	
							listeners:{
								'keyUp':this._global_para.keyUpAction,
								'select':this._global_para.keyUpAction,
								'change':this._global_para.keyUpAction,
								scope:this
							}
						});
						var cf_include = new Ext.form.ComboBox({
							id:this.panel_name+'_sp_value_include',
							width:100,
							hideLabel: false,
							editable:false,
							store:this._global_para.bitStore,
							mode:"local",
							
							valueField:'pkey',
							displayField:'pvalue',
							triggerAction:'all',
							enableKeyEvents:true,
							fieldLabel: getResource('Value_include','searchPanel'),
							labelAlign: 'top',
							name: 'value_include',	
							listeners:{
								'keyUp':this._global_para.keyUpAction,
								'select':this._global_para.keyUpAction,
								'change':this._global_para.keyUpAction,
								scope:this
							}
						});
						
						var cf_uninclude = new Ext.form.ComboBox({
							id:this.panel_name+'_sp_value_uninclude',
							width:100,
							hideLabel: false,
							editable:false,
							store:this._global_para.bitStore,
							mode:"local",
							valueField:'pkey',
							triggerAction:'all',
							displayField:'pvalue',
							enableKeyEvents:true,
							fieldLabel: getResource('Value_uninclude','searchPanel'),
							labelAlign: 'top',
							name: 'value_uninclude',	
							listeners:{
								'keyUp':this._global_para.keyUpAction,
								'select':this._global_para.keyUpAction,
								'change':this._global_para.keyUpAction,
								scope:this
							}
						});
				} else {
					var cf = new Ext.form.ComboBox({
						width:100,
						hideLabel: true,
						store:this._global_para.bitStore,
						enableKeyEvents:true,
						editable:false,
						mode:"local",
						valueField:'pkey',
						displayField:'pvalue',
						
						triggerAction:'all',
						clone: true,
						name: 'value',	
						listeners:{
							'keyUp':this._global_para.keyUpAction,
							'select':this._global_para.keyUpAction,
							'change':this._global_para.keyUpAction,
							scope:this
						}
					});
					var cf_from = new Ext.form.ComboBox({
						width:100,
						hideLabel: true,
						store:this._global_para.bitStore,
						mode:"local",
						valueField:'pkey',
						displayField:'pvalue',
						triggerAction:'all',
						editable:false,
						clone: true,
						name: 'value_from',	
						enableKeyEvents:true,
						listeners:{
							'keyUp':this._global_para.keyUpAction,
							'select':this._global_para.keyUpAction,
							'change':this._global_para.keyUpAction,
							scope:this
						}
					});
					var cf_to = new Ext.form.ComboBox({
						width:100,
						hideLabel: true,
						store:this._global_para.bitStore,
						mode:"local",
						valueField:'pkey',
						editable:false,
						displayField:'pvalue',
						triggerAction:'all',
						clone: true,
						enableKeyEvents:true,
						name: 'value_to',	
						listeners:{
							'keyUp':this._global_para.keyUpAction,
							'select':this._global_para.keyUpAction,
							'change':this._global_para.keyUpAction,
							scope:this
						}
					});
					var cf_include = new Ext.form.ComboBox({
						width:100,
						hideLabel: true,
						store:this._global_para.bitStore,
						clone: true,
						name: 'value_include',	
						mode:"local",
						valueField:'pkey',
						displayField:'pvalue',
						editable:false,
						triggerAction:'all',
						enableKeyEvents:true,
						listeners:{
							'keyUp':this._global_para.keyUpAction,
							'select':this._global_para.keyUpAction,
							'change':this._global_para.keyUpAction,
							scope:this
						}
					});
					var cf_uninclude = new Ext.form.ComboBox({
						width:100,
						hideLabel: true,
						store:this._global_para.bitStore,
						mode:"local",
						valueField:'pkey',
						displayField:'pvalue',
						editable:false,
						triggerAction:'all',
						clone: true,
						enableKeyEvents:true,
						name: 'value_uninclude',	
						listeners:{
							'keyUp':this._global_para.keyUpAction,
							'select':this._global_para.keyUpAction,
							'change':this._global_para.keyUpAction,
							scope:this
						}
					});
				}
				break;
				case 'COMBOBOX':
					var cmbJsonStore = new Ext.data.ArrayStore({
						fields: [{name: 'pkey', type: 'string'}, {name: 'pvalue', type: 'string'}],
						data : this._global_para.fieldDataArray[this._global_para.getIndexByCriFieldId(criFieldComValue)]
					});
					if (i == 0) {
						var cf = new Ext.form.ComboBox({
							id:this.panel_name+'_sp_value',
							width:100,
							minListWidth: 100,
							enableKeyEvents:true,
							hideLabel: false,
							store:cmbJsonStore,
							fieldLabel: getResource('Value','searchPanel'),
							labelAlign: 'top',
							mode:"local",
							triggerAction:'all',
							valueField:'pkey',
							displayField:'pvalue',
							editable:true,
							forceSelection:true,
							resizable:true,
							name: 'value',	
							listeners:{
								'keyUp':this._global_para.keyUpAction,
								'select':this._global_para.keyUpAction,
								'change':this._global_para.keyUpAction,
								scope:this
							}
						});
						
						var cf_from = new Ext.form.ComboBox({
							id:this.panel_name+'_sp_value_from',
							width:100,
							minListWidth: 100,
							hideLabel: false,
							enableKeyEvents:true,
							store:cmbJsonStore,
							mode:"local",
							resizable:true,
							valueField:'pkey',
							editable:true,
							forceSelection:true,
							displayField:'pvalue',
							triggerAction:'all',
							fieldLabel: getResource('Value_from','searchPanel'),
							labelAlign: 'top',
							name: 'value_from',	
							listeners:{
								'keyUp':this._global_para.keyUpAction,
								'select':this._global_para.keyUpAction,
								'change':this._global_para.keyUpAction,
								scope:this
							}
						});
						var cf_to = new Ext.form.ComboBox({
							id:this.panel_name+'_sp_value_to',
							width:100,
							minListWidth: 100,
							hideLabel: false,
							resizable:true,
							store:cmbJsonStore,
							disabled:true,
							mode:"local",
							editable:true,
							forceSelection:true,
							valueField:'pkey',
							displayField:'pvalue',
							triggerAction:'all',
							enableKeyEvents:true,
							fieldLabel: getResource('Value_to','searchPanel'),
							labelAlign: 'top',
							name: 'value_to',	
							listeners:{
								'keyUp':this._global_para.keyUpAction,
								'select':this._global_para.keyUpAction,
								'change':this._global_para.keyUpAction,
								scope:this
							}
						});
						var cf_include = new Ext.form.ComboBox({
							id:this.panel_name+'_sp_value_include',
							width:100,
							minListWidth: 100,
							hideLabel: false,
							store:cmbJsonStore,
							disabled:true,
							resizable:true,
							editable:true,
							forceSelection:true,
							mode:"local",
							valueField:'pkey',
							displayField:'pvalue',
							triggerAction:'all',
							enableKeyEvents:true,
							fieldLabel: getResource('Value_include','searchPanel'),
							labelAlign: 'top',
							name: 'value_include',	
							listeners:{
								'keyUp':this._global_para.keyUpAction,
								'select':this._global_para.keyUpAction,
								'change':this._global_para.keyUpAction,
								scope:this
							}
						});
						
						var cf_uninclude = new Ext.form.ComboBox({
							id:this.panel_name+'_sp_value_uninclude',
							width:100,
							minListWidth: 100,
							hideLabel: false,
							store:cmbJsonStore,
							mode:"local",
							resizable:true,
							editable:true,
							forceSelection:true,
							valueField:'pkey',
							triggerAction:'all',
							displayField:'pvalue',
							disabled:true,
							enableKeyEvents:true,
							fieldLabel: getResource('Value_uninclude','searchPanel'),
							labelAlign: 'top',
							name: 'value_uninclude',	
							listeners:{
								'keyUp':this._global_para.keyUpAction,
								'select':this._global_para.keyUpAction,
								'change':this._global_para.keyUpAction,
								scope:this
							}
						});
				} else {
					var cf = new Ext.form.ComboBox({
						width:100,
						minListWidth: 100,
						hideLabel: true,
						store:cmbJsonStore,
						enableKeyEvents:true,
						mode:"local",
						resizable:true,
						valueField:'pkey',
						editable:true,
						forceSelection:true,
						displayField:'pvalue',
						triggerAction:'all',
						disabled:true,
						clone: true,
						name: 'value',	
						listeners:{
							'keyUp':this._global_para.keyUpAction,
							'select':this._global_para.keyUpAction,
							'change':this._global_para.keyUpAction,
							scope:this
						}
					});
					var cf_from = new Ext.form.ComboBox({
						width:100,
						minListWidth: 100,
						hideLabel: true,
						store:cmbJsonStore,
						resizable:true,
						mode:"local",
						editable:true,
						forceSelection:true,
						valueField:'pkey',
						displayField:'pvalue',
						disabled:true,
						triggerAction:'all',
						clone: true,
						name: 'value_from',	
						enableKeyEvents:true,
						listeners:{
							'keyUp':this._global_para.keyUpAction,
							'select':this._global_para.keyUpAction,
							'change':this._global_para.keyUpAction,
							scope:this
						}
					});
					var cf_to = new Ext.form.ComboBox({
						width:100,
						minListWidth: 100,
						hideLabel: true,
						resizable:true,
						store:cmbJsonStore,
						editable:true,
						forceSelection:true,
						mode:"local",
						valueField:'pkey',
						displayField:'pvalue',
						disabled:true,
						triggerAction:'all',
						clone: true,
						enableKeyEvents:true,
						name: 'value_to',	
						listeners:{
							'keyUp':this._global_para.keyUpAction,
							'select':this._global_para.keyUpAction,
							'change':this._global_para.keyUpAction,
							scope:this
						}
					});
					var cf_include = new Ext.form.ComboBox({
						width:100,
						minListWidth: 100,
						resizable:true,
						hideLabel: true,
						store:cmbJsonStore,
						clone: true,
						name: 'value_include',	
						mode:"local",
						editable:true,
						forceSelection:true,
						valueField:'pkey',
						displayField:'pvalue',
						disabled:true,
						triggerAction:'all',
						enableKeyEvents:true,
						listeners:{
							'keyUp':this._global_para.keyUpAction,
							'select':this._global_para.keyUpAction,
							'change':this._global_para.keyUpAction,
							scope:this
						}
					});
					var cf_uninclude = new Ext.form.ComboBox({
						width:100,
						minListWidth: 100,
						resizable:true,
						hideLabel: true,
						store:cmbJsonStore,
						mode:"local",
						editable:true,
						forceSelection:true,
						valueField:'pkey',
						displayField:'pvalue',
						disabled:true,
						triggerAction:'all',
						clone: true,
						enableKeyEvents:true,
						name: 'value_uninclude',	
						listeners:{
							'keyUp':this._global_para.keyUpAction,
							'select':this._global_para.keyUpAction,
							'change':this._global_para.keyUpAction,
							scope:this
						}
					});
				}
				break;
				case 'TIMEFIELD':
					if (i == 0) {
						var cf = new Ext.form.TimeField({
							id:this.panel_name+'_sp_value',
							width:100,
							enableKeyEvents:true,
							hideLabel: false,
							fieldLabel: getResource('Value','searchPanel'),
							labelAlign: 'top',
							format: "H:i",
							increment: 5,
							name: 'value',	
							listeners:{
								'keyUp':this._global_para.keyUpAction,
								'select':this._global_para.keyUpAction,
								'change':this._global_para.keyUpAction,
								scope:this
							}
						});
						
						var cf_from = new Ext.form.TimeField({
							id:this.panel_name+'_sp_value_from',
							width:100,
							hideLabel: false,
							enableKeyEvents:true,
							format: "H:i",
							increment: 5,
							fieldLabel: getResource('Value_from','searchPanel'),
							labelAlign: 'top',
							name: 'value_from',	
							listeners:{
								'keyUp':this._global_para.keyUpAction,
								'select':this._global_para.keyUpAction,
								'change':this._global_para.keyUpAction,
								scope:this
							}
						});
						var cf_to = new Ext.form.TimeField({
							id:this.panel_name+'_sp_value_to',
							width:100,
							hideLabel: false,
							format: "H:i",
							increment: 5,
							enableKeyEvents:true,
							fieldLabel: getResource('Value_to','searchPanel'),
							labelAlign: 'top',
							name: 'value_to',	
							listeners:{
								'keyUp':this._global_para.keyUpAction,
								'select':this._global_para.keyUpAction,
								'change':this._global_para.keyUpAction,
								scope:this
							}
						});
						var cf_include = new Ext.form.TimeField({
							id:this.panel_name+'_sp_value_include',
							width:100,
							hideLabel: false,
							format: "H:i",
							increment: 5,
							enableKeyEvents:true,
							fieldLabel: getResource('Value_include','searchPanel'),
							labelAlign: 'top',
							name: 'value_include',	
							listeners:{
								'keyUp':this._global_para.keyUpAction,
								'select':this._global_para.keyUpAction,
								'change':this._global_para.keyUpAction,
								scope:this
							}
						});
						
						var cf_uninclude = new Ext.form.TimeField({
							id:this.panel_name+'_sp_value_uninclude',
							width:100,
							hideLabel: false,
							format: "H:i",
							increment: 5,
							enableKeyEvents:true,
							fieldLabel: getResource('Value_uninclude','searchPanel'),
							labelAlign: 'top',
							name: 'value_uninclude',	
							listeners:{
								'keyUp':this._global_para.keyUpAction,
								'select':this._global_para.keyUpAction,
								'change':this._global_para.keyUpAction,
								scope:this
							}
						});
				} else {
					var cf = new Ext.form.TimeField({
						width:100,
						hideLabel: true,
						enableKeyEvents:true,
						format: "H:i",
						increment: 5,
						clone: true,
						name: 'value',	
						listeners:{
							'keyUp':this._global_para.keyUpAction,
							'select':this._global_para.keyUpAction,
							'change':this._global_para.keyUpAction,
							scope:this
						}
					});
					var cf_from = new Ext.form.TimeField({
						width:100,
						hideLabel: true,
						format: "H:i",
						increment: 5,
						clone: true,
						name: 'value_from',	
						enableKeyEvents:true,
						listeners:{
							'keyUp':this._global_para.keyUpAction,
							'select':this._global_para.keyUpAction,
							'change':this._global_para.keyUpAction,
							scope:this
						}
					});
					var cf_to = new Ext.form.TimeField({
						width:100,
						hideLabel: true,
						format: "H:i",
						increment: 5,
						clone: true,
						enableKeyEvents:true,
						name: 'value_to',	
						listeners:{
							'keyUp':this._global_para.keyUpAction,
							'select':this._global_para.keyUpAction,
							'change':this._global_para.keyUpAction,
							scope:this
						}
					});
					var cf_include = new Ext.form.ComboBox({
						width:100,
						hideLabel: true,
						clone: true,
						name: 'value_include',	
						format: "H:i",
						increment: 5,
						enableKeyEvents:true,
						listeners:{
							'keyUp':this._global_para.keyUpAction,
							'select':this._global_para.keyUpAction,
							'change':this._global_para.keyUpAction,
							scope:this
						}
					});
					var cf_uninclude = new Ext.form.ComboBox({
						width:100,
						hideLabel: true,
						format: "H:i",
						increment: 5,
						clone: true,
						enableKeyEvents:true,
						name: 'value_uninclude',	
						listeners:{
							'keyUp':this._global_para.keyUpAction,
							'select':this._global_para.keyUpAction,
							'change':this._global_para.keyUpAction,
							scope:this
						}
					});
				}
				break;
			default:
				alert(criFieldType + ' has not been implemented');
		}
		// manipulate the value field depending on the search type:
		
		fieldsets.items.items[2].insert(i,cf);
		fieldsets.items.items[3].insert(i,cf_from);
		fieldsets.items.items[4].insert(i,cf_to);
		fieldsets.items.items[5].insert(i,cf_include);
		fieldsets.items.items[6].insert(i,cf_uninclude);
		fieldsets.items.items[7].items.items[i].setDisabled(false);
		fieldsets.doLayout();
		if (valueField != '') {
			if (criFieldType == 'DATEFIELD') {
				valueField = valueField.replace('T00:00:00','');
				fieldsets.items.items[2].items.items[i].setValue( valueField );
			} else {
				fieldsets.items.items[2].items.items[i].setValue( valueField );
			}
		} 
		if (operatorField != '') {
			fieldsets.items.items[1].items.items[i].setValue(operatorField);
		}
	}
	
});



















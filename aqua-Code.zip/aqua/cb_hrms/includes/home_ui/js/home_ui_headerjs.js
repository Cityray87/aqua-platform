/*** mask the home page when new menu UI is rendered ***/
var hideAllDiv = document.createElement("div");
hideAllDiv.id = 'hideAll';
hideAllDiv.style.position = "fixed";
hideAllDiv.style.left = "0px";
hideAllDiv.style.right = "0px";
hideAllDiv.style.top = "0px";
hideAllDiv.style.bottom = "0px";
hideAllDiv.style.backgroundColor = "#fff";
hideAllDiv.style.zIndex = "99999";

document.body.appendChild(hideAllDiv);

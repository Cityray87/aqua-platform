//v.2.0 build 90722
/*
Copyright DHTMLX LTD. http://www.dhtmlx.com
You allowed to use this component or parts of it under GPL terms
To use it on other terms or get Professional edition of the component please contact us at sales@dhtmlx.com
*/
/*$Rev$*/

scheduler._edit_stop_event=function(ev,mode){
	if (this._new_event){
		//if (!mode) this.deleteEvent(ev.id,true);	
		if (!mode);
		else this.callEvent("onEventAdded",[ev.id,ev]);
		this._new_event=null;
		// newly added
		this.render_view_data();		
	} else
	{
		if (mode) this.callEvent("onEventChanged",[ev.id,ev]);
		this.render_view_data();
	}
}

scheduler.deleteEvent=function(id,silent){ 
	deleteSchedulerEvents(id);
	var ev=this._events[id];
	if (!silent && !this.callEvent("onBeforeEventDelete",[id,ev]))
	{
		return;
	}
	if (ev){
		delete this._events[id];
		this.unselect(id);
		this.event_updated(ev);
	}
}
   
scheduler._on_mouse_up=function(e){
	if (this._drag_mode && this._drag_id){
		this._els["dhx_cal_data"][0].style.cursor="default";
		//drop
		var ev=this.getEvent(this._drag_id);
		if (!this._drag_event.start_date || ev.start_date.valueOf()!=this._drag_event.start_date.valueOf() || ev.end_date.valueOf()!=this._drag_event.end_date.valueOf()){
			var is_new=(this._drag_mode=="new-size");
			if (is_new && this.config.edit_on_create){
				this.unselect();
				this._new_event=new Date();//timestamp of creation
				if (this._table_view || this.config.details_on_create) {
					this._drag_mode=null;
					return this.showLightbox(this._drag_id);
				}
				this._drag_pos=true; //set flag to trigger full redraw
				this._select_id=this._edit_id=this._drag_id;
			}else
			{
				this.callEvent(is_new?"onEventAdded":"onEventChanged",[this._drag_id,this.getEvent(this._drag_id)]);
				var scheduler_id = getQuerystring('scheduler_id');
				updateSchedulerEvents(scheduler_id,ev.start_date,ev.end_date,ev.text,ev.id,ev.details);
			}
			this.render_view_data();
		}
		if (this._drag_pos) this.render_view_data(); //redraw even if there is no real changes - necessary for correct positioning item after drag
	}
	this._drag_mode=null;
	this._drag_pos=null;
}	

scheduler.editStop=function(mode,id){
	if (id && this._edit_id!=id) return;
	var ev=this.getEvent(this._edit_id);
	if (ev){
		if (mode)
		{
			ev.text=this._editor.value;
			//alert(ev.text);
			var scheduler_id = getQuerystring('scheduler_id');
			updateSchedulerEvents(scheduler_id,ev.start_date,ev.end_date,ev.text,ev.id,ev.details);
		}
		this._edit_id=null;
		this._editor=null;	
		this.updateEvent(ev.id);
		this._edit_stop_event(ev,mode);		
	}
}

scheduler.showLightbox=function(id){
	scheduler._lightbox_id=id;
	showlightbox();
	/*	
	if (!id) return;
	if (!this.callEvent("onBeforeLightbox",[id])) return;
	var box = this._get_lightbox();
	this.showCover(box);
	this._fill_lightbox(id,box);
	*/
}

function deleteSchedulerEvents(id)
{
	scheduler_id = getQuerystring('scheduler_id');			
	Ext.Ajax.request({
		waitMsg: "Please wait ... ",
		url: "/cb_hrms/index.cfm?event=scheduler.general.deleteEvent",
		method: "POST",
		params: {
			id: id
		},	
        failure: function(response,options){
            var responseText = Ext.util.JSON.decode(options.response.responseText);
            Ext.MessageBox.alert("Error",responseText.success_msg);
    	},
		success: function(response,options){
			var responseText = Ext.util.JSON.decode(response.responseText);
			scheduler.clearAll();
			scheduler.load("?event=scheduler.general.getSchedulerXML&scheduler_id="+scheduler_id+"&datenow=" + new Date());	      		
	
		}                                    
    });			
	
}


function updateSchedulerEvents(scheduler_id,start_date,end_date,text,id,details)
{
	var startMin = start_date.getMinutes();
	var startHour = start_date.getHours();
	var startDay = start_date.getDate() + "";
	var startMonth = (start_date.getMonth()+1) + "";
	var startYear = start_date.getFullYear();

	var endMin = end_date.getMinutes();
	var endHour = end_date.getHours();
	var endDay = end_date.getDate() + "";
	var endMonth = (end_date.getMonth()+1) + "";
	var endYear = end_date.getFullYear();	
	if (details == null)
		details = '';
	//Ext.MessageBox.wait('Please wait ... ', 'Saving ... ', '');
	Ext.Ajax.request({
		waitMsg: "Please wait ... ",
		url: "/cb_hrms/index.cfm?event=scheduler.general.updateEventByAjax",
		method: "POST",
		params: {
			scheduler_id: scheduler_id,
			startMin: startMin,
			startHour: startHour,
			startDay: startDay,
			startMonth: startMonth,
			startYear: startYear,
			endMin: endMin,
			endHour: endHour,
			endDay: endDay,
			endMonth: endMonth,
			endYear: endYear,
			text: text,
			id: id,
			details: details
		},	
        failure: function(response,options){
            var responseText = Ext.util.JSON.decode(options.response.responseText);
			//Ext.MessageBox.hide();
            Ext.MessageBox.alert("Error",responseText.success_msg);
    	},
		success: function(response,options){
			var responseText = Ext.util.JSON.decode(response.responseText);
			//Ext.MessageBox.hide();
			scheduler.clearAll();
			scheduler.load("?event=scheduler.general.getSchedulerXML&scheduler_id="+scheduler_id+"&datenow=" + new Date());	      		
		}                                    
    });		
}

function getMonthNumber(monthString)
{
	if (monthString == 'January')
		return '1';
	else if (monthString == 'February')
		return '2';
	else if (monthString == 'March')
		return '3';
	else if (monthString == 'April')
		return '4';
	else if (monthString == 'May')
		return '5';
	else if (monthString == 'June')
		return '6';
	else if (monthString == 'July')
		return '7';
	else if (monthString == 'Augest')
		return '8';
	else if (monthString == 'September')
		return '9';
	else if (monthString == 'October')
		return '10';
	else if (monthString == 'November')
		return '11';
	else if (monthString == 'December')
		return '12';
	return 'undefined';
}

function getTimeHour(HHMM)
{
	var hour=HHMM.split(":");
	return hour[0];
}

function getTimeMinute(HHMM)
{
	var minute=HHMM.split(":");
	return minute[1];
}

function getQuerystring(key, default_)
{
  if (default_==null) default_=""; 
  key = key.replace(/[\[]/,"\\\[").replace(/[\]]/,"\\\]");
  var regex = new RegExp("[\\?&]"+key+"=([^&#]*)");
  var qs = regex.exec(window.location.href);
  if(qs == null)
    return default_;
  else
    return qs[1];
}

function showlightbox() 
{
	var now = new Date();
	var evt = scheduler.getEvent(scheduler._lightbox_id);
	var startDay = evt.start_date.getDate() + "";
	var startMonth = (evt.start_date.getMonth()+1) + "";
	var startYear = evt.start_date.getFullYear();
	var endDay = evt.end_date.getDate() + "";
	var endMonth = (evt.end_date.getMonth()+1) + "";
	var endYear = evt.end_date.getFullYear();	
	var is_new = scheduler._new_event;
	var fromTimeHour = evt.start_date.getHours();
	var fromTimeMinute = evt.start_date.getMinutes();
	var toTimeHour = evt.end_date.getHours();
	var toTimeMinute = evt.end_date.getMinutes();	

	//alert (fromTimeHour +" "+ fromTimeMinute +" "+ toTimeHour +" "+ toTimeMinute);
	var scheduler_id = getQuerystring('scheduler_id');
	if (is_new)
		mode = 'new';
	else
		mode = 'edit';

	var is_new = scheduler._new_event;
	if (is_new)
		formTitle = 'Add new event';
	else
		formTitle = 'Edit event';
		
	win = new Ext.Window({
		renderTo : Ext.getBody(),
		width : 400,
		height : 500,
		title : formTitle,
		maximizable : true,
		resizable : true,
		modal : true,
		bodyStyle : "background: #fff;",
		autoLoad : {
			params: {
				event_num: evt.id,
				startDay: startDay,
				startMonth: startMonth, 
				startYear: startYear,
				endDay: endDay,
				endMonth: endMonth, 
				endYear: endYear,
				uid: now,
				mode: mode,		
				fromTimeHour: fromTimeHour,
				fromTimeMinute: fromTimeMinute,
				toTimeHour: toTimeHour,
				toTimeMinute: toTimeMinute,				
				scheduler_id: scheduler_id
			},	
			url: '/cb_hrms/index.cfm?event=scheduler.general.processEvent',
			//url: '/cb_hrms/index.cfm?event=shiftPolicy.shiftPolicy.editshiftPolicy',
			scripts: true
		},
		listeners : {
			beforeclose : function(){	
				cancelLightBox();
			}
		}
	});
	win.show();	
} 

function deleteLightBox()
{
	/*
	var a = document.getElementById("lightbox-iframe");
	//alert (a.contentWindow.document.getElementById("eventName").value);
	

	document.getElementById('lightbox-content').style.display='none'; 
	document.getElementById('lightbox-bg').style.display='none'; 
	document.getElementById('lightbox-iframe').src='about:blank';
	*/
	var evt = scheduler.getEvent(scheduler._lightbox_id);
	scheduler._edit_stop_event(evt,false);	
	scheduler.deleteEvent(evt.id,true);
}
function cancelLightBox()
{
	/*
		var a = document.getElementById("lightbox-iframe");
	//alert (a.contentWindow.document.getElementById("eventName").value);
	

	document.getElementById('lightbox-content').style.display='none'; 
	document.getElementById('lightbox-bg').style.display='none'; 
	document.getElementById('lightbox-iframe').src='about:blank';
	*/
	//alert('cancelLightBox()');
	//alert('scheduler reloaded');
	
	var scheduler_id = getQuerystring('scheduler_id');
	var evt = scheduler.getEvent(scheduler._lightbox_id);
	scheduler._edit_stop_event(evt,false);

	scheduler.clearAll();
	scheduler.load("?event=scheduler.general.getSchedulerXML&scheduler_id="+scheduler_id+"&datenow=" + new Date());	
	
}

function closelightbox(evts) 
{ 
	
	/*
	var a = document.getElementById("lightbox-iframe");
	document.getElementById('lightbox-content').style.display='none'; 
	document.getElementById('lightbox-bg').style.display='none'; 
	document.getElementById('lightbox-iframe').src='about:blank';
	*/

	var events = scheduler.getEvent(scheduler._lightbox_id);
	events.text = evts.event_name;
	startDate = new Date(evts.start_date);
	startDate.setHours(getTimeHour(evts.fromTime));
	startDate.setMinutes(getTimeMinute(evts.fromTime));
	endDate = new Date(evts.end_date);
	endDate.setHours(getTimeHour(evts.toTime));
	endDate.setMinutes(getTimeMinute(evts.toTime));
	
	//fromDate = new Date(evts.fromYear,getMonthNumber(evts.fromMonth)-1,evts.fromDay,getTimeHour(evts.fromTime),getTimeMinute(evts.fromTime));

	//toDate = new Date(evts.toYear,getMonthNumber(evts.toMonth)-1,evts.toDay,getTimeHour(evts.toTime),getTimeMinute(evts.toTime));
	//events.start_date = fromDate;
	//events.end_date = toDate;
	events.start_date = startDate;
	events.end_date = endDate;
	events._timed=scheduler.is_one_day_event(events);
	//alert(evt.text);
	//alert(evt._timed);
	//alert ('closelightbox event2');
	
	scheduler._edit_stop_event(events,true);
	
}



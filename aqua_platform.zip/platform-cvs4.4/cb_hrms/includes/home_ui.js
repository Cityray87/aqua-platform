// fix static page width and height
pageResizeHeight = 0;
pageResizeWidth = 6;

// add menu minimize and restore button.
$('<div id="west_panel_minimize_button"><a href="javascript:doMenuMinimize()" style="width:8px; height:50px; background-image: url(includes/home_ui/images/menu_icons/minimize_Right.png);position:fixed; z-index:9999;left:240px;top: 50%;"></a></div>').insertAfter( $("#menu_panel_west_id"));
$('<div id="west_panel_maximize_button" style="display:none;"><a href="javascript:doMenuMaximize()" style="width:8px; height:50px; background-image: url(includes/home_ui/images/menu_icons/minimize_Left.png);position:fixed; z-index:9999;left:0px;top: 50%;"></a></div>').insertAfter( $("#menu_panel_west_id"));

// change skin function and initialize it with user preference.
window.changeSkin = function (skin_color){
    var body  = document.getElementsByTagName('body')[0];
    var link  = document.createElement('link');
    link.rel  = 'stylesheet';
    link.type = 'text/css';
    link.href = 'includes/home_ui/images/skin/' + skin_color + "/" + skin_color + '.css';
    link.media = 'all';
    body.appendChild(link);
    document.cookie = "skin_color=" + skin_color;
}

var cookie_skin_color = document.cookie.replace(/(?:(?:^|.*;\s*)skin_color\s*\=\s*([^;]*).*$)|^.*$/, "$1");
if (cookie_skin_color != ""){
	changeSkin(cookie_skin_color);
}



window.doMenuMinimize = function(){
	Ext.getCmp('menu_panel_west_id').collapse( true );
	document.getElementById('west_panel_minimize_button').style.display = "none";
	document.getElementById('west_panel_maximize_button').style.display = "block";
	//$('#west_panel_maximize_button').fadeToggle();
}

window.doMenuMaximize = function(){
	Ext.getCmp('menu_panel_west_id').expand( true );
	//document.getElementById('west_panel_minimize_button').style.display = "block";
	$('#west_panel_minimize_button').fadeIn("800");
	document.getElementById('west_panel_maximize_button').style.display = "none";
}

// fix problem with left hand menu having a margin top when collapse and expand
$('#menu_panel_west_id').css({"top":"0px"});
Ext.getCmp("menu_panel_west_id").on('collapse',function(){
	$('#menu_panel_west_id').css({"top":"0px"});

});
Ext.getCmp("menu_panel_west_id").on('expand',function(){
	$('#menu_panel_west_id').css({"top":"0px"});

});



//for better effect it's better to hide the top menu then show it when js is ready
document.getElementById('top_menu_outer').style.display= "block";

//update i18ns for top menu items
if(Ext.get("top_menu_set_default_home")){
	Ext.get("top_menu_set_default_home").update(getResource("set_user_homepage","default_home"));
}

if(Ext.get("top_menu_change_password")){
	Ext.get("top_menu_change_password").update(getResource('modifyPassword',''));
}

if(Ext.get("top_menu_Skin")){
	Ext.get("top_menu_Skin").update(getResource('home_skin','home'));
}

if(Ext.get("skin_grey")){
	Ext.get("skin_grey").update(getResource('skin_grey','home'));
}

if(Ext.get("skin_light_blue")){
	Ext.get("skin_light_blue").update(getResource('skin_light_blue','home'));
}

if(Ext.get("skin_coffee")){
	Ext.get("skin_coffee").update(getResource('skin_coffee','home'));
}

if(Ext.get("skin_green")){
	Ext.get("skin_green").update(getResource('skin_green','home'));
}

if(Ext.get("skin_green2")){
	Ext.get("skin_green2").update(getResource('skin_green2','home'));
}

if(Ext.get("skin_red")){
	Ext.get("skin_red").update(getResource('skin_red','home'));
}


if(Ext.get("top_menu_setting")){
	Ext.get("top_menu_setting").update(getResource('home_setting','home'));
}

if(Ext.get("top_menu_change_role")){
	Ext.get("top_menu_change_role").update(getResource('choose_role','home'));
}

if(Ext.get("top_menu_change_delegate_role")){
	Ext.get("top_menu_change_delegate_role").update(getResource('delegate_role','home'));
}

if(Ext.get("top_menu_choose_language")){
	Ext.get("top_menu_choose_language").update(getResource('choose_language','home'));
}

if(Ext.get("top_menu_username")){
	Ext.get("top_menu_username").update(current_user_name);
}

if(Ext.get("top_menu_rolename")){
	Ext.get("top_menu_rolename").update('(' + current_role + ')');
}

//update the homepage employee photo
document.getElementById('top_menu_employee_photo_img').src = _user_define_session.home_page_head_photo;

//hide menu title
document.getElementById('menu_panel_west_id').childNodes[0].style.display = "none";


//new first tier menu on click function to be used
var showCurrentSessionMenuState = 0; // this variable indicate if top menu click needs to be performed, if system is to show a default menu, then it should not show the top menu.
window.essShowMenu = function (n)
{
	//show the menu if it's minimize
	doMenuMaximize();

	//extreme case if there is no menu available
	if (menuData.sysMenus.length == 1)
		return;

	//hide the menu search tree panel when top menu is clicked
	if (typeof(Ext.getCmp('top_menu_search_id')) != 'undefined'){
		Ext.getCmp('top_menu_search_id').hide();
	}

	//if search field was used and user click on a module, then clear the search field
	if (n != -1 && Ext.getCmp("filter_menu_treepanel_id").getValue() != ""){
		Ext.getCmp("filter_menu_treepanel_id").setValue("");
		doFilter(Ext.getCmp("filter_menu_treepanel_id"));
	}
	

	// first level is my favourite, so we start at index i=1
	var menu_item;
	var el;
	for(var i = 1;i<menuData.sysMenus.length;i++){
		
		if(Ext.getCmp("treepanel_"+menuData.sysMenus[i].module_id+"_id")){
			Ext.getCmp("treepanel_"+menuData.sysMenus[i].module_id+"_id").hide();
		}
		if (typeof(Ext.getCmp('my_fav_menu_id')) != 'undefined'){
			Ext.getCmp('my_fav_menu_id').hide();
		}
	
		//add the highlight effect to top menu
		menu_item = Ext.util.JSON.decode(menuData.sysMenus[i].module_data)[0];
		el = document.getElementById('top_menu_' + menu_item.menu_key);

		if (i == n)
			el.className = 'top_nav_second_title top_nav_second_title_selected';
		else
			el.className = 'top_nav_second_title';

	}
	


	//when user click on my favorite menu 
	if (n == 0){
		document.getElementById('top_menu_my_fav_menu_li').className = 'top_nav_second_title top_nav_second_title_selected';
		Ext.getCmp("my_fav_menu_id").show();
		Ext.getCmp("my_fav_menu_id").expand();

	}
	else if (n == -1){
		Ext.getCmp("top_menu_search_id").show();
		Ext.getCmp("top_menu_search_id").expand();

	}
	//when user click on other menu
	else{
		// only show the first tier menu redirect page if it's not performing a browser refresh or first time login.
		if (showCurrentSessionMenuState == 0){
			clickSysMenu(Ext.util.JSON.decode(menuData.sysMenus[n].module_data)[0].menu_key);
		}
		document.getElementById('top_menu_my_fav_menu_li').className = 'top_nav_second_title';
		Ext.getCmp("treepanel_"+menuData.sysMenus[n].module_id+"_id").show();
		Ext.getCmp("treepanel_"+menuData.sysMenus[n].module_id+"_id").expand();

	}


}


//add my favorite menu to the left hand side menu tree
var cur_men_fav_menu_node;
if (typeof(Ext.getCmp('my_fav_menu_id')) == 'undefined') {
	var temp_tree = new Ext.tree.TreePanel({
		id: "my_fav_menu_id",
		collapsed: true,
		hidden: false,
		title: getResource('my_fav_menu', 'home'),
		lines: false,
		split: true,
		collapsible: true,
		collapseMode: "mini",
		rootVisible: false,
		autoScroll: true,
		border: false,
		enableDD: true,
		root: {
			id: "my_fav_menu_root",
			text: 'my_fav_menu_root',
			expanded: true,
			children: [
			]
		},
		listeners: {
			'click': function(node) {

				if (validateDataFlag == 1) {
					Ext.Msg.confirm(getResource('confirm_title', ''), getResource('confirm_msg', 'confirm_modify_data'), function(_btn) {
						if (_btn == "no") {
							return false;
						} else {
							validateDataFlag = 0;
							clickSysMenu(node.attributes.menu_key);
						}
					})
				} else {
					clickSysMenu(node.attributes.menu_key);
				}

			},
			'beforemovenode': function(t, node, oldParent, newParent, index) {
				Ext.Ajax.request({
				method: "POST",
				url: "index.cfm?event=menuShortcut.general.updateMenuShortCutSeq&now=" + new Date(),
				params: {
					display_seq: index + 1,
					
					shortcut_id: '0',
					
					shortcut_menu_key: node.attributes.menu_key,
					icon: 'default.png'
				},
                              timeout: ajaxTimeOut,
                              failure: function(response, options) {
                                  exceptionHandling('', 'P10024');
                                  return false;
                              },
                              success: function(response, options) {
                      
                                  var responseObj = Ext.util.JSON.decode(response.responseText);
                      
                      
                                  if (responseObj.success == true && responseObj.flag == "S") {
                                      return true;
                                  }
                      
                      
                      
                              }
                          });
                      
                          return true;
                      }
			/*
			,
			contextmenu:function(node,e){
				var menuActions = [{
					text: getResource('delete_my_fav_menu', 'home'),
					icon:"ncludes/home_ui/images/menu_icons/my_fav_menu.png",
					handler: delete_my_fav_menu
            			}];
				var leafContextMenu = new Ext.menu.Menu({items:[menuActions[0]]});
				cur_men_fav_menu_node = node;
				leafContextMenu.showAt(e.getXY());
			}*/
		}

	});
	Ext.getCmp('menu_panel_west_id').add(temp_tree);
	Ext.getCmp('menu_panel_west_id').doLayout();
	
	Ext.Ajax.request({
		method:"POST",
		url:"index.cfm?event=menuShortcut.general.getMenuShortCutData&now="+new Date(),
		timeout : ajaxTimeOut,
		failure:function(response,options){
			exceptionHandling('','P10024');
			return;
		},
		success:function(response,options){
			var myFavMenuData = Ext.util.JSON.decode(response.responseText).query.data;
			for (var i = 0; i < myFavMenuData.length; i++) {
				myFavMenuData[i].id = myFavMenuData[i].menu_id;
				myFavMenuData[i].text = myFavMenuData[i].menu_name;
				myFavMenuData[i].leaf = true;
				Ext.getCmp('my_fav_menu_id').getRootNode().appendChild(myFavMenuData[i]);
			}


			Ext.getCmp('my_fav_menu_id').getRootNode().eachChild(function(childnode) {
				if (childnode.getUI().getIconEl().previousSibling.src.indexOf('/s.gif') > -1){
					childnode.getUI().getIconEl().previousSibling.style.visibility = "hidden";
					//childnode.getUI().getIconEl().previousSibling.style.marginLeft = "10px";
					childnode.getUI().getIconEl().previousSibling.onerror = function () {
                				childnode.getUI().getIconEl().previousSibling.src = "includes/home_ui/images/menu_icons/child/" + "default_icon.png";
						childnode.getUI().getIconEl().previousSibling.style.visibility = "visible";
        				};
					childnode.getUI().getIconEl().previousSibling.onload = function () {
						childnode.getUI().getIconEl().previousSibling.style.visibility = "visible";
        				};
					childnode.getUI().getIconEl().previousSibling.src = "includes/home_ui/images/menu_icons/child/" + childnode.attributes.menu_key + ".png";
				}
			});

			// trigger the switch at start
			toggle_fav_menu_button();
			return;
		}
	});
	

}

//add event to light up the "star" (or turn off the star) when user clicked on a menu
var prev_menu_favor_state = false;
var current_menu_favor_state = false;

function toggle_fav_menu_button(){
	var temp_current_click_menu_key;
	temp_current_click_menu_key = current_click_menu_key.split("menu_key=");
	
	//sometimes current_click_menu_key is in another form, e.g ess_homepage.ess_home.hr_home&menu_id=107089&menu_key=hr_home_page, this is to cater such case
	if (temp_current_click_menu_key.length == 2){
		current_click_menu_key = temp_current_click_menu_key[1];
	}
	
	var menuPropertyObj = getMenuFromLibByKey(current_click_menu_key);
	if (menuPropertyObj.leaf != true)
		return;
	if (Ext.getCmp('my_fav_menu_id').getRootNode().findChild("menu_key", current_click_menu_key, true)){
		current_menu_favor_state = true;
	}
	else{
		current_menu_favor_state = false;
	}

	if (current_menu_favor_state == true && prev_menu_favor_state == false)
	{
		var btnEl = Ext.getCmp('menuAddFavMenuBtn').getEl().child(Ext.getCmp('menuAddFavMenuBtn').buttonSelector);
		var url = 'includes/home_ui/images/ico03b.png';
		btnEl.setStyle('background-image', 'url(' +url+')');	
		btnEl.dom.style.display = "none";
		$(btnEl.dom).fadeToggle();
	}
	else if (current_menu_favor_state == false && prev_menu_favor_state == true)
	{
		var btnEl = Ext.getCmp('menuAddFavMenuBtn').getEl().child(Ext.getCmp('menuAddFavMenuBtn').buttonSelector);
		var url = 'includes/home_ui/images/ico03.png';
		btnEl.setStyle('background-image', 'url(' +url+')');	
		btnEl.dom.style.display = "none";
		$(btnEl.dom).fadeToggle();
	}
	prev_menu_favor_state = current_menu_favor_state;
}

Ext.getCmp("my_fav_menu_id").on("click",toggle_fav_menu_button,this);

for(var i = 0;i<menuData.sysMenus.length;i++){
	Ext.getCmp("treepanel_"+menuData.sysMenus[i].module_id+"_id").on("click",toggle_fav_menu_button,this);
}




//when user click on the star icon, to add to my favorite menu or delete current favorite menu
window.add_or_del_my_fav_menu = function() {

	if (!current_menu_favor_state)
	{
	Ext.getCmp('menuAddFavMenuBtn').setDisabled(true);
			Ext.Ajax.request({
				waitMsg: "",
				url: "index.cfm?event=menuShortcut.general.setItemAsMenuShortCut&datenow="+new Date(),
				method: "POST",
				failure:function(response,options){
					Ext.getCmp('menuAddFavMenuBtn').setDisabled(false);
					exceptionHandling('','P10024');
					return;
				},
				success: function(response,options){
					var responseText = Ext.util.JSON.decode(response.responseText);
					Ext.MessageBox.hide();
					if(responseText.flag == "S"){
						var menuPropertyObj = getMenuFromLibByKey(current_click_menu_key);
						if (typeof(Ext.getCmp('my_fav_menu_id').getNodeById(menuPropertyObj.id)) == 'undefined'){
							window.essShowMenu(0);	
							
							
						setTimeout(function (){
							Ext.getCmp('my_fav_menu_id').getRootNode().appendChild({id:menuPropertyObj.id, menu_key:menuPropertyObj.menu_key, text:menuPropertyObj.text, leaf:true});
							Ext.getCmp('my_fav_menu_id').getRootNode().eachChild(function(childnode) {
								if (childnode.getUI().getIconEl().previousSibling.src.indexOf('/s.gif') > -1){
									childnode.getUI().getIconEl().previousSibling.style.visibility = "hidden";
									//childnode.getUI().getIconEl().previousSibling.style.marginLeft = "10px";
									childnode.getUI().getIconEl().previousSibling.onerror = function () {
				                				childnode.getUI().getIconEl().previousSibling.src = "includes/home_ui/images/menu_icons/child/" + "default_icon.png";
										childnode.getUI().getIconEl().previousSibling.style.visibility = "visible";
				        				};
									childnode.getUI().getIconEl().previousSibling.onload = function () {
										childnode.getUI().getIconEl().previousSibling.style.visibility = "visible";
				        				};
									childnode.getUI().getIconEl().previousSibling.src = "includes/home_ui/images/menu_icons/child/" + childnode.attributes.menu_key + ".png";
								}
							});
 							toggle_fav_menu_button();
							Ext.getCmp('menuAddFavMenuBtn').setDisabled(false);
						}, 500);


						} else {
							Ext.getCmp('menuAddFavMenuBtn').setDisabled(false);
						}
					}else{
						Ext.getCmp('menuAddFavMenuBtn').setDisabled(false);
						return;
					}
			    }
			});

	}

	else{
		delete_my_fav_menu();
	}				

}

//when user click on my favorite menu, right click on a menu, then click delete.
window.delete_my_fav_menu = function() {
	var display_seq = 0;
	var shortcut_id = 0;
	var shortcut_menu_key = current_click_menu_key;
	var shortcut_icon = 'default.png';
	var current_menu_node = Ext.getCmp('my_fav_menu_id').getRootNode().findChild("menu_key", current_click_menu_key);

			Ext.Ajax.request({
				url: "index.cfm?event=menuShortcut.general.deleteMenuShortCutItem&_dc=" + new Date(),
				method: "POST",
				params: {
					display_seq: display_seq,
					shortcut_id: shortcut_id,
					shortcut_menu_key: shortcut_menu_key,
					icon: shortcut_icon
				},
				failure:function(response,options){
					Ext.getCmp('menuAddFavMenuBtn').setDisabled(false);
					exceptionHandling('','P10024');
					return;
				},
				success: function(response, options) {
					Ext.MessageBox.hide();
					Ext.getCmp('my_fav_menu_id').getRootNode().removeChild(current_menu_node);
					toggle_fav_menu_button();
				
				}
			});

}


//insert "my favorite" to first tier menu
var my_fav_menu = new Object();
my_fav_menu.eventName = "";
my_fav_menu.has_security = "0";
my_fav_menu.module_id = "0";
my_fav_menu.module_name = getResource('my_fav_menu','home');
my_fav_menu.module_data = "[{text: '" + getResource('my_fav_menu','home') + "',menu_key: '_my_fav_menu',has_security: '0',id: '0'}]";
menuData.sysMenus.unshift(my_fav_menu);


//insert top menu
var menu_html = "";
var menu_item = "";
var total_menu_width = $(window).width() - 260 - 28;
var current_menu_width = 0;
var i = 0;
var menu_page=0;
var current_page = 0;



for(var current_i=0; i<menuData.sysMenus.length; menu_page++){
	document.getElementById("top_menu").innerHTML += '<div id="top_menu_page_' + menu_page + '"></div>';
	current_i = i;
	for(current_menu_width=0;i<menuData.sysMenus.length ;i++){
		menu_item = Ext.util.JSON.decode(menuData.sysMenus[i].module_data)[0];
		//hide my favorite function at the top menu, only to show it at the left hand menu, uncomment the below code to show.
		if (i == 0)
			menu_html = '<li menu_seq="' + i + '" onclick="javascript:essShowMenu(' + i + ');" id="' + 'top_menu_my_fav_menu_li" class="top_nav_second_title" onMouseOver="document.getElementById(\'top_menu_my_fav_menu\').style.backgroundPosition=\'0px -50px\';" onMouseOut="document.getElementById(\'top_menu_my_fav_menu\').style.backgroundPosition=\'0px 0px\';"><a><span id="top_menu_my_fav_menu" class="top_menu_icon" style="background-image:url(\'includes/home_ui/images/menu_icons/my_fav_menu.png\');"></span>' + menu_item.text + '</a></li>';
		else
			menu_html = '<li menu_seq="' + i + '" onclick="javascript:essShowMenu(' + i + ');" id="' + 'top_menu_' + menu_item.menu_key + '" class="top_nav_second_title" onMouseOver="document.getElementById(\'top_menu_' + menu_item.id + '\').style.backgroundPosition=\'0px -50px\';" onMouseOut="document.getElementById(\'top_menu_' + menu_item.id + '\').style.backgroundPosition=\'0px 0px\';"><a><span id="top_menu_' + menu_item.id  + '" class="top_menu_icon" style="background-image:url(\'includes/home_ui/images/menu_icons/' + menu_item.menu_key + '.png\');"></span>' + menu_item.text + '</a></li>';

		document.getElementById("top_menu_page_" + menu_page).innerHTML += menu_html;

		if (i == 0){
			//current_menu_width += document.getElementById('top_menu_my_fav_menu_li').offsetWidth;
		}
		else
			current_menu_width += document.getElementById('top_menu_' + menu_item.menu_key).offsetWidth;

		if (current_menu_width >= total_menu_width){
			document.getElementById("top_menu_page_" + menu_page).removeChild(document.getElementById('top_menu_' + menu_item.menu_key));
			break;
		}
		
	}
	// extreme case: window is too small to insert menu, hide the paging button;
	if (current_i == i)
	{
		document.getElementById("top_menu_page_0").style.display = "none";
		document.getElementById("menu_paging_button").style.display = "none";
		break;
	}

	// show first menu page at start
	if (menu_page > 0)
	{
		document.getElementById("top_menu_page_" + menu_page).style.display = "none";
	}
	
}
	// don't show the paging button if there is only 1 page
	if (menu_page <= 1)
		document.getElementById("menu_paging_button").style.display = "none";

	// show the first page with some animation
	if (menu_page > 0)
	{
		document.getElementById("top_menu_page_0").style.display = "none";
		$("#top_menu_page_0").fadeIn("10000");
	}

	//hide my favorite function at the top menu, only to show it at the left hand menu.
	document.getElementById("top_menu_my_fav_menu_li").style.display = "none";

//top menu paging button
window.showNextMenuPage = function ()
{
	

	// take care of extreme case
	if (menu_page <= 0)
		return;

        
	document.getElementById("top_menu_page_" + current_page).style.display = "none";
	current_page ++;
	if (current_page >= menu_page)
		current_page = 0;
	$("#top_menu_page_" + current_page).fadeToggle();
	

}







//insert languages
var cur_lang = "";
var lang_html = "";
for(var i=0;i<laungeData.sysLanguages.data.length;i++){
	cur_lang = laungeData.sysLanguages.data[i];
	lang_html = '<a href="javascript:doChangeLanguage(' + cur_lang.lang_id + ",'" + cur_lang.locale + '\');"><li><span class="lang_icon" style="background-image:url(includes/home_ui/images/lang_icons/' + cur_lang.lang_id + '.png);"></span>' + cur_lang.localname + '</li></a>';
	document.getElementById("top_menu_choose_lang_ul").innerHTML = document.getElementById("top_menu_choose_lang_ul").innerHTML + lang_html;
}


//insert roles
var cur_role = "";
var role_html = "";
var selected_role_icon = '';
for(var i=0;i<roleData.sysRoles.data.length;i++){
	cur_role = roleData.sysRoles.data[i];
	/*
	if(current_role == cur_role.role_name){
		selected_role_icon = 'includes/home_ui/images/role_icons/' + cur_role.role_name + '.png';
	}
	else{
		selected_role_icon = '';
	}
	*/
	selected_role_icon = 'includes/home_ui/images/role_icons/' + cur_role.role_name + '.png';
	role_html = '<a href="javascript:doChangeRole(\'' + cur_role.role_name + '\')"><li><span class="Chineses_icon" style="background-image:url(\''+selected_role_icon+'\');"></span><div style=" width:160px;overflow:hidden; text-overflow:ellipsis;white-space:nowrap;">' + cur_role.role_name + '</div></li></a>';
	document.getElementById("top_menu_change_role_detail").innerHTML = document.getElementById("top_menu_change_role_detail").innerHTML + role_html;
}



//insert delegate roles

if (typeof(delegateRoleData) != 'undefined'){
	window.changeToDelegateRole = function (agent_user_id,agent_role,agent_name)
	{
		window.location = "index.cfm?event=hrms.doChangeDelegateRole&agent_user_id=" + agent_user_id + "&agent_role=" + agent_role + "&agent_name=" + agent_name;
	}


	// if we are in delegation mode
	if (applicationObj.current_delegate_role != 'none'){
		document.getElementById('top_menu_change_role_outer').style.display = "none";
		document.getElementById('top_menu_change_role_outer').style.visibility = "hidden";
		document.getElementById('Stroke').style.paddingTop = "0px";
		if(Ext.get("top_menu_username")){
			Ext.get("top_menu_username").update(getResource("delegate_mode","home"));
		}
		if(Ext.get("top_menu_rolename")){
			Ext.get("top_menu_rolename").update('(' + applicationObj.current_delegate_role + ')');
		}
	}

	// hide delegate div if there isn't one assigned to the user
	else{
		if (delegateRoleData.sysDelegateRoles.data.length <= 1)
		{
			document.getElementById('top_menu_change_delegate_role_outer').style.display = "none";
			document.getElementById('top_menu_change_delegate_role_outer').style.visibility = "hidden";
		}
	}

	var cur_dele_role = "";
	var dele_role_html = "";
	for(var i=0;i<delegateRoleData.sysDelegateRoles.data.length;i++){
		cur_dele_role = delegateRoleData.sysDelegateRoles.data[i];
		if (i == 0 && applicationObj.current_delegate_role != 'none'){
			selected_role_icon = '';
			var cancel_delegate_text = getResource("cancel_delegate_text","home");
			dele_role_html = '<a href="javascript:changeToDelegateRole(\'' + cur_dele_role.agent_user_id + '\',\'' + cur_dele_role.agent_role + '\',\'' + cur_dele_role.agent_name + '\')"><li><span class="Chineses_icon" style="background-image:url(\'' + selected_role_icon + '\');"></span><div style=" width:160px;overflow:hidden; text-overflow:ellipsis;white-space:nowrap;">' + cancel_delegate_text + '</div></li></a>';
			document.getElementById("top_menu_change_delegate_role_detail").innerHTML = document.getElementById("top_menu_change_delegate_role_detail").innerHTML + dele_role_html;
		}

		else if (i > 0) {
			selected_role_icon = 'includes/home_ui/images/role_icons/' + cur_dele_role.agent_role + '.png';
			dele_role_html = '<a href="javascript:changeToDelegateRole(\'' + cur_dele_role.agent_user_id + '\',\'' + cur_dele_role.agent_role + '\',\'' + cur_dele_role.agent_name + '\')"><li><span class="Chineses_icon" style="background-image:url(\'' + selected_role_icon + '\');"></span><div style=" width:160px;overflow:hidden; text-overflow:ellipsis;white-space:nowrap;">' + cur_dele_role.agent_name + ' (' + cur_dele_role.agent_role + ')' + '</div></li></a>';
			document.getElementById("top_menu_change_delegate_role_detail").innerHTML = document.getElementById("top_menu_change_delegate_role_detail").innerHTML + dele_role_html;
		}
	}
}
else{
	document.getElementById('top_menu_change_delegate_role_outer').style.display = "none";
	document.getElementById('top_menu_change_delegate_role_outer').style.visibility = "hidden";
}




// add a new menu filter tree
if (typeof(Ext.getCmp('top_menu_search_id')) == 'undefined') {
	var temp_menu_search_tree = new Ext.tree.TreePanel({
		id: "top_menu_search_id",
		collapsed: true,
		hidden: false,
		title: getResource('top_menu_search_id', 'home'),
		lines: false,
		split: true,
		collapsible: true,
		collapseMode: "mini",
		rootVisible: false,
		autoScroll: true,
		border: false,
		enableDD: false,
		root: {
			id: "top_menu_search_root",
			text: 'top_menu_search_root',
			expanded: true,
			children: [
			]
		},
		listeners: {
			'click': function(node) {

				if (validateDataFlag == 1) {
					Ext.Msg.confirm(getResource('confirm_title', ''), getResource('confirm_msg', 'confirm_modify_data'), function(_btn) {
						if (_btn == "no") {
							return false;
						} else {
							validateDataFlag = 0;
							clickSysMenu(node.attributes.menu_key);
						}
					})
				} else {
					clickSysMenu(node.attributes.menu_key);
				}

			}
		}

	});
	Ext.getCmp('menu_panel_west_id').add(temp_menu_search_tree);
	Ext.getCmp('menu_panel_west_id').doLayout();

}
Ext.getCmp("top_menu_search_id").on("click",toggle_fav_menu_button,this);

//do filter function
function doFilter(t){
	var cur_search_text = Ext.getCmp("filter_menu_treepanel_id").getValue();
	Ext.getCmp('top_menu_search_id').getRootNode().removeAll();

	if (cur_search_text == ""){
		return;
	}

	var temp_menu_obj;
	for (var key in menuDataLib) {
		temp_menu_obj = menuDataLib[key];
		if (temp_menu_obj.text.indexOf(cur_search_text) > -1 && temp_menu_obj.hasOwnProperty('leaf')){
			Ext.getCmp('top_menu_search_id').getRootNode().appendChild({id:temp_menu_obj.id, menu_key:temp_menu_obj.menu_key, text:temp_menu_obj.text, leaf:true});
		}

	}

	Ext.getCmp('top_menu_search_id').getRootNode().eachChild(function(childnode) {
		if (childnode.getUI().getIconEl().previousSibling.src.indexOf('/s.gif') > -1){
			childnode.getUI().getIconEl().previousSibling.style.visibility = "hidden";
			childnode.getUI().getIconEl().previousSibling.onerror = function () {
				childnode.getUI().getIconEl().previousSibling.src = "includes/home_ui/images/menu_icons/child/" + "default_icon.png";
				childnode.getUI().getIconEl().previousSibling.style.visibility = "visible";
			};
			childnode.getUI().getIconEl().previousSibling.onload = function () {
				childnode.getUI().getIconEl().previousSibling.style.visibility = "visible";
			};
			childnode.getUI().getIconEl().previousSibling.src = "includes/home_ui/images/menu_icons/child/" + childnode.attributes.menu_key + ".png";
			}
	});

	essShowMenu(-1);

	
}

//update menu filter function
Ext.getCmp("filter_menu_treepanel_id").purgeListeners();
Ext.getCmp("filter_menu_treepanel_id").on("keyup", doFilter ,this);




Ext.getCmp('menu_panel_west_id_bbar').show();
//hide the previous and next button of the left hand menu
Ext.get("previous_moudle_id").hide();
Ext.get("next_moudle_id").hide();

//add 4 icons to the bottom of the menu
var menuTbar = Ext.getCmp("previous_moudle_id").findParentByType("toolbar");
menuTbar.insertButton( 0, 
{
	id: 'menuMyMessageBtn',
	xtype: 'tbbutton',
	icon: "includes/home_ui/images/ico01.png",
	tooltip:getResource('user_information_mbtn',''),//aven add 20150724
	tooltipType:'title',
	width: 59,
	listeners: {
	    	'click':function(c,r){
	    		clickSysMenu('user_information');
	    	}
	}
}
);
menuTbar.insertButton( 1, 
{
	id: 'menuChangePassordBtn',
	xtype: 'tbbutton',
	icon: "includes/home_ui/images/ico02.png",
	tooltip:getResource('my_modifypwd_mbtn',''),
	tooltipType:'title',
	width: 59,
	listeners: {
	    	'click':function(c,r){
	    		dynModifyPwd();
	    	}
	}
}
);
menuTbar.insertButton( 2, 
{
	id: 'menuAddFavMenuBtn',
	xtype: 'tbbutton',
	icon: "includes/home_ui/images/ico03.png",
	tooltip:getResource('add_to_my_favorite_mbtn',''),
	tooltipType:'title',
	width: 60,
	listeners: {
	    	'click':function(c,r){
	    		add_or_del_my_fav_menu();
	    	}
	}
}
);
menuTbar.insertButton( 3, 
{
	id: 'menuOpenFavMenuBtn',
	xtype: 'tbbutton',
	//icon: "includes/home_ui/images/ico04.png",
	icon: "includes/home_ui/images/Heart.png",
	tooltip:getResource('my_favorite_mbtn',''),
	tooltipType:'title',
	width: 60,
	listeners: {
	    	'click':function(c,r){
	    		essShowMenu(0);
	    	}
	}
}
);



//add menu icon to the left hand menu
var curModule;
var curModuleData;
var curModuleDataMenuKey;
for(var i = 0;i<menuData.sysMenus.length;i++){
	if(Ext.getCmp("treepanel_"+menuData.sysMenus[i].module_id+"_id")){
		curModule = menuData.sysMenus[i];
		curModuleData = Ext.util.JSON.decode(menuData.sysMenus[i].module_data);
		curModuleDataMenuKey = curModuleData[0].menu_key;
		Ext.getCmp('treepanel_' + curModule.module_id + '_id').getEl().dom.childNodes[0].style.background  = "transparent repeat-x 0 0px";
		Ext.getCmp('treepanel_' + curModule.module_id + '_id').getEl().dom.childNodes[0].style.backgroundImage  = "url('includes/home_ui/images/menu_icons/" + curModuleDataMenuKey + ".png')";
		Ext.getCmp('treepanel_' + curModule.module_id + '_id').getEl().dom.childNodes[0].style.backgroundRepeat  = "no-repeat";
		Ext.getCmp('treepanel_' + curModule.module_id + '_id').getEl().dom.childNodes[0].style.paddingLeft  = "40px";
		Ext.getCmp('treepanel_' + curModule.module_id + '_id').getEl().dom.childNodes[0].style.backgroundPosition  = "0px -105px";
	}
}
Ext.getCmp('my_fav_menu_id').getEl().dom.childNodes[0].style.background  = "transparent repeat-x 0 0px";
Ext.getCmp('my_fav_menu_id').getEl().dom.childNodes[0].style.backgroundImage  = "url('includes/home_ui/images/menu_icons/my_fav_menu.png')";
Ext.getCmp('my_fav_menu_id').getEl().dom.childNodes[0].style.backgroundRepeat  = "no-repeat";
Ext.getCmp('my_fav_menu_id').getEl().dom.childNodes[0].style.paddingLeft  = "40px";
Ext.getCmp('my_fav_menu_id').getEl().dom.childNodes[0].style.backgroundPosition  = "0px -105px";














for(var i = 1;i<menuData.sysMenus.length;i++){
        Ext.getCmp("treepanel_"+menuData.sysMenus[i].module_id+"_id").getRootNode().cascade(function(childnode) {
		if (childnode.isLeaf()){
			
			if (childnode.getUI().getIconEl().previousSibling.src.indexOf('/s.gif') > -1){
				childnode.getUI().getIconEl().previousSibling.style.visibility = "hidden";
				//childnode.getUI().getIconEl().previousSibling.style.marginLeft = "10px";
				childnode.getUI().getIconEl().previousSibling.onerror = function () {
                			childnode.getUI().getIconEl().previousSibling.src = "includes/home_ui/images/menu_icons/child/" + "default_icon.png";
					childnode.getUI().getIconEl().previousSibling.style.visibility = "visible";
        			};
				childnode.getUI().getIconEl().previousSibling.onload = function () {
					childnode.getUI().getIconEl().previousSibling.style.visibility = "visible";
        			};
				childnode.getUI().getIconEl().previousSibling.style.backgroundRepeat="round";
				childnode.getUI().getIconEl().previousSibling.style.backgroundImage="url('includes/home_ui/images/menu_icons/child/" + childnode.attributes.menu_key + ".png')";
				//childnode.getUI().getIconEl().previousSibling.src = "includes/home_ui/images/menu_icons/child/" + childnode.attributes.menu_key + ".png";

			}
		}
        });

}

for(var i = 1;i<menuData.sysMenus.length;i++){
	Ext.getCmp("treepanel_"+menuData.sysMenus[i].module_id+"_id").on("expandnode",function(node){
        	node.eachChild(function(childnode) {
			if (childnode.isLeaf()){
				if (childnode.getUI().getIconEl().previousSibling.src.indexOf('/s.gif') > -1){
					childnode.getUI().getIconEl().previousSibling.style.visibility = "hidden";
					//childnode.getUI().getIconEl().previousSibling.style.marginLeft = "10px";
					childnode.getUI().getIconEl().previousSibling.onerror = function () {
	                			childnode.getUI().getIconEl().previousSibling.src = "includes/home_ui/images/menu_icons/child/" + "default_icon.png";
						childnode.getUI().getIconEl().previousSibling.style.visibility = "visible";
	        			};
					childnode.getUI().getIconEl().previousSibling.onload = function () {
						childnode.getUI().getIconEl().previousSibling.style.visibility = "visible";
        				};
					childnode.getUI().getIconEl().previousSibling.src = "includes/home_ui/images/menu_icons/child/" + childnode.attributes.menu_key + ".png";

					
				}
			}
        	});
	},this);
}


//show first menu
//essShowMenu(1);
showCurrentSessionMenu();

function showCurrentSessionMenu(){
	for(var i = 0;i<menuData.sysMenus.length;i++){
		if (menuData.sysMenus[i].module_data.indexOf("menu_key:'" + current_click_menu_key + "'") != -1){
			showCurrentSessionMenuState = 1;
			essShowMenu(i);
			showCurrentSessionMenuState = 0;
			for(var j = 0;j<menu_page;j++){
				if (document.getElementById("top_menu_page_" + j).innerHTML.indexOf('menu_seq="' + i + '"') != -1){
					document.getElementById("top_menu_page_" + j).style.display = "block";
					current_page = j;
				}
				else{
					document.getElementById("top_menu_page_" + j).style.display = "none";
				}
			}
			return;
		}
	}
	showCurrentSessionMenuState = 1;
	essShowMenu(1);
	showCurrentSessionMenuState = 0;
	
}




if (menu_collapse_at_startup == "1"){
	doMenuMinimize();
}



// show the page when it's finished loading
$("#hideAll").fadeToggle();



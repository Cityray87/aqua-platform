/**
 * searchpanel �齨
 * 
 * ��������б�
 * 1 panel_name				----string		
 * 2 panel_type             ----string  ��δ����
 * 3 simple_search_field    ----json    ��ʽ�磺[['employee_id','employee_id','NUMBERFIELD','employee_id','=']..]
 * 			1)pkey 	---combobox valueField
 * 			2)pvalue ---combobox displayField
 * 			3)field type ---combobox ���� 	
 * 			4)default_search_field   --Ĭ��������
 * 			5)default_search_operator --Ĭ��������
 * 4 simple_search_operator ----json    ��ʽ�磺[['=','Equal']..]
 * 
 * 
 * 
 * ʹ�÷�����
 * 		new searchpanel(_data); ---_data��ʾ����Ĳ����б�(json)
 */
 
SimpleSearchPanel = Ext.extend(Ext.form.FormPanel, {
	ss_field_store:null,
	ss_operator_store:null,
	ss_querysql:null,
	str_test:null,
	searchObject:null,
	fieldDataJsonArray:null,
	fieldDataArray:null,
	criFieldArray:null,
	height:18,
	constructor:function(_cfg) {
		//��������
		if(_cfg == null)_cfg={};
		Ext.apply(this, _cfg);
		this.searchObject = this;
		this.searchObject._cfg = _cfg;
		this.fieldDataJsonArray = new Array();
		this.fieldDataArray = new Array();
		var tempArray;
		if(Ext.getCmp(this.searchObject.panel_name+"_simple_search_panel_id")){
			Ext.getCmp(this.searchObject.panel_name+"_simple_search_panel_id").destroy();
		}

		this.ss_field_store = new Ext.data.ArrayStore({
			fields:[
			        {name:"pkey", type:"string"},
			        {name:"pvalue", type:"string"},
			        {name: 'fieldType', type: 'string'},
			        {name:"default_search_field", type:"string"},
			        {name:"default_search_operator", type:"string"},
			        {name:"is_need_search_all", type:"string"},
			        {name:"url", type:"string"}
			        ],
			data:Ext.decode(this.simple_search_field)
		});

		this.ss_operator_store = new Ext.data.ArrayStore({
			fields:[
			        {name:"pkey", type:"string"},
			        {name:"pvalue", type:"string"}
			        ],
			 data:Ext.decode(this.simple_search_operator)      
		});
		
		if(this.criFieldList.length > 0){
			this.criFieldArray = this.criFieldList.split(')~~~(');
		}
		if(this.fieldDataList.length > 0){
			this.fieldDataJsonArray = this.fieldDataList.split(')~~~(');
		}
		if(this.fieldDataJsonArray!=null){
			for (i=0;i < this.fieldDataJsonArray.length;i++){
				tempArray = new Array();
				decodedFieldData = Ext.decode(this.fieldDataJsonArray[i]);
				for (j=0;j < decodedFieldData.data.length; j++){
					tempArray[j] = new Array();
					tempArray[j][0] = decodedFieldData.data[j]['pkey'];
					tempArray[j][1] = decodedFieldData.data[j]['pvalue'];
				}
				this.fieldDataArray[i] = tempArray;
			}
		}
		
		this.searchObject.ss_operator_store = this.ss_operator_store;
		this.searchObject.ss_field_store = this.ss_field_store;
		
		
		SimpleSearchPanel.superclass.constructor.call(this, {
			id:this.searchObject.panel_name+"_simple_search_panel_id",
			bodyStyle: "padding: 1px 0px 0px 0px; background:#D3E1F1",
			border: false,
			labelAlign: "right",
			height:22,
			items:[{
				width:600,
				bodyStyle: "background:#D3E1F1",
				border: false,
				layout: "column",
				items:[{
					   bodyStyle: "padding-left:0px; background:#D3E1F1",
			    	   columnWidth:0.2,
			    	   labelWidth: 1,
			    	   border:false,
			    	   layout:"anchor",
			    	   items:[
			    	          new Ext.form.ComboBox({
					    		   bodyStyle: "padding-top:1px; background:#D3E1F1",
					    		   anchor:"96%",
					    		   border:false,
					    		   editable:false,
					    		   xtype:"combo",
					    		   mode:"local",
					    		   triggerAction:"all",
					    		   store:this.ss_field_store,
					    		   displayField:"pvalue",
					    		   valueField:"pkey",
					    		   tpl: '<tpl for="."><div x-combo-list-item :qtip="{url}" class="x-combo-list-item"><img src="{url}">&nbsp;{pvalue}</div></tpl>',
					    		   listeners:{
					    			   "select": {
					    				   fn:function(combo, record, index){
					    					    var _ss_panel = Ext.getCmp(this.searchObject.panel_name+"_simple_search_panel_id");
					    						var _ss_field =_ss_panel.items.items[0].items.items[0].items.items[0]; 
					    						var _ss_operator =_ss_panel.items.items[0].items.items[1].items.items[0]; 
					    						var _ss_value =_ss_panel.items.items[0].items.items[2].items.items[0]; 
					    						
												if(_ss_field.store.getAt(0).data.default_search_field!=""&&
														_ss_field.store.getAt(0).data.default_search_field==combo.getValue()&&
														_ss_field.store.getAt(0).data.default_search_operator!=""){
													_ss_operator.setValue(_ss_field.store.getAt(0).data.default_search_operator);
												}else{
													_ss_operator.setValue(this.searchObject.ss_operator_store.getAt(0).get('pkey'));
												}
												if(combo.getValue() == "blur_search") {
													_ss_operator.setDisabled(true);
												}else {
													_ss_operator.setDisabled(false);
												}
												this.searchObject.replaceValueField();
												this.searchObject.keyUpAction(this);
											}
					    			   },
					    			   "render":function(_cmp) {
					    				   if(this.ss_field_store.getCount()>0) {
					    					   var is_need_search_all = this.ss_field_store.getAt(0).get("is_need_search_all");
					    					   if(is_need_search_all == 1) {
					    						   var _store = _cmp.getStore();
							    				   var _record = new Ext.data.Record(["pkey" , "pvalue", "fieldType", "default_search_field", "default_search_operator"]);
							    				   _record.set("pkey" ,"blur_search") ;
							    				   _record.set("pvalue" ,getResource("search_all", this.searchObject.panel_name)) ;
							    				   _record.set("fieldType" ,"TEXT") ;
							    				   _record.set("default_search_field" ,"blur_search") ;
							    				   _record.set("default_search_operator" ,"") ;
							    				   _record.set("is_need_search_all" ,"1") ;
							    				   _record.set("url" ,"../ext/resources/images/icons/zoom.png") ;
							    				   _store.insert(0,_record);
					    					   }					
					    				   }
					    			   },
					    			   scope:this
					    		   }
					    	   })
			    	          ]
			       },{
			    	   bodyStyle: "padding-left: 0px;background:#D3E1F1",
			    	   border:false,
			    	   labelWidth: 1,
			    	   columnWidth:0.2,
			    	   handler:{
			    		   fn:function(){
			    			   this.keyUpAction(this);
			    		   }
			    	   },
			    	   layout:"anchor",
			    	   items:[
			    	          new Ext.form.ComboBox({
					    		   bodyStyle: "padding-top:0px;padding-left:0px; background:#D3E1F1",
					    		   anchor:"95%",
					    		   border:false,
					    		   editable:false,
					    		   xtype:"combo",
					    		   mode:"local",
					    		   triggerAction:"all",
					    		   store:this.ss_operator_store,
					    		   displayField:"pvalue",
					    		   valueField:"pkey",
					    		   listeners:{
					    			   "select": {
					    				   fn:function(){
					    					   this.keyUpAction(this);
					    				   }
					    			   },
					    			   scope:this
					    		   }
			    	          })
			    	   ]
			       },{
			    	   bodyStyle: "background:#D3E1F1;padding-right:0px",
			    	   border:false,
			    	   labelWidth: 1,
			    	   columnWidth:0.23,
			    	   layout:"anchor",
			    	   items:[
			  				new Ext.form.TextField({
			  					id: this.searchObject.panel_name+"_simple_value",
								name: "value",
								selectOnFocus: true,
								anchor:"95%"
							})
			    	          ]
			       },{
			    	   bodyStyle: "background:#D3E1F1",
			    	   border:false,
			    	   columnWidth:0.1,
			    	   layout:"anchor",
			    	   items:[
			    	          new Ext.Button({
			    	        	  text:getResource('search','searchPanel'),
			    	        	  type:"submit",
			    	        	  anchor:"99%",
			    	        	  icon: "../ext/resources/images/icons/zoom.png",
			    	        	  cls: "x-btn-text-icon",
			    	        	  bodyStyle: "background:#D3E1F1;",
			    	        	  handler:this.searchAction,
			    	        	  scope:this
			    	          })
			    	          ]
			       },{
			    	   bodyStyle: "background:#D3E1F1;padding-top:0px;",
			    	   border:false,
			    	   columnWidth:0.1,
			    	   layout:"anchor",
			    	   items:[
			    	          new Ext.Button({
			    	        	  text:getResource('clear','searchPanel'),
			    	        	  type:"submit",
			    	        	  anchor:"98%",
			    	        	  icon: "../ext/resources/images/icons/clear.png",
			    	        	  bodyStyle: "background:#D3E1F1;",
			    	        	  cls: "x-btn-text-icon",
			    	        	  handler:this.clearAction,
			    	        	  scope:this
			    	          })
			    	          ]
			       }]
			}],
			
			 listeners:{
				 "afterrender":this.setDefaultSearchField,
  			   	 scope:this
			 }   
		});
	},
	
	//���TriggerField��ʱ�򵯳�����
	triggerClickAction:function (_p,id) {
		var field_id = id;
		var fieldname = Ext.getCmp(_p.searchObject.panel_name+"_simple_search_panel_id").items.items[0].items.items[0].items.items[0].getValue();
		
		if(typeof(Ext.getCmp("picklist_"+_p.searchObject.panel_name+"_"+fieldname))!="undefined"){
			Ext.getCmp("picklist_"+_p.searchObject.panel_name+"_"+fieldname).show();
		}else{
			var jsFile = "views/dynamicGenerateScript/picklist_"+_p.searchObject.panel_name+"_"+fieldname+".js";
			myLoader.require(jsFile,function(){
				var popupString = "var win = new picklist_"+_p.searchObject.panel_name+"_"+fieldname+"({paramList:{cid:'"+field_id+"',fname:'"+fieldname+"',pname:'"+_p.searchObject.panel_name+"',sourcePage:'searchPanel',needDelimiter:0}}).show();";
				eval(popupString);				
			},this,true);
		}
		return false;
	},
	triggerTreeAction:function(_p,id){
		var field_id = id;
		var fieldname = Ext.getCmp(_p.searchObject.panel_name+"_simple_search_panel_id").items.items[0].items.items[0].items.items[0].getValue();
		
		if(typeof(Ext.getCmp("picklist_"+_p.searchObject.panel_name+"_"+fieldname))!="undefined"){
			Ext.getCmp("picklist_"+_p.searchObject.panel_name+"_"+fieldname).show();
		}else{
			var jsFile = "views/dynamicGenerateScript/picklist_"+_p.searchObject.panel_name+"_"+fieldname+".js";
			myLoader.require(jsFile,function(){
				var popupString = "var win = new picklist_"+_p.searchObject.panel_name+"_"+fieldname+"({paramList:{cid:'"+field_id+"',fname:'"+fieldname+"',pname:'"+_p.searchObject.panel_name+"',sourcePage:'searchPanel',needDelimiter:0}}).show();";
				eval(popupString);				
			},this,true);
		}
		return false;
	},
	
	keyUpAction:function(_p){//����ѡ���¼�
		var _ss_panel = Ext.getCmp(_p.searchObject.panel_name+"_simple_search_panel_id");
		var _field = _ss_panel.items.items[0].items.items[0].items.items[0].getValue();
		var _operator = _ss_panel.items.items[0].items.items[1].items.items[0].getValue();
		var _value = "";
		var _field_store = _ss_panel.items.items[0].items.items[0].items.items[0].getStore();
		var _fieldType = _field_store.query('pkey', _field).get(0).get('fieldType');
		if(_fieldType.toLowerCase()=='datefield'){
			if(_ss_panel.items.items[0].items.items[2].items.items[0].value != undefined) {
				_value = _ss_panel.items.items[0].items.items[2].items.items[0].value;
			}
		}else {
			_value = _ss_panel.items.items[0].items.items[2].items.items[0].getValue();
		}
		_value = ""+_value;
		_value = _value.replace(/\"/g, "~char(34)~"); 
		_value = _value.replace(/\&/g, "~char(38)~");  
		_value = _value.replace(/\|/g, "~char(124)~");  
		if(_field!=""&&_operator!=""){
			if(_operator.toLowerCase() == "like"){
				if(_fieldType.toLowerCase()=='datefield'){
					_p.searchObject.querySql = " && [" + _field + "] = " + '"' + _value + '"'; 
				}else{
					_p.searchObject.querySql = " && [" + _field + "] like " + '"%' + _value + '%"'; 
				}
			}else{
				_p.searchObject.querySql = " && [" + _field + "] " + _operator + ' "' + _value +'"';
			}
		}
	}, 
	searchAllAction:function(_p) {
		var _ss_panel = Ext.getCmp(_p.searchObject.panel_name+"_simple_search_panel_id");
		var _field = _ss_panel.items.items[0].items.items[0].items.items[0].getValue();
		var _operator = _ss_panel.items.items[0].items.items[1].items.items[0].getValue();
		var _value = "";
		var _valueArray = [];
		
		var _field_store = _ss_panel.items.items[0].items.items[0].items.items[0].getStore();
		var _fieldType = _field_store.query('pkey', _field).get(0).get('fieldType');
		if(_fieldType.toLowerCase()=='datefield'){
			if(_ss_panel.items.items[0].items.items[2].items.items[0].value != undefined) {
				_value = _ss_panel.items.items[0].items.items[2].items.items[0].value;
			}
		}else {
			_value = _ss_panel.items.items[0].items.items[2].items.items[0].getValue();
		}
		_value = ""+_value;
		_value = _value.replace(/\"/g, "~char(34)~"); 
		_value = _value.replace(/\&/g, "~char(38)~");  
		_value = _value.replace(/\|/g, "~char(124)~");
		_valueArray = _value.split("+");
		var _sql_where = " || (";
		if(_field!=""&&_operator!=""){
			for(var m=0;m<_valueArray.length;m++){
				if (m==0){
					_sql_where=_sql_where+" (";
				}else{
					_sql_where=_sql_where+" && (";
				}
				for(var i=0;i<_field_store.getCount();i++) {
					var _key = _field_store.getAt(i).get("pkey");
					var _keyType = _field_store.getAt(i).get("fieldType");
					if(_key != "blur_search"){
						if(i==0) {
							if(_keyType.toLowerCase() != 'datefield'){
								_sql_where = _sql_where+ " where ["+_key+'] like "%'+ Ext.util.Format.trim(_valueArray[m])+'%"';
							}
						}else {
							if(_keyType.toLowerCase() != 'datefield'){
								_sql_where = _sql_where+ " ["+_key+'] like "%'+ Ext.util.Format.trim(_valueArray[m])+'%"';
							}
						}
					}
					if(i>=1&&(i<_field_store.getCount()-1)&&(_keyType.toLowerCase() != 'datefield')){
						_sql_where=_sql_where+" || ";
					}
				}
				if(Ext.util.Format.trim(_sql_where.substring(_sql_where.length-3,_sql_where.length)) == '||'){
					_sql_where = _sql_where.substring(0,_sql_where.length-3);
				}
				_sql_where=_sql_where+")";
			}
		}
		_sql_where=_sql_where+")";
		if(Ext.util.Format.trim(_sql_where) =="|| ( ())"){
			_sql_where = " "
		}
		return _sql_where;
	},
	getIndexByCriFieldId:function(CriFieldId){
		for (i=0;i<this.criFieldArray.length;i++){
			if (this.criFieldArray[i] == CriFieldId){
				return i;
			}
		}
	},
	searchAction:function() {
		this.searchObject.keyUpAction(this);
		var isvalid = Ext.getCmp(this.searchObject.panel_name+"_simple_search_panel_id").getForm().isValid();
		if(!isvalid){
			Ext.MessageBox.alert(getResource('Error','searchPanel'),getResource('Correct_Form_Errors_Message','searchPanel'));
			return;
		}
		var _sql="";
		var _cmp = Ext.getCmp(this.searchObject.panel_name+"_simplepanel_criteriadata_combo");
		if(typeof(_cmp)!="undefined") {
			var _value = Ext.util.Format.htmlDecode(_cmp.getValue());
			if(_value.replace(/(^\s*)|(\s*$)/g, "") != "") {
				_sql = " && "+_value;
			}
		} 
		if(typeof(this.searchObject.querySql)!="undefined" && this.searchObject.querySql!='') {
		}else {
			this.searchObject.querySql = "";
		}
		var _field_name = Ext.getCmp(this.searchObject.panel_name+"_simple_search_panel_id").items.items[0].items.items[0].items.items[0];
		if(_field_name.getValue() != "blur_search") {
			if(typeof(this.searchObject.panel_type)!="undefined"&&this.searchObject.panel_type.toLowerCase()=="treegridpanel"){
				Ext.getCmp(this.searchObject.panel_name).getLoader().baseParams.sql_where= this.searchObject.querySql+_sql;
				Ext.getCmp(this.searchObject.panel_name).getLoader().load_type='search';
				Ext.getCmp(this.searchObject.panel_name).getRootNode().reload();
			}else{
				Ext.getCmp(this.searchObject.panel_name).store.setBaseParam('sql_where', this.searchObject.querySql+_sql);
				Ext.getCmp(this.searchObject.panel_name).store.load();
			}
		}else {
			var _sql_where = this.searchAllAction(this);
			if(typeof(this.searchObject.panel_type)!="undefined"&&this.searchObject.panel_type.toLowerCase()=="treegridpanel"){
				Ext.getCmp(this.searchObject.panel_name).getLoader().baseParams.sql_where= _sql_where+_sql;
				Ext.getCmp(this.searchObject.panel_name).getLoader().load_type='search';
				Ext.getCmp(this.searchObject.panel_name).getRootNode().reload();
			}else{
				Ext.getCmp(this.searchObject.panel_name).store.setBaseParam('sql_where', _sql_where+_sql);
				Ext.getCmp(this.searchObject.panel_name).store.load();
			}
		}
		
	},
	clearAction:function() {
		this.keyUpAction(this);
		_ss_panel=Ext.getCmp(this.searchObject.panel_name+"_simple_search_panel_id");
		_ss_panel.items.items[0].items.items[0].items.items[0].clearValue();
		_ss_panel.items.items[0].items.items[1].items.items[0].clearValue();
			
		if(typeof(Ext.getCmp(this.searchObject.panel_name+"_simplepanel_criteriadata_combo"))!="undefined") {
			Ext.getCmp(this.searchObject.panel_name+"_simplepanel_criteriadata_combo").clearValue();
		}
		var cf = new Ext.form.TextField({
			name: 'value',
			anchor: "95%"
		});
		this.searchObject.querySql = " ";
		_ss_panel.items.items[0].items.items[2].remove(_ss_panel.items.items[0].items.items[2].items.items[0],true);
	
		_ss_panel.items.items[0].items.items[2].insert(0,cf);
		_ss_panel.items.items[0].items.items[2].render(this.searchObject.panel_name+"_simple_search_panel_id");
		_ss_panel.items.items[0].items.items[2].doLayout();
		_ss_panel.render(this.searchObject.panel_name+"_simple_search_panel_id");
		_ss_panel.items.items[0].items.items[1].items.items[0].setDisabled(false);
		_ss_panel.doLayout();
	},
	replaceValueField:function () {
		var _ss_panel = Ext.getCmp(this.searchObject.panel_name+'_simple_search_panel_id');
		var criteriaField = _ss_panel.items.items[0].items.items[0].items.items[0];
		var fieldValue = criteriaField.getValue();
		var fieldType ="";
		var _p=this;
		for(var i=0;i<criteriaField.store.getCount();i++){
			if(criteriaField.store.getAt(i).get("pkey")==fieldValue){
				fieldType=criteriaField.store.getAt(i).get("fieldType");
				break;
			}
		}
		switch(fieldType.toUpperCase()){
			case 'DATEFIELD':
				var cf = new Ext.form.DateField({
					name: 'value',
					anchor:"95%",
					format:web_platform_dateformat,
					enableKeyEvents:true,
					editable:false,
					listeners : {
						'keyUp':{
							fn:function(){
								this.keyUpAction(this);
							}
						},
						'select':{
							fn:function(){
								this.keyUpAction(this);
							}
						},
						'change':{
							fn:function(){
								this.keyUpAction(this);
							}
						},
						scope:this
					}
				});
				break;
			case 'COMBOBOX':
				var cmbJsonStore = new Ext.data.ArrayStore({
					fields: [{name: 'pkey', type: 'string'}, {name: 'pvalue', type: 'string'}],
					data : this.fieldDataArray[this.getIndexByCriFieldId(fieldValue)]
				});

				var cf = new Ext.form.ComboBox({
						hideOnSelect:true,
						maxHeight:150,
						anchor:"95%",
						store:cmbJsonStore,
						triggerAction:'all',
						resizable:true,
						editable:false,
						enableKeyEvents:true,
						labelAlign: 'top',
						valueField:'pkey',
						displayField:'pvalue',
						hiddenName:'value',
						mode:'local',
						beforeBlur:function(){},
						listeners:{
							'keyUp':{
								fn:function(){
									this.keyUpAction(this);
								}
							},
							'select':{
								fn:function(){
									this.keyUpAction(this);
								}
							},
							scope:this
						}
				});
				break;
			case 'NUMBERFIELD':
				var cf = new Ext.form.NumberField({
					name: 'value',
					anchor:"95%",
					enableKeyEvents:true,
					listeners:{
						'keyUp':{
							fn:function(){
								this.keyUpAction(this);
							}
						},
						scope:this
					}
				});
				break;
			case 'TEXT':
				var cf = new Ext.form.TextField({
					name: 'value',
					anchor:"95%",
					enableKeyEvents:true,
					listeners:{
						'keyUp':{
							fn:function(){
								this.keyUpAction(this);
							}
						},
						scope:this
					}
				});
				break;
			case 'BIT':
				var bitStore = new Ext.data.ArrayStore({
					fields: [
						{name: 'pvalue', type: 'string'},
						{name: 'pkey', type: 'string'}
					],
					data : [[getResource('yes','searchPanel'),'1'],
						[getResource('no','searchPanel'),'0']]
				});
				var cf = new Ext.form.ComboBox({
					name: 'value',
					store:bitStore,
					anchor:"95%",
					displayField:'pvalue',
					valueField:'pkey',
					hiddenName:'value',
					editable:false,
					triggerAction:'all',
					mode:'local',
					forceSelection:true,
					resizable:true,
					enableKeyEvents:true,
					typeAhead:true,
					value:'1',	
					listeners:{
						'keyUp':{
							fn:function(){
								this.keyUpAction(this);
							}
						},
						'select':{
							fn:function(){
								this.keyUpAction(this);
							}
						},
						scope:this
					}
				});
				break;
			case 'TIMEFIELD':
				var cf = new Ext.form.TimeField({
					name: 'value',
					format: "H:i",
					anchor:"95%",
					increment: 5,
					readOnly: false,
					enableKeyEvents:true,
					listeners:{
						'keyUp':{
							fn:function(){
								this.keyUpAction(this);
							}
						},
						'select':{
							fn:function(){
								this.keyUpAction(this);
							}
						},
						'change':{
							fn:function(){
								this.keyUpAction(this);
							}
						},
						scope:this
					}
				});
				break;
			case 'POPUP':
				var cf = new Ext.form.TriggerField({
					name: 'value',
					enableKeyEvents:true,
					triggerClass: 'x-form-search-trigger',
					resizable:true,
					'onTriggerClick': function(){
						_p.triggerClickAction(_p,this.id);
					},	
					listeners:{
						'keyUp':{
							fn:function(){
								this.keyUpAction(this);
							}
						},
						scope:this
					}
				});
				break;
			case 'TREE':
				var cf = new Ext.form.TriggerField({
					name: 'value',
					enableKeyEvents:true,
					triggerClass: 'x-form-search-trigger',
					resizable:true,
					'onTriggerClick': function(){
						_p.triggerTreeAction(_p,this.id);
					},	
					listeners:{
						'keyUp':{
							fn:function(){
								this.keyUpAction(this);
							}
						},
						scope:this
					}
				});
				break;
			default:
				alert(fieldType + ' has not been implemented');
		}
		_ss_panel.items.items[0].items.items[2].remove(_ss_panel.items.items[0].items.items[2].items.items[0],true);
		
		_ss_panel.items.items[0].items.items[2].insert(0,cf);
		_ss_panel.items.items[0].items.items[2].doLayout();
		_ss_panel.render(this.searchObject.panel_name+'_simple_search_panel_id');
		_ss_panel.doLayout();
	},
	
	
	
	setDefaultSearchField:function() {//�״μ��� ��һ������
		var _ss_panel = Ext.getCmp(this.searchObject.panel_name+"_simple_search_panel_id");
		var _field_store = _ss_panel.items.items[0].items.items[0].items.items[0].getStore();
		var _operator_store = _ss_panel.items.items[0].items.items[1].items.items[0].getStore();
		
		
		if(_field_store.getCount()>0 && _field_store.getAt(0).data.default_search_field!=""){
			_ss_panel.items.items[0].items.items[0].items.items[0].setValue(_field_store.getAt(0).data.default_search_field);
			if(_field_store.getAt(0).data.default_search_operator!=""){
				_ss_panel.items.items[0].items.items[1].items.items[0].setValue(_field_store.getAt(0).data.default_search_operator);
			}else{
				_ss_panel.items.items[0].items.items[1].items.items[0].setValue(_operator_store.getAt(0).get('pkey'));
			}
			if(_field_store.getAt(0).data.default_search_field != "blur_search"){
				this.searchObject.replaceValueField();
				this.searchObject.keyUpAction(this);
			}else {
				_ss_panel.items.items[0].items.items[1].items.items[0].setDisabled(true);
			}
			
		}
	}
});
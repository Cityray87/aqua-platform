var position_code = Ext.getCmp("form_add_hr_position_tree_node_position_code_id");
			var position_name = Ext.getCmp("form_add_hr_position_tree_node_position_name_id");
			var DESCRIPTION = Ext.getCmp("form_add_hr_position_tree_node_description_id");
			var dept_id_ = Ext.getCmp("form_add_hr_position_tree_node_dept_id__id");
			var is_manager_pos = Ext.getCmp("form_add_hr_position_tree_node_is_manager_pos_id");
			var action_code = Ext.getCmp("form_add_hr_position_tree_node_action_code_id");
			var reason_code = Ext.getCmp("form_add_hr_position_tree_node_reason_code_id");
			var direct_report_to_pos_desc = Ext.getCmp("form_add_hr_position_tree_node_direct_report_to_pos_desc_id");
			var functional_report_to_pos = Ext.getCmp("form_add_hr_position_tree_node_functional_report_to_pos_id");
			var job_code = Ext.getCmp("form_add_hr_position_tree_node_job_code_id");
			var job_rank = Ext.getCmp("form_add_hr_position_tree_node_job_rank_id");
			var job_grade = Ext.getCmp("form_add_hr_position_tree_node_job_grade_id");
			var work_location = Ext.getCmp("form_add_hr_position_tree_node_work_location_id");
			var cost_center = Ext.getCmp("form_add_hr_position_tree_node_cost_center_id");
			var is_temp_pos = Ext.getCmp("form_add_hr_position_tree_node_is_temp_pos_id");
			var effect_date = Ext.getCmp("form_add_hr_position_tree_node_effect_date_id");
			var effect_date_temp = Ext.getCmp("form_add_hr_position_tree_node_effect_date_temp_id");
			var expired_date = Ext.getCmp("form_add_hr_position_tree_node_expired_date_id");
			var work_form = Ext.getCmp("form_add_hr_position_tree_node_work_form_id");
			var max_headcount = Ext.getCmp("form_add_hr_position_tree_node_max_headcount_id");
			var headcount_is_allow_over = Ext.getCmp("form_add_hr_position_tree_node_headcount_is_allow_over_id");
			var over_headcount = Ext.getCmp("form_add_hr_position_tree_node_over_headcount_id");
			var holiday_policy = Ext.getCmp("form_add_hr_position_tree_node_holiday_policy_id");
			var leave_policy = Ext.getCmp("form_add_hr_position_tree_node_leave_policy_id");
			var medical_policy = Ext.getCmp("form_add_hr_position_tree_node_medical_policy_id");
			var tax_policy = Ext.getCmp("form_add_hr_position_tree_node_tax_policy_id");
			var salary_policy = Ext.getCmp("form_add_hr_position_tree_node_salary_policy_id");
			var pay_band = Ext.getCmp("form_add_hr_position_tree_node_pay_band_id");
			var social_security_policy = Ext.getCmp("form_add_hr_position_tree_node_social_security_policy_id");

			var position_id = Ext.getCmp("form_add_hr_position_tree_node_position_id_id");
			var dept_id = Ext.getCmp("form_add_hr_position_tree_node_dept_id_id");
			var business_unit_key= Ext.getCmp("form_add_hr_position_tree_node_business_unit_key_id");


			var positionAddPanel = new Ext.Panel({     
			border : false,     
			autoHeight : true,     
			layout : "form",     
			items : [{      
				width : 1000,        
				autoHeight : true,         
				layout : "column",        
				items : [{
							   columnWidth : "0.5",           
							   layout : "form",           
							   border : false,           
							   items : [position_code,position_name,DESCRIPTION,dept_id_,is_manager_pos,action_code,
										reason_code,direct_report_to_pos_desc,functional_report_to_pos,job_code,
										job_rank,job_grade,work_location]
						 }, {
							   columnWidth : "0.5",           
							   layout : "form",           
							   border : false,           
							   items : [cost_center,is_temp_pos,effect_date,effect_date_temp,expired_date,work_form,
										max_headcount,headcount_is_allow_over,over_headcount,holiday_policy,leave_policy,
										medical_policy,tax_policy,salary_policy,pay_band,social_security_policy]          
						 }]
				 }]    
			  }); 
			positionAddPanel.doLayout();  
			Ext.getCmp("form_add_hr_position_tree_node_form").add(positionAddPanel);  
			Ext.getCmp("form_add_hr_position_tree_node_form").doLayout();
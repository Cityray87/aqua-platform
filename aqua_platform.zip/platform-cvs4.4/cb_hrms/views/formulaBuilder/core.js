Ext.FormulaBuilder = {};
(function(){
	var win = null;
	var wsp = null;
	var type = "code";
	var baseId =  "FormulaBuilder";
	var o = Ext.FormulaBuilder;
	var nodeId = -1;
	var buildMask = null;
	var cid = 0; //add
	var ptid = 0;
	var dd = null;
	var md = null;
	var ku = true; //keyup Event
	var mn = null;
	var cl = true;
	var mt = "payroll"; //model type;
	var panel_name = "";
	var extraParams = {};
	var imgPath = "../ext";
	Ext.QuickTips.init();
	
	ContextAreaField = Ext.extend(Ext.form.TextArea,{
		constructor:function(cfg){
			cfg = cfg || {};
			Ext.apply(this,cfg);
			ContextAreaField.superclass.constructor.call(this);
		},
		initEvents:function(){
			ContextAreaField.superclass.initEvents.call(this);
			if(this.enableKeyEvents){
	        	this.mon(this.el, 'contextmenu', this.onContextmenu, this,{preventDefault: true});
	        }
		},
		onContextmenu:function(e){
			this.fireEvent('contextmenu', this, e);
		}
	});
	
	Ext.apply(Ext.FormulaBuilder,{
		loadOperators: function(p,cfg){
			Ext.Ajax.request({
				url: "index.cfm?event=formulaBuilder.general.loadOperators&dt_="+new Date().getTime(),
				method: "POST",
				params:Ext.applyIf({
					mt: mt,
					panel_name: panel_name,
					bsid: baseId,
					cid: cid
				},extraParams),
				success:function(response, opts){
					var obj = Ext.decode(response.responseText);
					var qry = obj.data;
					var ct,opr,tx,tip;
					try{
						for(var i=0;i<qry.length;i++){
							opr=qry[i];
							ct=Ext.getCmp(baseId+"_operator_row_"+opr.row);
							if(!ct){
								ct=new Ext.Panel({
									id: baseId+"_operator_row_"+opr.row,
									xtype: "panel",
									border: false,
									layout: "hbox",
									bodyStyle: "padding:0px 5px 5px 0px",
									items:[]
								});
								p.add(ct);
							}
							tx=Ext.util.Format.htmlDecode(opr.text);
							tip=Ext.util.Format.htmlDecode(opr.tips);
							if(opr.text_as_i18n=="1"){
								tx=getResource(tx, panel_name);
							}
							if(opr.tips_as_i18n=="1"){
								tip=getResource(tip, panel_name);
							}
							ct.add(o.btn(tx,tip,2,opr.insert_text));
						}
						p.doLayout();
					}catch(e){
						console.debug(e);
						Ext.Msg.alert(getResource("tip",""),getResource("load_operators_failed",""));
					}
				},
				failure: function(response, opts){
					Ext.Msg.alert(getResource("tip",""),getResource("load_operators_failed",""));
				}
			});
		},
		loadFormula: function(sf,_form,cfg,id){
			var _params=Ext.applyIf({
				mt: mt,
				panel_name: panel_name,
				bsid: baseId,
				cid: cid,
				nid: nodeId,
				node_id: nodeId,
				id: id
			},extraParams);
			Ext.apply(_params, _form.form.getValues());
			Ext.Ajax.request({
				url: "index.cfm?event=formulaBuilder.general.loadFormula&dt_="+new Date().getTime(),
				method: "POST",
				params:_params,
				success:function(response, opts){
					var obj = Ext.decode(response.responseText);
					if(sf){
						try{
							sf.setValue(Ext.util.Format.htmlDecode(obj.data[0].formula_value));
							sf.show();
						}catch(e){
							sf.setValue("");
							sf.hide();
						};
					}
				},
				failure: function(response, opts){
					Ext.Msg.alert(getResource("tip",""),getResource("load_formula_failed",""));
				}
			});
		},
		init: function(cfg){
			cfg = cfg || {};
			type = cfg.type || type;
			cid = cfg.cid>0?cfg.cid:cid;
			ptid = Ext.isNumber(cfg.ptid)?cfg.ptid:ptid;
			ku = cfg.ku || ku;
			mt = cfg.mt || mt;
			panel_name = cfg.panel_name || panel_name;
			extraParams = cfg.extraParams || extraParams;
			
			var _form = null,its1 = [{
				id: baseId+"_code_name_id",
				name: "code_name",
				field_type: "fixed",
				allowBlank: false,
				readOnly: cid>0?true:false,
				regex: /^[0-9a-zA-Z_\(\)\u4e00-\u9fa5]+$/i,
				regexText:getResource("code_name_invalid",""),
				fieldLabel: getResource("code_name","")
			},{
				id: baseId+"_code_name_desc_id",
				name: "code_name_desc",
				field_type: "fixed",
				allowBlank: false,
				fieldLabel: getResource("code_name_desc","")
			},{
				xtype: "checkbox",
				id: baseId+"_save_to_fig_id",
				name: "save_to_fig",
				field_type: "fixed",
				inputValue: 1,
				fieldLabel: getResource("save_to_fig","")
			}],its2 = [{
				xtype: "panel",
				border: false,
				width:525,
				html:"<hr/>"
			},{
				xtype: "panel",
				border: false,
				width: 525,
				bodyStyle: "padding:0px 5px 0px 125px",
				items:[],
				listeners: {
					afterrender: function(p){
						o.loadOperators(p,cfg);
					}
				}
			},o.ff(),{
				xtype: "textarea",
				//disabled: true,
				cls: "x-item-readOnly_css",
				readOnly: true,
				hidden: true,
				id: baseId+"_selected_formula_id",
				name: "selected_formula",
				fieldLabel: getResource("selected_formula",""),
				height: 200
			}];
			
			_form = new Ext.form.FormPanel({
				xtype: "form",
				autoScroll: true,
				region: "center",
				id: baseId+"_formula_form",
				bodyStyle: "padding:10px 10px 10px 10px",
				labelWidth: 120,
				margins: "5 5 5 0",
				tbar:[{
					text: getResource("save",""),
					id: baseId+ "_save_param_id",
					icon: imgPath + "/resources/images/icons/save.gif",
					handler:function(){
						if(cfg.custom_submit){
							if(cfg.cf){ cfg.cf(_form, cfg);}
						}else{
							o.saveform(_form, cfg);
						}
					}
				}],
				defaults:{
					xtype: "textfield",
					width: 400
				},
				items: [],
				listeners:{
					afterrender: function(p){
						o.fixedfs(p, false, o.ar, its2, cfg);
					},
					beforeremove: function(ct, f){
						if(type == "function"){
							if(f.ownerCt){
								f.ownerCt.un('afterlayout', f.alignErrorIcon, f);
							    f.ownerCt.un('expand', f.alignErrorIcon, f);
						    }
						}
					}
				}
			});
				
			
			wsp = new Ext.Panel({
				id: baseId+"_wsp",
				border: false,
				layout: "border",
				items:[{
					region: "west",
					width: cfg._tree_width>100?cfg._tree_width:200,
					title:getResource("formula_builder_items",""),
					xtype:"treepanel",
					id: baseId+"_tree",
					rootVisible: false,
					autoScroll: true,
					containerScroll: true,
					enableDrag: true,
					ddGroup:"formula_builder_ddgroup", 
					loader: new Ext.tree.TreeLoader({
						listeners: {
							beforeload: function(l, n, callback){
								if(dd) dd.destroy();
								dd = null;
								md = null;
							},
							load: function(l, n, response){
								var obj = Ext.decode(response.responseText);
								var i=0,c1=null,c2=null,ar=[];
								for(;i<obj.length;i++){
									if(obj[i].children && obj[i].children.length>0){
										ar = ar.concat(ar, obj[i].children);
									}
								}
								md = ar;
								dd = new Ext.data.ArrayStore({
									fields:["node_id","text","leaf"],
									data: ar
								});
							}
						}
					}),
					margins: "5 5 5 5",
					root: {
						//nodeType: "async",
						id: baseId+"_tree_root",
						node_id: 0,
						text: "root",
						expanded:true,
						draggable: false
					},
					tools: [{
						id:"plus",
						handler:function(){
							var tree = Ext.getCmp(baseId+"_tree");
							if(tree){
								tree.expandAll();
							}
						}
					},{
						id:"minus",
						handler:function(){
							var tree = Ext.getCmp(baseId+"_tree");
							if(tree){
								tree.collapseAll();
							}
						}
					},{
						id: "refresh",
						handler: function(){
							var tree = Ext.getCmp(baseId+"_tree");
							if(tree){
								tree.getRootNode().reload();
							}
						}
					}],
					listeners: {
						beforeload: function(node){
							this.loader.dataUrl = "index.cfm?event=formulaBuilder.general.loadTree&"+new Date();
							this.loader.baseParams = {
								mt: mt,
								panel_name: panel_name,
								nid: node.attributes.node_id,
								ftype: type,
								cid:cid,
								ptid: ptid
							};
							Ext.applyIf(this.loader.baseParams, extraParams);
						},
						contextmenu: function(node,e){
							e.stopEvent();
						},
						click: function(n,e){
							if(type == "function"){
								var nnodeId = n.attributes.node_id;
								if(nnodeId != nodeId){
									nodeId = nnodeId;
									if(nodeId == cfg.function_id){
										o.buildform(true);
									}else{
										o.buildform();
									}
								}
							}else{
								var nid = n.attributes.node_id;
								var sf=Ext.getCmp(baseId+"_selected_formula_id");
								nodeId=nid;
								if(n.isLeaf()){
									if(sf){
										o.loadFormula(sf,_form,cfg,n.attributes.id);
									}
								}else{
									if(sf){
										sf.hide();
									}
								}
							}
						},
						beforenodedrop: function(e){
							if(!e.dropNode.isLeaf()) return false;
						}
					}
				},_form]
			});
			
			win = new Ext.Window({
				id: baseId+"_win",
				title: getResource("formula_builder_win_title",""),
				layout: "fit",
				width: cfg._win_width>500?cfg._win_width:810,
				height: cfg._win_height>300?cfg._win_height:500,
				modal: true,
				resizable: false,
				items:[wsp],
				listeners:{
					beforeclose: function(w){
						w.removeAll(true);
						win = null;
						nodeId = -1;
						wsp = null;
						_form = null;
						buildMask = null;
						cid = 0;
						ptid = 0;
						dd = null;
						md = null;
						ku = true; //keyup Event
						mn = null;
						cl = true;
						mt = "payroll";
						panel_name = "";
						extraParams = {};
					},
					move: function(w, x, y){
						o.winMove(w, x, y);
					}
				}
			});
		},
		ar: function(p, its2, cfg){
			if(type == "function"){
				buildMask = new Ext.LoadMask(p.getEl(), {msg: getResource("loading","")});
				if(cid > 0){
					/////////////////////////
					nodeId = cfg.function_id;
					o.buildform(true);
					/////////////////////////
					//o.loadform();
				}
			}else{
				p.add(its2);
			}
			p.doLayout();
		},
		ff: function(){
			return new ContextAreaField({
				id: baseId+"_formula_id",
				name: "formula",
				fieldLabel: getResource("formula",""),
				height: 200,
				allowBlank: false,
				enableKeyEvents: true,
				listeners:{
					afterrender:function(field){
						new Ext.dd.DropTarget(field.getEl(),{
							ddGroup:"formula_builder_ddgroup", 
							copy:false,
							notifyDrop:function(dragSource,e,data){
								var v = "["+data.node.attributes.text+"]";
								if(data.node.isLeaf()){
									o.sv(field, v);
									return true;
								}else{
									return false;
								}
							},
							notifyOver:function(dragSource,e,data){
								if(!data.node.isLeaf()){
									return this.dropNotAllowed;
								}
								return this.dropAllowed;
							}
						});
						field.ov = "";
						if(cid > 0){
							o.loadform();
						}
					},
					contextmenu: function(field, e, p){
						e.preventDefault();
						if(mn) mn.destroy();
						if(dd){
							if(p){
								var v = field.getValue().substr(0, field.el.dom.selectionStart);
								var idx = v.lastIndexOf("[");
								if(idx>-1 && v.lastIndexOf("]")<idx){
									v = v.substring(idx+1,field.el.dom.selectionStart);
									if(v.trim().length>0){
										var cd = [];
										Ext.each(md,function(item){
											if((item.text+"").indexOf(v) > -1){
												cd.push(item);
											}
										});
										if(cd.length>0){
											var m = new Ext.menu.Menu({
												items:cd,
												listeners:{
													itemclick: function(item, e){
														o.sv(field, (item.text+"").replace(v,"")+"]");
													},
													show: function(mm){
														field.focus();
														this.el.on("keydown",function(e, t, oo){
															if(!(e.getKey()>=35 && e.getKey()<=40)){
																field.focus();
															}
														});
													}
												}//ANSI
											});
											mn = m;
											var xy=[field.el.getX()+field.getWidth(),field.el.getY()];
											m.showAt(xy);
										}else{
											if(mn) mn.destroy();
										}
									}else{
										if(mn) mn.destroy();
									}
								}else{
									if(mn) mn.destroy();
								}
							}else{
								var m = new Ext.menu.Menu({
									items:md,
									listeners:{
										itemclick: function(item, e){
											o.sv(field, "["+item.text+"]");
										}
									}
								});
								mn = m;
								m.showAt(e.getXY());
							}
							field.focus();
						}
					},
					keyup: function(field, e){
						//if(e.getKey()>=48 && e.getKey()<=90){
							if(field.ov != field.getValue()){
								field.fireEvent("contextmenu", field, e, {});
							}
						//}
						field.ov = field.getValue();
					},
					beforedestroy: function(field){
						if(mn) mn.destroy();
					}
				}
			});
		},
		btn: function(b,p,t,v){
			if(t==1){
				return {
					xtype: "button",
					text:"<b>&nbsp;"+b+"&nbsp;</b>",
					tooltip: {title:getResource("usages",""),text:p,dismissDelay:30000},
					handler: function(){o.sv(null,b+"("+v+")");}
				};
			}else if(t==2){
				return {
					xtype: "button",
					text:"<b>&nbsp;"+b+"&nbsp;</b>",
					tooltip: {title:getResource("usages",""),text:p,dismissDelay:30000},
					handler: function(){o.sv(null,v);}
				};
			}else{
				return {
					xtype: "button",
					text:"<b>&nbsp;"+b+"&nbsp;</b>",
					tooltip: {title:getResource("usages",""),text:b,dismissDelay:30000},
					handler: function(){o.sv(null,b);}
				};
			}
		},
		sv: function(t, v){
			t = t || Ext.getCmp(baseId+"_formula_id");
			t.focus();
			var nvalue = t.getValue().substr(0, t.el.dom.selectionStart) + v + t.getValue().substr(t.el.dom.selectionEnd);
			t.setValue(nvalue);
		},
		winMove: function(w, x, y){
			var ww = Ext.getBody().getWidth();
			var hh = Ext.getBody().getHeight();
			if(x < 0 || y < 0 || x > ww - w.getWidth() || y > hh - w.getHeight()){
				var xx = x;
				var yy = y;
				if(xx < 0) xx = 1;
				if(xx > ww - w.getWidth()) xx = ww - w.getWidth();
				if(yy < 0) yy = 1;
				if(yy > hh - w.getHeight()) yy = hh - w.getHeight();
				w.setPosition(xx, yy);
			}
		},
		open: function(cfg){
			cfg = cfg || {};
			Ext.applyIf(cfg,{cid:0, ptid:-1});
			type = cfg.type || type;
			cid = cfg.cid>0?cfg.cid:cid;
			ptid = Ext.isNumber(cfg.ptid)?cfg.ptid:ptid;
			ku = cfg.ku || ku;
			mt = cfg.mt || mt;
			panel_name = cfg.panel_name || panel_name;
			extraParams = cfg.extraParams || extraParams;
			o.init(cfg);
			win.show();
		},
		saveform: function(f, cfg){
			f.form.submit({
				url: "index.cfm?event=formulaBuilder.general.saveFormula&dt_="+new Date().getTime(),
				method: "POST",
				clientValidation: true,
				waitMsg: getResource("wait",""),
				params:Ext.applyIf({
					mt: mt,
					panel_name: panel_name,
					nodeId: nodeId,
					ftype: type,
					ptid: ptid,
					cid: cid
				},extraParams),
				success:function(form, action){
					if(action.result.flag == "S"){
						Ext.Msg.alert(getResource("tip",""),getResource("save","") +" " +getResource("success",""));
						if(cl) win.close();
					}else{
						Ext.Msg.alert(getResource("tip",""),action.result.error_msg);
					}
					if(cfg.af) cfg.af({form:f, action:action, success:action.result.flag=="S"?true:false, cid:cid, ptid:ptid, type:type, win: win});
				},
				failure: function(form, action){
					Ext.Msg.alert(getResource("tip",""),getResource("save","") +" " +getResource("failed",""));
					if(cfg.af) cfg.af({form:f, action:action, success:false, cid:cid, ptid:ptid, type:type, win: win});
				}
			});
		},
		loadform: function(){
			if(buildMask){
				buildMask.show();
			}
			var f = Ext.getCmp(baseId+"_formula_form");
			//f.form.load({
			Ext.Ajax.request({
				url: "index.cfm?event=formulaBuilder.general.loadForm&dt_="+new Date().getTime(),
				method: "POST",
				params:Ext.applyIf({
					mt: mt,
					panel_name: panel_name,
					bsid: baseId,
					cid: cid
				},extraParams),
				success:function(response, opts){
					var obj = Ext.decode(response.responseText);
					try{
						for(var p in obj.data[0]){
							obj.data[0][p]=Ext.util.Format.htmlDecode(obj.data[0][p]);
						}
						f.form.setValues(obj.data[0]);
					}catch(e){}
					if(buildMask){
						buildMask.hide();
					}
				},
				failure: function(response, opts){
					if(buildMask){
						buildMask.hide();
					}
					Ext.Msg.alert(getResource("tip",""),getResource("failed",""));
				}
			});
		},
		nf: function(x,p,o){
			return Ext.apply({
				xtype: x,
				id: baseId+"_"+p+"_id",
				name: p,
				fieldLabel: getResource(p, baseId+"_fn_"+(nodeId<0?0:nodeId))
			},o||{});
		},
		fixedfs: function(p, cb, callback, its2, cfg){
			var f = Ext.getCmp(baseId+"_formula_form");
			f.form.clearInvalid();
			Ext.Ajax.request({
				url: "index.cfm?event=formulaBuilder.general.fixedFields&dt_="+new Date().getTime(),
				method: "POST",
				params:Ext.applyIf({
					mt: mt,
					panel_name: panel_name,
					cid: cid
				},extraParams),
				success:function(response, opts){
					var obj = Ext.decode(response.responseText);
					if(callback && Ext.isFunction(callback)){
						o.af(p, cb, obj, {field_type: "fixed"});
						callback.call(o,p,its2,cfg);
					}
				},
				failure: function(response, opts){
					Ext.Msg.alert(getResource("tip",""),getResource("failed",""));
				}
			});
		},
		buildform: function(cb){
			if(buildMask){
				buildMask.show();
			}
			var f = Ext.getCmp(baseId+"_formula_form");
			f.form.clearInvalid();
			Ext.Ajax.request({
				url: "index.cfm?event=formulaBuilder.general.dynamicData&dt_="+new Date().getTime(),
				method: "POST",
				params:Ext.applyIf({
					mt: mt,
					panel_name: panel_name,
					nodeId: nodeId
				},extraParams),
				success:function(response, opts){
					var obj = Ext.decode(response.responseText);
					o.af(f, cb, obj);
				},
				failure: function(response, opts){
					if(buildMask){
						buildMask.hide();
					}
					Ext.Msg.alert(getResource("tip",""),getResource("failed",""));
				}
			});
		},
		af: function(f, cb, obj, opts){
			//f.removeAll(true);
			var rms = [];
			f.items.each(function(item){
				//if(item.name != "code_name" && item.name != "code_name_desc" && item.name != "save_to_fig")
				if(item.field_type != "fixed"){
					rms.push(item);
				}
			});
			for(var i=0;i<rms.length;i++){
				f.remove(rms[i].id, true);
			}
			rms = [];
			rms = null;
			//var obj = Ext.decode(response.responseText);
			var parray = obj.PARAMNAMES.split(",");
			if(obj.PARAMNAMES.length > 0){
				for(var i=0;i<parray.length;i++){
					var p = parray[i];
					var param = obj.PARAMS[p];
					var field = {};
					var ptype = param.PARAMTYPE;
					var pcklistType = param.PTYPE;
					var delm = param.DELIMITER;
					var pvalue = param.PVALUE;
					var hidden = pvalue==""?false:true;
					var fieldOpts = param.OPTS;
					try{
						fieldOpts = Ext.decode(fieldOpts);
					}catch(e){}
					if(pcklistType != ""){
						if(pcklistType == "combobox"){
							if(delm.length>0){
								field = new Ext.ux.form.LovCombo({
									id: baseId+"_param_"+p+"_id",
									name:p,
									hiddenName:p,
									hidden:hidden,
									store: new Ext.data.JsonStore({
										autoLoad: true,
										fields: obj.PARAMS[p].PDATA.columnlist.split(","),
										root: "data",
										data: obj.PARAMS[p].PDATA,
										totalProperty: "recordcount"
									}),
									fieldLabel: getResource(p, ""),
									displayField:"data_value",
									valueField:"data_key",
									forceSelection:true,
									mode:"local",
									beforeBlur:function(){},
									hideOnSelect:true,
									editable: false,
									allowBlank: false,
									triggerAction:"all"
								});
							}else{
								field = new Ext.form.ComboBox({
									id: baseId+"_param_"+p+"_id",
									name:p,
									hiddenName:p,
									hidden:hidden,
									store: new Ext.data.JsonStore({
										autoLoad: true,
										fields: obj.PARAMS[p].PDATA.columnlist.split(","),
										root: "data",
										data: obj.PARAMS[p].PDATA,
										totalProperty: "recordcount"
									}),
									fieldLabel: getResource(p, ""),
									displayField:"data_value",
									valueField:"data_key",
									forceSelection:true,
									editable: false,
									allowBlank: false,
									mode:"local",
									triggerAction:"all"
								});
							}
						}else if(pcklistType == "tree"){
							field = new Ext.form.TriggerField({
								id: baseId+"_param_"+p+"_id",
								name: p,
								hidden:hidden,
								editable: false,
								allowBlank: false,
								msgTarget: "side",
								fieldLabel: getResource(p, ""),
								delm: delm
							});
							field.onTriggerClick = function(e){
								var fo = this;
								var p = fo.name;
								var treeData = obj.PARAMS[p].PDATA;
								try{
									treeData = eval(treeData);
								}catch(e){
									treeData = [];
								}
								var triggerWin = new Ext.Window({
									id: baseId+"_"+p+"_popup_win",
									//title: getResource("formula_builder_win_title",""),
									layout: "fit",
									width: 400,
									height: 400,
									modal: true,
									resizable: false,
									items:[new Ext.ux.tree.FilterTreeGrid({
										//xtype: "treepanel",
										id: "picklistTree_"+panel_name.trim()+"_"+p.trim(),
										autoScroll: true,
										containerScroll: true,
								        enableDD: false,
										enableSort: false,
										border: false,
										columns:[{
											header:"value",
											dataIndex: "text",
											width: 263
										}],
										loader: new Ext.tree.TreeLoader(),
										root: new Ext.tree.AsyncTreeNode({
											id: "tree_root",
											text: "tree_root",
								            expanded: true,
								            children: treeData
								        }),
								        rootVisible: false,
										listeners: {
											dblclick: function(node, e){
												node.select();
												fo.setValue(node.attributes.value||node.attributes.text);
												triggerWin.close();
											}
										}
									})],
									listeners:{
										beforeclose: function(w){
											w.removeAll(true);
										},
										move: function(w, x, y){
											o.winMove(w, x, y);
										}
									}
								});
								triggerWin.show();
							}
						}else{//default popup
							field = new Ext.form.TriggerField({
								id: baseId+"_param_"+p+"_id",
								name: p,
								hidden:hidden,
								editable: false,
								allowBlank: false,
								msgTarget: "side",
								fieldLabel: getResource(p, ""),
								delm: delm
							});
							field.onTriggerClick = function(e){
								var fo = this;
								var sm = null;
								var cm = [];
								var p = fo.name;
								var cla = obj.PARAMS[p].PDATA.columnlist.split(",");
								if(fo.delm.length>0){
									sm = new Ext.grid.CheckboxSelectionModel({singleSelect: false});
									cm.push(sm);
								}else{
									sm = new Ext.grid.RowSelectionModel({singleSelect: true});
								}
								for(var i=0;i<cla.length;i++){
									cm.push({header:getResource(cla[i],""), width:200, sortable:true, dataIndex:cla[i]});
								}
								var triggerWin = new Ext.Window({
									id: baseId+"_"+p+"_popup_win",
									//title: getResource("formula_builder_win_title",""),
									layout: "fit",
									width: 450,
									height: 300,
									modal: true,
									resizable: false,
									items:[{
										xtype: "grid",
										id: baseId+"_"+p+"_grid",
										frame: true,
										store: new Ext.data.JsonStore({
											autoLoad: true,
											fields: obj.PARAMS[p].PDATA.columnlist.split(","),
											root: "data",
											data: obj.PARAMS[p].PDATA,
											totalProperty: "recordcount"
										}),
										columns:cm,
										sm: sm,
										tbar:[{text:getResource("save",""),icon: imgPath + "/resources/images/icons/save.gif",handler:function(){
											var g = Ext.getCmp(baseId+"_"+p+"_grid");
											var s = g.getSelectionModel().getSelections();
											var a = [];
											Ext.each(s, function(rec){
												a.push(rec.get("data_key"));
											});
											fo.setValue(a.join(fo.delm));
											triggerWin.close();
										}},'-',{
											xtype:"textfield",
											width:250,
											emptyText: getResource("search",""),
											id:baseId+"_quick_search",
											enableKeyEvents: true,
											listeners:{
												keyup: function(f, e){
													var g = Ext.getCmp(baseId+"_"+p+"_grid");
													if(f.getValue().length > 0){
														g.getStore().filterBy(function(rec,id){
															return (rec.get("data_key")+"").toLowerCase().indexOf(f.getValue().toLowerCase().trim())>-1 || (rec.get("data_value")+"").toLowerCase().indexOf(f.getValue().toLowerCase().trim())>-1
														});
													}else{
														g.getStore().filterBy(function(rec,id){
															return true;
														});
													}
												}
											}
										},'-',{text: getResource("clear","searchPanel"), icon: imgPath + "/resources/images/icons/clear.png", handler:function(){
											var g = Ext.getCmp(baseId+"_"+p+"_grid");
											g.getStore().filterBy(function(rec,id){
												return true;
											});
											Ext.getCmp(baseId+"_quick_search").setValue("");
										}},'-'],
										listeners:{
											rowdblclick: function(g, ridx, e){
												fo.setValue(g.getSelectionModel().getSelected().get("data_key"));
												triggerWin.close();
											}
										}
									}],
									listeners:{
										beforeclose: function(w){
											w.removeAll(true);
										},
										move: function(w, x, y){
											o.winMove(w, x, y);
										}
									}
								});
								triggerWin.show();
							}
						}
					}else{
						if(hidden){
							field = o.nf(ptype, p, {allowBlank: false, hidden:hidden, value:pvalue});
						}else{
							field = o.nf(ptype, p, {allowBlank: false, hidden:hidden});
						}
					}
					if(ptype=="checkbox"){
						Ext.apply(field, {inputValue: 1});
					}
					if(opts){
						Ext.apply(field, opts);
					}
					if(fieldOpts && Ext.isObject(fieldOpts)){
						Ext.apply(field, fieldOpts);
					}
					f.add(field);
				}
				f.doLayout();
			}
			if(buildMask){
				buildMask.hide();
			}
			if(cb){
				o.loadform();
			}
		}
	});
})();
Ext.define('Cityray.Blank', {
	extend : 'Ext.Container',
	config : {
		scrollable : true,
		border : false,
		layout : 'vbox',
		items : [{
					xtype : 'toolbar',
					title : '',
					docked : 'top'
				}],
		listeners : {
			painted : function() {

			}
		}		
	}
});
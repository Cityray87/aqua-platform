
Ext.define("Cityray.SlideNav", {
    extend: 'Cityray.ux.SlideNavigation',
    config: {
    	 fullscreen: true,
         slideSelector: 'x-toolbar',
         containerSlideDelay: 10,
         selectSlideDuration: 200,
         itemMask: true,
         hidden:true,
         slideButtonDefaults: {
             selector: 'toolbar'
         },
         listPosition: 'left',
         defaults: {
             style: 'background: #fff',
             xtype: 'container'
         }
    }
});
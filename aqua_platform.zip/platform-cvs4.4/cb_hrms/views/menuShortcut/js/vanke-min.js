$(document).ready(function() {
    $('a[href="#"]').each(function() {
        $(this).attr("href", "javascript:void(0)")
    });
    $(".perform li").each(function() {
        var d = $(this);
        $(this).find(".s").click(function() {
            var e = $(this).index();
            d.find(".s").removeClass("on").eq(e).addClass("on");
            d.find(".info").hide().eq(e).fadeIn(500)
        })
    });
    $(".artist_l li").each(function(d) {
        $(this).find("a").css("top", -$(this).height());
        $(this).hover(function() {
            $(this).find("a").animate({
                top: "0"
            },
            200)
        },
        function() {
            $(this).find("a").animate({
                top: $(this).height()
            },
            {
                duration: 200,
                complete: function() {
                    $(this).css("top", -$(this).parent("li").height())
                }
            })
        })
    });
    $("#calendar td").live("mouseover",
    function() {
        $("#calendar td").removeClass("hover");
        $(this).addClass("hover")
    });
    $(".category_list .item").each(function(d) {
        $(this).hover(function() {
            $(".category_list .item").removeClass("on").eq(d).addClass("on");
            $(".category_list ol").hide().eq(d).show()
        },
        function() {
            $(this).find("ol").hide();
            $(this).removeClass("on")
        })
    });
    $(".u_city_a li").each(function(d) {
        $(this).click(function() {
            if (d == 10) {
                return false
            }
            $(".u_city_nav li").removeClass("on").eq(d).addClass("on");
            $(".u_city_nav p").hide().eq(d).show()
        })
    });
    var b = 0;
    var a = 0;
    $(".u_city_nav .more").click(function() {
        if (b == 1) {
            $(this).removeClass("on");
            $(".s_citys").hide(200);
            b = 0
        } else {
            $(this).addClass("on");
            $(".s_citys").show(200);
            b = 1
        }
        return false
    });
    $(".s_citys").hover(function() {
        a = 1
    },
    function() {
        a = 0
    });
    $("body").bind("click",
    function() {
        if (b == 1 && a == 0) {
            $(".s_citys").hide(200);
            $(".u_city_nav .more").removeClass("on");
            b = 0
        }
    });
    function c() {
        if ($(".scroll_txt li").length <= 1) {
            return
        }
        var d = $(".scroll_txt li:last");
        d.hide();
        $(".scroll_txt li:last").remove();
        $(".scroll_txt li:first").before(d);
        d.slideDown(500)
    }
    window.setInterval(c, 5000);
    $(".live_top li").each(function(d) {
        $(this).hover(function() {
            $(".live_top li").removeClass("on").eq(d).addClass("on")
        })
    });
    $(".list_1 li").each(function(d) {
        $(this).hover(function() {
            $(".list_1 li").removeClass("on").eq(d).addClass("on")
        })
    });
    $(".vote_m dd").each(function(d) {
        $(this).click(function() {
            $(".vote_m dd").removeClass("on").eq(d).addClass("on")
        })
    });
    $(".tr_commend dl").each(function(d) {
        $(this).hover(function() {
            $(".tr_commend dl").removeClass("on").eq(d).addClass("on")
        })
    });
    $(".ticketInfo .help").hover(function() {
        $(".minTips").fadeIn("fast")
    },
    function() {
        $(".minTips").fadeOut("fast")
    });
    $(".videoList li").hover(function() {
        $(this).addClass("on")
    },
    function() {
        $(this).removeClass("on")
    });
    $(".min_tip .tab_min_b a").each(function(d) {
        $(this).click(function() {
            $(".tab_min_b a").removeClass("on").eq(d).addClass("on")
        })
    });
    $(".news_list li").hover(function() {
        $(this).addClass("on")
    },
    function() {
        $(this).removeClass("on")
    });
    $(".tr_pic_list li").hover(function() {
        $(this).addClass("on")
    },
    function() {
        $(this).removeClass("on")
    });
    $(".sift .expand").toggle(function() {
        $("#city").height(24);
        $(this).html("\u5c55\u5f00")
    },
    function() {
        $("#city").height("auto");
        $(this).html("\u6536\u7f29")
    });
    $(".hzlist .hztitle").each(function(d) {
        $(this).click(function() {
            $(".hzlist .info")
        })
    });
    $(".buy_caption .tab_t a").each(function(d) {
        $(this).click(function() {
            $(".buy_caption .tab_t a").removeClass("on").eq(d).addClass("on");
            $(".buy_caption dl").hide().eq(d).show()
        })
    });
    $(".vocal_list li .t .c7").click(function() {
        $(this).parent().parent().find(".t").show();
        $(this).parent().hide()
    })
});
$(document).ready(function() {
    var m = false;
    var i = "";
    var e = 500;
    var j = 968;
    var d = $("#actor li").length;
    var b = d * 12;
    var o = (j - (b + 26)) / 2;
    var h = 0;
    $("#actor").width(j * d);
    $("#actor li").each(function(c) {
        i += "<span>" + (c + 1) + "</span>"
    });
    $("#numInner").width(b).html(i);
    $("#imgPlay .mc").width(b);
    $("#numInner span:first").addClass("on");
    function l(n, c) {
        n = $(n) ? $(n) : n;
        n.addClass(c).siblings().removeClass(c)
    }
    $("#imgPlay .next").click(function() {
        g(1)
    });
    $("#imgPlay .prev").click(function() {
        g( - 1)
    });
    function g(c) {
        if ($("#actor").is(":animated") == false) {
            h += c;
            if (h != -1 && h != d) {
                $("#actor").animate({
                    marginLeft: -h * j + "px"
                },
                e)
            } else {
                if (h == -1) {
                    h = d - 1;
                    $("#actor").css({
                        marginLeft: -(j * (h - 1)) + "px"
                    });
                    $("#actor").animate({
                        marginLeft: -(j * h) + "px"
                    },
                    e)
                } else {
                    if (h == d) {
                        h = 0;
                        $("#actor").css({
                            marginLeft: -j + "px"
                        });
                        $("#actor").animate({
                            marginLeft: 0 + "px"
                        },
                        e)
                    }
                }
            }
            l($("#numInner span").eq(h), "on")
        }
    }
    $("#numInner span").click(function() {
        h = $(this).index();
        f(h);
        l($("#numInner span").eq(h), "on")
    });
    function f(c) {
        if ($("#actor").css("marginLeft") != -c * j + "px") {
            $("#actor").css("marginLeft", -c * j + "px");
            $("#actor").fadeOut(0,
            function() {
                $("#actor").fadeIn(500)
            })
        }
    }
    function a() {
        m = setInterval(function() {
            g(1)
        },
        5000)
    }
    function k() {
        if (m) {
            clearInterval(m)
        }
    }
    $("#imgPlay").hover(function() {
        k()
    },
    function() {
        a()
    });
    //a();
});
$(document).ready(function() {
    var a = false;
    var b = false;
    $(".s_city .s").click(function() {
        if (a == false) {
            $(".s_c_links").show(200);
            $(this).addClass("on");
            a = true
        } else {
            $(".s_c_links").hide(200);
            $(this).removeClass("on");
            a = false
        }
        return false
    });
    $(".s_c_links").hover(function() {
        b = true
    },
    function() {
        b = false
    });
    $("body").bind("click",
    function() {
        if (a == true && b == false) {
            $(".s_c_links").hide(200);
            $(".s_city .s").removeClass("on");
            a = false
        }
    })
});
$(document).ready(function() {
    $(".sd").each(function(a) {
        $(this).find(".hztitle").click(function() {
            $(".sd").eq(a).find("p").toggle()
        })
    });
    $(".hztitle").toggle(function() {
        $(this).addClass("hztitle-2")
    },
    function() {
        $(this).removeClass("hztitle-2")
    })
});
function loadpic() {
    var b = $("#artist_photo").width() / $("#artist_photo").height();
    if (b < 1) {
        if ($("#artist_photo").height() > 243) {
            $("#artist_photo").height(243)
        }
    } else {
        if ($("#artist_photo").width() > 243) {
            $("#artist_photo").width(243)
        }
        var a = 243 - $("#artist_photo").height();
        $("#artist_photo").css("marginTop", a / 2)
    }
}
function artHeight() {
    var b = $(".artists_r").height();
    var a = $(".artists_l").height();
    var e = $(".artists_l .tab_min_in").height();
    var d = b - a;
    if (d > 0) {
        var c = a + d - 12;
        $(".artists_l").height(c)
    }
    if (b - e < 90) {
        $(".artists_l").height("auto")
    }
};

							
				mobile_component_manager_formpanel = Ext.extend(Ext.form.FormPanel,{
					paramList:null,
					mobile_component_manager_formpanel_globalVariable:null,
					constructor:function(_cfg){
						if(_cfg==null){_cfg=={};this.paramList={}}else{this.paramList=_cfg.paramList;};
						this.mobile_component_manager_formpanel_globalVariable=new Array();
		
					this.paramList.panel_name="mobile_component_manager_formpanel";
					mobile_component_manager_formpanel.superclass.constructor.call(this,{
						autoScroll:true,id:"mobile_component_manager_formpanel_form",
						labelAlign:"right",padding:10,
						labelWidth:100,fileUpload:true,enctype:"multipart/form-data",border:false,
						bodyBorder:false,anchor:"100% 100%",items:[
		{ xtype:'panel',layout:'form',border:false,items:[createPicklistCompoment("mobile_component_manager_formpanel","table_name",{isVisibleRender:"1",picklistType:"COMBOBOX",fieldI18nKey:getResource('table_name','mobile_component_manager_formpanel'),fieldValue:"",comboboxKeyColumn:"table_name",comboboxValueColumn:"table_name",isNeedConfirmDirtyData:"0",editGridId:"",isNeedPicklistFilter:"0",isEditable:true},this.mobile_component_manager_formpanel_globalVariable,"width:150,style:{marginLeft:\"0px\",marginTop:\"0px\",marginRight:\"0px\",marginBottom:\"0px\"}")]}],tbar:[{ text:getResource('mb_component_manager_generate','mobile_component_manager_formpanel'),icon:'/ext/resources/images/icons/add.gif',id:'mobile_component_manager_formpanel_mb_component_manager_generate_id',scope:this,
								handler:function(){this.event_mb_component_manager_generate();}}],listeners:{afterlayout:function(){},afterrender:function(){
						
						
			
						if(getAppPriv('mobile_component_manager_formpanel','mb_component_manager_generate')==0){
							Ext.getCmp('mobile_component_manager_formpanel_mb_component_manager_generate_id').hide();
						}
				},beforerender:function(){}}})},
						event_mb_component_manager_generate:function(){
							var globalVariables_mobile_component_manager_formpanel=new Object();
							var panelActionData_mobile_component_manager_formpanel=new Array();
					
							dynamicFormPanelEvent("mobile_component_manager_formpanel","mb_component_manager_generate",{panelActionDataArray:panelActionData_mobile_component_manager_formpanel,isRequireConfirmation:"0",confirmMessage:"getResource('mobile_component_manager_formpanel','')",isRequireValidation:"1",predefinedValues:"",handlerType:"BACKGROUND",actionHandlerEvent:"dynamicGenerateMobileScript.dynamicMobile.dynamicMobileComponentManager",dynPageName:"",winWidth:"0",winHeight:"0",winTitleI18n:"",isNeedConfirmDirtyData:"0",gridPanelName:"",isRequireSuccessTip:"1",isCloseWindowAfterAction:"0",resetFormAfterSuccess:"0",isRequireReloadGrid:"0",afterSuccessJs:"",handlerJs:"",isWorkFlowStart:"0",workFlowProcessKey:"",wfTable:"",rptFormat:"",isHtmlXls:"0",rptNumber:"",rptPageType:"MAIN_PANEL",targetPanelName:"",targetPanelType:"",menuKey:"mobile_component_manager"},globalVariables_mobile_component_manager_formpanel);
						}	
					,mobile_component_manager_formpanel_setStyle:function() {
			var varStyleArray_mobile_component_manager_formpanel=new Array();
		
					},makeNode:function(name,value){
						var node = document.createElement("input");node.type="hidden";node.name=name;
						node.id=name;node.value=this.URLencode(value);return node;
					},
					insertWithin:function(nodeId, name,value) {
						var node = document.getElementById(nodeId);var newNode = this.makeNode(name,value);node.appendChild(newNode);	
					},
					URLencode:function(sStr) {
						return escape(sStr).replace(/\+/g, "%2B").replace(/\'/g,"%22").replace(/\"/g, "%27").replace(/\//g,"%2F");
					},					
					run_popReport:function(panel_name,rpt_format,rpt_number,width,height,formValues){
						var t_url = "/cb_hrms/index.cfm?event=rpt.report.report.runReportPage";
						for(var i in formValues){
							t_url = t_url + "&"+ i + "="+this.URLencode(formValues[i]);
						}window.open (t_url) ;
					},
					mobile_component_manager_formpanel_clientSideValidation:function(v_event_name){
						var validData = "";var error_msg = "";
						return formClientSideValidation("mobile_component_manager_formpanel",validData,v_event_name);
					}
					});
					
				page_mobile_component_manager = Ext.extend(Ext.Panel,{
					paramList:null,
					loadCounter:null,
		
					constructor:function(_cfg){
							if(_cfg==null){_cfg=={};this.paramList={}}else{this.paramList = _cfg.paramList;};
							Ext.apply(this,_cfg);
						page_mobile_component_manager.superclass.constructor.call(this,{
							border:false,
							autoScroll:false,	
							id:'page_mobile_component_manager',
							anchor:'100% 100%',
							layout:'anchor',
							items:[
								
		
							{
								anchor:'100% 100%',border:false,disabled:false,flex:1,
								layout:"fit",
								panel_name:"mobile_component_manager_formpanel",
								panel_type:"advformpanel",
								id:"mobile_component_manager_formpanel_parentPanel",
								items:[new mobile_component_manager_formpanel({paramList:this.paramList})]
						}]
						})
					},
					listeners:{
						beforerender:function(_grid){
							var winObj = eval(Ext.getCmp(Ext.getCmp('page_mobile_component_manager').paramList.win_id));
							if(typeof(winObj)!='undefined'){
								maskObj = new Ext.LoadMask(winObj.getEl(), {msg:getResource('loading','')});
								maskObj.show();
							}
						},
						render:function(_grid){
							Ext.getCmp('page_mobile_component_manager').loadCounter=0;
		
					if(getAppPriv('mobile_component_manager_formpanel','')==0){
				
						if(typeof(Ext.getCmp('mobile_component_manager_formpanel_form'))!='undefined'){
							Ext.getCmp('mobile_component_manager_formpanel_form').destroy();
							if(typeof(Ext.getCmp('mobile_component_manager_formpanel_parentPanel'))!='undefined'){
								var parent = Ext.getCmp('mobile_component_manager_formpanel_parentPanel').ownerCt;
								parent.remove(Ext.getCmp('mobile_component_manager_formpanel_parentPanel'));
								parent.doLayout();
							}
						}
					}
				if(Ext.getCmp('page_mobile_component_manager').loadCounter==0){
					maskObj.hide();	
					Ext.getCmp('page_mobile_component_manager').loadCounter=0;
				} 
		
							if(getAppPriv('mobile_component_manager_formpanel','')){
								Ext.getCmp('mobile_component_manager_formpanel_form').getForm().reset();
								var baseParams = new Object();
								var paramList = Ext.getCmp('mobile_component_manager_formpanel_form').paramList;
								Ext.apply(baseParams,paramList);
								baseParams.panel_name='mobile_component_manager_formpanel';
								baseParams.currentPanel='mobile_component_manager_formpanel';
								baseParams.pname='mobile_component_manager_formpanel';
								Ext.Ajax.request({
									params:baseParams,
									method: 'POST',
									url: 'index.cfm?event=dynamicGenerateScript.dynamicGenerateScript.dynamicGetPanelComboData&datenow=' + new Date(),
									failure: function(response,options){
										var responseText = Ext.util.JSON.decode(options.response.responseText);
										Ext.MessageBox.hide();
										Ext.MessageBox.alert('failure','failure');
									},
									success: function(response,options){
										var responseText = Ext.util.JSON.decode(response.responseText);
										Ext.MessageBox.hide();
						
									Ext.getCmp("mobile_component_manager_formpanel_table_name_id").getStore().loadData(responseText.jsonObject.table_name);
								
								   Ext.getCmp('mobile_component_manager_formpanel_form').doLayout();
							
										
										
									   	}
								});
							}
						
							if(null!=maskObj&&maskObj!=undefined){
								if(Ext.getCmp('page_mobile_component_manager').loadCounter<=0){
									maskObj.hide();	
									Ext.getCmp('page_mobile_component_manager').loadCounter=0;
								}
							}	
							
						
						},
						afterrender:function(_grid){}	
					}
				})
		

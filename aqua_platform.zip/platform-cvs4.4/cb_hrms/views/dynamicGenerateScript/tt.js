
				picklist_aa_aa = Ext.extend(Ext.Window,{
					operatorStore:null,
					picklist_search_store:null,
					filter_form:null,
					picklist_grid:null,
					constructor:function(_cfg){
						if(_cfg==null){_cfg=={};this.paramList={}}else{this.paramList = _cfg.paramList;};
						Ext.apply(this,_cfg);
								
						this.operatorStore = new Ext.data.ArrayStore({
							fields: [{name: 'pkey', type: 'string'}, {name: 'pvalue', type: 'string'}],
							data : [['=','等于'],['>','大于'],['<','小于'],['>=','大于等于'],['<=','小于等于'],['<>','不等于']]
						});
						
						this.picklist_search_store = new Ext.data.JsonStore({
							remoteSort: true,
							root: 'query.data',
							autoLoad:'true',
							baseParams:this.paramList,
							totalProperty: 'totalcount',
							url: 'index.cfm?event=picklist.general.picklistData&pname=aa&fname=aa&date='+new Date(),
							fields: [
		
					        			"operator_type_key"
					        	,
					        			"description"
					        	],
							dummy: true
						});
		
						this.filter_form = new Ext.form.FormPanel({
							frame:true,
							bodyBorder:false,
							buttonAlign:"left",
							id:"aa_aa_picklistSerchForm",
							autoWidth:true,
							labelAlign:"left",
							border:false,
							labelWidth:90,
							keys:[{key:13,fn:function(){Ext.getCmp("picklist_aa_aa").adv_search_event();}}],
			
							items : [
				
							{
								border : false,
								layout : "column",
								items:[{
									border : false,
									layout : "form",
									width : 200,
									items:[
										new Ext.form.ComboBox({
											allowBlank : true,
											displayField : "pvalue",
				
											fieldLabel : getResource("operator_type_key","aa"),
					
											forceSelection : true,
											hiddenName : "operator_type_key_operator",
											id : "operator_type_key_operator_desc",
											listeners : {
												render : this.comRender,
												scope:this
											},
											mode : "local",
											name : "operator_type_key_operator",
											resizable : true,
											selectOnFocus : true,
											store : this.operatorStore,
											triggerAction : "all",
											typeAhead : true,
											valueField : "pkey",
											width : 100,
											dummy : true
										})		
					
									]
								},{
									border : false,
									layout : "form",
									width : 100,
									items : [new Ext.form.TextField({
										id:"operator_type_key",
										name:"operator_type_key",
										hideLabel:true,
										width:100
									})]
								}]
							}
				
							],
				
							buttons:[
			
							new Ext.Button({
								handler : this.adv_search_event,
								scope:this,
								id : "adv_search_btn_aa_aa",
								style : "margin-top:-5px",
								text : getResource("adv_search_btn","searchPanel"),
								dummy : true
							})	
							]
						})
			
						this.picklist_grid = new Ext.grid.GridPanel({
							border : false,
							loadMask:true,
							height : 300,
							id : 'adv_grid_panel_aa_aa',
							store : this.picklist_search_store,
							stripeRows : true,	
							listeners : {
								rowclick:this.rowSelected,
								scope:this
							},
		
							columns:[
			
							{
			
									header:getResource("operator_type_key","aa"),
				
									width:100,
				
									dataIndex : "operator_type_key",
									sortable:true
							}
			,
							{
			
									header:getResource("description","aa"),
				
									width:100,
				
									dataIndex : "description",
									sortable:true
							}
			
							],
			
							bbar : new Ext.PagingToolbar({
								displayInfo : true,
								pageSize : 10,
								store : this.picklist_search_store,
								dummy : true
							})								
						})
							
						picklist_aa_aa.superclass.constructor.call(this,{
							constrainHeader:true,
							id:'picklist_aa_aa',
							setZIndex:Ext.emptyFn,
							width:(600 > window.parent.document.body.clientWidth ? window.parent.document.body.clientWidth : 600),
							height:(600 > window.parent.document.body.clientHeight ? window.parent.document.body.clientHeight : 600),
							title: getResource('aa','aa_picklist'),
							maximizable:false,
							resizable:true,
							modal:true,
							items:[
		
							   this.filter_form,
		
							   this.picklist_grid
							],
							listeners:{
								afterrender:this.resizeContent,
								resize:this.resizeContent,
								scope:this
							}
						})
					},
					resizeContent:function(){
						if(typeof(Ext.getCmp("picklist_aa_aa").filter_form)!="undefined"){
							var formHeight = Ext.getCmp("picklist_aa_aa").filter_form.getHeight();
							Ext.getCmp("picklist_aa_aa").picklist_grid.setHeight(Ext.getCmp("picklist_aa_aa").getHeight()-formHeight-29);
							Ext.getCmp("picklist_aa_aa").picklist_grid.setWidth(Ext.getCmp("picklist_aa_aa").getWidth()-14);
						}else{
							Ext.getCmp("picklist_aa_aa").picklist_grid.setHeight(Ext.getCmp("picklist_aa_aa").getHeight()-29);
							Ext.getCmp("picklist_aa_aa").picklist_grid.setWidth(Ext.getCmp("picklist_aa_aa").getWidth()-14);
						}
					},
					clearDestValue:function(){
		
						Ext.getCmp("aa_aa_id").setValue("");
						
					},
					adv_search_event:function(){
						var sqlString = "";
						var valueField = "";
						var i=0;
						var operators="";
		
				valueField = Ext.getCmp("operator_type_key").getValue();
				operators = Ext.getCmp("operator_type_key_operator_desc").getValue();
				if(operators == "like"){
					valueField = "%"+valueField+"%";
				}
				if(valueField!="" && valueField!=null){
					sqlString = sqlString + " and operator_type_key "+operators+" N'"+valueField+"'";
				}
				Ext.getCmp("picklist_aa_aa").picklist_search_store.baseParams.adv_search_where=sqlString;
				Ext.getCmp("picklist_aa_aa").picklist_search_store.load();
			
					},
					rowSelected:function(){
						var lookupbox = Ext.getCmp("aa_aa_id");
						var paramList = Ext.getCmp("picklist_aa_aa").paramList;
						var value = lookupbox.getValue();
						if((paramList.sourcePage).toLowerCase()=="searchpanel"){
							if(paramList.needDelimiter==1 && value!=""){
								lookupbox.setValue(Ext.util.Format.htmlDecode(value+","+Ext.getCmp("adv_grid_panel_aa_aa").getSelectionModel().getSelected().get("operator_type_key")));	
							}else{
								lookupbox.setValue(Ext.util.Format.htmlDecode(Ext.getCmp("adv_grid_panel_aa_aa").getSelectionModel().getSelected().get("operator_type_key")));
							}
							lookupbox.focus();
							lookupbox.fireEvent("keyUp");
						}else if((paramList.sourcePage).toLowerCase()=="formpanel"){
		
						value = Ext.getCmp("aa_aa_id").getValue();
						if("" == ""||value==""){
							Ext.getCmp("aa_aa_id").setValue(Ext.util.Format.htmlDecode(Ext.getCmp("adv_grid_panel_aa_aa").getSelectionModel().getSelected().get("operator_type_key")));
						}else{
							Ext.getCmp("aa_aa_id").setValue(Ext.util.Format.htmlDecode(value+""+Ext.getCmp("adv_grid_panel_aa_aa").getSelectionModel().getSelected().get("operator_type_key")));
						}
				
							lookupbox.fireEvent("focus");
							lookupbox.fireEvent("keyUp");	
						}else if((paramList.sourcePage).toLowerCase()=="editgrid"){
							var myGrid;
							var editor;
							if(typeof(paramList.editgrid_id)!="undefined"){
								myGrid = eval(Ext.getCmp(paramList.editgrid_id));
								myGrid.startEditing(paramList.editorrow,paramList.editorcol);
								editor =  myGrid.activeEditor;
							}
	    
									value = editor.getValue();
									if("" == ""||value==""){
										editor.setValue(Ext.util.Format.htmlDecode(Ext.getCmp("adv_grid_panel_aa_aa").getSelectionModel().getSelected().get("operator_type_key")));
									}else{
										editor.setValue(Ext.util.Format.htmlDecode(value+""+Ext.getCmp("adv_grid_panel_aa_aa").getSelectionModel().getSelected().get("operator_type_key")));
									}
		
							lookupbox.focus();
							lookupbox.fireEvent("keyUp");
						}
		
						if((lookupbox.getValue()).toLowerCase()=="=".toLowerCase()){
					
							if("numberfield" == "fieldset" || "numberfield" == "tabpanel" || "numberfield" == "hbox" || "numberfield" == "vbox"){
								Ext.getCmp("aa_bb_id").hide();
							}else if("numberfield" == "panel"){
								Ext.getCmp("aa_bb_id").ownerCt.hideTabStripItem("aa_bb_id");
							}else if("numberfield" == "searchheaderfield"){
								Ext.getCmp("aa_bb_searchheaderfield").hide();
							}else{
								if(Ext.getCmp("aa_bb_id").getEl()&&Ext.getCmp("aa_bb_id").getEl().up(".x-form-item")){
									Ext.getCmp("aa_bb_id").getEl().up(".x-form-item").dom.style.display="none";
								}								
							}
						
							if("timefield" == "fieldset" || "timefield" == "tabpanel" || "timefield" == "hbox" || "timefield" == "vbox"){
								Ext.getCmp("aa_ff_id").show();
							}else if("timefield" == "panel"){
								Ext.getCmp("aa_ff_id").ownerCt.unhideTabStripItem("aa_ff_id");
							}else if("timefield" == "searchheaderfield"){
								Ext.getCmp("aa_ff_searchheaderfield").show();
							}else{
								if(Ext.getCmp("aa_ff_id").getEl()&&Ext.getCmp("aa_ff_id").getEl().up(".x-form-item")){
									Ext.getCmp("aa_ff_id").getEl().up(".x-form-item").dom.style.display="block";	
								}
							}	
						}
						if((lookupbox.getValue()).toLowerCase()=="<".toLowerCase()){
					
							if("timefield" == "fieldset" || "timefield" == "tabpanel" || "timefield" == "hbox" || "timefield" == "vbox"){
								Ext.getCmp("aa_ff_id").hide();
							}else if("timefield" == "panel"){
								Ext.getCmp("aa_ff_id").ownerCt.hideTabStripItem("aa_ff_id");
							}else if("timefield" == "searchheaderfield"){
								Ext.getCmp("aa_ff_searchheaderfield").hide();
							}else{
								if(Ext.getCmp("aa_ff_id").getEl()&&Ext.getCmp("aa_ff_id").getEl().up(".x-form-item")){
									Ext.getCmp("aa_ff_id").getEl().up(".x-form-item").dom.style.display="none";
								}								
							}
						
							if("numberfield" == "fieldset" || "numberfield" == "tabpanel" || "numberfield" == "hbox" || "numberfield" == "vbox"){
								Ext.getCmp("aa_bb_id").show();
							}else if("numberfield" == "panel"){
								Ext.getCmp("aa_bb_id").ownerCt.unhideTabStripItem("aa_bb_id");
							}else if("numberfield" == "searchheaderfield"){
								Ext.getCmp("aa_bb_searchheaderfield").show();
							}else{
								if(Ext.getCmp("aa_bb_id").getEl()&&Ext.getCmp("aa_bb_id").getEl().up(".x-form-item")){
									Ext.getCmp("aa_bb_id").getEl().up(".x-form-item").dom.style.display="block";	
								}
							}	
						}
						var actionFlag=1;
						var flag = 1;
		
						if(Ext.getCmp("aa_aa_id")){
							if("aa"=="aa"){
								actionFlag = 1;
								flag=1;
					
								if(Ext.getCmp("aa_aa_id").getValue()==""||Ext.getCmp("aa_aa_id").getValue()==null)
								{
									if(Ext.getCmp("aa_aa_id").getValue()=="0"){
										actionFlag=1;
									}else{
										actionFlag=0;
									}									
								}
						
						if (actionFlag == 1){
							var formPanelCmp=Ext.getCmp("aa_form");
							var flag = 0;
							var form_params = formPanelCmp.getForm().getValues();
							var parameters = new Object();
							for(var p in formValues){
								flag = 0;
								for(var p2 in form_params){
									if(p == p2){
										flag=0;
										break;
									}else{
										flag=1;
									}
								}
								if(flag == 1){
									parameters[p]=formValues[p];
								}									
							}
							 if(formPanelCmp.getForm().isValid()){		
					
					 		formPanelCmp.getForm().submit({
							 	url: "index.cfm?event=dynamicPanel.general.dynDefaultValueAction&default_panel_name=aa&default_trigger_fields=aa&datenow=" + new Date(),
								method: "POST",
								timeout:30000,
								params:parameters,
								failure: function(response,action){
					 
					   		Ext.MessageBox.alert(getResource("failure","aa"),getResource("error","aa"));
										},
										success: function(response,action){	
					  
					  		if(action.result.success == true){
								var resultJson = Ext.util.JSON.decode(action.result.jsonData);		
					  
								if(Ext.getCmp("aa_gg_id")){
									Ext.getCmp("aa_gg_id").setValue(Ext.util.Format.htmlDecode(resultJson.gg));
								}else if(action.result.flag == "E"){
									Ext.Msg.alert(getResource("Warning","aa"),"Change field: <font color='red'>gg </font>is not exists in the form.");
								}
							 
											}else if(action.result.flag == "E"){
												Ext.MessageBox.alert(getResource("error","aa"),action.result.error_msg);
											}
										}
									})
								 }
							}
							}
						}else{
							Ext.Msg.alert(getResource("Warning","aa"),"Trigger Field: <font color='red'>aa </font>is not exists in the form.");
						}		
					  
						 Ext.getCmp("picklist_aa_aa").close();
					},
					comRender:function(_combo){
						_combo.setValue(this.operatorStore.getAt(0).get("pkey"));	
					}
				});
		

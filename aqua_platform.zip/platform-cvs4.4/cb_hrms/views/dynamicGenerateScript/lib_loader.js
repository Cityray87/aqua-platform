/**
 * 
 * 两个参数
 * 	1：需要加载的js文件
 *  2：js加载完成的回调方法
 *  DynLoader.loadScript("ux/test.js", function () {
 *				var win = new _win();
 *				win.show();
 *			});
 */


(function() {
	 
	myLoader = new Object({
		loadFiles:[],
		require:function(url, callback){
			if (!this.contains(this.loadFiles,url)) {
				this.loadFiles.push(url);
				var noCacheUrl = url + ('?_dc'+ '=' + new Date()),
                isCrossOriginRestricted = false,
                xhr, status;
				if (typeof XMLHttpRequest !== 'undefined') {
                    xhr = new XMLHttpRequest();
                } else {
                    xhr = new ActiveXObject('Microsoft.XMLHTTP');
                }

                try {
                    xhr.open('GET', noCacheUrl, false);
                    xhr.send(null);
                } catch (e) {
                    isCrossOriginRestricted = true;
                }

                status = (xhr.status === 1223) ? 204 : xhr.status;

                if (!isCrossOriginRestricted) {
                    isCrossOriginRestricted = (status === 0);
                }

                if (status >= 200 && status < 300) {
                	new Function(xhr.responseText)();
                	callback.call();
                }else{
                	var index = this.loadFiles.indexOf(url);
                	if (index > -1) {
		                this.loadFiles.splice(index, 1);
		            }
                	alert ('An error ocurred while connecting to the server.');
                	if(typeof(maskObj)!="undefined"){
                		maskObj.hide();
                	}
                }
                xhr = null;
			}else {
				callback.call();
			}
		},
		contains:function(array, item) {
        	for (i = 0, ln = array.length; i < ln; i++) {
                if (array[i] === item) {
                    return true;
                }
            }
        }
		
		
	
	});
})()
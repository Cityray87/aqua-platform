 
function getRadioGroupValue(panelName,fieldName){
	var valueList = "";
	var tableObj_id = panelName+'_'+fieldName+'_table';
	var radiogroup = document.getElementById(tableObj_id).getElementsByTagName("input");
	for (var g=0;g<radiogroup.length;g++) {
		if (radiogroup[g].checked) {
			valueList=radiogroup[g].value;
			break;
		}
	}
	return valueList;
} 
 
function getCheckboxGroupValues(panelName,fieldName){
	var valueList = "";
	var tableObj_id = panelName+'_'+fieldName+'_table';
	var radiogroup = document.getElementById(tableObj_id).getElementsByTagName("input");
	for (var g=0;g<radiogroup.length;g++) {
		if (radiogroup[g].checked) {
			valueList=valueList+","+radiogroup[g].value;
		}
	}
	if(valueList=="")
		return "";
	else
		return valueList.substr(1,valueList.length);
}

function findValueFromArray(value,valueArray){
	var flag = false;
	for(var k=0;k<valueArray.length;k++){
			if (value==valueArray[k]) {
				flag = true;
			}
	}
	return flag
}

function setCheckboxGroupValues(panelName,fieldName,valueList){
	var valueArray = valueList.split(",");
	var tableObj_id = panelName+'_'+fieldName+'_table';
	var radiogroup = document.getElementById(tableObj_id).getElementsByTagName("input");
	for (var g=0;g<radiogroup.length;g++) {
		if(findValueFromArray(radiogroup[g].value,valueArray)){
			radiogroup[g].checked=true;
		}else{
			radiogroup[g].checked=false;
		}
	}
}

function URLencodeSingle(sStr) {
	if(typeof(sStr)=="string"){
		return sStr.replace(/\'/g, "chr(single)");
	}else{
		return sStr;
	}
}


function deleteParamListPro(o, c){
    if(o){
        for(var p in c){
			var lower_p = p.toLowerCase();
			delete o[p];
			delete o[lower_p];
        }
    }
    return o;
}


function getPanelVariable(panelName,panelVariableData){
	var panelVariable = new Object();
	for(var j=0;j<panelVariableData.length;j++){
		var sourceFieldListObj = (panelVariableData[j].sourceFieldList).split(",");
		var varSourceFieldListObj = (panelVariableData[j].varSourceFieldList).split(",");
		if(panelVariableData[j].panelType=="editorgridpanel"){
			if(Ext.getCmp(panelVariableData[j].sourcePanelName)){
				var sourcePanelObj = Ext.getCmp((panelVariableData[j].sourcePanelName));
				var selections = sourcePanelObj.getSelectionModel().getSelections();
				if(selections.length>=1){
					var selectedRow = sourcePanelObj.getSelectionModel().getSelections()[0];
					for(var i=0;i<sourceFieldListObj.length;i++){
						if(selectedRow.get(sourceFieldListObj[i])){
							panelVariable[varSourceFieldListObj[i]]=selectedRow.get(sourceFieldListObj[i]);
						}
					}
				}
			}
		}else if(panelVariableData[j].panelType=="advformpanel"){
			for(var i=0;i<sourceFieldListObj.length;i++){
				var sourceFieldId = panelVariableData[j].sourcePanelName+"_"+sourceFieldListObj[i]+"_id";
				if(Ext.getCmp(sourceFieldId)){
					var fieldObj = Ext.getCmp(sourceFieldId);
					if(fieldObj.xtype=="combo"){
						panelVariable[varSourceFieldListObj[i]]=fieldObj.getValue();
					}else if(fieldObj.xtype=="container"){
						if(fieldObj.picklistType=='RADIOGROUP'){
							var tableObj_id = panelVariableData[j].sourcePanelName+'_'+sourceFieldListObj[i]+'_table';
							var radiogroup = document.getElementById(tableObj_id).getElementsByTagName("input");
							for (var g=0;g<radiogroup.length;g++) {
								if (radiogroup[g].checked) {
									panelVariable[varSourceFieldListObj[i]]=radiogroup[g].value;
									break;
								}
							}
						}else{
							panelVariable[varSourceFieldListObj[i]]=getCheckboxGroupValues(panelName,sourceFieldListObj[i]);
						}
					}else if(fieldObj.xtype=="checkbox"){
						if(fieldObj.checked){
							panelVariable[varSourceFieldListObj[i]]=1;
						}else{
							panelVariable[varSourceFieldListObj[i]]=0;
						}
					}else{
						panelVariable[varSourceFieldListObj[i]]=Ext.get(sourceFieldId).dom.value;
					}
				}
			}
		}
	}
	return panelVariable;
}


function dynamicDefaultDetail(panelName,isNeedProgressBar,triggerFields,isOverwriteOriginalValue,changeFields,panelVariableData){
	var formSubmitValues=new Object();
	var globalVariables = new Object();
	var formchecklist="{";
	var formParameterObj=new Object();
	var paramList1 = Ext.getCmp(panelName+"_form").paramList;
	var changeFields=changeFields.split(",");
	Ext.apply(formParameterObj,paramList1);
	globalVariables=getPanelVariable(panelName,panelVariableData);
	Ext.applyIf(formSubmitValues,formParameterObj);
	Ext.applyIf(formSubmitValues,globalVariables);
	formSubmitValues.panel_name=panelName;
	var formPanelCmp=Ext.getCmp(panelName+"_form");
	var checkboxList = Ext.getCmp(panelName+"_form").findByType("checkbox");
	for(var k=0;k<checkboxList.length;k++){
		if(!checkboxList[k].checked){
			formchecklist=formchecklist+checkboxList[k].name+":0,";
		}
		if(k==checkboxList.length-1&&formchecklist!="{"){
			formchecklist=formchecklist.substr(0,formchecklist.length-1)+"}";
		}
	}
	var radiogroupValues = formPanelCmp.find('picklistType','RADIOGROUP');
	var checkboxgroupValues = formPanelCmp.find('picklistType','CHECKBOXGROUP');
	var rfield,rfieldValue;
	for(var s=0;s<radiogroupValues.length;s++){
		rfield=radiogroupValues[s].fieldName;
		rfieldValue=getRadioGroupValue(panelName,rfield);
		formSubmitValues[rfield]=rfieldValue;
	}
	for(var s=0;s<checkboxgroupValues.length;s++){
		rfield=checkboxgroupValues[s].fieldName;
		rfieldValue=getCheckboxGroupValues(panelName,rfield);
		formSubmitValues[rfield]=rfieldValue;
	}
	
	if(formchecklist!="{"){
		Ext.applyIf(formSubmitValues,Ext.decode(formchecklist));
	}
	if(formPanelCmp.getForm().isValid()){
		if(isNeedProgressBar=="1"){
			Ext.MessageBox.wait(getResource("waitMsg",panelName+"_wait"), getResource("waitMsg",panelName+"_wait"), "");
		}
		formSubmitValues.default_panel_name=panelName;
		formSubmitValues.default_trigger_fields=triggerFields;
		Ext.apply(formSubmitValues,formPanelCmp.getForm().getValues());
		Ext.Ajax.request({
		 	url: "index.cfm?event=dynamicPanel.general.dynamicDefaultValueAction&datenow=" + new Date(),
			method: "POST",
			timeout:1000000,
			submitEmptyText:false,
			params:formSubmitValues,
			failure: function(response,options){
				if(isNeedProgressBar=="1"){
					Ext.MessageBox.hide();
				}
				Ext.MessageBox.alert(getResource("failure",panelName),getResource("error",panelName));
			},
			success: function(response,options){
				var result = Ext.util.JSON.decode(response.responseText);
				if(isNeedProgressBar=="1"){
					Ext.MessageBox.hide();
				}
				if(result.success == true){
					var resultJson = result.jsonObject;
					for(var g=0;g<changeFields.length;g++){
						var responseField = (changeFields[g]).toLowerCase();
						var obj = Ext.getCmp(panelName+"_"+changeFields[g]+"_id");
						if(obj){
							if(obj.xtype=="label"){
								Ext.get(panelName+"_"+changeFields[g]+"_id").dom.innerHTML=Ext.util.Format.htmlDecode(resultJson[responseField]);
							}else if(obj.xtype=="container"){
								if(obj.picklistType=='RADIOGROUP'){
									var tableObj_id = panelName+'_'+changeFields[g]+'_table';
									var radiogroup = document.getElementById(tableObj_id).getElementsByTagName("input");
									for (var i=0;i<radiogroup.length;i++) {
										if (radiogroup[i].value==resultJson[responseField]) {
											radiogroup[i].checked=true;
											break;
										}
									}									
								}else{
									setCheckboxGroupValues(panelName,changeFields[g],resultJson[responseField]);
								}								
							}else{
								if(isOverwriteOriginalValue=="1"){
									obj.setValue(Ext.util.Format.htmlDecode(resultJson[responseField]));
								}else{
									if(obj.getValue()=="" || obj.getValue()==null){
										obj.setValue(Ext.util.Format.htmlDecode(resultJson[responseField]));
									}
								}
							}
						}
					}
					eval('Ext.getCmp("'+panelName+'_form").'+panelName+"_setStyle()");
				}
			}
		})
	}					
}


function dynamicFormStyleFeatureDetail(panelName,tagetControlScope,style,targetControl,targetControlType,isReset){
	var styleArray=new Array();
	var targetControlArray = new Array();
	var targetControlTypeArray = new Array();
	var targetControlId;
	styleArray=style.split(";");
	targetControlArray=targetControl.split(",");
	targetControlTypeArray=targetControlType.split(",");
	for(var j=0;j<targetControlArray.length;j++){
		var targetControlObj;
		var subStyleArray=new Array();
		var valueCssStyle=new Object();
		targetControlId = panelName+"_"+targetControlArray[j]+"_id";
		targetControlObj=Ext.getCmp(targetControlId);
		if(styleArray.length>0){
			for(var i=0;i<styleArray.length;i++){
				subStyleArray = styleArray[i].split(":");
				if(subStyleArray.length==2&&subStyleArray[1]!=""){
					if(typeof(targetControlObj)!='undefined') {
						if(isReset=="1"){
							subStyleArray[1]="";
						}
						if(tagetControlScope=="label"||tagetControlScope=="label and value"){
							if(subStyleArray[0]=="backgroundColor"){
								if(targetControlTypeArray[j]=="radiogroup"||targetControlTypeArray[j]=="checkboxgroup"){
									if(document.getElementById(panelName+"_"+targetControlArray[j]+"_table")!=null){
										document.getElementById(panelName+"_"+targetControlArray[j]+"_table").style.backgroundColor=subStyleArray[1];
									}
								}else{
									Ext.query('label[for='+targetControlId+']')[0].style.backgroundColor=subStyleArray[1];
								}
							}else{
								if(targetControlTypeArray[j]=="radiogroup"||targetControlTypeArray[j]=="checkboxgroup"){
									var _id=targetControlId;
									if(isReset=="1"){
										if(subStyleArray[0]=="color"){
											Ext.DomHelper.applyStyles(Ext.get(_id),'color:black');
										}else{
											Ext.DomHelper.applyStyles(Ext.get(_id),subStyleArray[0]+':');	
										}
									}else{
										Ext.DomHelper.applyStyles(Ext.get(_id),subStyleArray[0]+':'+subStyleArray[1]+";");	
									}
								}else{
									try{
									if(subStyleArray[0]=="color")
										targetControlObj.getEl().up(".x-form-item").dom.style.color=subStyleArray[1];
									else if(subStyleArray[0]=="fontSize")
										targetControlObj.getEl().up(".x-form-item").dom.style.fontSize=subStyleArray[1];
									else if(subStyleArray[0]=="textDecoration")
										targetControlObj.getEl().up(".x-form-item").dom.style.textDecoration=subStyleArray[1];
									else if(subStyleArray[0]=="fontStyle")
										targetControlObj.getEl().up(".x-form-item").dom.style.fontStyle=subStyleArray[1];
									else if(subStyleArray[0]=="fontWeight")
										targetControlObj.getEl().up(".x-form-item").dom.style.fontWeight=subStyleArray[1];
									else if(subStyleArray[0]=="align")
										targetControlObj.getEl().up(".x-form-item").dom.style.align=subStyleArray[1];
									else if(subStyleArray[0]=="vAlign")
										targetControlObj.getEl().up(".x-form-item").dom.style.vAlign=subStyleArray[1];
									else if(subStyleArray[0]=="textAlign")
										targetControlObj.getEl().up(".x-form-item").dom.style.textAlign=subStyleArray[1];
									}catch(e){
										alert(targetControlTypeArray[j]+","+targetControlObj.id);
									}
								}
							}
						}
						if(tagetControlScope=="value"||tagetControlScope=="label and value"){
							if(subStyleArray[0]=="backgroundColor")
								valueCssStyle.backgroundImage='url(includes/images/s.gif)';
							valueCssStyle[subStyleArray[0]]=subStyleArray[1];
						}
						if(tagetControlScope=="label and value"&&(subStyleArray[0]=="backgroundColor"||subStyleArray[0]=="align"||subStyleArray[0]=="vAlign")){
							if(targetControlTypeArray[j]=="radiogroup"||targetControlTypeArray[j]=="checkboxgroup"){
								if(document.getElementById(panelName+"_"+targetControlArray[j]+"_table")!=null){
									if(subStyleArray[0]=="backgroundColor"){
										document.getElementById(panelName+"_"+targetControlArray[j]+"_table").style.backgroundColor = subStyleArray[1];
									}else if(subStyleArray[0]=="align"){
										document.getElementById(panelName+"_"+targetControlArray[j]+"_table").firstChild.align = subStyleArray[1];			
										document.getElementById(panelName+"_"+targetControlArray[j]+"_table").style.align = subStyleArray[1];
									}else{
										document.getElementById(panelName+"_"+targetControlArray[j]+"_table").firstChild.vAlign = subStyleArray[1];		
										document.getElementById(panelName+"_"+targetControlArray[j]+"_table").style.vAlign = subStyleArray[1];
									}
								}
							}else{
								if(typeof(targetControlObj)!='undefined'&&typeof(document.getElementById(targetControlObj.ownerCt.id).firstChild.firstChild)!='undefined'&&document.getElementById(targetControlObj.ownerCt.id).parentNode.className=='x-table-layout-cell'){
									if(subStyleArray[0]=="backgroundColor"){
										document.getElementById(targetControlObj.ownerCt.id).parentNode.style.backgroundColor = subStyleArray[1];
										document.getElementById(targetControlObj.ownerCt.id).firstChild.firstChild.style.backgroundColor = subStyleArray[1];
									}else if(subStyleArray[0]=="align"){
										document.getElementById(targetControlObj.ownerCt.id).parentNode.align = subStyleArray[1];			
										document.getElementById(targetControlObj.ownerCt.id).firstChild.firstChild.style.align = subStyleArray[1];
									}else{
										document.getElementById(targetControlObj.ownerCt.id).parentNode.vAlign = subStyleArray[1];		
										document.getElementById(targetControlObj.ownerCt.id).firstChild.firstChild.style.vAlign = subStyleArray[1];
									}
								}
							}
						}
					}
				}
			}
			if(typeof(targetControlObj)!='undefined'){
				if(tagetControlScope=="value"||tagetControlScope=="label and value"){
					try{
						targetControlObj.el.setStyle(valueCssStyle);
					}catch(e){
						console.log(targetControlId);
					}
				}
			}
		}
	}
}


function addDynamicFormStyleFeature(panelName,dynStyleData){
	for(var i=0;i<dynStyleData.length;i++){
		var _value;
		var fieldId="";
		var fieldValue="";
		_value=dynStyleData[i].value;		
		fieldId=panelName+"_"+dynStyleData[i].controlName+"_id";
		if(typeof(Ext.getCmp(fieldId))!="undefined"){
			if(dynStyleData[i].controlType=="htmlcontrol"){
				fieldValue = Ext.get(fieldId).dom.innerHTML;
			}else if(dynStyleData[i].controlType=="radiogroup"||dynStyleData[i].controlType=="checkboxgroup"){
				if(Ext.getCmp(fieldId).picklistType=="RADIOGROUP"){
					var tableObj_id = panelName+'_'+dynStyleData[i].controlName+'_table';
					var radiogroup = document.getElementById(tableObj_id).getElementsByTagName("input");
					for (var j=0;j<radiogroup.length;j++) {
						if (radiogroup[j].checked) {
							fieldValue=radiogroup[j].value;
							break;
						}
					}				
				}else{
					fieldValue=getCheckboxGroupValues(panelName,dynStyleData[i].controlName);
				}				
			}else{
				fieldValue = Ext.getCmp(fieldId).getValue();
			}
			if(dynStyleData[i].operator=="like"){
				if(fieldValue.indexOf(_value)!=-1){
					dynamicFormStyleFeatureDetail(panelName,dynStyleData[i].tagetControlScope,dynStyleData[i].style,dynStyleData[i].targetControl,dynStyleData[i].targetControlType,"0");
				}else{
					dynamicFormStyleFeatureDetail(panelName,dynStyleData[i].tagetControlScope,dynStyleData[i].style,dynStyleData[i].targetControl,dynStyleData[i].targetControlType,"1");
				}
			}else if(dynStyleData[i].operator=="<>"){
				if(fieldValue != _value){
					dynamicFormStyleFeatureDetail(panelName,dynStyleData[i].tagetControlScope,dynStyleData[i].style,dynStyleData[i].targetControl,dynStyleData[i].targetControlType,"0");
				}else{
					dynamicFormStyleFeatureDetail(panelName,dynStyleData[i].tagetControlScope,dynStyleData[i].style,dynStyleData[i].targetControl,dynStyleData[i].targetControlType,"1");
				}
			}else if(dynStyleData[i].operator=="=="){
				if(fieldValue == _value){
					dynamicFormStyleFeatureDetail(panelName,dynStyleData[i].tagetControlScope,dynStyleData[i].style,dynStyleData[i].targetControl,dynStyleData[i].targetControlType,"0");
				}else{
					dynamicFormStyleFeatureDetail(panelName,dynStyleData[i].tagetControlScope,dynStyleData[i].style,dynStyleData[i].targetControl,dynStyleData[i].targetControlType,"1");
				}
			}else if(dynStyleData[i].operator==">"){
				if(fieldValue > _value){
					dynamicFormStyleFeatureDetail(panelName,dynStyleData[i].tagetControlScope,dynStyleData[i].style,dynStyleData[i].targetControl,dynStyleData[i].targetControlType,"0");
				}else{
					dynamicFormStyleFeatureDetail(panelName,dynStyleData[i].tagetControlScope,dynStyleData[i].style,dynStyleData[i].targetControl,dynStyleData[i].targetControlType,"1");
				}
			}else if(dynStyleData[i].operator=="<"){
				if(fieldValue < _value){
					dynamicFormStyleFeatureDetail(panelName,dynStyleData[i].tagetControlScope,dynStyleData[i].style,dynStyleData[i].targetControl,dynStyleData[i].targetControlType,"0");
				}else{
					dynamicFormStyleFeatureDetail(panelName,dynStyleData[i].tagetControlScope,dynStyleData[i].style,dynStyleData[i].targetControl,dynStyleData[i].targetControlType,"1");
				}
			}else if(dynStyleData[i].operator==">="){
				if(fieldValue >= _value){
					dynamicFormStyleFeatureDetail(panelName,dynStyleData[i].tagetControlScope,dynStyleData[i].style,dynStyleData[i].targetControl,dynStyleData[i].targetControlType,"0");
				}else{
					dynamicFormStyleFeatureDetail(panelName,dynStyleData[i].tagetControlScope,dynStyleData[i].style,dynStyleData[i].targetControl,dynStyleData[i].targetControlType,"1");
				}
			}else if(dynStyleData[i].operator=="<="){
				if(fieldValue <= _value){
					dynamicFormStyleFeatureDetail(panelName,dynStyleData[i].tagetControlScope,dynStyleData[i].style,dynStyleData[i].targetControl,dynStyleData[i].targetControlType,"0");
				}else{
					dynamicFormStyleFeatureDetail(panelName,dynStyleData[i].tagetControlScope,dynStyleData[i].style,dynStyleData[i].targetControl,dynStyleData[i].targetControlType,"1");
				}
			}
			
		}
	}
}
 

function addPicklistFilterEvent(panelName,fieldName,isNeedFormData){
	var paramListObj = new Object();
	var formValues = new Object();
	var panelObj = Ext.getCmp(panelName+"_form");
	var fieldObj = Ext.getCmp(panelName+"_"+fieldName+"_id");
	Ext.apply(paramListObj,panelObj.paramList);
	var checkboxList = Ext.getCmp(panelName+"_form").findByType("checkbox");
	for(var k=0;k<checkboxList.length;k++){
		if(!checkboxList[k].checked){
			paramListObj[checkboxList[k].name]="0";
		}
	}
	if(isNeedFormData=="1"||isNeedFormData=="2"){
		formValues=panelObj.getForm().getValues();
		var checkboxList = Ext.getCmp(panelName+"_form").findByType("checkbox");
		for(var k=0;k<checkboxList.length;k++){
			if(!checkboxList[k].checked){
				formValues[checkboxList[k].name]="0";
			}
		}
		var radiogroupValues = panelObj.find('picklistType','RADIOGROUP');
		var checkboxgroupValues = panelObj.find('picklistType','CHECKBOXGROUP');
		var rfield,rfieldValue;
		for(var s=0;s<radiogroupValues.length;s++){
			rfield=radiogroupValues[s].fieldName;
			rfieldValue=getRadioGroupValue(panelName,rfield);
			formValues[rfield]=rfieldValue;
		}
		for(var s=0;s<checkboxgroupValues.length;s++){
			rfield=checkboxgroupValues[s].fieldName;
			rfieldValue=getCheckboxGroupValues(panelName,rfield);
			formValues[rfield]=rfieldValue;
		}
		Ext.apply(paramListObj,formValues);
	}
	if(isNeedFormData=="1"||isNeedFormData=="0"){
		if(fieldObj.xtype == "checkbox"){
			if(fieldObj.checked){
				paramListObj.field_value=1;
			}else{
				paramListObj.field_value=0;
			}
		}else if(fieldObj.xtype=="container"){
			if(fieldObj.picklistType=='RADIOGROUP'){
				var tableObj_id = panelName+'_'+fieldName+'_table';
				var radiogroup = document.getElementById(tableObj_id).getElementsByTagName("input");
				for (var i=0;i<radiogroup.length;i++) {
					if (radiogroup[i].checked) {
						paramListObj.field_value=radiogroup[i].value;
					}
				}									
			}else{
				paramListObj.field_value=getCheckboxGroupValues(panelName,fieldName);
			}
		}else{
			paramListObj.field_value=fieldObj.getValue();
		}
		paramListObj.field_name=fieldName;
		paramListObj.panel_name=panelName;
		Ext.Ajax.request({
			method:"post",
			url: "index.cfm?event=dynamicGenerateScript.dynamicGenerateScript.getPicklistFilterData&&now=" + new Date(),
			params:paramListObj,
			failure: function(response,options){
				Ext.MessageBox.alert(getResource("failure",panelName),"failure");
			},
			success: function(response,options){
				var responseText = Ext.util.JSON.decode(response.responseText);
				var jsfunction = new Function(responseText.success_msg);
				jsfunction();
			}
		});
	}else{
		paramListObj.panel_name=panelName;
		Ext.Ajax.request({
			method:"post",
			url: "index.cfm?event=dynamicGenerateScript.dynamicGenerateScript.getPanelPicklistFilterData&&now=" + new Date(),
			params:paramListObj,
			failure: function(response,options){
				Ext.MessageBox.alert(getResource("failure",panelName),"failure");
			},
			success: function(response,options){
				var responseText = Ext.util.JSON.decode(response.responseText)
				var jsfunction = new Function(responseText.success_msg);
				jsfunction();
			}
		});
	}	
}


function dynmaicHelpDetail(panelName,isAutoShow,winTitleI18n,winWidth,winHeight){
	var helpButton = new Ext.Button({
		text:typeof(getResource)!='undefined'?getResource('help',panelName):'Help',
		icon:'../ext/resources/images/icons/help.png',
		isAutoShow:isAutoShow,
		panelName:panelName,
		winTitleI18n:""+winTitleI18n,
		winWidth:winWidth,
		winHeight:winHeight,
		listeners:{
			'render':function(_btn){
				if(this.isAutoShow == "1"){
					_btn.fireEvent('click',_btn);
				}
			},
			'click':function(){
				var winTitleI18n = this.winTitleI18n;
				var winWidth = this.winWidth;
				var winHeight = this.winHeight;
				var panelName = this.panelName;
				if(Ext.getCmp(panelName+"_help_win")){
					Ext.getCmp(panelName+"_help_win").show();
				}else{
					Ext.Ajax.request({
						method:"POST",
						url:'index.cfm?event=dynamicPanel.general.getHelpContentByPanelName&now='+new Date(),
						params:{
							panel_name:panelName
						},
						success:function(response,options){
							var result = Ext.util.JSON.decode(response.responseText);
							var titleArray = (winTitleI18n).split("@");
							var _winTitle;
							if(titleArray.length == 2){
								_winTitle = typeof(getResource)!='undefined'?getResource(titleArray[0],titleArray[1]):'Title';
							}else if(titleArray.length == 1){
								_winTitle = typeof(getResource)!='undefined'?getResource(titleArray[0],panelName):'Title';
							}else{
								_winTitle = typeof(getResource)!='undefined'?getResource("help",panelName):'Help';
							}
							if(result.success==true){
								var resultJson = result.jsonObject.contentList;
								var contentData = resultJson.data;
								if(resultJson.recordcount>0){
									var _mywin_help = Ext.extend(Ext.Window, {
										constructor : function(_cfg) {
											if (_cfg == null) {_cfg == {};} 
											Ext.apply(this, _cfg);
											if (contentData.length  > 1) {
												this.bbar = new Ext.Toolbar({
													enableOverflow: true,
													items: [{
														text: typeof(getResource)!='undefined'?getResource('previous_help',panelName):'Previous Help',
														disabled:true,
														icon:'../ext/resources/images/icons/previous.png',
														id:panelName+'_prev',
														handler:function(_btn){
															var wizard=Ext.getCmp(panelName+'_help_win').layout;
															var currentItem = parseInt(Ext.getCmp(wizard.activeItem.id).number,10);
															if(currentItem == 2){
																wizard.setActiveItem(0);
																_btn.setDisabled(true);
															}else{
																wizard.setActiveItem(currentItem-2);
															}
															if(Ext.getCmp(panelName+'_next').disabled){
																Ext.getCmp(panelName+'_next').setDisabled(false);	
															}
														}
													},'->',{
														text: typeof(getResource)!='undefined'?getResource('next_help',panelName):'Next Help',
														id:panelName+'_next',
														iconAlign:'right',
														icon:'../ext/resources/images/icons/next.png',
														handler:function(_btn){
															var wizard=Ext.getCmp(panelName+'_help_win').layout;
															var currentItem = parseInt(Ext.getCmp(wizard.activeItem.id).number,10);
															if(currentItem == contentData.length-1){
																wizard.setActiveItem(contentData.length-1);
																_btn.setDisabled(true);
															}else{
																wizard.setActiveItem(currentItem);
															}
															if(Ext.getCmp(panelName+'_prev').disabled){
																Ext.getCmp(panelName+'_prev').setDisabled(false);	
															}
														}
													}]
												})
											}
											_mywin_help.superclass.constructor.call(this, {
												title:_winTitle,
												iconCls:typeof(getResource)!='undefined'?'userHelp':'',
												id:panelName+'_help_win',
												width:winWidth,
												height:winHeight,
												activeItem:0,
												constrainHeader:true,
												collapsible:true,
												x:window.parent.document.body.clientWidth-winWidth,
												y:0,
												layout:'card',
												defaults:{
													border:false  
									            }
											});
										},
										listeners:{
											'render':function(_win){
												if(contentData.length>0){
													for(var i = 0;i<contentData.length;i++){
														_win.add({
															id:panelName+'_'+contentData[i].page_no,
															number:contentData[i].page_no,
															padding:'10px',
															autoScroll:true,
															html:Ext.util.Format.htmlDecode(contentData[i].help_content+'<br/>')
														});
													}
												}
											}
										}
									});
									new _mywin_help().show();
								}else{
									Ext.Msg.show({
									   title: typeof(getResource)!='undefined'?getResource('_help_data_error_title',panelName):'Title',
									   msg:  typeof(getResource)!='undefined'?getResource('_help_data_error',panelName):'Data Error!',
									   buttons: Ext.Msg.OK,
									   animEl: 'elId',
									   icon: Ext.MessageBox.WARNING
									});
								}
							}else{
								Ext.Msg.show({
										   title: typeof(getResource)!='undefined'?getResource('_help_data_error_title',panelName):'Title',
										   msg:  typeof(getResource)!='undefined'?getResource('_help_data_error',panelName):'Data Error!',
										   buttons: Ext.Msg.OK,
										   animEl: 'elId',
										   icon: Ext.MessageBox.WARNING
								});
							}
						},
						failure:function(response,options){
							Ext.Msg.show({
							   title: typeof(getResource)!='undefined'?getResource('_help_data_error_title',panelName):'Title',
							   msg: typeof(getResource)!='undefined'?getResource('_help_data_error',panelName):'Data Error!',
							   buttons: Ext.Msg.OK,
							   animEl: 'elId',
							   icon: Ext.MessageBox.WARNING
							});
						}
					})
				}
			}
		}
	})
	return helpButton;
}


function formClientSideValidation(panelName, validData, eventName) {
	var error_msg = "";
	if (validData != "") {
		var validDataArray = validData.split("}{");
		var len = validDataArray.length;
		validDataArray[0] = validDataArray[0].substring(1,
				validDataArray[0].length);
		validDataArray[len - 1] = validDataArray[len - 1].substring(0,
				validDataArray[len - 1].length - 1);
		var formArray = new Array();
		function getformArrayObject(vData) {
			var formArrayObj = new Object();
			var vDataArray = vData.split("],[");
			var vlen = vDataArray.length;
			var value = "";
			var this_field = "";
			vDataArray[0] = vDataArray[0].substring(1, vDataArray[0].length);
			vDataArray[vlen - 1] = vDataArray[vlen - 1].substring(0,
					vDataArray[vlen - 1].length - 1);
			formArrayObj.event_names = vDataArray[0];
			formArrayObj.field_names = vDataArray[1];
			formArrayObj.valid_rule = vDataArray[2];
			formArrayObj.error_msg = vDataArray[3];
			formArrayObj.error_msg_desc = eval(vDataArray[4]);
			Ext.getCmp(panelName + "_form").getForm().items.each(function(f) {
						if (f.xtype == "datefield") {
							value = f.formatDate(f.getValue());
						}else if(f.xtype == "container"){
							if(f.picklistType=='RADIOGROUP'){
								var tableObj_id = panelName+'_'+f.fieldName+'_table';
								var radiogroup = document.getElementById(tableObj_id).getElementsByTagName("input");
								for (var g=0;g<radiogroup.length;g++) {
									if (radiogroup[g].checked) {
										value = radiogroup[g].value;
										break;
									}
								}								
							}else{
								value=getCheckboxGroupValues(panelName,f.fieldName);
							}
						} else {
							value = f.getValue();
						}
						this_field = "this." + f.name;
						formArrayObj.error_msg_desc = (formArrayObj.error_msg_desc)
								.replace(new RegExp("''" + this_field + "''",
												"gm"), "''" + value + "''");
					});
			return formArrayObj;
		}
		for (var i = 0; i < len; i++) {
			formArray[i] = getformArrayObject(validDataArray[i]);
		}
		for (var n = 0; n < formArray.length;) {
			if (formArray[n].event_names != ""
					&& formArray[n].event_names != eventName) {
				if (formArray.length == 1) {
					formArray = new Array();
				} else {
					formArray = formArray.slice(0, n).concat(formArray.slice(n
									+ 1, formArray.length));
					n = 0;
				}
			} else {
				n = n + 1;
			}
		}
		for (var i = 0; i < formArray.length; i++) {
			var args = new Array();
			var valid_rule;
			var obj;
			fieldArray = formArray[i].field_names.split(",");
			for (var j = 0; j < fieldArray.length; j++) {
				obj = Ext.getCmp(panelName + "_" + fieldArray[j] + "_id");
				if (obj.xtype == "datefield") {
					args[j] = obj.formatDate(obj.getValue());
				}else if(obj.xtype == "container"){
					if(obj.picklistType=='RADIOGROUP'){
						var tableObj_id = panelName+'_'+obj.fieldName+'_table';
						var radiogroup = document.getElementById(tableObj_id).getElementsByTagName("input");
						for (var g=0;g<radiogroup.length;g++) {
							if (radiogroup[g].checked) {
								args[j] = radiogroup[g].value;
								break;
							}
						}								
					}else{
						args[j]=getCheckboxGroupValues(panelName,obj.fieldName);
					}
				} else {
					if(typeof(obj.getValue())=='undefined'){
						args[j]="";
					}else{
						args[j] = obj.getValue().toString();
					}
				}
				args[j] = args[j].replace(/\r\n/g, " ");
				args[j] = args[j].replace(/\n/g, " ");
				args[j] = args[j].replace(new RegExp('"', "gm"), '\\"');
				args[j] = args[j].replace(new RegExp("'", "gm"), "\\'");
				fieldArray[j] = "this." + fieldArray[j];
			}
			valid_rule = formArray[i].valid_rule;
			for (var j = 0; j < fieldArray.length; j++) {
				valid_rule = valid_rule.replace(new RegExp("'" + fieldArray[j]
										+ "'", "gm"), "'" + args[j] + "'");
			}
			var jsFunction = new Function("args", valid_rule);
			var result = jsFunction(args);
			if (result == false) {
				if (error_msg.length > 0)
					error_msg = error_msg + "<hr>"
							+ formArray[i].error_msg_desc;
				else
					error_msg = error_msg + formArray[i].error_msg_desc;
			}
		}
	}
	if (error_msg != "") {
		Ext.MessageBox
				.alert(
						"<img width=20 height=20 src='../ext/resources/images/default/window/icon-error.gif'>"
								+ getResource("valid_title_error",panelName), error_msg);
		return 0;
	} else {
		return 1;
	}
}


function panelActionReload(reloadParam,sourceSels){
	var source_panel_name = reloadParam.source_panel_name;
	var source_panel_type = reloadParam.source_panel_type;
	var source_panel_action = reloadParam.source_panel_action;
	var target_panel_name = reloadParam.target_panel_name;
	var target_panel_type = reloadParam.target_panel_type;
	var pageMenuKey = reloadParam.pageMenuKey ;
	var sourceFieldName = reloadParam.sourceFieldName;
	var target_is_tab = reloadParam.target_is_tab ;
	var sourcePanel = reloadParam.sourcePanel;
	var winObj_action = Ext.getCmp(reloadParam.winObj_action);
	var grid_ds_key = reloadParam.t_grid_ds_key;
	var sourceValueList =new Object();
	var checkNodes = new Array();
	var gridKeyList = new Array();
	var targetPanel;
	var globalVariablesData;
	eval('var globalVariables = sourcePanel.'+source_panel_name+'_globalVariable');
	if(source_panel_type == "advformpanel"){
		sourceValueList = sourcePanel.getForm().getFieldValues();
	}else if(source_panel_type == "editorgridpanel"){
		if(source_panel_action == "rowselect"){
			checkNodes = sourcePanel.getSelectionModel().getSelections();
			for (var i = 0; i < checkNodes.length; i++) {
				eval('gridKeyList.push(checkNodes[i].data.'+grid_ds_key+')');
			}
			eval('sourceValueList.'+grid_ds_key+' = gridKeyList.toString()');
		}else if(source_panel_action == "rowclick"){
			if (sourcePanel.getColumnModel().isCellEditable(sourcePanel.columnIndex,sourcePanel.rowIndex)|| sourcePanel.is_allow_edit == 0) {
				return
			}
			sourceValueList = sourcePanel.getSelectionModel().getSelected().data;
		}else{
			if (sourcePanel.getColumnModel().isCellEditable(sourcePanel.columnIndex,sourcePanel.rowIndex)|| sourcePanel.is_allow_edit == 0) {
				return
			}
			if(typeof(sourcePanel.getSelectionModel().getSelected())!= "undefined"){
				sourceValueList = sourcePanel.getSelectionModel().getSelected().data;	
			}
		}
	}else if(source_panel_type == "treegridpanel"){
		if(source_panel_action == "nodeclick"){
			sourceValueList = sourceSels.attributes;
		}else if(source_panel_action == "nodecheck"){
			checkNodes = sourcePanel.getChecked();
			for (var i = 0; i < checkNodes.length; i++) {
				eval('gridKeyList.push(checkNodes[i].attributes.'+grid_ds_key+')');
			}
			eval('sourceValueList.'+grid_ds_key+' = gridKeyList.toString()');
		}
	}
	globalVariablesData = getPanelVariable(source_panel_name,globalVariables);
	Ext.applyIf(sourceValueList,globalVariablesData);
	if(target_panel_type == "advformpanel"){
		if(typeof(Ext.getCmp(target_panel_name+'_form'))!="undefined"){
			var paramList = Ext.getCmp(target_panel_name+'_form').paramList;
			Ext.apply(paramList,sourceValueList);
			
			if(target_is_tab=="true"){
				var targetParentPanel = Ext.getCmp(target_panel_name+'_parentPanel');
				if(targetParentPanel!=undefined){
					if(typeof(winObj_action)!='undefined'){
						maskObj = new Ext.LoadMask(winObj_action.getEl(), {msg:getResource('loading','')});
					}else{
						maskObj = new Ext.LoadMask(Ext.getBody(), {msg:getResource('loading','')});
					}
					if(targetParentPanel.ownerCt.getActiveTab()==targetParentPanel){
						if(null!=maskObj&&maskObj!=undefined){
							maskObj.show();
						}
						Ext.getCmp(target_panel_name+'_form').getForm().getEl().dom.reset();
						eval('pageMenuKey.'+target_panel_name+'_loadFormData()');
					}
			 	}
			}else{
				if(typeof(winObj_action)!='undefined'){
					maskObj = new Ext.LoadMask(winObj_action.getEl(), {msg:getResource('loading','')});
				}else{
					maskObj = new Ext.LoadMask(Ext.getBody(), {msg:getResource('loading','')});
				}
				if(null!=maskObj&&maskObj!=undefined){
					maskObj.show();
				}
				Ext.getCmp(target_panel_name+'_form').getForm().getEl().dom.reset();
				eval('pageMenuKey.'+target_panel_name+'_loadFormData()');
			}
		}
	}

	else if(target_panel_type == "editorgridpanel" || target_panel_type == "treegridpanel"){
		if(typeof(Ext.getCmp(target_panel_name))!="undefined"){
			var targetGridPanel = Ext.getCmp(target_panel_name);
			var paramList ;
			var baseParams ;
			if(target_panel_type == "editorgridpanel"){
				paramList = targetGridPanel.getStore().paramList;
			}
			else{
				paramList = targetGridPanel.getLoader().baseParams;
			}
			if(typeof(winObj_action)!='undefined'){
				maskPanelAction = new Ext.LoadMask(winObj_action.getEl(), {msg:getResource('loading','')});
			}else{
				maskPanelAction = new Ext.LoadMask(Ext.getBody(), {msg:getResource('loading','')});
			}
			maskPanelAction.show();
			if(target_panel_type == "editorgridpanel"){
				baseParams = targetGridPanel.getStore().baseParams;
			}else{
				baseParams = targetGridPanel.getLoader().baseParams;
			}
			
			Ext.apply(baseParams,paramList);
			Ext.apply(baseParams,sourceValueList);
			targetGridPanel.hideLoadingMask = true;
			if(target_panel_type == "editorgridpanel"){
				targetGridPanel.getStore().baseParams=baseParams;
				targetGridPanel.getStore().load();
				targetGridPanel.getStore () .on('load',function(){
					  if(maskPanelAction){
	                   		maskPanelAction.hide();
	                  }
				})
			}
			else{
				targetGridPanel.getLoader().baseParams=baseParams;
				targetGridPanel.getRootNode().reload();
				targetGridPanel.getLoader().on('load',function(){
					  if(maskPanelAction){
	                   		maskPanelAction.hide();
	                  }
				})
			}
		}
	}

	else if(target_panel_type == "chartpanel"){
		targetPanel = Ext.getCmp(target_panel_name);
	}
	
	/******************************* Calendar ********************************/
	else if(target_panel_type == "calendarpanel"){
		if(typefof(Ext.getCmp(target_panel_name))!="undefined"){
			var targetCalendarPanel = Ext.getCmp(target_panel_name);
			var baseParams ;
			var paramList = targetCalendarPanel.getStore().paramList;
			if(typeof(winObj_action)!='undefined'){
				maskPanelAction = new Ext.LoadMask(winObj_action.getEl(), {msg:getResource('loading','')});
			}else{
				maskPanelAction = new Ext.LoadMask(Ext.getBody(), {msg:getResource('loading','')});
			}
			maskPanelAction.show();
			baseParams = targetCalendarPanel.getStore().baseParams;
			Ext.apply(baseParams,paramList);
			Ext.apply(baseParams,sourceValueList);
			targetCalendarPanel.hideLoadingMask = true;
			targetCalendarPanel.getStore().baseParams=baseParams;
			targetCalendarPanel.getStore().load();
			targetCalendarPanel.getStore().on('load',function(){
				  if(maskPanelAction){
	               		maskPanelAction.hide();
	              }
			})
		}
	}
}


function dynamicPanelAction(panelActionDatas){
	var source_panel_name,source_panel_action,target_panel_action;
	var source_panel_type;
	var target_panel_name;
	var target_panel_type;
	var pageMenuKey;
	var winObj_action;
	var t_grid_ds_key;
	var target_is_tab;
	var sourceFieldName;
	var sourcePanel;
	var _listeners_action;
	var paramStr;
	var source_field_name;
	var source_event_name;
	for(var i=0;i<panelActionDatas.length;i++){
		source_panel_name = panelActionDatas[i].source_panel_name;
		source_panel_type = panelActionDatas[i].source_panel_type;
		source_panel_action = panelActionDatas[i].source_panel_action;
		target_panel_name = panelActionDatas[i].target_panel_name;
		target_panel_type = panelActionDatas[i].target_panel_type;
		target_panel_action = panelActionDatas[i].target_panel_action;
		pageMenuKey = Ext.getCmp('page_'+panelActionDatas[i].menu_key);
		if(typeof(pageMenuKey) == "undefined"){
			winObj_action = "undefined";
		}else{
			winObj_action = pageMenuKey.paramList.win_id;
		}
		t_grid_ds_key = panelActionDatas[i].t_grid_ds_key;
		target_is_tab = panelActionDatas[i].t_is_tab;
		paramStr = 'panelActionParam_'+i+'.source_panel_name = source_panel_name;panelActionParam_'+i+'.source_panel_type = source_panel_type;panelActionParam_'+i+'.target_panel_name = target_panel_name;panelActionParam_'+i+'.target_panel_type = target_panel_type;panelActionParam_'+i+'.pageMenuKey = pageMenuKey;panelActionParam_'+i+'.sourceFieldName = sourceFieldName;panelActionParam_'+i+'.target_is_tab = target_is_tab;panelActionParam_'+i+'.sourcePanel = sourcePanel;panelActionParam_'+i+'.winObj_action = winObj_action;panelActionParam_'+i+'.t_grid_ds_key = t_grid_ds_key;';
		eval('var panelActionParam_'+i+' = new Object();');
		
		if(panelActionDatas[i].source_panel_action == "afterevent"){
			source_event_name = panelActionDatas[i].source_event_name;
			target_event_name = panelActionDatas[i].target_event_name;
			eval('panelActionParam_'+i+'.source_event_name = source_event_name;');
			eval('panelActionParam_'+i+'.target_event_name = target_event_name;');
			eval('panelActionParam_'+i+'.target_is_tab = target_is_tab;');
			eval('panelActionParam_'+i+'.target_panel_action = target_panel_action;');
			if(source_panel_type == "advformpanel"){
				sourceFieldName = Ext.getCmp(source_panel_name+'_'+source_field_name+'_id');
				sourcePanel = Ext.getCmp(source_panel_name+'_form');
			}else if (source_panel_type == "chartpanel"){
				sourcePanel = Ext.getCmp(source_panel_name+'_chart_panel');
			}else{
				sourcePanel = Ext.getCmp(source_panel_name);
			}
			eval(paramStr);
			if(source_panel_action == "afterevent"){
				if(target_panel_action == "reload"){
					eval('panelActionReload(panelActionParam_'+i+',null)');
				}else if(target_panel_action == "enable" || target_panel_action == "disable"){
					eval('cascadeSetAble(panelActionParam_'+i+')');
				}else if(target_panel_action == "activate"){
					eval('cascadeSetActivate(panelActionParam_'+i+')');
				}else if(target_panel_action == "fireevent"){
					eval('cascadeFireEvent(panelActionParam_'+i+')');
				}
			}
		}else{
			source_field_name =  panelActionDatas[i].source_field_name;
			if(source_panel_type == "advformpanel"){
				sourceFieldName = Ext.getCmp(source_panel_name+'_'+source_field_name+'_id');
				sourcePanel = Ext.getCmp(source_panel_name+'_form');
				eval(paramStr);
				if((source_panel_action == "picklistselect"  || 
					source_panel_action == "focus" || 
					source_panel_action == "blur"  ||
					source_panel_action == "keyup"  ||
					source_panel_action == "keydown"  ||
					source_panel_action == "keypress"  ||
					source_panel_action == "change"
				) && target_panel_action == "reload"){
					if(source_panel_action == "blur"){
						_listeners_action = 'blur';
					}else if(source_panel_action == "focus"){
						_listeners_action = 'focus';
					}else if(source_panel_action == "keyup"){
						_listeners_action = 'keyup';
					}else if(source_panel_action == "keydown"){
						_listeners_action = 'keydown';
					}else if(source_panel_action == "keypress"){
						_listeners_action = 'keypress';
					}else if(source_panel_action == "change"){
						_listeners_action = 'change';
					}else{
						if(sourceFieldName.xtype == 'radiogroup' || sourceFieldName.xtype == 'checkboxgroup')
						{
							_listeners_action = 'change';	
						}else if(sourceFieldName.xtype == 'trigger'){
							_listeners_action = 'keyUp';
						}
						else{
							_listeners_action = 'select';	
						}
					}
					if(sourceFieldName.xtype == 'container'){
						var tableObj_id = source_panel_name+'_'+sourceFieldName.fieldName+'_table';
						var radiogroup = document.getElementById(tableObj_id).getElementsByTagName("input");
						for (var f=0;f<radiogroup.length;f++) {
							if(window.addEventListener){
								eval('radiogroup[f].addEventListener("click",function(comb){panelActionReload(panelActionParam_'+i+',null);},sourceFieldName,panelActionParam_'+i+');');	
							}else{
								eval('radiogroup[f].attachEvent("onclick",function(comb){panelActionReload(panelActionParam_'+i+',null);},sourceFieldName,panelActionParam_'+i+');');
							}
						}
					}else{
						eval('sourceFieldName.on("'+_listeners_action+'",function(comb){panelActionReload(panelActionParam_'+i+',null);},sourceFieldName,panelActionParam_'+i+');');
					}
				}
			}
			else if (source_panel_type == "editorgridpanel"){
				sourcePanel = Ext.getCmp(source_panel_name);
				eval(paramStr);
				eval('panelActionParam_'+i+'.source_panel_action = source_panel_action;');
				if((source_panel_action == "rowclick" ||
					source_panel_action == "mousedown" ||
					source_panel_action == "mouseup" ||
					source_panel_action == "rowselect" ||
					source_panel_action == "rowmousedown"
				) && target_panel_action == "reload"){
					if(source_panel_action == "rowclick"){
						_listeners_action = 'rowclick';
					}else if(source_panel_action == "mousedown"){
						_listeners_action = 'mousedown';
					}else if(source_panel_action == "mouseup"){
						_listeners_action = 'mouseup';
					}else if(source_panel_action == "rowselect"){
						_listeners_action = 'rowselect';
					}else{
						_listeners_action = 'rowmousedown';
					}
					if(_listeners_action == 'rowselect'){
						eval('sourcePanel.getSelectionModel().on("'+_listeners_action+'",function(row){panelActionReload(panelActionParam_'+i+',null);},sourceFieldName,panelActionParam_'+i+');')
					}else{
						eval('sourcePanel.on("'+_listeners_action+'",function(row){panelActionReload(panelActionParam_'+i+',null);},sourceFieldName,panelActionParam_'+i+');');
					}
				}
			}
			else if (source_panel_type == "treegridpanel"){
				sourcePanel = Ext.getCmp(source_panel_name);
				var nodeList = new Array();
				eval(paramStr);
				eval('panelActionParam_'+i+'.source_panel_action = source_panel_action;');
				if((source_panel_action == "nodeclick" ||
					source_panel_action == "nodecheck"
				) && target_panel_action == "reload"){
					if(source_panel_action == "nodeclick"){
						_listeners_action = 'click';
					}else{
						_listeners_action = 'checkchange';
					}
					eval('sourcePanel.on("'+_listeners_action+'",function(node){panelActionReload(panelActionParam_'+i+',node);},sourceFieldName,panelActionParam_'+i+');');
				}
			}
			else if (source_panel_type == "chartpanel"){
				
			}
			/******************************* Calendar ********************************/
			else if (source_panel_type == "calendarpanel"){
				sourcePanel = Ext.getCmp(source_panel_name);
				eval(paramStr);
				eval('panelActionParam_'+i+'.source_panel_action = source_panel_action;');
				if((source_panel_action == "dayclick" ||
					source_panel_action == "eventclick"
				)  && target_panel_action == "reload"){
					if(source_panel_action == "dayclick"){
						_listeners_action = 'dayclick';
					}else if(source_panel_action == "eventclick"){
						_listeners_action = 'eventclick';
					}
					eval('sourcePanel.calendar.on("'+_listeners_action+'",function(node){panelActionReload(panelActionParam_'+i+',node);},sourceFieldName,panelActionParam_'+i+');');
				}
			}
		}
		
	}
}


function cascadeFireEvent(fireEventParam){
	var target_panel_name = fireEventParam.target_panel_name;
	var target_panel_type = fireEventParam.target_panel_type;
	var target_event_name = fireEventParam.target_event_name;
	var targetPanel;
	if(target_panel_type == "advformpanel"){
		targetPanel = Ext.getCmp(target_panel_name+'_form');
	}else if(target_panel_type == "chartpanel"){
		targetPanel = Ext.getCmp(target_panel_name+'_chart_panel');
	}else{
		targetPanel = Ext.getCmp(target_panel_name);
	}
	if(typeof(targetPanel) != "undefined"){
		eval('targetPanel.event_'+target_event_name+'()');
	}
}


function cascadeSetAble(ableParam){
	var target_panel_name = ableParam.target_panel_name;
	var target_panel_type = ableParam.target_panel_type;
	var target_panel_action = ableParam.target_panel_action;
	var targetPanel;
	var targetParentPanel;
	var action_flag;
	if(target_panel_action == "enable"){
		action_flag = false;
	}
	else{
		action_flag = true;
	}
	targetParentPanel = eval('Ext.getCmp('+target_panel_name+'_parentPanel)');
	if(target_panel_type == "advformpanel"){
		targetPanel = Ext.getCmp(target_panel_name+'_form');
	}else if(target_panel_type == "chartpanel"){
		targetPanel = Ext.getCmp(target_panel_name+'_chart_panel');
	}else{
		targetPanel = Ext.getCmp(target_panel_name);
	}
	
	if(typeof(targetParentPanel)!="undefined"){
		targetParentPanel.setDisabled(action_flag);
	}else{
		targetPanel.setDisabled(action_flag);
	}
}


function cascadeSetActivate(activateParam){
	var target_panel_name = activateParam.target_panel_name;
	var target_panel_type = enableParam.target_panel_type;
	var target_is_tab = activateParam.target_is_tab;
	var targetParentPanel;
	if(target_is_tab == true || target_is_tab == 1){
		targetParentPanel = eval('Ext.getCmp('+target_panel_name+'_parentPanel)');
		if(typeof(targetParentPanel)!="undefined"){
			targetParentPanel.ownerCt.activate(targetParentPanel);
		}
	}
	
}

function loadProperty(panelName,jsonPro,formValues,formSubmitValues){
	var winObj = Ext.getCmp(Ext.getCmp(panelName+"_form").paramList.win_id);
	var _grid = Ext.getCmp(panelName+'_form').paramList.grid;
	if(jsonPro.isCloseWindowAfterAction == "1"){
		if(typeof(winObj)!='undefined'){winObj.close();}
	}else{
		if(jsonPro.resetFormAfterSuccess == "1"){Ext.getCmp(panelName+"_form").getForm().reset();}
	}
	
	if(jsonPro.isRequireReloadGrid == "1"){
		if(typeof(_grid)!='undefined'){
			if(_grid.xtype == 'treepanel'){
				reloadTreePanelByNode(_grid,_grid.currentNodeParent,_grid.treeLoaderType);
				_grid.getLoader().on("load",function(){
					var jsfunction = new Function("formPanelCmp","formValues","formSubmitValues",jsonPro.afterSuccessJs);
					jsfunction(Ext.getCmp(panelName+'_form'),formValues,formSubmitValues);
					dynamicPanelAction(jsonPro.panelActionDataArray);
				});
			}else{
				var count = 0;
				_grid.getStore().reload();
				_grid.store.on('load',function(){
					if(count == 0){
						var jsfunction = new Function("formPanelCmp","formValues","formSubmitValues",jsonPro.afterSuccessJs);
						jsfunction(Ext.getCmp(panelName+'_form'),formValues,formSubmitValues);
						dynamicPanelAction(jsonPro.panelActionDataArray);
					}
					count++;
				});
			}
		}
	}else{
		var jsfunction = new Function("formPanelCmp","formValues","formSubmitValues",jsonPro.afterSuccessJs);
		jsfunction(Ext.getCmp(panelName+'_form'),formValues,formSubmitValues);
		dynamicPanelAction(jsonPro.panelActionDataArray);
	}
}


function loadFormHandlerType(panelName,eventName,jsonPro,panelVariable){
	var globalVariables = panelVariable;
	var formchecklist='{';
	var formParameterObj=new Object();	
	var formObj = Ext.getCmp(panelName+'_form');
	var paramList1 = formObj.paramList;
	Ext.apply(formParameterObj,paramList1);
	var formValues = new Object();
	formValues = formObj.getForm().getValues();
	formValues.p_name=panelName;
	var formSubmitValues=new Object();
	formSubmitValues.p_name = panelName;
	Ext.applyIf(formValues,formParameterObj);
	formValues.panel_name=panelName;
	if(jsonPro.predefinedValues != ""){
		Ext.apply(formSubmitValues,Ext.decode("{"+jsonPro.predefinedValues+"}"));
		Ext.apply(formValues,Ext.decode("{"+jsonPro.predefinedValues+"}"));
	}
	Ext.applyIf(formSubmitValues,formParameterObj);
	Ext.applyIf(formValues,globalVariables);
	Ext.applyIf(formSubmitValues,globalVariables);
	formValues.event_name=eventName;
	formValues.panel_name=panelName;
	formSubmitValues.panel_name=panelName;
	formSubmitValues=deleteParamListPro(formSubmitValues,formObj.getForm().getFieldValues());
	formSubmitValues=deleteParamListPro(formSubmitValues,formObj.getForm().getValues());
	var checkboxList = formObj.findByType('checkbox');
	for(var j=0;j<checkboxList.length;j++){
		if(!checkboxList[j].checked){
			if(formchecklist == '{') {
				formchecklist = formchecklist+checkboxList[j].name + ':0}';
			}else{
				formchecklist = formchecklist.substr(0,formchecklist.length - 1)+ ',' + checkboxList[j].name + ':0}';
			}
		}
		if(j==checkboxList.length-1&&formchecklist!='{'){
			formchecklist=formchecklist.substr(0,formchecklist.length-1)+'}';
		}
	}
	var radiogroupValues = formObj.find('picklistType','RADIOGROUP');
	var checkboxgroupValues = formObj.find('picklistType','CHECKBOXGROUP');
	var rfield,rfieldValue;
	for(var s=0;s<radiogroupValues.length;s++){
		rfield=radiogroupValues[s].fieldName;
		rfieldValue=getRadioGroupValue(panelName,rfield);
		if(rfieldValue==""){
			formValues[rfield]=rfieldValue;
			formSubmitValues[rfield]=rfieldValue;
		}
	}
	for(var s=0;s<checkboxgroupValues.length;s++){
		rfield=checkboxgroupValues[s].fieldName;
		rfieldValue=getCheckboxGroupValues(panelName,rfield);
		if(rfieldValue==""){
			formValues[rfield]=rfieldValue;
			formSubmitValues[rfield]=rfieldValue;
		}
	}
	
	if(formchecklist!='{'){
		Ext.apply(formValues,Ext.decode(formchecklist));
		Ext.apply(formSubmitValues,Ext.decode(formchecklist));
	}
	formValues.panel_name=panelName;
	formSubmitValues.panel_name=panelName;
	if(jsonPro.handlerType=="POPUP"){
		var obj = Ext.getCmp(panelName+"_"+eventName+"_win_popUp_parent");
		if(typeof(obj)!="undefined"&&jsonPro.actionHandlerEvent==""){
			maskObj = new Ext.LoadMask(obj.getEl(),{msg:getResource("loading","")});
			maskObj.show();
			formValues.win_id=panelName+"_"+eventName+"_win_popUp_parent";
			Ext.apply(Ext.getCmp("page_"+jsonPro.dynPageName).paramList,formValues);
			Ext.getCmp("page_"+jsonPro.dynPageName).fireEvent("render",Ext.getCmp("page_"+jsonPro.dynPageName));
			obj.show();
		}else{
			var windowItem;
			var windowString;
			var _win;
			var winWidth;
			var winHeight;
			formValues.win_id=panelName+"_"+eventName+"_win_popUp_parent";
			if(jsonPro.winWidth == "0"){
				winWidth=window.parent.document.body.clientWidth;
			}else{
				winWidth=parseInt(jsonPro.winWidth);
			}

			if(jsonPro.winHeight == "0"){
				winHeight=window.parent.document.body.clientWidth;
			}else{
				winHeight=parseInt(jsonPro.winHeight);
			}

			if(jsonPro.actionHandlerEvent!=""){
				_win = new Ext.Window({
					manager:windows,
					modal:true,
					id:panelName+"_"+eventName+"_win_popUp_parent",
					bodyStyle: 'background: #fff;',
					constrainHeader:true,
					autoscroll: true,
					autoLoad: {
						url: 'index.cfm?event='+jsonPro.actionHandlerEvent+'&datenow=' + new Date(),
						params:formValues,
						scripts: true
					},
					width:(winWidth>window.parent.document.body.clientWidth?window.parent.document.body.clientWidth : winWidth),
					minWidth:(winWidth>window.parent.document.body.clientWidth ? window.parent.document.body.clientWidth : winWidth),
					height:(winHeight > window.parent.document.body.clientHeight ? window.parent.document.body.clientHeight : winHeight),
					minHeight:(winHeight > window.parent.document.body.clientHeight ? window.parent.document.body.clientHeight : winHeight)
				});
				if(eval(jsonPro.winTitleI18n)!=""){
					_win.setTitle(eval(jsonPro.winTitleI18n));
				}
				_win.show();
			}else{
				var jsFile = "views/dynamicGenerateScript/page_"+jsonPro.dynPageName+".js";
				myLoader.require(jsFile,function(){destroy_key_list.push(panelName+"_"+eventName+"_win_popUp_parent");
					windowString = "windowItem = new page_"+jsonPro.dynPageName+"({paramList:formValues})";
					eval(windowString);

					_win = new Ext.Window({
						manager:windows,
						modal:true,
						id:panelName+"_"+eventName+"_win_popUp_parent",
						bodyStyle: 'background: #fff;',
						constrainHeader:true,
						jsonPro:jsonPro,
						autoscroll: true,
						layout:"fit",
						items:[windowItem],
						width:(winWidth>window.parent.document.body.clientWidth?window.parent.document.body.clientWidth : winWidth),
						minWidth:(winWidth>window.parent.document.body.clientWidth ? window.parent.document.body.clientWidth : winWidth),
						height:(winHeight > window.parent.document.body.clientHeight ? window.parent.document.body.clientHeight : winHeight),
						minHeight:(winHeight > window.parent.document.body.clientHeight ? window.parent.document.body.clientHeight : winHeight),
						listeners:{
							scope:this,
							beforehide:function(){
								if(jsonPro.isNeedConfirmDirtyData == "1"){
									if(validateDataFlag == 1){
										Ext.Msg.confirm(getResource('confirm_title',''),getResource('confirm_msg','confirm_modify_data'),function(_btn){
											if(_btn=='no'){
												return false;
											}else{
												validateDataFlag = 0;
												Ext.getCmp(jsonPro.panelName+"_"+jsonPro.eventName+"_win_popUp_parent").close();
											}
										});
										return false;
									}
								}
							},
							beforeclose:function(){
								if(jsonPro.isNeedConfirmDirtyData == "1"){
									if(validateDataFlag == 1){
										Ext.Msg.confirm(getResource('confirm_title',''),getResource('confirm_msg','confirm_modify_data'),function(_btn){
											if(_btn=='no'){
												return false;
											}else{
												validateDataFlag = 0;
												Ext.getCmp(jsonPro.panelName+"_"+jsonPro.eventName+"_win_popUp_parent").close();
											}
										});
										return false;
									}
								}
							}
						}
					});
					if(eval(jsonPro.winTitleI18n)!=""){
						_win.setTitle(eval(jsonPro.winTitleI18n));
					}
					_win.show();
				})
			}
		}
	}else if(jsonPro.handlerType=="IOEXPORT"){
		formValues.grid_panel_name="";
		if(jsonPro.gridPanelName!=""){
			formValues.grid_panel_name = jsonPro.gridPanelName;
			if(Ext.getCmp(jsonPro.gridPanelName).getStore().baseParams.sql_where){
				formValues._grid_sql_where = Ext.getCmp(jsonPro.gridPanelName).getStore().baseParams.sql_where;
			}else{
				formValues._grid_sql_where = " and 1=1";
			}
		}
		formValues.export_type=jsonPro.rptFormat;
		var urlEvent = "index.cfm?event=nio.nio.export";
		for(var p in formValues){
			if(p=="sql_where"){
				urlEvent = urlEvent + "&" + p + "=" + encodeURIComponent(formValues[p]);
			}
		}
		var report_form = new  Ext.form.FormPanel({
			    renderTo:'_report-out',
			    name:panelName+'_export',
			    id:panelName+'_exportForm',
		        frame: true,
		        collapsible:true,
		        labelAlign:'right',
		        buttonAlign:'center',
		        autoHeight: true,items:[{}]
			});
		for(var i in formValues){
			if(i!="sql_where"){
				var textfield = new Ext.form.TextField({
					name:i,
					value:formValues[i],
					xtype:'textfield'
				});
				report_form.insert(0,textfield);
			}
		}
		report_form.doLayout();
		report_form.getForm().getEl().dom.method='POST';
		report_form.getForm().getEl().dom.action=urlEvent;
		report_form.getForm().getEl().dom.submit();
	}else if(jsonPro.handlerType=="IOIMPORT"){
		var io_formValues = new Object();
		for(var p in  formValues){
			if(typeof(formValues[p])!="object"){
				io_formValues[p]=formValues[p];
			}
		}
		var popWin = new Ext.Window({
			manager:windows,
			resizable:false,
			manager:windows,
			modal:true,
			id:"#arguments.panel_name#_#event_name#_win_popUp_parent",
			bodyStyle: "background: #fff;",
			autoscroll: true,
			autoLoad: {
				url:"index.cfm?event=nio.nio.importMain&datenow=" + new Date().getTime(), 
				params:{
					parameter:Ext.encode(io_formValues),
					event_name:eventName,
					p_name:panelName,
					panel_name:panelName
				},
				nocache:true,
				scripts:true,
				timeout:1000000
			},
			width:800,
			height:585
		}).show();
	}else if(jsonPro.handlerType=="BACKGROUND"){
		formSubmitValues.grid_panel_name='';
		if(jsonPro.gridPanelName != ""){
			formSubmitValues.grid_panel_name = jsonPro.gridPanelName;
			if(Ext.getCmp(jsonPro.gridPanelName).getStore().baseParams.sql_where){
				formSubmitValues._grid_sql_where = Ext.getCmp(jsonPro.gridPanelName).getStore().baseParams.sql_where;
			}else{
				formSubmitValues._grid_sql_where = ' and 1=1';
			}
		}
		var url="";
		if(jsonPro.actionHandlerEvent !=""){
			url = "index.cfm?event="+jsonPro.actionHandlerEvent+"&datenow="+new Date();
		}else{
			url = "index.cfm?event=dynamicGrid.general.dynamicGridBackGround&datenow="+new Date();
		}
		formSubmitValues.event_name=eventName;
		formSubmitValues.prefix_name=panelName+"_"+eventName;
		var formPanelCmp=Ext.getCmp(panelName+'_form');
		formSubmitValues.is_validate=1;
		if(formPanelCmp.getForm().isValid()){
			formPanelCmp.getForm().submit({
				waitMsg:getResource('waitMsg',panelName+'_wait'),
				timeout:30000000,
			 	submitEmptyText:false,
			 	params:formSubmitValues,
			 	url:url,
			 	method:"POST",
			 	failure: function(response,action){
			 		Ext.MessageBox.hide();
			 		Ext.MessageBox.alert(getResource('failure',panelName),getResource('error',panelName));
			 	},success: function(response,action){
					Ext.MessageBox.hide();
					if(action.result.flag == 'S'){
						validateDataFlag=0;
						if(jsonPro.isRequireSuccessTip == "1"){
							Ext.MessageBox.alert(getResource('success',panelName),action.result.success_msg,function(){
								loadProperty(panelName,jsonPro,formValues,formSubmitValues);
							})
						}else{
							loadProperty(panelName,jsonPro,formValues,formSubmitValues);
						}
					}else if(action.result.flag == 'E'){
						Ext.MessageBox.alert("<img width=20 height=20 src='../ext/resources/images/default/window/icon-error.gif'>"+getResource('error',panelName),action.result.error_msg);
					}else if(action.result.flag == 'C'){
						Ext.MessageBox.confirm(getResource('confirm',panelName),action.result.confirm_msg,function(_btn){
							if(_btn == 'yes'){
								formSubmitValues.is_validate=0;
								formPanelCmp.getForm().submit({
									waitMsg:getResource('waitMsg',panelName+'_wait'),
									timeout:30000000,
								 	submitEmptyText:false,
								 	params:formSubmitValues,
								 	url:url,
								 	method:"POST",
								 	failure: function(response,action){
								 		Ext.MessageBox.hide();
								 		Ext.MessageBox.alert(getResource('failure',panelName),getResource('error',panelName));
								 	},success: function(response,action){
										Ext.MessageBox.hide();
										if(action.result.flag == 'S'){
											validateDataFlag=0;
											if(jsonPro.isRequireSuccessTip == "1"){
												Ext.MessageBox.alert(getResource('success',panelName),action.result.success_msg,function(){
													loadProperty(panelName,jsonPro,formValues,formSubmitValues);
												})
											}else{
												loadProperty(panelName,jsonPro,formValues,formSubmitValues);
											}
										}else if(action.result.flag == 'E'){
											Ext.MessageBox.alert("<img width=20 height=20 src='../ext/resources/images/default/window/icon-error.gif'>"+getResource('error',panelName),action.result.error_msg);
										}
								 	}
								})										
							}
						})
					}
				}
			});
		}
	}else if(jsonPro.handlerType=="REDIRECT"){
		var winObj = Ext.getCmp(Ext.getCmp(panelName+"_form").paramList.win_id);
		if(typeof(winObj)!="undefined"){
			targetComp = winObj;
		}else{
			targetComp = Ext.getCmp("contentPanel");
		}
		if(jsonPro.actionHandlerEvent != ""){
			targetComp.removeAll();
			targetComp.getUpdater().update({
				url:"index.cfm?event="+jsonPro.actionHandlerEvent+"&datenow=" + new Date(),
				params:formValues,
				nocache:true,
				scripts:true,
				timeout:30000
			})
		}else{
			targetComp.removeAll();
			var jsFile = "views/dynamicGenerateScript/page_"+jsonPro.dynPageName+".js";
			myLoader.require(jsFile,function(){
				destroy_key_list.push("page_"+jsonPro.dynPageName);
				var obj = eval("new page_"+jsonPro.dynPageName+"({paramList:formValues})");
				targetComp.add(obj);
			},this,true);
		}
		targetComp.doLayout();
	}else if(jsonPro.handlerType=="JAVASCRIPT"){
		var jsfunction = new Function("formValues","formSubmitValues",jsonPro.handlerJs);
		jsfunction(formValues,formSubmitValues);
		var _grid = Ext.getCmp(panelName+'_form').paramList.grid;
		var winObj = Ext.getCmp(Ext.getCmp(panelName+'_form').paramList.win_id);
		if(jsonPro.isCloseWindowAfterAction == "1"){
			winObj.close();
		}
		if(jsonPro.isRequireReloadGrid=="1"){
			if(typeof(_grid)!='undefined'){
				if(_grid.xtype == 'treepanel'){
					_grid.getRootNode().reload();
				}else{
					if(jsonPro.isCloseWindowAfterAction=="0"){
						_grid.store.reload();
					}
				}
			}
		}
	}else if(jsonPro.handlerType=="WORKFLOW"){
		formSubmitValues.grid_panel_name = '';
		var url;
		if(jsonPro.gridPanelName != ""){
			formSubmitValues.grid_panel_name = jsonPro.gridPanelName;
			if(Ext.getCmp(jsonPro.gridPanelName).getStore().baseParams.sql_where){
				formSubmitValues._grid_sql_where = Ext.getCmp(jsonPro.gridPanelName).getStore().baseParams.sql_where;
			}else{
				formSubmitValues._grid_sql_where = ' and 1=1';
			}
		}
		formSubmitValues.event_name=eventName;
		var formPanelCmp=Ext.getCmp(panelName+'_form');
		if(formPanelCmp.getForm().isValid()){
		 	formSubmitValues.is_validate=1;
		 	if(jsonPro.isWorkFlowStart == "1"){
		 		formSubmitValues.process_key=jsonPro.workFlowProcessKey;
			 	formSubmitValues.wf_table=jsonPro.wfTable;
			 	url="index.cfm?event=workFlow.jbpm.initWorkflow&datenow=" + new Date();
		 	}else{
		 		url="index.cfm?event=workFlow.jbpm.performTask&datenow=" + new Date();
		 	}
		 	formSubmitValues.panel_name = panelName;
			formPanelCmp.getForm().submit({
				submitEmptyText:false,
				waitMsg:getResource('waitMsg',panelName+'_wait'),
				method:"POST",
				url:url,
				params:formSubmitValues,
				failure: function(response,action){
					Ext.MessageBox.hide();
					Ext.MessageBox.alert(getResource('failure',panelName),action.result.message);
				},
				success: function(response,action){
					Ext.MessageBox.hide();
					if(action.result.success == true){
						if(action.result.flag&&action.result.flag=='E'){
							Ext.MessageBox.alert("<img width=20 height=20 src='../ext/resources/images/default/window/icon-error.gif'>"+getResource('error',panelName),action.result.error_msg);
						}else if(action.result.flag&&action.result.flag=='C'){
							Ext.MessageBox.confirm(getResource('confirm',panelName),action.result.confirm_msg,function(_btn){
								if(_btn == 'yes'){
									formSubmitValues.is_validate=0;
									if(jsonPro.isWorkFlowStart == "1"){
								 		formSubmitValues.process_key=jsonPro.workFlowProcessKey;
									 	formSubmitValues.wf_table=jsonPro.wfTable;
									 	url="index.cfm?event=workFlow.jbpm.initWorkflow&datenow=" + new Date();
								 	}else{
								 		url="index.cfm?event=workFlow.jbpm.performTask&datenow=" + new Date();
								 	}
								 	formPanelCmp.getForm().submit({
										submitEmptyText:false,
										waitMsg:getResource('waitMsg',panelName),
										url:url,
										method: 'POST',
										params:formSubmitValues,
										failure: function(response,action){
											Ext.MessageBox.hide();
											Ext.MessageBox.alert(getResource('failure',panelName),action.result.message);
										},
										success: function(response,action){
											Ext.MessageBox.hide();
											if(action.result.success == true){
												if(action.result.flag&&action.result.flag=='E'){
													Ext.MessageBox.alert("<img width=20 height=20 src='../ext/resources/images/default/window/icon-error.gif'>"+getResource('error',panelName),action.result.error_msg);
												}else{
													validateDataFlag=0;
													if(jsonPro.isRequireSuccessTip=="1"){
														Ext.MessageBox.alert(getResource('success',panelName),getResource('save_success',panelName),function(){
															loadProperty(panelName,jsonPro,formValues,formSubmitValues);
														})
													}else{
														loadProperty(panelName,jsonPro,formValues,formSubmitValues);
													}
												}
											}else if(action.result.success == false){
												Ext.MessageBox.alert("<img width=20 height=20 src='../ext/resources/images/default/window/icon-error.gif'>"+getResource('error',panelName),action.result.message);
											}
										}
								 	})
								}
							})
						}else{
							validateDataFlag=0;
							if(jsonPro.isRequireSuccessTip=="1"){
								Ext.MessageBox.alert(getResource('success',panelName),getResource('save_success',panelName),function(){
									loadProperty(panelName,jsonPro,formValues,formSubmitValues);
								})
							}else{
								loadProperty(panelName,jsonPro,formValues,formSubmitValues);
							}
						}
					}else if(action.result.success == false){
						Ext.MessageBox.alert("<img width=20 height=20 src='../ext/resources/images/default/window/icon-error.gif'>"+getResource('error',panelName),action.result.message);
					}
				}
			})
		}
	}else if(jsonPro.handlerType=="COLDFUSION"){
		var formPanelCmp=Ext.getCmp(panelName+'_form');
		if(formPanelCmp.getForm().isValid()){
			formPanelCmp.getForm().submit({
				submitEmptyText:false,
		 		waitMsg:getResource('waitMsg',panelName+'_wait'),
	 			url: 'index.cfm?event=dynamicCF.general.'+eventName+'&datenow=' + new Date(),
				method: 'POST',
				params:formSubmitValues,
				failure: function(response,action){
					Ext.MessageBox.hide();
					Ext.MessageBox.alert(getResource('failure',panelName),getResource('error',panelName));
				},
				success: function(response,action){
					Ext.MessageBox.hide();
					if(action.result.flag == 'S'){
						if(jsonPro.isRequireSuccessTip=="1"){
							Ext.MessageBox.alert(getResource('success',panelName),getResource('save_success',panelName),function(){
								loadProperty(panelName,jsonPro,formValues,formSubmitValues);
							})
						}else{
							loadProperty(panelName,jsonPro,formValues,formSubmitValues);		
						}
					}else if(action.result.flag == 'E'){
						Ext.MessageBox.alert("<img width=20 height=20 src='../ext/resources/images/default/window/icon-error.gif'>"+getResource('error',panelName),action.result.error_msg);
					}
				}
 			})
		}
	}else if(jsonPro.handlerType=="REPORT"){
		var formPanelCmp=Ext.getCmp(panelName+'_form');
		for(var i in formValues){
			formValues[i]=Ext.getCmp(panelName+'_form').URLencode(formValues[i]);
		}
		var url_event= '';
		var rpt_format = '';
		var rpt_form;
		if(jsonPro.rptFormat==''){
			if(typeof(Ext.getCmp(panelName+'_rpt_format_id'))=='undefined'){
				Ext.MessageBox.alert(getResource('error',panelName),getResource('rpt_format_notexists',panelName));
			}else{
				rpt_format = Ext.getCmp(panelName+'_rpt_format_id').getValue();
			}
		}else{
			rpt_format = jsonPro.rptFormat;
		}
		if(formPanelCmp.getForm().isValid()){
			if(rpt_format == 'xls' && jsonPro.isHtmlXls == '1'){
					url_event='index.cfm?event=rpt.report.report.runReportForExcel&rpt_number='+jsonPro.rptNumber+'&is_validate=0&currentPanel='+panelName+'&datenow=' + new Date();
					url_event=url_event + '&rpt_format=' + rpt_format;
					rpt_form = Ext.getCmp(panelName+'_form');
					for(var i in formValues){
						Ext.getCmp(panelName+'_form').insertWithin(panelName+'_form',i,formValues[i]);
					}
					rpt_form.getForm().getEl().dom.action=url_event;
					rpt_form.getForm().getEl().dom.submit();
			}else{
				url_event='index.cfm?event=rpt.report.report.runReport&is_validate=0&currentPanel='+panelName+'&rpt_number='+jsonPro.rptNumber+'&datenow=' + new Date();
				Ext.MessageBox.wait(getResource('waitMsg',panelName+'_wait'),getResource('redirectToReport','dynaGrid'),'');
				Ext.getCmp(panelName+'_form').getForm().submit({
					url: url_event,
					submitEmptyText:false,
					success: function (form, action) {
						var flag = action.result.flag;
						var width = Ext.getCmp('contentPanel').getWidth() - 2;
						var height = Ext.getCmp('contentPanel').getHeight() - 29;var c = Ext.getCmp('contentPanel');
						formValues.width=width;
						formValues.height=height;
						formValues.currentPanel=panelName;
						formValues.rpt_format=rpt_format;
						formValues.rpt_number=jsonPro.rptNumber;
						if(flag == 'S'){
							Ext.MessageBox.hide();
							if(typeof(Ext.getCmp(panelName+'_form').paramList.win_obj)!='undefined'){
								Ext.getCmp(panelName+'_form').paramList.win_obj.close();
							}
							if(formValues.rpt_format=='xls'){
								Ext.getCmp('hiddenPanel').getUpdater().update({
									url: 'index.cfm?event=rpt.report.report.runReportPage&datenow=' + new Date(),
									params:formValues,
									nocache: true,
									scripts: true,
									timeout: 1000000
								});
							}else if(jsonPro.rptPageType=='MAIN_PANEL'){
								c.getUpdater().update({
									url: 'index.cfm?event=rpt.report.report.runReportPage&datenow=' + new Date(),
									params:formValues,
									nocache: true,
									scripts: true,
									timeout: 1000000
								});
							}else{
								var popWin = new Ext.Window({modal:true,
									manager:windows,
									id:panelName+'_window',
									bodyStyle: 'background: #fff;',
									autoscroll: true,
									autoLoad: { 
										url: 'index.cfm?event=rpt.report.report.runReportPage&datenow=' + new Date(),
										params:formValues,
										scripts: true 
									} ,
									width:width,
									height:height,
									dummp:true
								}).show();
							}
						}else if(flag == 'E'){
							Ext.MessageBox.hide();
							Ext.MessageBox.alert("<img width=20 height=20 src='../ext/resources/images/default/window/icon-error.gif'>"+getResource('error',panelName), action.result.error_msg);
						}
					}
				})
			}
		}
	}else if(jsonPro.handlerType=="DATAREFRESH"){
		var target_panel_name_list = (jsonPro.targetPanelName).split(",");
		var target_panel_type_list = (jsonPro.targetPanelType).split(",");
		for (var k=0;k < target_panel_name_list.length; k++){
			if(target_panel_type_list[k] == 'editorgridpanel'||'#lcase(trim(target_panel_type_list[k]))#' == 'chartpanel'){
				if(Ext.getCmp(target_panel_name_list[k])){
					formValues.sql_where = '';
					var baseParams = Ext.getCmp(target_panel_name_list[k]).store.baseParams;
					Ext.apply(baseParams,formValues);
					formValues.panel_name=target_panel_name_list[k];
					Ext.getCmp(target_panel_name_list[k]).store.baseParams=baseParams;
					Ext.getCmp(target_panel_name_list[k]).store.load();
				}
			}else if(target_panel_type_list[k] == 'advformpanel'){
				if(Ext.getCmp(target_panel_name_list[k]+'_form')){
					formValues.panel_name=target_panel_name_list[k];
					formValues.gridPanelName='';
					Ext.apply(Ext.getCmp(target_panel_name_list[k]+'_form').paramList,formValues);
					maskObj = new Ext.LoadMask(Ext.getCmp('page_'+jsonPro.menuKey).getEl(), {msg:getResource('loading','')});
					maskObj.show();
					eval("Ext.getCmp('page_"+jsonPro.menuKey+"')."+target_panel_name_list[k]+"_loadFormData()");
				}
			}
		}
	}
}


function dynamicFormPanelEvent(panelName,eventName,jsonPro,panelVariable){
	setActionLog(panelName,eventName);
	if(jsonPro.isRequireConfirmation == "1"){
		Ext.MessageBox.confirm(getResource('Confirm',''),eval(jsonPro.confirmMessage),function(_btn){
			if(_btn=="yes"){
				if(jsonPro.isRequireValidation == "1"){
					if(eval('Ext.getCmp("'+panelName+'_form").'+panelName+'_clientSideValidation("'+eventName+'")')){
						loadFormHandlerType(panelName,eventName,jsonPro,panelVariable);
					}
				}else{
					loadFormHandlerType(panelName,eventName,jsonPro,panelVariable);
				}
			}
		});
	}else{
		if(jsonPro.isRequireValidation == "1"){
			if(eval('Ext.getCmp("'+panelName+'_form").'+panelName+'_clientSideValidation("'+eventName+'")')){
				loadFormHandlerType(panelName,eventName,jsonPro,panelVariable);
			}
		}else{
			loadFormHandlerType(panelName,eventName,jsonPro,panelVariable);
		}
	}
}


function loadGridHandlerType(e,panelName,eventName,jsonPro,panelVariable,paramList){
	var obj = Ext.getCmp(panelName);
	if(jsonPro.predefinedValues != ""){
		var predefinedValues = "{"+jsonPro.predefinedValues+"}";
		Ext.apply(paramList,Ext.decode(predefinedValues));	
	}
	Ext.apply(paramList,panelVariable);
	paramList.gridPanelName=panelName;
	paramList.panel_name=panelName;
	if(jsonPro.handlerType=="EDITGRID_SAVE"){
		if(jsonPro.gridPanelName != ""){
			paramList.grid_panel_name = jsonPro.gridPanelName;
			if(Ext.getCmp(jsonPro.gridPanelName).getStore().baseParams.sql_where){
				paramList._grid_sql_where = Ext.getCmp(jsonPro.gridPanelName).getStore().baseParams.sql_where;
			}else{
				paramList._grid_sql_where = " and 1=1";
			}
		}
		var rec = e.record; 
		var url_event="index.cfm?event=dynamicEditgrid.editgrid.saveEditgrid";
		var columnListArray = (jsonPro.columnList).split(",");
		var t_array = new Array();
		var s_store = obj.getSelectionModel();
		var sr_array = s_store.getSelections();
		for (var j = 0; j < s_store.getCount(); j++) {
			s = obj.getStore().indexOf(sr_array[j]);
			t_array[s] = sr_array[j];
		}
		for(var i=0;i<t_array.length;i++){
			if(typeof(t_array[i])!=="undefined"){
				for(var j=0;j<columnListArray.length;j++){
					if(obj.getColumnModel().isCellEditable(j,i)&&obj.getColumnModel().getCellEditor(j,i).field.xtype=="datefield"){
						paramList[columnListArray[j]] =Ext.util.Format.date(t_array[i].data[columnListArray[j]],'Y-m-d');
					}else{
						paramList[columnListArray[j]]=String(rec.get(columnListArray[j])).replace(new RegExp('&lt;', 'g'),'<').replace(new RegExp('&gt;', 'g'),'>');
					}
				}
			}
		
		}
		paramList.mode="E";
		paramList.save_type=jsonPro.saveType;
		paramList.currentPanel=panelName;
		paramList.event_name=eventName;
		Ext.Ajax.request({
			url:url_event+"&is_validate=1&datenow=" + new Date(),
			method: "POST",
			params: paramList,								
			success: function (response, opts) {
				var winObj = Ext.getCmp(obj.paramList.win_id);
				var result = Ext.util.JSON.decode(response.responseText);
				var flag =  result.flag;
				var requestConfig = {
					url: url_event + "&is_validate=0",
					method:"POST",
					waitMsg:getResource("saving",""),
					params: paramList,
					success: function (response, opts) {
						var result =  Ext.util.JSON.decode(response.responseText);
						var flag =  result.flag;
						if(flag == "S"){
							var count = 0;
							var record = obj.getSelectionModel().getSelected();
							var index = obj.store.indexOf(record);
							obj.getStore().reload();
							obj.getStore().on('load',function(){
								if(count == 0){
									var jsfunction = new Function(jsonPro.afterSuccessJs);
									jsfunction();
									obj.getSelectionModel().selectRow(index);
									dynamicPanelAction(jsonPro.panelActionDataArray);
									if(jsonPro.isCloseWindowAfterAction=="1"){
										if(typeof(winObj)!='undefined'){
											winObj.close();
										}
									}
								}
								count++;
							})
						}else if(flag == "E"){
							Ext.MessageBox.alert(getResource("Error",""), result.error_msg);
						}
					}
				}
				if(flag=="S"){
					var count = 0;
					var record = obj.getSelectionModel().getSelected();
					var index = obj.store.indexOf(record);
					obj.getStore().reload();
					obj.getStore().on('load',function(){
						if(count == 0){
							var jsfunction = new Function(jsonPro.afterSuccessJs);
							jsfunction();
							obj.getSelectionModel().selectRow(index);
							dynamicPanelAction(jsonPro.panelActionDataArray);
							if(jsonPro.isCloseWindowAfterAction=="1"){
								if(typeof(winObj)!='undefined'){
									winObj.close();
								}
							}
						}
						count++;
					})
				}else if(flag == "E"){
					Ext.MessageBox.alert(getResource("Error",""), result.error_msg);
				}else if(flag == "C"){
					Ext.MessageBox.confirm(getResource("Confirm",""), result.confirm_msg,function(btn,text){
						if(btn == 'yes'){
							Ext.Ajax.request(requestConfig);
						}
					})
				}
			}
		})
	}else if(jsonPro.handlerType=="BATCH_PROCESS" && ("EG_SAVEALL,EG_CHECKBOX").indexOf(jsonPro.saveType)!=-1){
		var columnListArray = (jsonPro.columnList).split(",");
		var jsonData="[";
		if(jsonPro.saveType=="EG_CHECKBOX"){
			var t_array = new Array();
			var j = 0;var s = 0;
			var s_store = obj.getSelectionModel();
			var sr_array = s_store.getSelections();
			for (j = 0; j < s_store.getCount(); j++) {
				s = obj.getStore().indexOf(sr_array[j]);
				t_array[s] = sr_array[j];
			}
			var jsonData="[";
			for(var i=0;i<t_array.length;i++){
				if(typeof(t_array[i])!=="undefined"){
					if(jsonData == "["){
						jsonData = jsonData + "[";
					}else{
						jsonData = jsonData + ",[";
					}
					for(var j=0;j<columnListArray.length;j++){
						if(j > 0){
							jsonData = jsonData + ",";
						}
						if(obj.getColumnModel().isCellEditable(j,i)&&obj.getColumnModel().getCellEditor(j,i).field.xtype=="datefield"){
							jsonData=jsonData+"'"+Ext.util.Format.date(t_array[i].data[columnListArray[j]],'Y-m-d')+"'";
						}else{
							jsonData=jsonData+"'"+URLencodeSingle(t_array[i].data[columnListArray[j]])+"'";
						}
					}
					jsonData = jsonData + "]";
				}
			}
		}else{
			for(var i=0;i<obj.store.getCount();i++){
				if(jsonData == "["){
					jsonData = jsonData + "[";
				}else{
					jsonData = jsonData + ",[";
				}
				for(var j=0;j<columnListArray.length;j++){
					if(j > 0){
						jsonData = jsonData + ",";
					}
					if(obj.getColumnModel().isCellEditable(j,i)&&obj.getColumnModel().getCellEditor(j,i).field.xtype=="datefield"){
						jsonData=jsonData+"'"+Ext.util.Format.date(obj.getStore().getAt(i).get(columnListArray[j]),'Y-m-d')+"'";
					}else{
						jsonData=jsonData+"'"+URLencodeSingle(obj.getStore().getAt(i).get(columnListArray[j]))+"'";
					}
				}
				jsonData = jsonData + "]";
			}
		}
		jsonData = jsonData + "]";
		jsonData = "{'data':"+jsonData+"}";
		var url_event="index.cfm?event=dynamicEditgrid.editgrid.saveEditgrid";
		paramList.grid_panel_name = "";
		if(jsonPro.gridPanelName!=""){
			paramList.grid_panel_name = jsonPro.gridPanelName;
			if(Ext.getCmp(jsonPro.gridPanelName).getStore().baseParams.sql_where){
				paramList._grid_sql_where = Ext.getCmp(jsonPro.gridPanelName).getStore().baseParams.sql_where;
			}else{
				paramList._grid_sql_where = " and 1=1";
			}
		}
		paramList.json_data=jsonData;
		paramList.save_type=jsonPro.saveType;
		paramList.currentPanel=panelName;paramList.event_name=eventName;
		paramList.mode="E";
		Ext.MessageBox.wait(getResource("batch_process_tip",panelName), getResource("tip",panelName), '');
		Ext.Ajax.request({
			url:url_event+"&is_validate=1&datenow=" + new Date(),
			method: "POST",
			params: paramList,
			waitMsg:getResource("saving",panelName),
			success: function (response, opts) {
				var result = Ext.util.JSON.decode(response.responseText);
				var flag =  result.flag;
				var requestConfig = {
					url: url_event + "&is_validate=0&datenow=" + new Date(),
					method:"POST",
					params: paramList,
					success: function (response, opts) {
						var result =  Ext.util.JSON.decode(response.responseText);
						var flag =  result.flag;
						var winObj = Ext.getCmp(obj.paramList.win_id);
						if(flag == "S"){
							if(jsonPro.isRequireSuccessTip=="1"){
								Ext.MessageBox.alert(getResource("Success",panelName),result.success_msg,function(id){
									if(id == "ok"){
										var count = 0;
										obj.getStore().reload();
										obj.getStore().on('load',function(){
											if(count == 0){
												var jsfunction = new Function(jsonPro.afterSuccessJs);
												jsfunction();
												dynamicPanelAction(jsonPro.panelActionDataArray);
											}
											if(jsonPro.isCloseWindowAfterAction=="1"){
												if(typeof(winObj)!='undefined'){
													winObj.close();
												}
											}
											count++;
										})										
									}
								})
							}else{
								var count = 0;
								obj.getStore().reload();
								obj.getStore().on('load',function(){
									if(count == 0){
										var jsfunction = new Function(jsonPro.afterSuccessJs);
												jsfunction();
										dynamicPanelAction(jsonPro.panelActionDataArray);
									}
									if(jsonPro.isCloseWindowAfterAction=="1"){
										if(typeof(winObj)!='undefined'){
											winObj.close();
										}
									}
									count++;
								})
							}
						}else if(flag == "E"){
							Ext.MessageBox.alert(getResource("Error",panelName),result.error_msg,function(){
								Ext.getCmp(panelName).getStore().reload();
							});
						}
					},
					waitMsg:getResource("saving",panelName)
				}
				if(flag == "S"){
					Ext.MessageBox.hide();
					var winObj = Ext.getCmp(obj.paramList.win_id);
					if(jsonPro.isRequireSuccessTip=="1"){
						Ext.MessageBox.alert(getResource("Success",panelName),result.success_msg,function(id){
							if(id == "ok"){
								var count = 0;
								obj.getStore().reload();
								obj.getStore().on('load',function(){
									if(count == 0){
										var jsfunction = new Function(jsonPro.afterSuccessJs);
												jsfunction();
										dynamicPanelAction(jsonPro.panelActionDataArray);
									}
									if(jsonPro.isCloseWindowAfterAction=="1"){
										if(typeof(winObj)!='undefined'){
											winObj.close();
										}
									}
									count++;
								})										
							}
						})
					}else{
						var count = 0;
						obj.getStore().reload();
						obj.getStore().on('load',function(){
							if(count == 0){
								var jsfunction = new Function(jsonPro.afterSuccessJs);
												jsfunction();
								dynamicPanelAction(jsonPro.panelActionDataArray);
							}
							if(jsonPro.isCloseWindowAfterAction=="1"){
								if(typeof(winObj)!='undefined'){
									winObj.close();
								}
							}
							count++;
						})
					}
				}else if(flag == "E"){
					Ext.MessageBox.hide();
					Ext.MessageBox.alert(getResource("Error",panelName), result.error_msg,function(){
						obj.getStore().reload();
					});
				}else if(flag == "C"){
					Ext.MessageBox.hide();
					Ext.MessageBox.confirm(getResource("Confirm",panelName),result.confirm_msg,function(btn,text){
						if(btn == "yes"){
							Ext.Ajax.request(requestConfig);
						}
					});
				}
			}
		})
	}else if(jsonPro.handlerType=="WORKFLOW" && jsonPro.saveType=="EG_CHECKBOX"){
		var columnListArray = (jsonPro.columnList).split(",");
		var jbpmjsonData = "";
		var jsonData="[";
		var s_store = obj.getSelectionModel();
		var sr_array = s_store.getSelections();
		var t_array = new Array();
		var j=0;var s=0;
		for(j=0;j<s_store.getCount();j++){
			s= obj.getStore().indexOf(sr_array[j]);
			t_array[s]=sr_array[j];
		}
		for(var i=0;i<t_array.length;i++){
			if(typeof(t_array[i])!=="undefined"){
				if(jsonData == "["){
					jsonData = jsonData + "[";
				}else{
					jsonData = jsonData + ",[";
				}
				for(var j=0;j<columnListArray.length;j++){
					if(j > 0){
						jsonData = jsonData + ",";
					}
					jsonData=jsonData+"'"+URLencodeSingle(t_array[i].data[columnListArray[j]])+"'";
				}
				jsonData = jsonData + "]";
			}
		}
		jsonData = jsonData + "]";
		jsonData = "{'data':"+jsonData+"}";
		var panel_name;
		var action;
		if(jsonPro.predefinedValues != ""){
			var predefinedValues = "{"+jsonPro.predefinedValues+"}";
			panel_name=Ext.decode(predefinedValues).panel_name;
			action = Ext.decode(predefinedValues).action;
		}else{
			panel_name=panelName;
			action = "Approve";
		}
		paramList.json_data=jsonData;
		paramList.save_type=jsonPro.saveType;
		paramList.mode="E";
		paramList.currentPanel=panelName;
		paramList.panel_name=panelName;
		paramList.action=action;
		paramList.column_list=jsonPro.columnList;
		paramList.event_name=eventName;
		var url;
		if(jsonPro.isWorkFlowStart == "1"){
			paramList.process_key=jsonPro.workflowProcessKey;
			paramList.wf_table=jsonPro.wfTable;
			url='index.cfm?event=workFlow.jbpm.batchInitWorkflow&datenow=' + new Date();
		}else{
			url='index.cfm?event=workFlow.jbpm.batchPerformTask&datenow=' + new Date();
		}
		Ext.MessageBox.wait(getResource("waitMsg",panelName+"_wait"),getResource("waitMsg",panelName+"_wait"), ""); 
		Ext.Ajax.request({
			method: "POST",
			params: paramList,
			url:url,
			failure: function(response,options){
				var responseText = Ext.util.JSON.decode(options.response.responseText);
				Ext.MessageBox.hide();
				Ext.MessageBox.alert(getResource("failure","dynaGrid"),responseText.success_msg);
			},
			success: function(response,options){
				var winObj = Ext.getCmp(obj.paramList.win_id);
				var responseText = Ext.util.JSON.decode(response.responseText);
				Ext.MessageBox.hide();
				if(responseText.flag == "S"){
					jbpmjsonData = Ext.util.JSON.decode(responseText.jsonData);
					if(jsonPro.isRequireSuccessTip=="1"){
						Ext.MessageBox.alert(getResource("success","dynaGrid"),jbpmjsonData.message,function(){
							if(jsonPro.isRequireReloadGrid=="1"){
								var count = 0;
								obj.getStore().reload();
								obj.getStore().on('load',function(){
									if(count == 0){
										var jsfunction = new Function(jsonPro.afterSuccessJs);
												jsfunction();
										dynamicPanelAction(jsonPro.panelActionDataArray);
									}
									count++;
								});
							}else{
								var jsfunction = new Function(jsonPro.afterSuccessJs);
												jsfunction();
								dynamicPanelAction(jsonPro.panelActionDataArray);
							}
							if(jsonPro.isCloseWindowAfterAction=="1"){
								if(typeof(winObj)!='undefined'){winObj.close();}
							}
						})
					}else{
						if(jsonPro.isRequireReloadGrid=="1"){
							var count = 0;
							obj.getStore().reload();
							obj.getStore().on('load',function(){
								if(count == 0){
									var jsfunction = new Function(jsonPro.afterSuccessJs);
												jsfunction();
									dynamicPanelAction(jsonPro.panelActionDataArray);
								}
								count++;
							});
						}else{
							var jsfunction = new Function(jsonPro.afterSuccessJs);
												jsfunction();
							dynamicPanelAction(jsonPro.panelActionDataArray);
						}
						if(jsonPro.isCloseWindowAfterAction=="1"){
							if(typeof(winObj)!='undefined'){winObj.close();}
						}
					}
				}else if(responseText.flag == "E"){
					jbpmjsonData = Ext.util.JSON.decode(responseText.jsonData);
					if(jsonPro.isRequireSuccessTip=="1"){
						Ext.MessageBox.alert(getResource("error","dynaGrid"),responseText.error_msg,function(){
							if(jsonPro.isRequireReloadGrid=="1"){
								var count = 0;
								obj.getStore().reload();
								obj.getStore().on('load',function(){
									if(count == 0){
										var jsfunction = new Function(jsonPro.afterSuccessJs);
												jsfunction();
										dynamicPanelAction(jsonPro.panelActionDataArray);
									}
									count++;
								});
							}else{
								var jsfunction = new Function(jsonPro.afterSuccessJs);
												jsfunction();
								dynamicPanelAction(jsonPro.panelActionDataArray);
							}
							if(jsonPro.isCloseWindowAfterAction=="1"){
								if(typeof(winObj)!='undefined'){winObj.close();}
							}
						})
					}else{
						if(jsonPro.isRequireReloadGrid=="1"){
							var count = 0;
							obj.getStore().reload();
							obj.getStore().on('load',function(){
								if(count == 0){
									var jsfunction = new Function(jsonPro.afterSuccessJs);
												jsfunction();
									dynamicPanelAction(jsonPro.panelActionDataArray);
								}
								count++;
							});
						}else{
							var jsfunction = new Function(jsonPro.afterSuccessJs);
												jsfunction();
							dynamicPanelAction(jsonPro.panelActionDataArray);
						}
						if(jsonPro.isCloseWindowAfterAction=="1"){
							if(typeof(winObj)!='undefined'){winObj.close();}
						}
					}
				}
			}
		})
	}else if(jsonPro.handlerType=="POPUP"){
		if(typeof(Ext.getCmp(panelName+"_"+eventName+"_win_popUp_parent"))!="undefined"&&jsonPro.actionHandlerEvent==""&&jsonPro.useDynamicMenuKey==""){
			maskObj = new Ext.LoadMask(Ext.getCmp(panelName+"_"+eventName+"_win_popUp_parent").getEl(), {msg:getResource("loading","")});
			maskObj.show();
			paramList.win_id=panelName+"_"+eventName+"_win_popUp_parent";
			paramList.grid = obj;
			Ext.apply(Ext.getCmp("page_"+jsonPro.dynPageName).paramList,paramList);
			Ext.getCmp("page_"+jsonPro.dynPageName).fireEvent("render",Ext.getCmp("page_"+jsonPro.dynPageName));
			Ext.getCmp(panelName+"_"+eventName+"_win_popUp_parent").show();
		}else{
			var windowItem;
			var windowString;
			var closeAction;
			paramList.win_id = panelName+"_"+eventName+"_win_popUp_parent";
			paramList.grid = obj;
			
			if(jsonPro.actionHandlerEvent == ""){
				var jsFile
				if(jsonPro.useDynamicMenuKey!=""){
					jsFile = "views/dynamicGenerateScript/page_"+jsonPro.useDynamicMenuKey+".js";
					windowString = "windowItem = new page_"+jsonPro.useDynamicMenuKey+"({paramList:paramList});";
					closeAction="close";
				}else{
					jsFile = "views/dynamicGenerateScript/page_"+jsonPro.dynPageName+".js";
					windowString = "windowItem = new page_"+jsonPro.dynPageName+"({paramList:paramList});";
					closeAction=jsonPro.isDestroyWin=="0"?'hide':'close';
				}
				myLoader.require(jsFile,function(){
					destroy_key_list.push(paramList.win_id);
					eval(windowString);
					var popWin = new Ext.Window({
						manager:windows,
						resizable:true,
						modal:true,
						id:panelName+"_"+eventName+"_win_popUp_parent",
						bodyStyle: "background: #fff;",
						autoscroll: true,
						layout:"fit",
						closeAction:closeAction,
						layout:'fit',
						items:[{layout:'anchor',items:[windowItem]}],
						width:(parseInt(jsonPro._win_width) > window.parent.document.body.clientWidth ? window.parent.document.body.clientWidth : parseInt(jsonPro._win_width) ),
						minWidth:(parseInt(jsonPro._win_width)  > window.parent.document.body.clientWidth ? window.parent.document.body.clientWidth : parseInt(jsonPro._win_width) ),
						height:(parseInt(jsonPro._win_height) > window.parent.document.body.clientHeight ? window.parent.document.body.clientHeight : parseInt(jsonPro._win_height)),
						minHeight:(parseInt(jsonPro._win_height) > window.parent.document.body.clientHeight ? window.parent.document.body.clientHeight : parseInt(jsonPro._win_height)),
						listeners:{
							"beforehide":function(){
								if(jsonPro.isNeedConfirmDirtyData=="1"){
									if(validateDataFlag == 1){
										Ext.Msg.confirm(getResource("confirm_title",""),getResource("confirm_msg","confirm_modify_data"),function(_btn){
											if(_btn=="no"){
												return false;
											}else{
												validateDataFlag = 0;
												Ext.getCmp(panelName+"_"+eventName+"_win_popUp_parent").close();
											}
										});return false;
									}
								}
							},
							"close":function(){
								if(jsonPro.isRequireReloadGrid=="1"){
									obj.getStore().reload();
								}
							}
						}
					});
					if(eval(jsonPro.titleI18nKey)!=""){
						popWin.setTitle(eval(jsonPro.titleI18nKey));
					}
					popWin.show()
				},this,true)
			}else{
				if(typeof(Ext.getCmp(panelName+"_"+eventName+"_win_popUp_parent"))!="undefined"){
					paramList.win_id=panelName+"_"+eventName+"_win_popUp_parent";
					paramList.grid = obj;
					Ext.getCmp(panelName+"_"+eventName+"_win_popUp_parent").show();
				}else{
					var popWin = new Ext.Window({
						manager:windows,
						resizable:true,
						modal:true,
						id:panelName+"_"+eventName+"_win_popUp_parent",
						bodyStyle: "background: #fff;",
						autoscroll: true,
						layout:"fit",
						closeAction:jsonPro.isDestroyWin=="0"?'hide':'close',
						layout:'fit',
						autoLoad: {
							url: "index.cfm?event="+jsonPro.actionHandlerEvent+"&_popid="+panelName+"_"+eventName+"_win_popUp_parent&datenow=" + new Date(),
							params:paramList,
							scripts: true
						},
						width:(parseInt(jsonPro._win_width) > window.parent.document.body.clientWidth ? window.parent.document.body.clientWidth : parseInt(jsonPro._win_width) ),
						minWidth:(parseInt(jsonPro._win_width)  > window.parent.document.body.clientWidth ? window.parent.document.body.clientWidth : parseInt(jsonPro._win_width) ),
						height:(parseInt(jsonPro._win_height) > window.parent.document.body.clientHeight ? window.parent.document.body.clientHeight : parseInt(jsonPro._win_height)),
						minHeight:(parseInt(jsonPro._win_height) > window.parent.document.body.clientHeight ? window.parent.document.body.clientHeight : parseInt(jsonPro._win_height)),
						listeners:{
							"close":function(){
								if(jsonPro.isRequireReloadGrid=="1"){
									obj.getStore().reload();
								}
							}
						}
					});
					if(eval(jsonPro.titleI18nKey)!=""){
						popWin.setTitle(eval(jsonPro.titleI18nKey));
					}
					popWin.show()
				}
			}
		}		
	}else if(jsonPro.handlerType=="BACKGROUND"){
		paramList.panel_name=panelName;
		paramList.event_name=eventName;
		paramList.prefix_name=panelName+"_"+eventName;
		paramList.grid_panel_name="";
		if(jsonPro.gridPanelName!=""){
			paramList.grid_panel_name = jsonPro.gridPanelName;
			if(Ext.getCmp(jsonPro.gridPanelName).getStore().baseParams.sql_where){
				paramList._grid_sql_where = Ext.getCmp(jsonPro.gridPanelName).getStore().baseParams.sql_where;
			}else{
				paramList._grid_sql_where = " and 1=1";
			}
		}
		paramList.is_validate=1;
		Ext.MessageBox.wait(getResource("waitMsg",panelName+"_wait"),getResource("waitMsg",panelName+"_wait"), "");		
		var url;
		if(jsonPro.actionHandlerEvent!=""){
			url="index.cfm?event="+jsonPro.actionHandlerEvent+"&datenow=" + new Date();
		}else{
			url="index.cfm?event=dynamicGrid.general.dynamicGridBackGround&datenow=" + new Date();
		}
		Ext.Ajax.request({
			params:paramList,
			url:url,
			method: "POST",
			failure: function(response,options){var responseText = Ext.util.JSON.decode(options.response.responseText);
				Ext.MessageBox.hide();Ext.MessageBox.alert(getResource("failure",panelName),responseText.success_msg);
			},
			success: function(response,options){
				var winObj = eval(Ext.getCmp(obj.paramList.win_id));
				var responseText = Ext.util.JSON.decode(response.responseText);Ext.MessageBox.hide();
				if(responseText.flag == "S"){
					if(jsonPro.isRequireSuccessTip=="1"){
						Ext.MessageBox.alert(getResource("success",panelName),responseText.success_msg,function(){
							if(jsonPro.isRequireReloadGrid=="1"){
								var count = 0;
								obj.getStore().reload();
								obj.getStore().on("load",function(){
									if(count == 0){
										var jsfunction = new Function(jsonPro.afterSuccessJs);
												jsfunction();
										if(jsonPro.isCloseWindowAfterAction=="1"){
											if(typeof(winObj)!='undefined'){winObj.close();}
										}
									}
									count++;
								})
								dynamicPanelAction(jsonPro.panelActionDataArray);
							}else{
								var jsfunction = new Function(jsonPro.afterSuccessJs);
												jsfunction();
								dynamicPanelAction(jsonPro.panelActionDataArray);
							}
						})
					}else{
						if(jsonPro.isRequireReloadGrid=="1"){
							var count = 0;
							obj.getStore().reload();
							obj.getStore().on("load",function(){
								if(count == 0){
									var jsfunction = new Function(jsonPro.afterSuccessJs);
												jsfunction();
									if(jsonPro.isCloseWindowAfterAction=="1"){
										if(typeof(winObj)!='undefined'){winObj.close();}
									}
								}
								count++;
							})
							dynamicPanelAction(jsonPro.panelActionDataArray);
						}else{
							var jsfunction = new Function(jsonPro.afterSuccessJs);
												jsfunction();
							dynamicPanelAction(jsonPro.panelActionDataArray);
						}
					}
				}else if(responseText.flag == "E"){
					Ext.MessageBox.alert(getResource("error",panelName),responseText.error_msg,function(){
						if(jsonPro.isRequireReloadGrid=="1"){
							obj.getStore().reload();
						}
					})
				}else if(responseText.flag == "C"){
					Ext.MessageBox.confirm(getResource("confirm",panelName),responseText.confirm_msg,function(_btn){
						if(_btn == "yes"){
							Ext.MessageBox.wait(getResource("waitMsg",panelName+"_wait"), getResource("waitMsg",panelName+"_wait"), "");
							paramList.is_validate=0;
							Ext.Ajax.request({
							 	params:paramList,
							 	url:url,
							 	method:"POST",
							 	failure: function(response,options){
									var responseText = Ext.util.JSON.decode(options.response.responseText);
									Ext.MessageBox.hide();
									Ext.MessageBox.alert(getResource("failure",panelName),responseText.success_msg);
								},
								success: function(response,options){
									var winObj = eval(Ext.getCmp(obj.paramList.win_id));
									var responseText = Ext.util.JSON.decode(response.responseText);
									Ext.MessageBox.hide();
									if(responseText.flag == "S"){
										if(jsonPro.isRequireSuccessTip=="1"){
											Ext.MessageBox.alert(getResource("success",panelName),responseText.success_msg,function(){
												if(jsonPro.isRequireReloadGrid=="1"){
													var count = 0;
													obj.getStore().reload();
													obj.getStore().on("load",function(){
														if(count == 0){
															var jsfunction = new Function(jsonPro.afterSuccessJs);
												jsfunction();
															if(jsonPro.isCloseWindowAfterAction=="1"){
																if(typeof(winObj)!='undefined'){winObj.close();}
															}
														}
														count++;
													})
													dynamicPanelAction(jsonPro.panelActionDataArray);
												}else{
													var jsfunction = new Function(jsonPro.afterSuccessJs);
												jsfunction();
													dynamicPanelAction(jsonPro.panelActionDataArray);
												}
											})
										}else{
											if(jsonPro.isRequireReloadGrid=="1"){
												var count = 0;
												obj.getStore().reload();
												obj.getStore().on("load",function(){
													if(count == 0){
														var jsfunction = new Function(jsonPro.afterSuccessJs);
												jsfunction();
														if(jsonPro.isCloseWindowAfterAction=="1"){
															if(typeof(winObj)!='undefined'){winObj.close();}
														}
													}
													count++;
												});
												dynamicPanelAction(jsonPro.panelActionDataArray);
											}else{
												var jsfunction = new Function(jsonPro.afterSuccessJs);
												jsfunction();
												dynamicPanelAction(jsonPro.panelActionDataArray);
											}
										}
									}else if(responseText.flag == "E"){
										Ext.MessageBox.alert(getResource("error",panelName),responseText.error_msg,function(){
											if(jsonPro.isRequireReloadGrid=="1"){
												obj.getStore().reload();
											}
										})
									}
								}
							})
						}
					})
				}
			}
		})
	}else if(jsonPro.handlerType=="REDIRECT"){
		var winObj = Ext.getCmp(obj.paramList.win_id);
		var targetComp;
		if(typeof(winObj)!="undefined"){
			targetComp = winObj;
		}else{
			targetComp = Ext.getCmp("contentPanel");
		}
		var jsFile;
		if(jsonPro.useDynamicMenuKey!=""){
			paramList.dyn_page_name=jsonPro.useDynamicMenuKey;
			jsFile="views/dynamicGenerateScript/page_"+jsonPro.useDynamicMenuKey+".js";
		}else{
			paramList.dyn_page_name=jsonPro.dynPageName;
			jsFile = "views/dynamicGenerateScript/page_"+jsonPro.dynPageName+".js";
		}
		if(jsonPro.actionHandlerEvent != ""){
			targetComp.removeAll();
			targetComp.getUpdater().update({
				url:"index.cfm?event="+jsonPro.actionHandlerEvent+"&datenow=" + new Date(),
				params:paramList,
				nocache:true,
				scripts:true,
				timeout:30000
			})
		}else{
			targetComp.removeAll();
			myLoader.require(jsFile,function(){
				destroy_key_list.push("page_"+paramList.dyn_page_name);
				var windowItem;
				var windowString = "windowItem = new page_"+paramList.dyn_page_name+"({paramList:paramList});";
				eval(windowString);
				targetComp.add(windowItem);
			},this,true);
			targetComp.doLayout();
		}
	}else if(jsonPro.handlerType=="JAVASCRIPT"){
		var jsfunction = new Function(jsonPro.handlerJs);
		jsfunction();
		if(jsonPro.isRequireReloadGrid=="1"){
			obj.getStore().reload();
		}
	}else if(jsonPro.handlerType=="IOEXPORT"){
		paramList.grid_panel_name="";
		if(jsonPro.gridPanelName!=""){
			paramList.grid_panel_name = jsonPro.gridPanelName;
			if(Ext.getCmp(jsonPro.gridPanelName).getStore().baseParams.sql_where){
				paramList._grid_sql_where = Ext.getCmp(jsonPro.gridPanelName).getStore().baseParams.sql_where;
			}else{
				paramList._grid_sql_where = " and 1=1";
			}
		}
		paramList.export_type=jsonPro.rptFormat;
		var urlEvent = "index.cfm?event=nio.nio.export";
		for(var p in paramList){
			if(p=="sql_where"){
				urlEvent = urlEvent + "&" + p + "=" + encodeURIComponent(paramList[p]);
			}
		}
		var report_form = new  Ext.form.FormPanel({
			    renderTo:'_report-out',
			    name:panelName+'_export',
			    id:panelName+'_exportForm',
		        frame: true,
		        collapsible:true,
		        labelAlign:'right',
		        buttonAlign:'center',
		        autoHeight: true,items:[{}]
			});
		for(var i in paramList){
			if(i!="sql_where"){
				var textfield = new Ext.form.TextField({
					name:i,
					value:paramList[i],
					xtype:'textfield'
				});
				report_form.insert(0,textfield);
			}
		}
		report_form.doLayout();report_form.getForm().getEl().dom.method='POST';
		report_form.getForm().getEl().dom.action=urlEvent;
		report_form.getForm().getEl().dom.submit();		
	}else if(jsonPro.handlerType=="IOIMPORT"){
		var io_paramList = new Object();
		for(var p in  paramList){
			if(typeof(paramList[p])!="object"){
				io_paramList[p]=paramList[p];
			}
		}
		var popWin = new Ext.Window({
			manager:windows,
			resizable:false,
			manager:windows,
			modal:true,
			id:"#arguments.panel_name#_#event_name#_win_popUp_parent",
			bodyStyle: "background: #fff;",
			autoscroll: true,
			autoLoad: {
				url:"index.cfm?event=nio.nio.importMain&datenow=" + new Date().getTime(), 
				params:{
					parameter:Ext.encode(io_paramList),
					event_name:eventName,
					p_name:panelName,
					panel_name:panelName
				},
				nocache:true,
				scripts:true,
				timeout:1000000
			},
			width:800,
			height:585,
			listeners:{
				"close":function(){obj.getStore().reload();}
			}
		}).show();
	}else if(jsonPro.handlerType=="REPORT"){
		var url_event= '';
		if((jsonPro.rptFormat).indexOf("xls")!=-1 && jsonPro.isHtmlXls=="1"){
			url_event='index.cfm?event=rpt.report.report.runReportForExcel&rpt_format='+jsonPro.rptFormat+'&rpt_number='+jsonPro.rptNumber+'&is_validate=0&currentPanel='+panelName+'&rptformat='+jsonPro.rptFormat;
			var report_form = new  Ext.form.FormPanel({
				    renderTo:'_report-out',
				    name:panelName+'_form',
				    id:panelName+'_reportform',
			        frame: true,
			        collapsible:true,
			        labelAlign:'right',
			        buttonAlign:'center',
			        autoHeight: true,items:[{}]
				});
			for(var i in paramList){
				var textfield = new Ext.form.TextField({
					name:i,
					value:encodeURIComponent(paramList[i]),
					xtype:'textfield'
				});
				report_form.insert(0,textfield);
			}
			report_form.doLayout();report_form.getForm().getEl().dom.method='POST';
			report_form.getForm().getEl().dom.action=url_event;report_form.getForm().getEl().dom.submit();
		}else{
			url_event='index.cfm?event=rpt.report.report.runReport&rpt_format='+jsonPro.rptFormat+'&rpt_number='+jsonPro.rptNumber+'&is_validate=0&currentPanel='+panelName+'&rptformat='+jsonPro.rptFormat;
			Ext.Ajax.request({
				method: 'POST',
				waitMsg:getResource('redirectToReport','dynaGrid'),
				url: url_event,
				success: function (response,options) {
					var responseText = Ext.util.JSON.decode(response.responseText);
					if(responseText.flag == 'S'){
						var width = Ext.getCmp('contentPanel').getWidth() - 2;
						var height = Ext.getCmp('contentPanel').getHeight() - 29;
						var c = Ext.getCmp('contentPanel');
						paramList.width=width;paramList.height=height;
						paramList.currentPanel=panelName;
						paramList.rpt_format=jsonPro.rptFormat;
						paramList.rpt_number=jsonPro.rptNumber;
						if((jsonPro.rptFormat).indexOf("xls")!=-1){
							if(jsonPro.rptPageType=="MAIN_PANEL"){
								c.getUpdater().update({
									url: "index.cfm?event=rpt.report.report.runReportPage&datenow=" + new Date(),
									params:paramList,
									nocache: true, 
									scripts: true,
									timeout: 1000000
								});
							}else{
								var popWin = new Ext.Window({
									modal:true,
									manager:windows,
									id:panelName+"_window",
									bodyStyle: "background: #fff;",
									autoscroll: true,
									autoLoad: { 
										url: "index.cfm?event=rpt.report.report.runReportPage&datenow=" + new Date(),
										params:paramList,
										scripts: true 
									},
									width:width,
									height:height,
									dummp:true
								}).show();
							}
						}else{
							c.getUpdater().update({
								url: "index.cfm?event=rpt.report.report.runReportPage&datenow=" + new Date(),
								params:paramList,
								nocache: true, 
								scripts: true,
								timeout: 1000000
							});	
						}
					}else if(responseText.flag == "E"){
						Ext.MessageBox.alert(getResource("error",panelName), responseText.error_msg);
					}
				}
			})
		}
	}else if(jsonPro.handlerType=="WORKFLOW"){
		paramList.event_name=eventName;
		paramList.grid_panel_name="";
		if(jsonPro.gridPanelName!=""){
			paramList.grid_panel_name = jsonPro.gridPanelName;
			if(Ext.getCmp(jsonPro.gridPanelName).getStore().baseParams.sql_where){
				paramList._grid_sql_where = Ext.getCmp(jsonPro.gridPanelName).getStore().baseParams.sql_where;
			}else{
				paramList._grid_sql_where = " and 1=1";
			}
		}
		var url;
		if(jsonPro.isWorkFlowStart=="1"){
			url="index.cfm?event=workFlow.jbpm.initWorkflow&datenow=" + new Date();
			paramList.process_key=jsonPro.workFlowProcessKey;
			paramList.wf_table=jsonPro.wfTable;
		}else{
			url="index.cfm?event=workFlow.jbpm.performTask&datenow=" + new Date();
		}
		paramList.panel_name=panelName; 
		Ext.MessageBox.wait(getResource("waitMsg",panelName+"_wait"),getResource("waitMsg",panelName+"_wait"), "");
		paramList.is_validate=1;
		Ext.Ajax.request({
			url:url,
			method: "POST",
			params:paramList,
			failure: function(response,options){
				var responseText = Ext.util.JSON.decode(options.response.responseText);
				Ext.MessageBox.hide();
				Ext.MessageBox.alert(getResource("failure",panelName),responseText.success_msg);
			},
			success: function(response,options){
				var responseText = Ext.util.JSON.decode(response.responseText);
				Ext.MessageBox.hide();
				if(responseText.success == true){
					if(responseText.flag&&responseText.flag=="E"){
						Ext.MessageBox.alert(getResource("error",panelName),responseText.error_msg);
					}else if(responseText.flag&&responseText.flag=="C"){
						Ext.MessageBox.confirm(getResource("confirm",panelName),responseText.confirm_msg,function(_btn){
							if(_btn == "yes"){
								Ext.MessageBox.wait(getResource("waitMsg",panelName+"_wait"), getResource("waitMsg",panelName+"_wait"), "");
								paramList.is_validate=0;
								Ext.Ajax.request({
									url:url,
									method: "POST",params:paramList,
									failure: function(response,options){
										var responseText = Ext.util.JSON.decode(options.response.responseText);
										Ext.MessageBox.hide();
										Ext.MessageBox.alert(getResource("failure",panelName),responseText.success_msg);
									},
									success: function(response,options){
										var responseText = Ext.util.JSON.decode(response.responseText);
										Ext.MessageBox.hide();
										var winObj = Ext.getCmp(obj.paramList.win_id);
										if(responseText.success == true){
											if(responseText.flag&&responseText.flag=="E"){
												Ext.MessageBox.alert(getResource("error",panelName),responseText.error_msg);
											}else if(responseText.flag&&responseText.flag=="S"){
												if(jsonPro.isRequireSuccessTip=="1"){
													Ext.MessageBox.alert(getResource("success",panelName),responseText.success_msg,function(){
														if(jsonPro.isRequireReloadGrid=="1"){
															var count = 0;
															obj.getStore().reload();
															obj.getStore().on("load",function(){
																if(count == 0){ 
																	var jsfunction = new Function(jsonPro.afterSuccessJs);
																	jsfunction();
																	if(jsonPro.isCloseWindowAfterAction=="1"){
																		if(typeof(winObj)!='undefined'){winObj.close();}
																	}
																}
																count++;
															});
															dynamicPanelAction(jsonPro.panelActionDataArray);
														}else{
															var jsfunction = new Function(jsonPro.afterSuccessJs);
																	jsfunction();
															dynamicPanelAction(jsonPro.panelActionDataArray);
														}
													})
												}else{
													if(jsonPro.isRequireReloadGrid=="1"){
														var count = 0;
														obj.getStore().reload();
														obj.getStore().on("load",function(){
															if(count == 0){ 
																var jsfunction = new Function(jsonPro.afterSuccessJs);
																jsfunction();
																if(jsonPro.isCloseWindowAfterAction=="1"){
																	if(typeof(winObj)!='undefined'){winObj.close();}
																}
															}
															count++;
														});
														dynamicPanelAction(jsonPro.panelActionDataArray);
													}else{
														var jsfunction = new Function(jsonPro.afterSuccessJs);
																jsfunction();
														dynamicPanelAction(jsonPro.panelActionDataArray);
													}
												}
											}
										}else if(responseText.success == false){
											Ext.MessageBox.alert(getResource("error",panelName),responseText.success_msg,function(){
												if(jsonPro.isRequireReloadGrid=="1"){
													obj.getStore().reload();
												}
											})
										}
									}
								})
							}
						})
					}else{
						if(jsonPro.isRequireSuccessTip=="1"){
							Ext.MessageBox.alert(getResource("success",panelName),responseText.success_msg,function(){
								if(jsonPro.isRequireReloadGrid=="1"){
									var count = 0;
									obj.getStore().reload();
									obj.getStore().on("load",function(){
										if(count == 0){ 
											var jsfunction = new Function(jsonPro.afterSuccessJs);
																	jsfunction();
											if(jsonPro.isCloseWindowAfterAction=="1"){
												if(typeof(winObj)!='undefined'){winObj.close();}
											}
										}
										count++;
									});
									dynamicPanelAction(jsonPro.panelActionDataArray);
								}else{
									var jsfunction = new Function(jsonPro.afterSuccessJs);
																	jsfunction();
									dynamicPanelAction(jsonPro.panelActionDataArray);
								}
							})
						}else{
							if(jsonPro.isRequireReloadGrid=="1"){
								var count = 0;
								obj.getStore().reload();
								obj.getStore().on("load",function(){
									if(count == 0){ 
										var jsfunction = new Function(jsonPro.afterSuccessJs);
																jsfunction();
										if(jsonPro.isCloseWindowAfterAction=="1"){
											if(typeof(winObj)!='undefined'){winObj.close();}
										}
									}
									count++;
								});
								dynamicPanelAction(jsonPro.panelActionDataArray);
							}else{
								var jsfunction = new Function(jsonPro.afterSuccessJs);
																jsfunction();
								dynamicPanelAction(jsonPro.panelActionDataArray);
							}
						}
					}
				}else if(responseText.success == false){
					Ext.MessageBox.alert(getResource("error",panelName),responseText.success_msg,function(){
						if(jsonPro.isRequireReloadGrid=="1"){
							obj.getStore().reload();
						}
					})
				}
			}
		})
	}else if(jsonPro.handlerType=="COLDFUSION"){
		Ext.MessageBox.wait(getResource("waitMsg",panelName+"_wait"),getResource("waitMsg",panelName+"_wait"), "");
		Ext.Ajax.request({
			url: "index.cfm?event=dynamicCF.general."+eventName+"&datenow=" + new Date(),
			method: "POST",
			params:paramList,
			failure: function(response,options){
				var responseText = Ext.util.JSON.decode(options.response.responseText);
				Ext.MessageBox.hide();
				Ext.MessageBox.alert(getResource("failure",panelName),responseText.success_msg);
			},
			success: function(response,options){
				var responseText = Ext.util.JSON.decode(response.responseText);
				Ext.MessageBox.hide();
				if(responseText.flag == "S"){
					if(jsonPro.isRequireSuccessTip=="1"){
						Ext.MessageBox.alert(getResource("success",panelName),responseText.success_msg,function(){
							if(jsonPro.isRequireReloadGrid=="1"){
								var count = 0;
								obj.getStore().reload();
								obj.getStore().on("load",function(){
									if(count == 0){ 
										var jsfunction = new Function(jsonPro.afterSuccessJs);
																	jsfunction();
										if(jsonPro.isCloseWindowAfterAction=="1"){
											if(typeof(winObj)!='undefined'){winObj.close();}
										}
									}
									count++;
								});
								dynamicPanelAction(jsonPro.panelActionDataArray);
							}else{
								var jsfunction = new Function(jsonPro.afterSuccessJs);
																	jsfunction();
								dynamicPanelAction(jsonPro.panelActionDataArray);
							}
						})
					}
				}else if(responseText.flag == "E"){
					Ext.MessageBox.alert(getResource("error",panelName),responseText.error_msg,function(){
						if(jsonPro.isRequireReloadGrid=="1"){
							obj.getStore().reload();
						}
					})
				}
			}
		})
	}else if(jsonPro.handlerType=="DATAREFRESH"){
		var target_panel_name_list = (jsonPro.targetPanelName).split(",");
		var target_panel_type_list = (jsonPro.targetPanelType).split(",");
		for (var k=0;k < target_panel_name_list.length; k++){
			if(target_panel_type_list[k] == 'editorgridpanel'||target_panel_type_list[k] == 'chartpanel'){
				if(Ext.getCmp(target_panel_name_list[k])){
					paramList.sql_where="";
					var baseParams = Ext.getCmp(target_panel_name_list[k]).store.baseParams;
					Ext.apply(baseParams,paramList);
					paramList.panel_name = target_panel_name_list[k];
					Ext.getCmp(target_panel_name_list[k]).store.baseParams=baseParams;
					Ext.getCmp(target_panel_name_list[k]).store.load();
				}
			}else if(target_panel_type_list[k] == 'advformpanel'){
				paramList.panel_name=target_panel_name_list[k];
				paramList.gridPanelName="";
				if(Ext.getCmp(target_panel_name_list[k]+'_form')){
					Ext.apply(Ext.getCmp(target_panel_name_list[k]+'_form').paramList,paramList);
					maskObj = new Ext.LoadMask(Ext.getCmp("page_"+jsonPro.menuKey).getEl(), {msg:getResource("loading","")});
					maskObj.show();
					eval("Ext.getCmp('page_"+jsonPro.menuKey+"')."+target_panel_name_list[k]+"_loadFormData()");
				}
			}
		}
	}else if(jsonPro.handlerType=="DOWNLOADTXT"){
		paramList.p_name=panelName;
		paramList.sql_where=obj.getStore().baseParams.sql_where;
		paramList.event_name=eventName;
		var loadW=Ext.Msg.wait(getResource("ExportData","")+"...",getResource("tip",""),{width:300 });
        paramList.menu_id=jsonPro.menuId;
        paramList.currentPanel=panelName; 
        paramList.is_validate=1;
		Ext.Ajax.request({
			url: "index.cfm?event=dynamicTxt.downloadTxt.downloadTxt&datenow=" + new Date(),
			method: "POST",
			params:paramList,
			failure: function(response,options){
				var responseText = Ext.util.JSON.decode(options.response.responseText);
				loadW.hide();
				Ext.MessageBox.alert(getResource("failure",panelName),responseText.success_msg);
			},
			success: function(response,options){
				var responseText = Ext.util.JSON.decode(response.responseText);
				Ext.MessageBox.hide();
				if(responseText.flag == "S"){
					window.location.href="index.cfm?event=dynamicTxt.downloadTxt.downloadTxt&menu_id="+jsonPro.menuId+"&currentPanel="+panelName+"&is_validate=0";
					loadW.hide();
				}else if(responseText.flag == "E"){
					Ext.MessageBox.alert(getResource("error",panelName),responseText.error_msg);
				}
			}
		});
	}else if(jsonPro.handlerType=="EDITGRID_ADD"){
		var recordJson=obj.getStore().recordType;
		var columnListArray = (jsonPro.columnList).split(",");
		var recordObj=new Object();;
		for(var i=0;i<columnListArray.length;i++){
			recordObj[columnListArray[i]]="";
		}
		var record = new recordJson(recordObj);
		obj.stopEditing();
		obj.store.insert(0, record);
		obj.startEditing(0, 0);
	}
}
 

function dynamicGridPanelEvent(e,panelName,eventName,jsonPro,panelVariable){
	setActionLog(panelName,eventName);
	var obj = Ext.getCmp(panelName),paramList1 = obj.paramList,paramList = new Object(),_win_height=0,_win_width=0,useDynamicMenuKey="";
	Ext.apply(paramList,paramList1);
	paramList.event_name=eventName;
	paramList.p_name=panelName;
	jsonPro.useDynamicMenuKey="";
	jsonPro._win_height=jsonPro.winHeight;
	jsonPro._win_width=jsonPro.winWidth;
	var selectedRows = Ext.getCmp(panelName).getSelectionModel().getCount();
	if(jsonPro.isRequireGridRowSelection=="1"){
		if(selectedRows == 0){
			Ext.MessageBox.show({
				title:getResource("Warning",""),
				msg:"<img src=../ext/resources/images/default/window/icon-warning.gif>"+getResource("noRecordSelected","DynamicGrid"),
				buttons:Ext.Msg.OK,width:300
			});
			return false;
		}else if(selectedRows > 1){
			var alertTipFlag = true;
			if(jsonPro.handlerType=="BATCH_PROCESS"){
				alertTipFlag = false;
			}
			if(jsonPro.handlerType=="WORKFLOW" && jsonPro.saveType == "EG_CHECKBOX"){
				alertTipFlag = false;
			}
			if(alertTipFlag){
				Ext.MessageBox.show({
					title:getResource("Warning",""),
					msg:"<img src=../ext/resources/images/default/window/icon-warning.gif>"+getResource("toManyRecordSelected","DynamicGrid"),
					buttons:Ext.Msg.OK,width:300
				});
				return false;
			}
		}
	}
	if(selectedRows == 1){
		var columnListArray = (jsonPro.columnList).split(",");
		var selectedRow = obj.getSelectionModel().getSelected();
		var field_name;
		for(var i=0;i<columnListArray.length;i++){
			field_name=columnListArray[i].toLowerCase();
			if(!(field_name=="_menu_key" || field_name=="_panel_name" || field_name=="_win_width" || field_name=="_win_height")){
				paramList[field_name]=Ext.util.Format.htmlDecode(selectedRow.get(field_name));
			}else if(field_name=="_menu_key" && jsonPro.isUseDynamicPanel=="1"){
				jsonPro.useDynamicMenuKey=Ext.util.Format.htmlDecode(selectedRow.get(field_name));
			}else if(field_name=="_win_height"){
				jsonPro._win_height=Ext.util.Format.htmlDecode(selectedRow.get(field_name));
			}else if(field_name=="_win_width"){
				jsonPro._win_width=Ext.util.Format.htmlDecode(selectedRow.get(field_name));
			}
		}
		paramList.sql_where=obj.getStore().baseParams.sql_where;
	}
	if(jsonPro.isRequireConfirmation=="1"){
		Ext.MessageBox.confirm(getResource("Confirm",""),eval(jsonPro.confirmMessage),function(_btn){
	 		if(_btn == "yes"){
	 			loadGridHandlerType(e,panelName,eventName,jsonPro,panelVariable,paramList);
	 		}
		})
	}else{
		loadGridHandlerType(e,panelName,eventName,jsonPro,panelVariable,paramList);
	}
}


function createAdvSearchPanel(panelName,titleI18nKey){
	if(Ext.getCmp(panelName+"_win")){
		Ext.getCmp(panelName+"_win").destroy();
	}
	var title = titleI18nKey==""?"":eval(titleI18nKey);
	return new Ext.Window({
		id : panelName+"_win",
		manager : windows,
		title : "" + getResource("search", "searchPanel") + " "
				+ title,
		width : 965,
		minWidth : 720,
		height : 200,
		minheight : 200,
		closeAction : "hide",
		autoscroll : false,
		modal : true,
		listeners : {
			"render" : function(w) {
				Ext.Ajax.request({
					method : "post",
					url : "index.cfm?event=searchPanel.general.generateAdvanceSearch&panel_name="+panelName+"&now="
							+ new Date(),
					failure : function(response, options) {
						Ext.MessageBox.alert(getResource("failure",
										panelName), "failure");
					},
					success : function(response, options) {
						var responseText = Ext.util.JSON
								.decode(response.responseText)
						var paramList = new Object();
						paramList.panel_name = panelName;
						paramList.simple_search_field = responseText.success_msg;
						paramList.simple_search_operator = responseText.external_params_1;
						paramList.criFieldList = responseText.external_params_2;
						paramList.fieldDataList = responseText.external_params_3;
						paramList._sql_sys_public = responseText.jsonObject._sql_sys_public;
						paramList._is_admin_user = responseText.jsonObject._is_admin_user;
						w.add(new AdvSearchPanel(paramList));
						w.doLayout();
					}
				});
			}
		}
	});
}


function loadFormData(panelName,action,fieldListObj,controlTypeList){
	var fieldId;
	var controlTypeArray = controlTypeList.split(",");
	var counter=0;
	for(var field in fieldListObj){
		fieldId=panelName+"_"+field+"_id";
		if(controlTypeArray[counter]=="htmlcontrol"){
			Ext.get(fieldId).dom.innerHTML=fieldListObj[field];
		}else if(controlTypeArray[counter]=="checkbox"){
			Ext.getCmp(fieldId).originalValue=fieldListObj[field]==1?true:false;
			Ext.getCmp(fieldId).setValue(fieldListObj[field]==1?true:false);
		}else if(controlTypeArray[counter]=="colorpalette"){
			Ext.getCmp(fieldId).originalValue=fieldListObj[field];
			Ext.getCmp(fieldId).setValue(fieldListObj[field]);
			Ext.getCmp(fieldId).el.setStyle({
				'backgroundImage':'url(includes/images/s.gif)',
				'backgroundColor':''+fieldListObj[field]
			});
		}else if(controlTypeArray[counter]=="radiogroup"||controlTypeArray[counter]=="checkboxgroup"){
			if(action != "action"){
				var cmp = Ext.getCmp(fieldId);
				cmp.originalValue=fieldListObj[field];
				if(cmp.picklistType=="RADIOGROUP"){
					var tableObj_id = panelName+'_'+cmp.fieldName+'_table';
					var radiogroup = document.getElementById(tableObj_id).getElementsByTagName("input");
					for (var i=0;i<radiogroup.length;i++) {
						if (radiogroup[i].value==fieldListObj[field]) {
							radiogroup[i].checked=true;
							break;
						}
					}
				}else{
					setCheckboxGroupValues(panelName,cmp.fieldName,fieldListObj[field]);
				}				
			}
		}else if(controlTypeArray[counter]=="button"){
			if(getAppPriv(panelName,field)==1){
				if(fieldListObj[field]==0){
					Ext.getCmp(fieldId).hide();
				}else if(fieldListObj[field]==1){
					Ext.getCmp(fieldId).show();
					Ext.getCmp(fieldId).enable();
				}else if(fieldListObj[field]==-1){
					Ext.getCmp(fieldId).disable();
				}
			}
		}else if(controlTypeArray[counter]=="filedownloadfield"){
			if(Ext.util.Format.trim(fieldListObj[field])!="72849742E4"){
				Ext.getCmp(fieldId.substring(0,fieldId.length-8)+"_id").show();
			}
			document.getElementById(fieldId).value = fieldListObj[field];
		}else{
			Ext.getCmp(fieldId).originalValue=fieldListObj[field];
			Ext.getCmp(fieldId).setValue(fieldListObj[field]);
		}
		counter=counter+1;
	}
	Ext.getCmp(panelName+'_form').doLayout(); 
}

function isNeedConfirmDirtyData(panelObj,isNeedConfirmDirtyData){
	if(isNeedConfirmDirtyData=="1"){
		if(panelObj.getForm().isDirty()){
			validateDataFlag=1;
		}else{
			validateDataFlag=0;
		}
	}
}


function createPicklistRedirect(panelName,fieldName,picklist_redirect_page,win_titleI18nKey,_win_width,_win_height,picklistObj){
	var paramList = new Object();
	var titleArray = (win_titleI18nKey).split("@");
	var _winTitle;
	if(titleArray.length == 2){
		_winTitle = typeof(getResource)!='undefined'?getResource(titleArray[0],titleArray[1]):getResource('picklist_redirect',panelName);
	}else if(titleArray.length == 1){
		_winTitle = typeof(getResource)!='undefined'?getResource(titleArray[0],panelName):getResource('picklist_redirect',panelName);
	}else{
		_winTitle = typeof(getResource)!='undefined'?getResource('picklist_redirect',panelName):'Add Data';
	}
	if(_winTitle==""){
		_winTitle = getResource('picklist_redirect',panelName);
	}
	if(typeof(Ext.getCmp(panelName+"_"+fieldName+"picklist_redirect_win_popUp_parent"))!="undefined"){
		maskObj = new Ext.LoadMask(Ext.getCmp(panelName+"_"+fieldName+"picklist_redirect_win_popUp_parent").getEl(), {msg:getResource("loading","")});
		maskObj.show();
		paramList.win_id=panelName+"_"+fieldName+"picklist_redirect_win_popUp_parent";
		Ext.getCmp(panelName+"_"+fieldName+"picklist_redirect_win_popUp_parent").show();
	}else{
		var windowItem;
		var windowString;
		var closeAction;
		paramList.win_id = panelName+"_"+fieldName+"picklist_redirect_win_popUp_parent";
		var jsFile
		jsFile = "views/dynamicGenerateScript/page_"+picklist_redirect_page+".js";
		windowString = "windowItem = new page_"+picklist_redirect_page+"({paramList:paramList});";
		myLoader.require(jsFile,function(){
			destroy_key_list.push(paramList.win_id);
			eval(windowString);
			var popWin = new Ext.Window({
				manager:windows,
				resizable:true,
				modal:true,
				id:panelName+"_"+fieldName+"picklist_redirect_win_popUp_parent",
				bodyStyle: "background: #fff;",
				autoscroll: true,
				layout:"fit",
				title:_winTitle,
				items:[{layout:'anchor',items:[windowItem]}],
				width:(parseInt(_win_width) > window.parent.document.body.clientWidth ? window.parent.document.body.clientWidth : parseInt(_win_width) ),
				minWidth:(parseInt(_win_width)  > window.parent.document.body.clientWidth ? window.parent.document.body.clientWidth : parseInt(_win_width) ),
				height:(parseInt(_win_height) > window.parent.document.body.clientHeight ? window.parent.document.body.clientHeight : parseInt(_win_height)),
				minHeight:(parseInt(_win_height) > window.parent.document.body.clientHeight ? window.parent.document.body.clientHeight : parseInt(_win_height)),
				listeners:{
					"beforehide":function(_win){
					},
					"close":function(){
						if(typeof(picklistObj)!="undefined"){
							if(picklistObj.getStore()!=null){
								picklistObj.getStore().load();
							}
						}
					}
				}
			});
			popWin.show()
		},this,true)
	}	
}

function getPrivPicklistRedirect(redirect_page_panel_list){
	var privFlag = false;
	if(redirect_page_panel_list !=''){
		var redirect_panel_list = redirect_page_panel_list.split(",");
		for(var i=0;i<redirect_panel_list.length;i++){
			if(getAppPriv(redirect_panel_list[i], '') == 1){
				privFlag = true;
			}
		}
	}else{
		privFlag = false;
	}
	return privFlag;
}

function createPicklistCompoment(panelName,fieldName,jsonPro,panelVariableArray,controlProperty){
	var compoment;
	var formPanel = Ext.getCmp(panelName+"_form");
	var fieldId=panelName+"_"+fieldName+"_id";	
	jsonPro.fieldId=fieldId;
	jsonPro.panelName=panelName;
	jsonPro.fieldName=fieldName;
	jsonPro.panelVariableArray=panelVariableArray;	
	
	if(jsonPro.picklistType=="COMBOBOX"){
		compoment={
			xtype:"combo",
			fieldLabel:jsonPro.fieldI18nKey,
			id:fieldId,
			name:fieldName,
			value:jsonPro.fieldValue,
			store:new Ext.data.JsonStore({
				url:"index.cfm?event=picklist.general.cascadeComboData&_dc="+new Date(),
				method:"post",
				root: "query.data",
				autoLoad:false,
				baseParams:{
					pname:panelName,
					fname:fieldName	
				},
				fields: [
					jsonPro.comboboxKeyColumn,jsonPro.comboboxValueColumn
		        ],
		        listeners:{
		        	load:function(_st){
		        		if(getPrivPicklistRedirect(jsonPro.redirect_page_panel_list)){
			        		var _record = new Ext.data.Record([jsonPro.comboboxKeyColumn , jsonPro.comboboxValueColumn]);
						    _record.set(jsonPro.comboboxKeyColumn ,"picklist_redirect") ;
						   	_record.set(jsonPro.comboboxValueColumn ,"----"+getResource('picklist_redirect',jsonPro.panelName)+"----") ;
						   	_record.set("url" ,"../ext/resources/images/icons/cog_edit.png") ;
						   	_st.insert(0,_record);
		        		}
		        	}
		        },
				remoteSort:true
			}),
			hiddenName:fieldName,
			displayField:jsonPro.comboboxValueColumn,
	        valueField:jsonPro.comboboxKeyColumn,
        	tpl: '<tpl for=".">' +
        		'<tpl if="typeof(url)!=\'undefined\'">' +
        			'<div class="x-combo-list-item" style="text-align:left;background:#B1D3EC;">' +
        			'<img src="{url}" style="height:15px;">&nbsp;' +
        			'{'+jsonPro.comboboxValueColumn+'}' +
        			'</div>'+
        		'</tpl>'+
        		'<tpl if="typeof(url)==\'undefined\'">' +
        			'<div class="x-combo-list-item">' +
        			'{'+jsonPro.comboboxValueColumn+'}' +
        			'</div>'+
        		'</tpl>'+
        		'</tpl>',
        		
        		
	        forceSelection:true,
	        selectOnFocus:true,
	        typeAhead: true,
			triggerAction:"all",
			enableKeyEvents:true,
			resizable:true,
	        mode:"local",
	        listeners:{
	        	scope:compoment,
	        	blur:function(){
	        		isNeedConfirmDirtyData(Ext.getCmp(this.jsonPro.panelName+"_form"),this.jsonPro.isNeedConfirmDirtyData);
	        	},
	        	keyup:function(){
	        		isNeedConfirmDirtyData(Ext.getCmp(this.jsonPro.panelName+"_form"),this.jsonPro.isNeedConfirmDirtyData);
	        	},
	        	render:function(_cmp){
	        		if(this.jsonPro.isVisibleRender=="0"){
		        		this.setVisible(false);
						this.ownerCt.doLayout();  
	        		}
	        	},
	        	select:function(_combo,_record,_index){
	        		if(_record.get(jsonPro.comboboxKeyColumn)=="picklist_redirect"){
	        			_combo.setValue("");
	        			_combo.collapse();
	        			createPicklistRedirect(this.jsonPro.panelName,this.jsonPro.fieldName,this.jsonPro.picklist_redirect_page,this.jsonPro.redirect_page_title,this.jsonPro.redirect_page_width,this.jsonPro.redirect_page_height,_combo);
	        		}else{
		        		isNeedConfirmDirtyData(Ext.getCmp(this.jsonPro.panelName+"_form"),this.jsonPro.isNeedConfirmDirtyData);
		        		if(this.jsonPro.isNeedPicklistFilter=="1"){
		        			addPicklistFilterEvent(this.jsonPro.panelName,this.jsonPro.fieldName,"1");
		        		}
		        		if(this.jsonPro.editGridId==""){
		        			eval('Ext.getCmp("'+this.jsonPro.panelName+'_form").'+this.jsonPro.panelName+"_setStyle()");
		        		}
	        		}
	        	},
	        	change:function(){
	        		if(this.jsonPro.isNeedPicklistFilter=="1"){
	        			addPicklistFilterEvent(this.jsonPro.panelName,this.jsonPro.fieldName,"1");
	        		}
	        	}
	        }
		}
	}else if(jsonPro.picklistType=="MUTILCASCADECOMBO"){
		compoment={
			xtype:"lovcombo",
			fieldLabel:jsonPro.fieldI18nKey, 
			id: fieldId, 
			name: fieldName, 
			enableKeyEvents:true,
			store:new Ext.data.JsonStore({
				url:"index.cfm?event=picklist.general.cascadeComboData&_dc="+new Date(),
				method:"post",
				root: "query.data",
				autoLoad:false,
				baseParams:{
					pname:panelName,
					fname:fieldName	
				},
				fields: [
					jsonPro.comboboxKeyColumn,jsonPro.comboboxValueColumn
		        ],
		        listeners:{
		        	load:function(_st){
		        		if(getPrivPicklistRedirect(jsonPro.redirect_page_panel_list)){
			        		var _record = new Ext.data.Record([jsonPro.comboboxKeyColumn , jsonPro.comboboxValueColumn]);
						    _record.set(jsonPro.comboboxKeyColumn ,"picklist_redirect") ;
						   		_record.set(jsonPro.comboboxValueColumn ,"----"+getResource('picklist_redirect',jsonPro.panelName)+"----") ;
						   	_record.set("url" ,"../ext/resources/images/icons/cog_edit.png") ;
						   	_st.insert(0,_record);
		        		}
		        	}
		        },
				remoteSort:true
			}),
			hiddenName:fieldName,
			displayField:jsonPro.comboboxValueColumn,
	        valueField:jsonPro.comboboxKeyColumn,
	        triggerAction:"all",
	        beforeBlur:function(){},
			resizable:true,
	        mode:"local",
	        "onTriggerClick": function(){
	        	if(this.disabled||this.readOnly){
		            return;
		        }
		        if(this.isExpanded()){
		            this.collapse();
		            this.el.focus();
		        }else {
		            this.onFocus({});
		            this.el.focus();
		            try{
			            if(this.triggerAction == 'all') {
			                this.doQuery(this.allQuery, true);
			            } else {
			                this.doQuery(this.getRawValue());
			            }
		            }catch(e){
		            	
		            }
		            this.fireEvent("focus",this);
		        }
	        },
	        listeners:{
	        	scope:compoment,
	        	blur:function(){
	        		isNeedConfirmDirtyData(Ext.getCmp(this.jsonPro.panelName+"_form"),this.jsonPro.isNeedConfirmDirtyData);
	        	},
	        	keyup:function(){
	        		isNeedConfirmDirtyData(Ext.getCmp(this.jsonPro.panelName+"_form"),this.jsonPro.isNeedConfirmDirtyData);
	        	},
	        	render:function(_combo){
	        		if(jsonPro.fieldValue!=""){
        				var panelVariable={};
        				if(this.jsonPro.panelVariableArray!=null&&typeof(this.jsonPro.panelVariableArray)!='undefined'){
							panelVariable=getPanelVariable(this.jsonPro.panelName,this.jsonPro.panelVariableArray);
						}
						panelVariable.pname=this.jsonPro.panelName;
        				panelVariable.fname=this.jsonPro.fieldName;
        				var store = _combo.getStore();
        				store.baseParams=panelVariable;
	        			store.on("load",function(){
		        			for(var i=0;i<store.getTotalCount();i++){
		        				var key = store.getAt(i).data[this.jsonPro.comboboxKeyColumn];
		        				if(fieldValue==key){
		        					_combo.setValue(store.getAt(i).data[this.jsonPro.comboboxKeyColumn]);
		        					break;
		        				}									
		        			}
	        			});		        			
	        		}
	        		if(this.jsonPro.isVisibleRender=="0"){
		        		this.setVisible(false);
						this.ownerCt.doLayout();  
	        		} 
	        	},
	        	focus:function(_combo){
	        		if(this.disabled||this.readOnly){
			            return;
			        }
		        	var formValues = new Object();
		        	var formParameterObj;
		        	if(this.jsonPro.editGridId!=""){
		        		var myGrid = Ext.getCmp(this.jsonPro.editGridId);
						var editor =  myGrid.activeEditor;
						var editorrow = editor.row;
						var editorcol = editor.col;
						formValues=myGrid.getStore().getAt(editorrow).data;
						formParameterObj = Ext.getCmp(this.jsonPro.panelName).paramList;
		        	}else{
		        		formValues = Ext.getCmp(this.jsonPro.panelName+"_form").getForm().getValues();
		        		var radiogroupValues = Ext.getCmp(this.jsonPro.panelName+"_form").find('picklistType','RADIOGROUP');
						var checkboxgroupValues = Ext.getCmp(this.jsonPro.panelName+"_form").find('picklistType','CHECKBOXGROUP');
						var rfield,rfieldValue;
						for(var s=0;s<radiogroupValues.length;s++){
							rfield=radiogroupValues[s].fieldName;
							rfieldValue=getRadioGroupValue(this.jsonPro.panelName,rfield);
							formValues[rfield]=rfieldValue;
						}
						for(var s=0;s<checkboxgroupValues.length;s++){
							rfield=checkboxgroupValues[s].fieldName;
							rfieldValue=getCheckboxGroupValues(this.jsonPro.panelName,rfield);
							formValues[rfield]=rfieldValue;
						}
						formParameterObj = Ext.getCmp(this.jsonPro.panelName+"_form").paramList;
		        	}
		        	Ext.applyIf(formValues,formParameterObj);
		        	var panelVariable={};
    				if(this.jsonPro.panelVariableArray!=null&&typeof(this.jsonPro.panelVariableArray)!='undefined'){
						panelVariable=getPanelVariable(this.jsonPro.panelName,this.jsonPro.panelVariableArray);
					}
					Ext.apply(panelVariable,formValues);
        			panelVariable.pname=this.jsonPro.panelName;
        			panelVariable.fname=this.jsonPro.fieldName;
        			_combo.getStore().baseParams=panelVariable;
	        		_combo.getStore().load();
	        		_combo.getStore().on("load",function(){
	        			_combo.setValue(_combo.getValue());
	        		});
	        	},
	        	select:function(_combo,_record,_index){
	        		if(_record.get(jsonPro.comboboxKeyColumn)=="picklist_redirect"){
	        			_combo.clearValue();
	        			_combo.collapse();
	        			createPicklistRedirect(this.jsonPro.panelName,this.jsonPro.fieldName,this.jsonPro.picklist_redirect_page,this.jsonPro.redirect_page_title,this.jsonPro.redirect_page_width,this.jsonPro.redirect_page_height,_combo);
	        		}else{
		        		isNeedConfirmDirtyData(Ext.getCmp(this.jsonPro.panelName+"_form"),this.jsonPro.isNeedConfirmDirtyData);
		        		if(this.jsonPro.isNeedPicklistFilter=="1"){
		        			addPicklistFilterEvent(this.jsonPro.panelName,this.jsonPro.fieldName,"1");
		        		}
		        		if(this.jsonPro.editGridId==""){
		        			eval('Ext.getCmp("'+this.jsonPro.panelName+'_form").'+this.jsonPro.panelName+"_setStyle()");
		        		}
	        		}
	        	},
	        	change:function(_combo){
	        		if(this.jsonPro.isNeedPicklistFilter=="1"){
	        			addPicklistFilterEvent(this.jsonPro.panelName,this.jsonPro.fieldName,"1");
	        		}
	        	}
	        }
		}
	}else if(jsonPro.picklistType=="CASCADECOMBO"){
		compoment={
			xtype:"combo",
			fieldLabel:jsonPro.fieldI18nKey, 
			id: fieldId, 
			name: fieldName, 
			enableKeyEvents:true,
			store:new Ext.data.JsonStore({
				url:"index.cfm?event=picklist.general.cascadeComboData&_dc="+new Date(),
				method:"post",
				root: "query.data",
				autoLoad:false,
				baseParams:{
					pname:panelName,
					fname:fieldName	
				},
				fields: [
					jsonPro.comboboxKeyColumn,jsonPro.comboboxValueColumn
		        ],
		        listeners:{
		        	load:function(_st){
		        		if(getPrivPicklistRedirect(jsonPro.redirect_page_panel_list)){
			        		var _record = new Ext.data.Record([jsonPro.comboboxKeyColumn , jsonPro.comboboxValueColumn]);
						    _record.set(jsonPro.comboboxKeyColumn ,"picklist_redirect") ;
						   	_record.set(jsonPro.comboboxValueColumn ,"----"+getResource('picklist_redirect',jsonPro.panelName)+"----") ;
						   	_record.set("url" ,"../ext/resources/images/icons/cog_edit.png") ;
						   	_st.insert(0,_record);
		        		}
		        	}
		        },
				remoteSort:true
			}),
			hiddenName:fieldName,
			displayField:jsonPro.comboboxValueColumn,
	        valueField:jsonPro.comboboxKeyColumn,
	        tpl: '<tpl for=".">' +
        		'<tpl if="typeof(url)!=\'undefined\'">' +
        			'<div class="x-combo-list-item" style="text-align:left;background:#B1D3EC;">' +
        			'<img src="{url}" style="height:15px;">&nbsp;' +
        			'{'+jsonPro.comboboxValueColumn+'}' +
        			'</div>'+
        		'</tpl>'+
        		'<tpl if="typeof(url)==\'undefined\'">' +
        			'<div class="x-combo-list-item">' +
        			'{'+jsonPro.comboboxValueColumn+'}' +
        			'</div>'+
        		'</tpl>'+
        		'</tpl>',
     		forceSelection:true,
	        selectOnFocus:true,
			triggerAction:"all",
			resizable:true,
	        mode:"local",
	        "onTriggerClick": function(){
	        	if(this.disabled||this.readOnly){
		            return;
		        }
		        if(this.isExpanded()){
		            this.collapse();
		            this.el.focus();
		        }else {
		            this.onFocus({});
		            this.el.focus();
		            try{
			            if(this.triggerAction == 'all') {
			                this.doQuery(this.allQuery, true);
			            } else {
			                this.doQuery(this.getRawValue());
			            }
		            }catch(e){
		            	
		            }
		            this.fireEvent("focus",this);
		        }
	        },
	        listeners:{
	        	scope:compoment,
	        	blur:function(){
	        		isNeedConfirmDirtyData(Ext.getCmp(this.jsonPro.panelName+"_form"),this.jsonPro.isNeedConfirmDirtyData);
	        	},
	        	keyup:function(){
	        		isNeedConfirmDirtyData(Ext.getCmp(this.jsonPro.panelName+"_form"),this.jsonPro.isNeedConfirmDirtyData);
	        	},
	        	render:function(_combo){
	        		if(this.jsonPro.fieldValue!=""){
	        			var panelVariable={};
        				if(this.jsonPro.panelVariableArray!=null&&typeof(this.jsonPro.panelVariableArray)!='undefined'){
							panelVariable=getPanelVariable(this.jsonPro.panelName,this.jsonPro.panelVariableArray);
						}
						panelVariable.pname=this.jsonPro.panelName;
        				panelVariable.fname=this.jsonPro.fieldName;
        				var store = _combo.getStore();
        				store.baseParams=panelVariable;
	        			store.on("load",function(){
		        			for(var i=0;i<store.getTotalCount();i++){
		        				var key = store.getAt(i).data[this.jsonPro.comboboxKeyColumn];
		        				if(this.jsonPro.fieldValue==key){
		        					_combo.setValue(store.getAt(i).data[this.jsonPro.comboboxKeyColumn]);
		        					break;
		        				}									
		        			}
	        			});		        			
	        		}
	        		if(this.jsonPro.isVisibleRender=="0"){
		        		this.setVisible(false);
						this.ownerCt.doLayout();  
	        		}
	        	},
	        	focus:function(_combo){
	        		if(this.disabled||this.readOnly){
			            return;
			        }
		        	var formValues = new Object();
		        	var formParameterObj;
		        	if(this.jsonPro.editGridId!=""){
		        		var myGrid = Ext.getCmp(this.jsonPro.editGridId);
						var editor =  myGrid.activeEditor;
						var editorrow = editor.row;
						var editorcol = editor.col;
						formValues=myGrid.getStore().getAt(editorrow).data;
						formParameterObj = Ext.getCmp(this.jsonPro.panelName).paramList;
		        	}else{
		        		formValues = Ext.getCmp(this.jsonPro.panelName+"_form").getForm().getValues();
		        		var radiogroupValues = Ext.getCmp(this.jsonPro.panelName+"_form").find('picklistType','RADIOGROUP');
						var checkboxgroupValues = Ext.getCmp(this.jsonPro.panelName+"_form").find('picklistType','CHECKBOXGROUP');
						var rfield,rfieldValue;
						for(var s=0;s<radiogroupValues.length;s++){
							rfield=radiogroupValues[s].fieldName;
							rfieldValue=getRadioGroupValue(this.jsonPro.panelName,rfield);
							formValues[rfield]=rfieldValue;
						}
						for(var s=0;s<checkboxgroupValues.length;s++){
							rfield=checkboxgroupValues[s].fieldName;
							rfieldValue=getCheckboxGroupValues(this.jsonPro.panelName,rfield);
							formValues[rfield]=rfieldValue;
						}
						formParameterObj = Ext.getCmp(this.jsonPro.panelName+"_form").paramList;
		        	}
		        	Ext.applyIf(formValues,formParameterObj);
		        	var panelVariable={};
    				if(this.jsonPro.panelVariableArray!=null&&typeof(this.jsonPro.panelVariableArray)!='undefined'){
						panelVariable=getPanelVariable(this.jsonPro.panelName,this.jsonPro.panelVariableArray);
					}
					Ext.apply(panelVariable,formValues);
        			panelVariable.pname=this.jsonPro.panelName;
        			panelVariable.fname=this.jsonPro.fieldName;
        			_combo.getStore().baseParams=panelVariable;
	        		_combo.getStore().load();
	        	},
	        	select:function(_combo,_record,_index){
	        		if(_record.get(jsonPro.comboboxKeyColumn)=="picklist_redirect"){
	        			_combo.setValue("");
	        			_combo.collapse();
	        			createPicklistRedirect(this.jsonPro.panelName,this.jsonPro.fieldName,this.jsonPro.picklist_redirect_page,this.jsonPro.redirect_page_title,this.jsonPro.redirect_page_width,this.jsonPro.redirect_page_height,_combo);
	        		}else{
		        		isNeedConfirmDirtyData(Ext.getCmp(this.jsonPro.panelName+"_form"),this.jsonPro.isNeedConfirmDirtyData);
		        		if(this.jsonPro.isNeedPicklistFilter=="1"){
		        			addPicklistFilterEvent(this.jsonPro.panelName,this.jsonPro.fieldName,"1");
		        		}
		        		if(this.jsonPro.editGridId==""){
		        			eval('Ext.getCmp("'+this.jsonPro.panelName+'_form").'+this.jsonPro.panelName+"_setStyle()");
		        		}
	        		}
	        	},
	        	change:function(_combo){
	        		if(this.jsonPro.isNeedPicklistFilter=="1"){
	        			addPicklistFilterEvent(this.jsonPro.panelName,this.jsonPro.fieldName,"1");
	        		}
	        	}
	        }
		}
	}else if(jsonPro.picklistType=="MULTICOMBOBOX"){
		compoment={
			xtype:"lovcombo",
			fieldLabel:jsonPro.fieldI18nKey, 
			id: fieldId, 
			name: fieldName, 
			enableKeyEvents:true,
			store:new Ext.data.JsonStore({
				url:"index.cfm?event=picklist.general.cascadeComboData&_dc="+new Date(),
				method:"post",
				root: "query.data",
				autoLoad:false,
				baseParams:{
					pname:panelName,
					fname:fieldName	
				},
				fields: [
					jsonPro.comboboxKeyColumn,jsonPro.comboboxValueColumn
		        ],
		        listeners:{
		        	load:function(_st){
		        		if(getPrivPicklistRedirect(jsonPro.redirect_page_panel_list)){
			        		var _record = new Ext.data.Record([jsonPro.comboboxKeyColumn , jsonPro.comboboxValueColumn]);
						    _record.set(jsonPro.comboboxKeyColumn ,"picklist_redirect") ;
						   		_record.set(jsonPro.comboboxValueColumn ,"----"+getResource('picklist_redirect',jsonPro.panelName)+"----") ;
						   	_record.set("url" ,"../ext/resources/images/icons/cog_edit.png") ;
						   	_st.insert(0,_record);
		        		}
		        	}
		        },
				remoteSort:true
			}),
			hiddenName:fieldName,
			displayField:jsonPro.comboboxValueColumn,
	        valueField:jsonPro.comboboxKeyColumn,
			triggerAction:"all",
			editable:false,				
			resizable:true,
	        mode:"local",
			beforeBlur:function(){},
			listeners:{
				scope:compoment,
				render:function(){
	        		if(this.jsonPro.isVisibleRender=="0"){
		        		this.setVisible(false);
						this.ownerCt.doLayout();  
	        		}	
	        	},
	        	blur:function(){
	        		isNeedConfirmDirtyData(Ext.getCmp(this.jsonPro.panelName+"_form"),this.jsonPro.isNeedConfirmDirtyData);
	        	},
	        	keyup:function(){
	        		isNeedConfirmDirtyData(Ext.getCmp(this.jsonPro.panelName+"_form"),this.jsonPro.isNeedConfirmDirtyData);
	        	},
	        	select:function(_combo,_record,_index){
	        		if(_record.get(jsonPro.comboboxKeyColumn)=="picklist_redirect"){
	        			_combo.clearValue();
	        			_combo.collapse();
	        			createPicklistRedirect(this.jsonPro.panelName,this.jsonPro.fieldName,this.jsonPro.picklist_redirect_page,this.jsonPro.redirect_page_title,this.jsonPro.redirect_page_width,this.jsonPro.redirect_page_height,_combo);
	        		}else{
		        		isNeedConfirmDirtyData(Ext.getCmp(this.jsonPro.panelName+"_form"),this.jsonPro.isNeedConfirmDirtyData);
		        		if(this.jsonPro.isNeedPicklistFilter=="1"){
		        			addPicklistFilterEvent(this.jsonPro.panelName,this.jsonPro.fieldName,"1");
		        		}
		        		if(this.jsonPro.editGridId==""){
		        			eval('Ext.getCmp("'+this.jsonPro.panelName+'_form").'+this.jsonPro.panelName+"_setStyle()");
		        		}
	        		}
	        	}
	        }
		}
	}else if(jsonPro.picklistType=="POPUP"){
		compoment={
			xtype:"trigger",
			fieldLabel:jsonPro.fieldI18nKey, 
			id: fieldId, 
			name: fieldName, 
			hiddenName:fieldName,
			value: jsonPro.fieldValue,
			triggerClass:"x-form-search-trigger",
			enableKeyEvents:true,
			editable:jsonPro.isEditable,
			listeners:{
				scope:compoment,
				render:function(){
	        		if(this.jsonPro.isVisibleRender=="0"){
		        		this.setVisible(false);
						this.ownerCt.doLayout();  
	        		} 	
	        	},
				blur:function(){
	        		isNeedConfirmDirtyData(Ext.getCmp(this.jsonPro.panelName+"_form"),this.jsonPro.isNeedConfirmDirtyData);
	        	},
	        	keyup:function(){
	        		isNeedConfirmDirtyData(Ext.getCmp(this.jsonPro.panelName+"_form"),this.jsonPro.isNeedConfirmDirtyData);
	        	}
			},
			onTriggerClick: function() {
				if(this.disabled||this.readOnly){
		            return;
		        }
				var fieldname = this.name;
				var field_id = this.id;
				var formValues = new Object();
				var formParameterObj;
				if(this.jsonPro.editGridId==""){
					formValues = Ext.getCmp(this.jsonPro.panelName+"_form").getForm().getValues();
					var radiogroupValues = Ext.getCmp(this.jsonPro.panelName+"_form").find('picklistType','RADIOGROUP');
					var checkboxgroupValues = Ext.getCmp(this.jsonPro.panelName+"_form").find('picklistType','CHECKBOXGROUP');
					var rfield,rfieldValue;
					for(var s=0;s<radiogroupValues.length;s++){
						rfield=radiogroupValues[s].fieldName;
						rfieldValue=getRadioGroupValue(this.jsonPro.panelName,rfield);
						formValues[rfield]=rfieldValue;
					}
					for(var s=0;s<checkboxgroupValues.length;s++){
						rfield=checkboxgroupValues[s].fieldName;
						rfieldValue=getCheckboxGroupValues(this.jsonPro.panelName,rfield);
						formValues[rfield]=rfieldValue;
					}
					formValues.sourcePage="formpanel";
					formValues.needDelimiter="0";
					formParameterObj = Ext.getCmp(this.jsonPro.panelName+"_form").paramList;
					Ext.applyIf(formValues,formParameterObj);
				}else{
					var myGrid = Ext.getCmp(this.jsonPro.editGridId);
					var editor =  myGrid.activeEditor;
					var editorrow = editor.row;
					var editorcol = editor.col;
					formValues=myGrid.getStore().getAt(editorrow).data;
					formValues.sourcePage="editgrid";
					formValues.needDelimiter="0";
					formValues.editgrid_id=this.jsonPro.editGridId;
					formValues.editorrow=editorrow;
					formValues.editorcol=editorcol;
				}
				var panelVariable={};
				if(this.jsonPro.panelVariableArray!=null&&typeof(this.jsonPro.panelVariableArray)!='undefined'){
					panelVariable=getPanelVariable(this.jsonPro.panelName,this.jsonPro.panelVariableArray);
				}
				Ext.applyIf(formValues,panelVariable);
				delete formValues.start_time;
				delete formValues.end_time;
				if(typeof(Ext.getCmp("picklist_"+this.jsonPro.panelName+"_"+this.jsonPro.fieldName))!="undefined"){
					Ext.getCmp("picklist_"+this.jsonPro.panelName+"_"+this.jsonPro.fieldName).show();
				}else{
					var jsFile = "views/dynamicGenerateScript/picklist_"+this.jsonPro.panelName+"_"+this.jsonPro.fieldName+".js";
					myLoader.require(jsFile,function(){
						eval("var win = new picklist_"+compoment.jsonPro.panelName+"_"+compoment.jsonPro.fieldName+"({paramList:formValues}).show();");
					},this,true);
				}
				return false;
			}
		}
	}else if(jsonPro.picklistType=="EDITORWINDOW"){
		compoment={
			xtype:"textarea",
			fieldLabel:jsonPro.fieldI18nKey, 
			id: fieldId, 
			name: fieldName,
			hiddenName:fieldName,
			height:21,
			value: jsonPro.fieldValue,
			style:"x-form-trigger x-form-search-trigger",
			enableKeyEvents:true,
			editable:jsonPro.isEditable,
			listeners:{
				scope:compoment,
				render:function(){
	        		if(this.jsonPro.isVisibleRender=="0"){
		        		this.setVisible(false);
						this.ownerCt.doLayout();  
	        		}
	        	},
				blur:function(){
	        		isNeedConfirmDirtyData(Ext.getCmp(this.jsonPro.panelName+"_form"),this.jsonPro.isNeedConfirmDirtyData);
	        	},
	        	keyup:function(){
	        		isNeedConfirmDirtyData(Ext.getCmp(this.jsonPro.panelName+"_form"),this.jsonPro.isNeedConfirmDirtyData);
	        	},
	        	focus:function(){
	        		if(this.disabled||this.readOnly){
			            return;
			        }
	        		 writeSQLWin = Ext.extend(Ext.Window,{
						srcWhere:null,
						sqlValue:null,
						constructor:function(_cfg){
							if(_cfg==null)_cfg={};
							Ext.apply(this,_cfg);
							this.srcWhere = _cfg.srcWhere;
							this.sqlValue = _cfg.sqlValue;
							writeSQLWin.superclass.constructor.call(this,{
								title:getResource('editorWindow',jsonPro.panelName),
								id:jsonPro.panelName+"_"+jsonPro.fieldName+"_writeSQLWin_id",
								width:940>window.parent.document.body.clientWidth?window.parent.document.body.clientWidth:940,
								height:550>window.parent.document.body.clientHeight?window.parent.document.body.clientHeight:550,
								iconCls:"property_title",
								modal:true,
								resizable:true,
								maximizable:true,
								layout:"fit",
								items:[{
									id:jsonPro.panelName+"_"+jsonPro.fieldName+"_sql_area_id",
									xtype:"textarea",
									enableKeyEvents:true,
									width : 940>window.parent.document.body.clientWidth?window.parent.document.body.clientWidth-30:910,
									height : 550>window.parent.document.body.clientHeight?window.parent.document.body.clientHeight-20:530,
									style:"font-size: 10pt; font-weight: bold; font-family: Courier New,Sans Serif,Times New Roman;",
									listeners:{
										"keydown":function(cmp, e) {
											var o = cmp.el.dom;
											function insertTab(o, e){
												var kC = e.keyCode ? e.keyCode : e.charCode ? e.charCode : e.which;
												if (kC == 9 && !e.shiftKey && !e.ctrlKey && !e.altKey)
												{
													var oS = o.scrollTop;
													if (o.setSelectionRange)
													{
														var sS = o.selectionStart;
														var sE = o.selectionEnd;
														o.value = o.value.substring(0, sS) + "\t" + o.value.substr(sE);
														o.setSelectionRange(sS + 1, sS + 1);
														o.focus();
													}
													else if (o.createTextRange)
													{
														document.selection.createRange().text = "\t";
														e.returnValue = false;
													}
													o.scrollTop = oS;
													if (e.preventDefault)
													{
														e.preventDefault();
													}
													return false;
												}
												return true;
											}
											insertTab(o,e);
										},
										scope:this
									}
								}],
								tbar:[{
									text:getResource("save",jsonPro.panelName),
									icon:"../ext/resources/images/icons/save.gif",
									id:jsonPro.panelName+"_"+jsonPro.fieldName+"_save_sql_id",
									scope:this,
									handler:function(){
										var _v = Ext.getCmp(jsonPro.panelName+"_"+jsonPro.fieldName+"_sql_area_id").getValue();
										if(jsonPro.editGridId!=""){
											var myGrid = Ext.getCmp(jsonPro.editGridId);
											myGrid.startEditing(myGrid.rowIndex, myGrid.columnIndex);
											var editor =  myGrid.activeEditor;
											editor.setValue(_v);
											myGrid.stopEditing();
										}else{
											Ext.getCmp(jsonPro.fieldId).setValue(_v);
										}
										Ext.getCmp(jsonPro.panelName+"_"+jsonPro.fieldName+"_writeSQLWin_id").close();
									}
								}],
								listeners:{
									afterrender:function() {
										var _v = Ext.getCmp(jsonPro.fieldId).getValue();
										var _title = Ext.getCmp(jsonPro.fieldId).fieldLabel;
										Ext.getCmp(jsonPro.panelName+"_"+jsonPro.fieldName+"_writeSQLWin_id").setTitle(_title);
										Ext.getCmp(jsonPro.panelName+"_"+jsonPro.fieldName+"_sql_area_id").setValue(_v);
									}
								}
							})
						}
					});
					new writeSQLWin().show();
	        	}
			}
		}
	}else if(jsonPro.picklistType=="COLORPALETTE"){
		compoment={
			fieldLabel:jsonPro.fieldI18nKey, 
			id: fieldId, 
			xtype:"textfield",
			name: fieldName,
			hiddenName:fieldName,
			value: jsonPro.fieldValue,
			enableKeyEvents:true,
			editable:jsonPro.isEditable,
			listeners:{
				scope:compoment,
				render:function(){
	        		if(this.jsonPro.isVisibleRender=="0"){
		        		this.setVisible(false);
						this.ownerCt.doLayout();  
	        		}
	        	},
				focus:function(_compoment){
					if(this.disabled||this.readOnly){
			            return;
			        }
					var colorPalette = new Ext.ColorPalette({
						scope:_compoment,
						listeners:{
							scope:_compoment,
							select:function(_p,_value){
								if(_compoment.jsonPro.editGridId!=""){
									var myGrid = Ext.getCmp(this.jsonPro.editGridId);
									myGrid.startEditing(myGrid.rowIndex, myGrid.columnIndex);
									var editor =  myGrid.activeEditor;
									editor.setValue(_value);
									myGrid.stopEditing();
								}else{
									Ext.getCmp(_compoment.jsonPro.fieldId).setValue('#'+_value);
									Ext.getCmp(_compoment.jsonPro.fieldId).el.setStyle({
										'backgroundImage':'url(includes/images/s.gif)',
										'backgroundColor':'#'+_value
									});
								}
								Ext.getCmp('color_win').close();
							}
						}
					});
					colorPalette.colors=['000000','272727','3C3C3C','4F4F4F','5B5B5B','6C6C6C','7B7B7B','8E8E8E','9D9D9D','ADADAD','BEBEBE','D0D0D0','E0E0E0','F0F0F0','FCFCFC','FFFFFF',
					'2F0000','4D0000','600000','750000','930000','AE0000','CE0000','EA0000','FF0000','FF2D2D','FF5151','FF7575','FF9797','FFB5B5','FFD2D2','FFECEC',
					'600030','820041','9F0050','BF0060','D9006C','F00078','FF0080','FF359A','FF60AF','FF79BC','FF95CA','FFAAD5','FFC1E0','FFD9EC','FFECF5','FFF7FB',
					'460046','5E005E','750075','930093','AE00AE','D200D2','E800E8','FF00FF','FF44FF','FF77FF','FF8EFF','FFA6FF','FFBFFF','FFD0FF','FFE6FF','FFF7FF',
					'000079','000093','0000C6','0000C6','0000E3','2828FF','4A4AFF','6A6AFF','7D7DFF','9393FF','AAAAFF','B9B9FF','CECEFF','DDDDFF','ECECFF','FBFBFF',
					'000079','003D79','004B97','005AB5','0066CC','0072E3','0080FF','2894FF','46A3FF','66B3FF','84C1FF','97CBFF','ACD6FF','C4E1FF','D2E9FF','ECF5FF',
					'003E3E','005757','007979','009393','00AEAE','00CACA','00E3E3','00FFFF','4DFFFF','80FFFF','A6FFFF','BBFFFF','CAFFFF','D9FFFF','ECFFFF','FDFFFF',
					'006030','01814A','019858','01B468','02C874','02DF82','02F78E','1AFD9C','4EFEB3','7AFEC6','96FED1','ADFEDC','C1FFE4','D7FFEE','E8FFF5','FBFFFD',
					'467500','548C00','64A600','73BF00','82D900','8CEA00','9AFF02','A8FF24','B7FF4A','C2FF68','CCFF80','D3FF93','DEFFAC','E8FFC4','EFFFD7','F5FFE8',
					'424200','5B5B00','737300','8C8C00','A6A600','C4C400','E1E100','F9F900','FFFF37','FFFF6F','FFFF93','FFFFAA','FFFFB9','FFFFCE','FFFFDF','FFFFF4',
					'5B4B00','796400','977C00','AE8F00','C6A300','D9B300','EAC100','FFD306','FFDC35','FFE153','FFE66F','FFED97','FFF0AC','FFF4C1','FFF8D7','FFFCEC',
					'844200','9F5000','BB5E00','D26900','EA7500','FF8000','FF9224','FFA042','FFAF60','FFBB77','FFC78E','FFD1A4','FFDCB9','FFE4CA','FFEEDD','FFFAF4',
					'6e1010','613030','743A3A','804040','984B4B','Aa5A5A','AD5A5A','B37070','B87070','C28888','C48888','CF9E9E','D9B3B3','E1C4C4','EBD6D6','F2E6E6',
					'616100','616130','707000','707038','808040','949449','A5a500','A5A552','AFAF61','B9B900','B9B973','C2C287','CDCD9A','D6D6AD','DEDEBE','E8E8D0',
					'336660','336666','3D7878','406060','408080','4F9D9D','5C8080','5CADAD','6FB7B7','71c0c0','81C0C0','95CACA','A3D1D1','B3D9D9','C4E1E1','D1E9E9',
					'484791','484891','5151A2','5A5AAD','7373B9','8070C0','8080C0','9989CC','9999CC','A6A6D2','B8a8DC','B8B8DC','C7C7E2','D8D8EB','E6E6F2','F3F3FA',
					'28004D','3A006F','4B0091','5B00AE','6F00D2','8600FF','921AFF','9F35FF','B15BFF','BE77FF','CA8EFF','D3A4FF','DCB5FF','E6CAFF','F1E1FF','FAF4FF',
					'006000','007500','009100','00A600','00BB00','00DB00','00EC00','28FF28','53FF53','79FF79','93FF93','A6FFA6','BBFFBB','CEFFCE','DFFFDF','F0FFF0',
					'642100','842B00','A23400','BB3D00','D94600','F75000','FF5809','FF8040','FF8F59','FF9D6F','FFAD86','FFBD9D','FFCBB3','FFDAC8','FFE6D9','FFF3EE',
					'663365','6C3365','703D76','7E3D76','804586','8F4586','9F4D95','AE57A4','B066AD','B766AD','C07AB8','CA8EC2','D2A2CC','DAB1D5','E2C2DE','EBD3E8'];
					var win = new Ext.Window({
						width: 305,
						id:'color_win',
						height:420,
						title: getResource('color_palette',panelName),
						items:colorPalette,
						modal:true,
						closable:true,
						tbar: new Ext.Toolbar({
				            items: [{
				                text: 'clear Color',
				                icon:'../ext/resources/images/icons/cog_edit.png',
				                handler: function() {
				                		Ext.getCmp(compoment.jsonPro.fieldId).setValue('');
										Ext.getCmp('color_win').close();
				                }
				            }]
				        })
					}).show();			
				}
			}
		}
	}else if(jsonPro.picklistType=="TIMEFIELD"){
		compoment={
			xtype:"timefield",
			listeners:{
				scope:compoment,
				render:function(){
	        		if(this.jsonPro.isVisibleRender=="0"){
		        		this.setVisible(false);
						this.ownerCt.doLayout();  
	        		}
	        	},
				blur:function(){
	        		isNeedConfirmDirtyData(Ext.getCmp(this.jsonPro.panelName+"_form"),this.jsonPro.isNeedConfirmDirtyData);
	        	},
	        	keyup:function(){
	        		isNeedConfirmDirtyData(Ext.getCmp(this.jsonPro.panelName+"_form"),this.jsonPro.isNeedConfirmDirtyData);
	        	},
	        	select:function(){
	        		isNeedConfirmDirtyData(Ext.getCmp(this.jsonPro.panelName+"_form"),this.jsonPro.isNeedConfirmDirtyData);
	        	}
			},
			fieldLabel:jsonPro.fieldI18nKey, 
			id: fieldId, 
			name: fieldName,
			hiddenName:fieldName,
			value: jsonPro.fieldValue,
			enableKeyEvents:true
		}
	}else if(jsonPro.picklistType=="NUMBERFIELD"){
		compoment={
			xtype:"numberfield",
			enableKeyEvents:true,
			listeners:{
				scope:compoment,
				render:function(){
	        		if(this.jsonPro.isVisibleRender=="0"){
		        		this.setVisible(false);
						this.ownerCt.doLayout();  
	        		}
	        	},
				blur:function(){
	        		isNeedConfirmDirtyData(Ext.getCmp(this.jsonPro.panelName+"_form"),this.jsonPro.isNeedConfirmDirtyData);
	        	},
	        	keyup:function(){
	        		isNeedConfirmDirtyData(Ext.getCmp(this.jsonPro.panelName+"_form"),this.jsonPro.isNeedConfirmDirtyData);
	        	}
			},
			fieldLabel:jsonPro.fieldI18nKey, 
			id: fieldId, 
			name: fieldName,
			hiddenName:fieldName,
			value: jsonPro.fieldValue
		}
	}else if(jsonPro.picklistType=="TEXTFIELD"){
		compoment={
			xtype:"textfield",
			enableKeyEvents:true,
			listeners:{
				scope:compoment,
				render:function(){
	        		if(this.jsonPro.isVisibleRender=="0"){
		        		this.setVisible(false);
						this.ownerCt.doLayout();  
	        		}
	        		this.addClass("x-form-text-platform");
	        	},
				blur:function(){
	        		isNeedConfirmDirtyData(Ext.getCmp(this.jsonPro.panelName+"_form"),this.jsonPro.isNeedConfirmDirtyData);
	        	},
	        	keyup:function(){
	        		isNeedConfirmDirtyData(Ext.getCmp(this.jsonPro.panelName+"_form"),this.jsonPro.isNeedConfirmDirtyData);
	        	}
			},
			fieldLabel:jsonPro.fieldI18nKey, 
			id: fieldId, 
			name: fieldName,
			hiddenName:fieldName,
			value: jsonPro.fieldValue
		}
	}else if(jsonPro.picklistType=="RADIOGROUP"||jsonPro.picklistType=="CHECKBOXGROUP"){
		compoment={
			xtype:"container",
			border:false,
			fieldName:fieldName,
			picklistType:jsonPro.picklistType,
			originalValue:"",
			containerLabel:jsonPro.fieldI18nKey, 
			id: panelName+"_"+fieldName+"_id"
		}		
	}else if(jsonPro.picklistType=="TREE"){
		compoment={
			xtype:"trigger",
			fieldLabel:jsonPro.fieldI18nKey, 
			id: fieldId, 
			name: fieldName, 
			enableKeyEvents:true,
			hiddenName:fieldName,
			value: jsonPro.fieldValue,
			triggerClass:"x-form-search-trigger",
			editable:jsonPro.isEditable,
			listeners:{
				scope:compoment,
				render:function(){
	        		if(this.jsonPro.isVisibleRender=="0"){
		        		this.setVisible(false);
						this.ownerCt.doLayout();  
	        		}
	        	},
				blur:function(){
	        		isNeedConfirmDirtyData(Ext.getCmp(this.jsonPro.panelName+"_form"),this.jsonPro.isNeedConfirmDirtyData);
	        	},
	        	keyup:function(){
	        		isNeedConfirmDirtyData(Ext.getCmp(this.jsonPro.panelName+"_form"),this.jsonPro.isNeedConfirmDirtyData);
	        	}
			},
			onTriggerClick: function() {
				var fieldname = this.name;
				var field_id = this.id;
				var formValues = new Object();
				var formParameterObj;
				if(this.jsonPro.editGridId==""){
					formValues = Ext.getCmp(panelName+"_form").getForm().getValues();
					var radiogroupValues = Ext.getCmp(this.jsonPro.panelName+"_form").find('picklistType','RADIOGROUP');
					var checkboxgroupValues = Ext.getCmp(this.jsonPro.panelName+"_form").find('picklistType','CHECKBOXGROUP');
					var rfield,rfieldValue;
					for(var s=0;s<radiogroupValues.length;s++){
						rfield=radiogroupValues[s].fieldName;
						rfieldValue=getRadioGroupValue(this.jsonPro.panelName,rfield);
						formValues[rfield]=rfieldValue;
					}
					for(var s=0;s<checkboxgroupValues.length;s++){
						rfield=checkboxgroupValues[s].fieldName;
						rfieldValue=getCheckboxGroupValues(this.jsonPro.panelName,rfield);
						formValues[rfield]=rfieldValue;
					}
					formValues.sourcePage="formpanel";
					formValues.needDelimiter="0";
					formParameterObj = Ext.getCmp(panelName+"_form").paramList;
					Ext.applyIf(formValues,formParameterObj);
				}else{
					var myGrid = Ext.getCmp(this.jsonPro.editGridId);
					var editor =  myGrid.activeEditor;
					var editorrow = editor.row;
					var editorcol = editor.col;
					formValues=myGrid.getStore().getAt(editorrow).data;
					formValues.sourcePage="editgrid";
					formValues.needDelimiter="0";
					formValues.editgrid_id=this.jsonPro.editGridId;
					formValues.editorrow=editorrow;
					formValues.editorcol=editorcol;
				}
				var panelVariable={};
				if(this.jsonPro.panelVariableArray!=null&&typeof(this.jsonPro.panelVariableArray)!='undefined'){
					panelVariable=getPanelVariable(this.jsonPro.panelName,this.jsonPro.panelVariableArray);
				}
				panelVariable.pname=this.jsonPro.panelName;
				panelVariable.fname=this.jsonPro.fieldName;
				Ext.applyIf(formValues,panelVariable);
				delete formValues.start_time;
				delete formValues.end_time;
				if(typeof(Ext.getCmp("picklist_"+this.jsonPro.panelName+"_"+this.jsonPro.fieldName))!="undefined"){
					Ext.getCmp("picklist_"+this.jsonPro.panelName+"_"+this.jsonPro.fieldName).show();
				}else{
					var jsFile = "views/dynamicGenerateScript/picklist_"+this.jsonPro.panelName+"_"+this.jsonPro.fieldName+".js";
					myLoader.require(jsFile,function(){
						eval("var win = new picklist_"+compoment.jsonPro.panelName+"_"+compoment.jsonPro.fieldName+"({paramList:formValues}).show();");
					},this,true);
				}
				return false;
			}
		}
	}
	
	if(controlProperty!=""){
		Ext.apply(compoment,Ext.decode("{"+controlProperty+"}"));
	}
	if(compoment.xtype=="container"){
		compoment.fieldWidth=compoment.width;
		compoment.hidden=false;
		compoment.width="auto";
	}
	compoment.jsonPro=jsonPro;
	return compoment;
}


function hideTrForTableLayout(id,start,end){
	var table;
	var divObj;
	var rows;
	if(Ext.getCmp(id)){
		divObj = Ext.getCmp(id).getEl().child("table");;
		table = document.getElementById(divObj.getAttribute("id")); 
		rows = table.getElementsByTagName("tr"); 
		for(var i = start-1;i<end;i++){
			if(rows[i].style.display =='none'){
				rows[i].style.display =''
			}else{
				rows[i].style.display ='none'
			}
		}
	}
	
}


function hide_module(start,end,arraryMenuModulesQuery){
	if(end > arraryMenuModulesQuery.length){
		end = arraryMenuModulesQuery.length;
	}
	for(var i = start;i<end;i++){
		if(Ext.getCmp("treepanel_"+arraryMenuModulesQuery[i]+"_id")){
			Ext.getCmp("treepanel_"+arraryMenuModulesQuery[i]+"_id").hide();	
		}
	}
}

function init_module_display(arraryMenuModeles,current_module_id){
	var filter_module_id = "";
	if(current_module_id!="undefined" && current_module_id!=null && current_module_id!=""){
		filter_module_id = current_module_id;
	}
	for(var i = 0;i<arraryMenuModeles.length;i++){
		if(filter_module_id != arraryMenuModeles[i]){
			if(Ext.getCmp("treepanel_"+arraryMenuModeles[i]+"_id")){
				Ext.getCmp("treepanel_"+arraryMenuModeles[i]+"_id").hide();
			}
		}
	}
}

function show_module(start,end,arraryMenuModulesQuery,defaultMenuMode,activeItemModuleId){
	if(end > arraryMenuModulesQuery.length){
		end = arraryMenuModulesQuery.length;
	}
	if(start <= 0){
		start = 0;
	}
	if(activeItemModuleId!="undefined"&&activeItemModuleId !=""&&activeItemModuleId!=null){
		if( Ext.getCmp("treepanel_"+activeItemModuleId+"_id")){
			Ext.getCmp("treepanel_"+activeItemModuleId+"_id").collapse();
		}
	}
	var activePanel = Ext.getCmp("treepanel_"+arraryMenuModulesQuery[start]+"_id");
	for(var i = start;i<end;i++){
		Ext.getCmp("treepanel_"+arraryMenuModulesQuery[i]+"_id").show();
	} 
	if(defaultMenuMode == 0){
		if(activePanel){	
			Ext.getCmp("menu_panel_west_id").getLayout().setActiveItem(activePanel.getItemId());
		}
	}
}

function init_search_module(sysMoudulesCount,arrarySearchMenuModule){
	if(Ext.getCmp("previous_moudle_id")){
		Ext.getCmp("previous_moudle_id").setDisabled(true);
	}
	if(sysMoudulesCount<arrarySearchMenuModule.length)
	{
		if(Ext.getCmp("next_moudle_id")){
			Ext.getCmp("next_moudle_id").setDisabled(false);
		}	
	}
	for(var i = 0;i<arrarySearchMenuModule.length;i++){
		if(Ext.getCmp("treepanel_"+arrarySearchMenuModule[i]+"_id")){
			Ext.getCmp("treepanel_"+arrarySearchMenuModule[i]+"_id").hide();
		}
	}
}

function menu_expand_collapse(flag,_p,current_module_id,start,end,arraryMenuModulesQuery){
	if(end>arraryMenuModulesQuery.length){
		end = arraryMenuModulesQuery.length;
	}
	for(var n = start;n<end;n++)
	{
		if(arraryMenuModulesQuery[n] != current_module_id)
		{
			if(flag == "expand"){
				if(Ext.getCmp("treepanel_"+arraryMenuModulesQuery[n]+"_id")){
					Ext.getCmp("treepanel_"+arraryMenuModulesQuery[n]+"_id").hide();
				}
			}else{
				if(Ext.getCmp("treepanel_"+arraryMenuModulesQuery[n]+"_id")){
					Ext.getCmp("treepanel_"+arraryMenuModulesQuery[n]+"_id").show();
				}
			}
			
		}
	}
}


function reloadTreePanelByNode(myTree,currentNodeParent,loadType,eventFlag){
	if(typeof(currentNodeParent)=="undefined" || currentNodeParent == null){
		myTree.getRootNode().reload();
	}else{
		if(loadType == 'async'){
			var path = currentNodeParent.getPath('id');  
			var node = currentNodeParent;
			node.attributes.children = null;
			if(node.isLeaf()){
				node.parentNode.attributes.children = null;
				node.parentNode.reload(null);
			}else{
				node.reload(null);
				node.expand();
			}
			myTree.expandPath(path,'id',function(bSucess,oLastNode){  
			    myTree.getSelectionModel().select(oLastNode);  
			});
		}else{
			myTree.getRootNode().reload();
			myTree.getRootNode().on('expand',function(node){
				if(myTree.currentNode){
					var n = this.getOwnerTree().getNodeById(myTree.currentNode.id);
					if(n){
						n.select();
					}
				}
				
			});
		}
	}
}

function initLockGridColumn(grid,dataIndexArray){
	var cm = grid.getColumnModel();
	var llen = cm.getLockedCount();
	for(var i=dataIndexArray.length-1;i>=0;i--){
		var colIndex = grid.getColumnModel().findColumnIndex(dataIndexArray[i])
		var item = grid.getColumnModel().getColumnById(grid.getColumnModel().getColumnId(colIndex));
		if(cm.getColumnCount(true) <= llen + 1){
	        item.onDenyColumnLock();
	        return undefined;
	    }
	    cm.setLocked(colIndex, true, llen != colIndex);
	    if(llen != colIndex){
	        cm.moveColumn(colIndex, llen);
	        grid.fireEvent('columnmove', colIndex, llen);
	    }
	}
}



/*************************************** Calendar **********************************************/
function loadCalendarHandlerType(panelName,eventName,jsonPro,panelVariable){
	var globalVariables = panelVariable;
	var obj = Ext.getCmp(panelName);
	var calendar = obj.calendar;
	var paramList = Ext.apply({},obj.paramList);
	Ext.apply(paramList,panelVariable);
	paramList.sql_where=obj.getStore().baseParams.sql_where;
	paramList.event_name=eventName;
	paramList.p_name=panelName;
	paramList.gridPanelName=panelName;
	paramList.grid_panel_name=panelName;
	paramList.calendar_panel_name=panelName;
	jsonPro.gridPanelName=panelName;
	jsonPro.grid_panel_name=panelName;
	if(paramList.useDynamicMenuKey){
		jsonPro.useDynamicMenuKey=paramList.useDynamicMenuKey;
	}else{
		jsonPro.useDynamicMenuKey="";
	}
	jsonPro._win_height=jsonPro.winHeight;
	jsonPro._win_width=jsonPro.winWidth;
	
	var pv={};
	if(panelVariable && panelVariable.length > 0){
		pv=getPanelVariable(panelName,panelVariable);
		Ext.apply(paramList,pv);	
	}
	
	if(jsonPro.predefinedValues != ""){
		var predefinedValues = "{"+jsonPro.predefinedValues+"}";
		Ext.apply(paramList,Ext.decode(predefinedValues));	
	}
	
	//console.debug(paramList);
	//console.debug(jsonPro);
	if(jsonPro.handlerType=="POPUP"){
		if(typeof(Ext.getCmp(panelName+"_"+eventName+"_win_popUp_parent"))!="undefined"&&jsonPro.actionHandlerEvent==""&&jsonPro.useDynamicMenuKey==""){
			maskObj = new Ext.LoadMask(Ext.getCmp(panelName+"_"+eventName+"_win_popUp_parent").getEl(), {msg:getResource("loading","")});
			maskObj.show();
			paramList.win_id=panelName+"_"+eventName+"_win_popUp_parent";
			Ext.apply(Ext.getCmp("page_"+jsonPro.dynPageName).paramList,paramList);
			Ext.getCmp("page_"+jsonPro.dynPageName).fireEvent("render",Ext.getCmp("page_"+jsonPro.dynPageName));
			Ext.getCmp(panelName+"_"+eventName+"_win_popUp_parent").show();
		}else{
			var windowItem;
			var windowString;
			var closeAction;
			paramList.win_id = panelName+"_"+eventName+"_win_popUp_parent";
			paramList.grid = obj;
			
			if(jsonPro.actionHandlerEvent == ""){
				var jsFile
				if(jsonPro.useDynamicMenuKey!=""){
					jsFile = "views/dynamicGenerateScript/page_"+jsonPro.useDynamicMenuKey+".js";
					windowString = "windowItem = new page_"+jsonPro.useDynamicMenuKey+"({paramList:paramList});";
					closeAction="close";
				}else{
					jsFile = "views/dynamicGenerateScript/page_"+jsonPro.dynPageName+".js";
					windowString = "windowItem = new page_"+jsonPro.dynPageName+"({paramList:paramList});";
					closeAction=jsonPro.isDestroyWin=="0"?'hide':'close';
				}
				myLoader.require(jsFile,function(){
					destroy_key_list.push(paramList.win_id);
					eval(windowString);
					var popWin = new Ext.Window({
						manager:windows,
						resizable:true,
						modal:true,
						id:panelName+"_"+eventName+"_win_popUp_parent",
						bodyStyle: "background: #fff;",
						autoscroll: true,
						layout:"fit",
						closeAction:closeAction,
						layout:'fit',
						items:[{layout:'anchor',items:[windowItem]}],
						width:(parseInt(jsonPro._win_width) > window.parent.document.body.clientWidth ? window.parent.document.body.clientWidth : parseInt(jsonPro._win_width) ),
						minWidth:(parseInt(jsonPro._win_width)  > window.parent.document.body.clientWidth ? window.parent.document.body.clientWidth : parseInt(jsonPro._win_width) ),
						height:(parseInt(jsonPro._win_height) > window.parent.document.body.clientHeight ? window.parent.document.body.clientHeight : parseInt(jsonPro._win_height)),
						minHeight:(parseInt(jsonPro._win_height) > window.parent.document.body.clientHeight ? window.parent.document.body.clientHeight : parseInt(jsonPro._win_height)),
						listeners:{
							"beforehide":function(){
								if(jsonPro.isNeedConfirmDirtyData=="1"){
									if(validateDataFlag == 1){
										Ext.Msg.confirm(getResource("confirm_title",""),getResource("confirm_msg","confirm_modify_data"),function(_btn){
											if(_btn=="no"){
												return false;
											}else{
												validateDataFlag = 0;
												Ext.getCmp(panelName+"_"+eventName+"_win_popUp_parent").close();
											}
										});return false;
									}
								}
							},
							"close":function(){
								if(jsonPro.isRequireReloadGrid=="1"){
									obj.getStore().reload();
								}
							}
						}
					});
					if(eval(jsonPro.titleI18nKey)!=""){
						popWin.setTitle(eval(jsonPro.titleI18nKey));
					}
					popWin.show()
				},this,true)
			}else{
				if(typeof(Ext.getCmp(panelName+"_"+eventName+"_win_popUp_parent"))!="undefined"){
					paramList.win_id=panelName+"_"+eventName+"_win_popUp_parent";
					Ext.getCmp(panelName+"_"+eventName+"_win_popUp_parent").show();
				}else{
					var popWin = new Ext.Window({
						manager:windows,
						resizable:true,
						modal:true,
						id:panelName+"_"+eventName+"_win_popUp_parent",
						bodyStyle: "background: #fff;",
						autoscroll: true,
						layout:"fit",
						closeAction:jsonPro.isDestroyWin=="0"?'hide':'close',
						layout:'fit',
						autoLoad: {
							url: "index.cfm?event="+jsonPro.actionHandlerEvent+"&_popid="+panelName+"_"+eventName+"_win_popUp_parent&datenow=" + new Date(),
							params:paramList,
							scripts: true
						},
						width:(parseInt(jsonPro._win_width) > window.parent.document.body.clientWidth ? window.parent.document.body.clientWidth : parseInt(jsonPro._win_width) ),
						minWidth:(parseInt(jsonPro._win_width)  > window.parent.document.body.clientWidth ? window.parent.document.body.clientWidth : parseInt(jsonPro._win_width) ),
						height:(parseInt(jsonPro._win_height) > window.parent.document.body.clientHeight ? window.parent.document.body.clientHeight : parseInt(jsonPro._win_height)),
						minHeight:(parseInt(jsonPro._win_height) > window.parent.document.body.clientHeight ? window.parent.document.body.clientHeight : parseInt(jsonPro._win_height)),
						listeners:{
							"close":function(){
								if(jsonPro.isRequireReloadGrid=="1"){
									obj.getStore().reload();
								}
							}
						}
					});
					if(eval(jsonPro.titleI18nKey)!=""){
						popWin.setTitle(eval(jsonPro.titleI18nKey));
					}
					popWin.show()
				}
			}
		}
	}else if(jsonPro.handlerType=="IOEXPORT"){
		paramList.export_type=jsonPro.rptFormat;
		var urlEvent = "index.cfm?event=nio.nio.export";
		for(var p in paramList){
			if(p=="sql_where"){
				urlEvent = urlEvent + "&" + p + "=" + encodeURIComponent(paramList[p]);
			}
		}
		var report_form = new  Ext.form.FormPanel({
			    renderTo:'_report-out',
			    name:panelName+'_export',
			    id:panelName+'_exportForm',
		        frame: true,
		        collapsible:true,
		        labelAlign:'right',
		        buttonAlign:'center',
		        autoHeight: true,items:[{}]
			});
		for(var i in paramList){
			if(i!="sql_where"){
				var textfield = new Ext.form.TextField({
					name:i,
					value:paramList[i],
					xtype:'textfield'
				});
				report_form.insert(0,textfield);
			}
		}
		report_form.doLayout();
		report_form.getForm().getEl().dom.method='POST';
		report_form.getForm().getEl().dom.action=urlEvent;
		report_form.getForm().getEl().dom.submit();
	}else if(jsonPro.handlerType=="IOIMPORT"){
		var io_paramList = new Object();
		for(var p in  paramList){
			if(typeof(paramList[p])!="object"){
				io_paramList[p]=paramList[p];
			}
		}
		var popWin = new Ext.Window({
			manager:windows,
			resizable:false,
			manager:windows,
			modal:true,
			id:"#arguments.panel_name#_#event_name#_win_popUp_parent",
			bodyStyle: "background: #fff;",
			autoscroll: true,
			autoLoad: {
				url:"index.cfm?event=nio.nio.importMain&datenow=" + new Date().getTime(), 
				params:{
					parameter:Ext.encode(io_paramList),
					event_name:eventName,
					p_name:panelName,
					panel_name:panelName
				},
				nocache:true,
				scripts:true,
				timeout:1000000
			},
			width:800,
			height:585
		}).show();
	}else if(jsonPro.handlerType=="BACKGROUND"){
		paramList.panel_name=panelName;
		paramList.event_name=eventName;
		paramList.prefix_name=panelName+"_"+eventName;
		paramList.grid_panel_name=panelName;
		if(jsonPro.gridPanelName!=""){
			paramList.grid_panel_name = jsonPro.gridPanelName;
			if(Ext.getCmp(jsonPro.gridPanelName).getStore().baseParams.sql_where){
				paramList._grid_sql_where = Ext.getCmp(jsonPro.gridPanelName).getStore().baseParams.sql_where;
			}else{
				paramList._grid_sql_where = " and 1=1";
			}
		}
		paramList.is_validate=1;
		Ext.MessageBox.wait(getResource("waitMsg",panelName+"_wait"),getResource("waitMsg",panelName+"_wait"), "");		
		var url;
		if(jsonPro.actionHandlerEvent!=""){
			url="index.cfm?event="+jsonPro.actionHandlerEvent+"&datenow=" + new Date();
		}else{
			url="index.cfm?event=dynamicGrid.general.dynamicGridBackGround&datenow=" + new Date();
		}
		
		Ext.Ajax.request({
			params:paramList,
			url:url,
			method: "POST",
			failure: function(response,options){var responseText = Ext.util.JSON.decode(options.response.responseText);
				Ext.MessageBox.hide();Ext.MessageBox.alert(getResource("failure",panelName),responseText.success_msg);
			},
			success: function(response,options){
				var winObj = eval(Ext.getCmp(obj.paramList.win_id));
				var responseText = Ext.util.JSON.decode(response.responseText);Ext.MessageBox.hide();
				if(responseText.flag == "S"){
					if(jsonPro.isRequireSuccessTip=="1"){
						Ext.MessageBox.alert(getResource("success",panelName),responseText.success_msg,function(){
							if(jsonPro.isRequireReloadGrid=="1"){
								var count = 0;
								obj.getStore().reload();
								obj.getStore().on("load",function(){
									if(count == 0){
										var jsfunction = new Function(jsonPro.afterSuccessJs);
												jsfunction();
										if(jsonPro.isCloseWindowAfterAction=="1"){
											if(typeof(winObj)!='undefined'){winObj.close();}
										}
									}
									count++;
								})
								dynamicPanelAction(jsonPro.panelActionDataArray);
							}else{
								var jsfunction = new Function(jsonPro.afterSuccessJs);
												jsfunction();
								dynamicPanelAction(jsonPro.panelActionDataArray);
							}
						})
					}else{
						if(jsonPro.isRequireReloadGrid=="1"){
							var count = 0;
							obj.getStore().reload();
							obj.getStore().on("load",function(){
								if(count == 0){
									var jsfunction = new Function(jsonPro.afterSuccessJs);
												jsfunction();
									if(jsonPro.isCloseWindowAfterAction=="1"){
										if(typeof(winObj)!='undefined'){winObj.close();}
									}
								}
								count++;
							})
							dynamicPanelAction(jsonPro.panelActionDataArray);
						}else{
							var jsfunction = new Function(jsonPro.afterSuccessJs);
												jsfunction();
							dynamicPanelAction(jsonPro.panelActionDataArray);
						}
					}
				}else if(responseText.flag == "E"){
					Ext.MessageBox.alert(getResource("error",panelName),responseText.error_msg,function(){
						if(jsonPro.isRequireReloadGrid=="1"){
							obj.getStore().reload();
						}
					})
				}else if(responseText.flag == "C"){
					Ext.MessageBox.confirm(getResource("confirm",panelName),responseText.confirm_msg,function(_btn){
						if(_btn == "yes"){
							Ext.MessageBox.wait(getResource("waitMsg",panelName+"_wait"), getResource("waitMsg",panelName+"_wait"), "");
							paramList.is_validate=0;
							Ext.Ajax.request({
							 	params:paramList,
							 	url:url,
							 	method:"POST",
							 	failure: function(response,options){
									var responseText = Ext.util.JSON.decode(options.response.responseText);
									Ext.MessageBox.hide();
									Ext.MessageBox.alert(getResource("failure",panelName),responseText.success_msg);
								},
								success: function(response,options){
									var winObj = eval(Ext.getCmp(obj.paramList.win_id));
									var responseText = Ext.util.JSON.decode(response.responseText);
									Ext.MessageBox.hide();
									if(responseText.flag == "S"){
										if(jsonPro.isRequireSuccessTip=="1"){
											Ext.MessageBox.alert(getResource("success",panelName),responseText.success_msg,function(){
												if(jsonPro.isRequireReloadGrid=="1"){
													var count = 0;
													obj.getStore().reload();
													obj.getStore().on("load",function(){
														if(count == 0){
															var jsfunction = new Function(jsonPro.afterSuccessJs);
												jsfunction();
															if(jsonPro.isCloseWindowAfterAction=="1"){
																if(typeof(winObj)!='undefined'){winObj.close();}
															}
														}
														count++;
													})
													dynamicPanelAction(jsonPro.panelActionDataArray);
												}else{
													var jsfunction = new Function(jsonPro.afterSuccessJs);
												jsfunction();
													dynamicPanelAction(jsonPro.panelActionDataArray);
												}
											})
										}else{
											if(jsonPro.isRequireReloadGrid=="1"){
												var count = 0;
												obj.getStore().reload();
												obj.getStore().on("load",function(){
													if(count == 0){
														var jsfunction = new Function(jsonPro.afterSuccessJs);
												jsfunction();
														if(jsonPro.isCloseWindowAfterAction=="1"){
															if(typeof(winObj)!='undefined'){winObj.close();}
														}
													}
													count++;
												});
												dynamicPanelAction(jsonPro.panelActionDataArray);
											}else{
												var jsfunction = new Function(jsonPro.afterSuccessJs);
												jsfunction();
												dynamicPanelAction(jsonPro.panelActionDataArray);
											}
										}
									}else if(responseText.flag == "E"){
										Ext.MessageBox.alert(getResource("error",panelName),responseText.error_msg,function(){
											if(jsonPro.isRequireReloadGrid=="1"){
												obj.getStore().reload();
											}
										})
									}
								}
							})
						}
					})
				}
			}
		})
	}else if(jsonPro.handlerType=="REDIRECT"){
		var winObj = Ext.getCmp(obj.paramList.win_id);
		var targetComp;
		if(typeof(winObj)!="undefined"){
			targetComp = winObj;
		}else{
			targetComp = Ext.getCmp("contentPanel");
		}
		var jsFile;
		if(jsonPro.useDynamicMenuKey!=""){
			paramList.dyn_page_name=jsonPro.useDynamicMenuKey;
			jsFile="views/dynamicGenerateScript/page_"+jsonPro.useDynamicMenuKey+".js";
		}else{
			paramList.dyn_page_name=jsonPro.dynPageName;
			jsFile = "views/dynamicGenerateScript/page_"+jsonPro.dynPageName+".js";
		}
		if(jsonPro.actionHandlerEvent != ""){
			targetComp.removeAll();
			targetComp.getUpdater().update({
				url:"index.cfm?event="+jsonPro.actionHandlerEvent+"&datenow=" + new Date(),
				params:paramList,
				nocache:true,
				scripts:true,
				timeout:30000
			})
		}else{
			targetComp.removeAll();
			myLoader.require(jsFile,function(){
				destroy_key_list.push("page_"+paramList.dyn_page_name);
				var windowItem;
				var windowString = "windowItem = new page_"+paramList.dyn_page_name+"({paramList:paramList});";
				eval(windowString);
				targetComp.add(windowItem);
			},this,true);
			targetComp.doLayout();
		}
	}else if(jsonPro.handlerType=="JAVASCRIPT"){
		var jsfunction = new Function(jsonPro.handlerJs);
		jsfunction();
		if(jsonPro.isRequireReloadGrid=="1"){
			obj.getStore().reload();
		}
	}else if(jsonPro.handlerType=="IOEXPORT"){
		paramList.export_type=jsonPro.rptFormat;
		var urlEvent = "index.cfm?event=nio.nio.export";
		for(var p in paramList){
			if(p=="sql_where"){
				urlEvent = urlEvent + "&" + p + "=" + encodeURIComponent(paramList[p]);
			}
		}
		var report_form = new  Ext.form.FormPanel({
			    renderTo:'_report-out',
			    name:panelName+'_export',
			    id:panelName+'_exportForm',
		        frame: true,
		        collapsible:true,
		        labelAlign:'right',
		        buttonAlign:'center',
		        autoHeight: true,items:[{}]
			});
		for(var i in paramList){
			if(i!="sql_where"){
				var textfield = new Ext.form.TextField({
					name:i,
					value:paramList[i],
					xtype:'textfield'
				});
				report_form.insert(0,textfield);
			}
		}
		report_form.doLayout();report_form.getForm().getEl().dom.method='POST';
		report_form.getForm().getEl().dom.action=urlEvent;
		report_form.getForm().getEl().dom.submit();		
	}else if(jsonPro.handlerType=="IOIMPORT"){
		var popWin = new Ext.Window({
			manager:windows,
			resizable:false,
			manager:windows,
			modal:true,
			id:"#arguments.panel_name#_#event_name#_win_popUp_parent",
			bodyStyle: "background: #fff;",
			autoscroll: true,
			autoLoad: {
				url:"index.cfm?event=nio.nio.importMain&datenow=" + new Date().getTime(), 
				params:{
					parameter:Ext.encode(paramList),
					event_name:eventName,
					p_name:panelName,
					panel_name:panelName
				},
				nocache:true,
				scripts:true,
				timeout:1000000
			},
			width:800,
			height:585,
			listeners:{
				"close":function(){obj.getStore().reload();}
			}
		}).show();
	}else if(jsonPro.handlerType=="REPORT"){
		var url_event= '';
		if((jsonPro.rptFormat).indexOf("xls")!=-1 && jsonPro.isHtmlXls=="1"){
			url_event='index.cfm?event=rpt.report.report.runReportForExcel&rpt_format='+jsonPro.rptFormat+'&rpt_number='+jsonPro.rptNumber+'&is_validate=0&currentPanel='+panelName+'&rptformat='+jsonPro.rptFormat;
			var report_form = new  Ext.form.FormPanel({
				    renderTo:'_report-out',
				    name:panelName+'_form',
				    id:panelName+'_reportform',
			        frame: true,
			        collapsible:true,
			        labelAlign:'right',
			        buttonAlign:'center',
			        autoHeight: true,items:[{}]
				});
			for(var i in paramList){
				var textfield = new Ext.form.TextField({
					name:i,
					value:encodeURIComponent(paramList[i]),
					xtype:'textfield'
				});
				report_form.insert(0,textfield);
			}
			report_form.doLayout();report_form.getForm().getEl().dom.method='POST';
			report_form.getForm().getEl().dom.action=url_event;report_form.getForm().getEl().dom.submit();
		}else{
			url_event='index.cfm?event=rpt.report.report.runReport&rpt_format='+jsonPro.rptFormat+'&rpt_number='+jsonPro.rptNumber+'&is_validate=0&currentPanel='+panelName+'&rptformat='+jsonPro.rptFormat;
			Ext.Ajax.request({
				method: 'POST',
				waitMsg:getResource('redirectToReport','dynaGrid'),
				url: url_event,
				success: function (response,options) {
					var responseText = Ext.util.JSON.decode(response.responseText);
					if(responseText.flag == 'S'){
						var width = Ext.getCmp('contentPanel').getWidth() - 2;
						var height = Ext.getCmp('contentPanel').getHeight() - 29;
						var c = Ext.getCmp('contentPanel');
						paramList.width=width;paramList.height=height;
						paramList.currentPanel=panelName;
						paramList.rpt_format=jsonPro.rptFormat;
						paramList.rpt_number=jsonPro.rptNumber;
						if((jsonPro.rptFormat).indexOf("xls")!=-1){
							if(jsonPro.rptPageType=="MAIN_PANEL"){
								c.getUpdater().update({
									url: "index.cfm?event=rpt.report.report.runReportPage&datenow=" + new Date(),
									params:paramList,
									nocache: true, 
									scripts: true,
									timeout: 1000000
								});
							}else{
								var popWin = new Ext.Window({
									modal:true,
									manager:windows,
									id:panelName+"_window",
									bodyStyle: "background: #fff;",
									autoscroll: true,
									autoLoad: { 
										url: "index.cfm?event=rpt.report.report.runReportPage&datenow=" + new Date(),
										params:paramList,
										scripts: true 
									},
									width:width,
									height:height,
									dummp:true
								}).show();
							}
						}else{
							c.getUpdater().update({
								url: "index.cfm?event=rpt.report.report.runReportPage&datenow=" + new Date(),
								params:paramList,
								nocache: true, 
								scripts: true,
								timeout: 1000000
							});	
						}
					}else if(responseText.flag == "E"){
						Ext.MessageBox.alert(getResource("error",panelName), responseText.error_msg);
					}
				}
			})
		}
	}else if(jsonPro.handlerType=="WORKFLOW"){
		paramList.event_name=eventName;
		paramList.grid_panel_name="";
		if(jsonPro.gridPanelName!=""){
			paramList.grid_panel_name = jsonPro.gridPanelName;
			if(Ext.getCmp(jsonPro.gridPanelName).getStore().baseParams.sql_where){
				paramList._grid_sql_where = Ext.getCmp(jsonPro.gridPanelName).getStore().baseParams.sql_where;
			}else{
				paramList._grid_sql_where = " and 1=1";
			}
		}
		var url;
		if(jsonPro.isWorkFlowStart=="1"){
			url="index.cfm?event=workFlow.jbpm.initWorkflow&datenow=" + new Date();
			paramList.process_key=jsonPro.workFlowProcessKey;
			paramList.wf_table=jsonPro.wfTable;
		}else{
			url="index.cfm?event=workFlow.jbpm.performTask&datenow=" + new Date();
		}
		paramList.panel_name=panelName; 
		Ext.MessageBox.wait(getResource("waitMsg",panelName+"_wait"),getResource("waitMsg",panelName+"_wait"), "");
		paramList.is_validate=1;
		Ext.Ajax.request({
			url:url,
			method: "POST",
			params:paramList,
			failure: function(response,options){
				var responseText = Ext.util.JSON.decode(options.response.responseText);
				Ext.MessageBox.hide();
				Ext.MessageBox.alert(getResource("failure",panelName),responseText.success_msg);
			},
			success: function(response,options){
				var responseText = Ext.util.JSON.decode(response.responseText);
				Ext.MessageBox.hide();
				if(responseText.success == true){
					if(responseText.flag&&responseText.flag=="E"){
						Ext.MessageBox.alert(getResource("error",panelName),responseText.error_msg);
					}else if(responseText.flag&&responseText.flag=="C"){
						Ext.MessageBox.confirm(getResource("confirm",panelName),responseText.confirm_msg,function(_btn){
							if(_btn == "yes"){
								Ext.MessageBox.wait(getResource("waitMsg",panelName+"_wait"), getResource("waitMsg",panelName+"_wait"), "");
								paramList.is_validate=0;
								Ext.Ajax.request({
									url:url,
									method: "POST",params:paramList,
									failure: function(response,options){
										var responseText = Ext.util.JSON.decode(options.response.responseText);
										Ext.MessageBox.hide();
										Ext.MessageBox.alert(getResource("failure",panelName),responseText.success_msg);
									},
									success: function(response,options){
										var responseText = Ext.util.JSON.decode(response.responseText);
										Ext.MessageBox.hide();
										var winObj = Ext.getCmp(obj.paramList.win_id);
										if(responseText.success == true){
											if(responseText.flag&&responseText.flag=="E"){
												Ext.MessageBox.alert(getResource("error",panelName),responseText.error_msg);
											}else if(responseText.flag&&responseText.flag=="S"){
												if(jsonPro.isRequireSuccessTip=="1"){
													Ext.MessageBox.alert(getResource("success",panelName),responseText.message,function(){
														if(jsonPro.isRequireReloadGrid=="1"){
															var count = 0;
															obj.getStore().reload();
															obj.getStore().on("load",function(){
																if(count == 0){ 
																	var jsfunction = new Function(jsonPro.afterSuccessJs);
																	jsfunction();
																	if(jsonPro.isCloseWindowAfterAction=="1"){
																		if(typeof(winObj)!='undefined'){winObj.close();}
																	}
																}
																count++;
															});
															dynamicPanelAction(jsonPro.panelActionDataArray);
														}else{
															var jsfunction = new Function(jsonPro.afterSuccessJs);
																	jsfunction();
															dynamicPanelAction(jsonPro.panelActionDataArray);
														}
													})
												}
											}
										}else if(responseText.success == false){
											Ext.MessageBox.alert(getResource("error",panelName),responseText.message,function(){
												if(jsonPro.isRequireReloadGrid=="1"){
													obj.getStore().reload();
												}
											})
										}
									}
								})
							}
						})
					}else{
						if(jsonPro.isRequireSuccessTip=="1"){
							Ext.MessageBox.alert(getResource("success",panelName),responseText.message,function(){
								if(jsonPro.isRequireReloadGrid=="1"){
									var count = 0;
									obj.getStore().reload();
									obj.getStore().on("load",function(){
										if(count == 0){ 
											var jsfunction = new Function(jsonPro.afterSuccessJs);
																	jsfunction();
											if(jsonPro.isCloseWindowAfterAction=="1"){
												if(typeof(winObj)!='undefined'){winObj.close();}
											}
										}
										count++;
									});
									dynamicPanelAction(jsonPro.panelActionDataArray);
								}else{
									var jsfunction = new Function(jsonPro.afterSuccessJs);
																	jsfunction();
									dynamicPanelAction(jsonPro.panelActionDataArray);
								}
							})
						}
					}
				}else if(responseText.success == false){
					Ext.MessageBox.alert(getResource("error",panelName),responseText.message,function(){
						if(jsonPro.isRequireReloadGrid=="1"){
							obj.getStore().reload();
						}
					})
				}
			}
		})
	}else if(jsonPro.handlerType=="COLDFUSION"){
		Ext.MessageBox.wait(getResource("waitMsg",panelName+"_wait"),getResource("waitMsg",panelName+"_wait"), "");
		Ext.Ajax.request({
			url: "index.cfm?event=dynamicCF.general."+eventName+"&datenow=" + new Date(),
			method: "POST",
			params:paramList,
			failure: function(response,options){
				var responseText = Ext.util.JSON.decode(options.response.responseText);
				Ext.MessageBox.hide();
				Ext.MessageBox.alert(getResource("failure",panelName),responseText.success_msg);
			},
			success: function(response,options){
				var responseText = Ext.util.JSON.decode(response.responseText);
				Ext.MessageBox.hide();
				if(responseText.flag == "S"){
					if(jsonPro.isRequireSuccessTip=="1"){
						Ext.MessageBox.alert(getResource("success",panelName),responseText.message,function(){
							if(jsonPro.isRequireReloadGrid=="1"){
								var count = 0;
								obj.getStore().reload();
								obj.getStore().on("load",function(){
									if(count == 0){ 
										var jsfunction = new Function(jsonPro.afterSuccessJs);
																	jsfunction();
										if(jsonPro.isCloseWindowAfterAction=="1"){
											if(typeof(winObj)!='undefined'){winObj.close();}
										}
									}
									count++;
								});
								dynamicPanelAction(jsonPro.panelActionDataArray);
							}else{
								var jsfunction = new Function(jsonPro.afterSuccessJs);
																	jsfunction();
								dynamicPanelAction(jsonPro.panelActionDataArray);
							}
						})
					}
				}else if(responseText.flag == "E"){
					Ext.MessageBox.alert(getResource("error",panelName),responseText.error_msg,function(){
						if(jsonPro.isRequireReloadGrid=="1"){
							obj.getStore().reload();
						}
					})
				}
			}
		})
	}else if(jsonPro.handlerType=="DATAREFRESH"){
		var target_panel_name_list = (jsonPro.targetPanelName).split(",");
		var target_panel_type_list = (jsonPro.targetPanelType).split(",");
		for (var k=0;k < target_panel_name_list.length; k++){
			if(target_panel_type_list[k] == 'editorgridpanel'||target_panel_type_list[k] == 'chartpanel'){
				if(Ext.getCmp(target_panel_name_list[k])){
					paramList.sql_where="";
					var baseParams = Ext.getCmp(target_panel_name_list[k]).store.baseParams;
					Ext.apply(baseParams,paramList);
					paramList.panel_name = target_panel_name_list[k];
					Ext.getCmp(target_panel_name_list[k]).store.baseParams=baseParams;
					Ext.getCmp(target_panel_name_list[k]).store.load();
				}
			}else if(target_panel_type_list[k] == 'advformpanel'){
				paramList.panel_name=target_panel_name_list[k];
				paramList.gridPanelName="";
				if(Ext.getCmp(target_panel_name_list[k]+'_form')){
					Ext.apply(Ext.getCmp(target_panel_name_list[k]+'_form').paramList,paramList);
					maskObj = new Ext.LoadMask(Ext.getCmp("page_"+jsonPro.menuKey).getEl(), {msg:getResource("loading","")});
					maskObj.show();
					eval("Ext.getCmp('page_"+jsonPro.menuKey+"')."+target_panel_name_list[k]+"_loadFormData()");
				}
			}
		}
	}else if(jsonPro.handlerType=="DOWNLOADTXT"){
		paramList.p_name=panelName;
		paramList.sql_where=obj.getStore().baseParams.sql_where;
		paramList.event_name=eventName;
		var loadW=Ext.Msg.wait(getResource("ExportData","")+"...",getResource("tip",""),{width:300 });
        paramList.menu_id=jsonPro.menuId;
        paramList.currentPanel=panelName; 
        paramList.is_validate=1;
		Ext.Ajax.request({
			url: "index.cfm?event=dynamicTxt.downloadTxt.downloadTxt&datenow=" + new Date(),
			method: "POST",
			params:paramList,
			failure: function(response,options){
				var responseText = Ext.util.JSON.decode(options.response.responseText);
				loadW.hide();
				Ext.MessageBox.alert(getResource("failure",panelName),responseText.success_msg);
			},
			success: function(response,options){
				var responseText = Ext.util.JSON.decode(response.responseText);
				Ext.MessageBox.hide();
				if(responseText.flag == "S"){
					window.location.href="index.cfm?event=dynamicTxt.downloadTxt.downloadTxt&menu_id="+jsonPro.menuId+"&currentPanel="+panelName+"&is_validate=0";
					loadW.hide();
				}else if(responseText.flag == "E"){
					Ext.MessageBox.alert(getResource("error",panelName),responseText.error_msg);
				}
			}
		});
	}
	jsonPro.useDynamicMenuKey = "";
	obj.paramList.useDynamicMenuKey = undefined;
}


function dynamicCalendarEvent(panelName,eventName,jsonPro,panelVariable){
	setActionLog(panelName,eventName);
	loadCalendarHandlerType(panelName,eventName,jsonPro,panelVariable);
}

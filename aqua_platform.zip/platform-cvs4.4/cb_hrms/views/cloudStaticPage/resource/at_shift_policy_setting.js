
$('.clockpicker').clockpicker();

var newSch = $("#newSch"),
	delSch = $("#deleteSch"),
	saveSch = $("#saveSch"),
	elastic = $("#elastic"),
    ot_before_tr = $(".ot_before_hours"),
    ot_after_tr = $(".ot_after_hours"),
    wh_input = $(".wh_input"),
    axis = $("#axis"),
    star_time = $("#star_time"),
    end_time = $("#end_time"),
    ot_before_time = $("#ot_before_time"),
    schName = $("#schedule_name"),
    ot_after_time = $("#ot_after_time"),
    star_time = $("#star_time"),
    end_time = $("#end_time"),
    starWork = $("#star_work"),
    endWork = $("#end_work"),
    otBefore = $("#ot_before_hours"),
    otAfter = $("#ot_after_hours"),
    starHours = "06:00",
    endHours = "22:00",
    is_ot_after = 0;
	is_ot_before = 0;
 
    changeUnit = 5,
    minDiff = 0,
    unit = 1152 / (22 - 6) / 60 * changeUnit; 
    minDiff = 36; 
    
	$("#fixedWH :checkbox").click(function(){
		if($(this).hasClass("ck_check")){
			$(this).removeClass("ck_check");
			$('.'+$(this).attr("id")+'_td').attr("disabled","true");
			$('.'+$(this).attr("id")+'_td').val(" ");
			$('.'+$(this).attr("id")+'_td').css("background-color","rgb(237, 237, 237)");
		}else{
			$(this).addClass("ck_check");
			$('.'+$(this).attr("id")+'_td').removeAttr("disabled");
			$('.'+$(this).attr("id")+'_td').css("background-color","white");
		}
	});

	
	$("#is_need_ot").click(function(){
		if($("#is_need_ot").hasClass("ck_check")){
			$("#is_need_ot").removeClass("ck_check");
			$(".ot_after_hours").addClass("ot_hours_class");
			ot_after_tr.hide();
			is_ot_after = 0;
		}else{
			$("#is_need_ot").addClass("ck_check");
			$(".ot_after_hours").removeClass("ot_hours_class");
			ot_after_tr.show();
			is_ot_after = 1;
		}
	})
	
	$("#is_ot_before").click(function(){
		if($("#is_ot_before").hasClass("ck_check")){
			$("#is_ot_before").removeClass("ck_check");
			$(".ot_before_hours").addClass("ot_hours_class");
			ot_before_tr.hide();
			is_ot_before = 0;
		}else{
			$("#is_ot_before").addClass("ck_check");
			$(".ot_before_hours").removeClass("ot_hours_class");
			ot_before_tr.show();
			is_ot_before = 1;
		}
	})
	
	
	$(".selInput").focus(function() {
        $(".schList").show();
        $(this).blur();
    })

    $(".selInput").click(function(event) {
        $(".schList").show();
        event.stopPropagation();
    })
    $("#allSchedule").delegate("li", "click", function(event) {
    	$("#policy_id").val($(this).attr("_value"));
        $(".selInput").val($(this).html());
        schName.val($(this).html());
        $(".schList").hide();
        
        
        
        $("#fixedWH :checkbox").each(function(){
			if($(this).hasClass("ck_check")){
				$(this).click();
			}
		});
		if($("#is_need_ot").hasClass("ck_check")){
			$("#is_need_ot").click();
		}
		if($("#is_ot_before").hasClass("ck_check")){
			$("#is_ot_before").click();
		}
		ot_before_tr.hide();
		ot_after_tr.hide();
		is_ot_before = 0;
		is_ot_after = 0;
		doAtRequestAction(2);
    })
    
    $(document).click(function(event) {
        $(".schList").hide();
    });
	
	delSch.click(function(){
		deleteAtPolicy();		
	});
	
	newSch.click(function(event) {
		$("#fixedWH :checkbox").each(function(){
			if($(this).hasClass("ck_check")){
				$(this).click();
			}
		});
		
		$(".selSch").hide();
		delSch.hide();
		newSch.hide();
		$("#cancelSch").show();
		if($("#is_need_ot").hasClass("ck_check")){
			$("#is_need_ot").click();
		}
		if($("#is_ot_before").hasClass("ck_check")){
			$("#is_ot_before").click();
		}
		ot_before_tr.hide();
		ot_after_tr.hide();
		is_ot_before = 0;
		is_ot_after = 0;
		schName.val('');
		doAtRequestAction(1);
    });
	
	saveSch.click(function(event) {
		saveAtRequestAction();
    });

	$("#cancelSch").click(function(){
		$("#cancelSch").hide();
		delSch.show();
		newSch.show();
		$(".selSch").show();
		if($("#is_need_ot").hasClass("ck_check")){
			$("#is_need_ot").click();
		}
		if($("#is_ot_before").hasClass("ck_check")){
			$("#is_ot_before").click();
		}
		ot_before_tr.hide();
		ot_after_tr.hide();
		is_ot_before = 0;
		is_ot_after = 0;
		schName.val('');
		$("#fixedWH :checkbox").each(function(){
			if($(this).hasClass("ck_check")){
				$(this).click();
			}
		});
		
		
		initAtPageData(_atData);
	});
	
	
	$(".clockpicker").change(function(_obj){
		var clock_val = $("#_clock_value").val();
		var ot_before,ot_end,start_time,end_time,current_clock,temp_value;
		
		$("#axis b:eq(0)").text(clock_val);
		current_clock = parseInt((clock_val).split(":")[0],10);
		
		endHours = current_clock+16;
		if(endHours>=24){
			endHours = endHours - 24;
		}
		if(endHours<10){
			endHours = "0"+endHours.toString()+":00";
		}else{
			endHours = endHours.toString()+":00";
		}
	    $("#axis b:eq(1)").text(endHours);
	    starHours = clock_val,
	    endHours = endHours,
	    
	    ot_before = clock_val.toString() + "--";
	    temp_value = current_clock + 2;
	    if(temp_value>=24){
	    	temp_value = temp_value - 24;
		}
		if(temp_value<10){
			temp_value = "0"+temp_value.toString()+":00";
		}else{
			temp_value = temp_value.toString()+":00";
		}
		ot_before = ot_before + temp_value;
		
		
		start_time = current_clock + 3;
	    if(start_time>=24){
	    	start_time = start_time - 24;
		}
		if(start_time<10){
			start_time = "0"+start_time.toString()+":00";
		}else{
			start_time = start_time.toString()+":00";
		}
		start_time = start_time + '--';
		temp_value = current_clock + 6;
		if(temp_value>=24){
			temp_value = temp_value - 24;
		}
		if(temp_value<10){
			temp_value = "0"+temp_value.toString()+":00";
		}else{
			temp_value = temp_value.toString()+":00";
		}
		start_time = start_time + temp_value;
		
		
		end_time = current_clock + 8;
	    if(end_time>=24){
	    	end_time = end_time - 24;
		}
		if(end_time<10){
			end_time = "0"+end_time.toString()+":00";
		}else{
			end_time = end_time.toString()+":00";
		}
		end_time = end_time + '--';
		temp_value = current_clock + 12;
		if(temp_value>=24){
			temp_value = temp_value - 24;
		}
		if(temp_value<10){
			temp_value = "0"+temp_value.toString()+":00";
		}else{
			temp_value = temp_value.toString()+":00";
		}
		end_time = end_time + temp_value;
		
		
		ot_end = current_clock + 13;
	    if(ot_end>=24){
	    	ot_end = ot_end - 24;
		}
		if(ot_end<10){
			ot_end = "0"+ot_end.toString()+":00";
		}else{
			ot_end = ot_end.toString()+":00";
		}
		ot_end = ot_end + '--';
		temp_value = current_clock + 15;
		if(temp_value>=24){
			temp_value = temp_value - 24;
		}
		if(temp_value<10){
			temp_value = "0"+temp_value.toString()+":00";
		}else{
			temp_value = temp_value.toString()+":00";
		}
		ot_end = ot_end + temp_value;
		
		setTimeVal({
	    	starTime:start_time,
	    	endTime:end_time,
	    	otBefore:ot_before,
	    	otAfter:ot_end
	    });
	})
	
function Drag(option) {
    this.init(option);
}

Drag.prototype.init = function(option) {
    var that = this,
        Obj;
    that.number = 0;
    that.temp = 0;
    this.opt = option;
    Obj = this.opt.obj;

    Obj.mousedown(function(event) {
        that.disx = event.clientX;
        that.disTime = that.opt.timeBox.html();
        that.disL = Obj.position().left;

        that.star_left = starWork.position().left;
        that.ot_before_left = otBefore.position().left;
        that.ot_after_left = otAfter.position().left;
        that.end_left = endWork.position().left;
        $(document).mousemove(function(event) {
            that.mouseMove(event);
           
            $(".work_hours_val").html( getHours(true).workHours );
        })
        $(document).mouseup(function() {
            $(document).off("mousemove");
            $(document).off("mouseup");
        })
        event.preventDefault(); 
        return false;
    })
    if (that.opt.elastic && that.opt.lBtn && that.opt.rBtn) {
      
        that.changeWidth(that.opt.lBtn, that.opt.rBtn);
    } else {
        Obj.find(".cursor_cw").removeClass('cursor_cw');
        Obj.find(".add_left,.add_right").off();
    };

}

Drag.prototype.mouseMove = function(event) {
    var that = this,
        l = 0,
        oBtn = that.opt.obj,
        curLeft = 0,
        maxLeft,
        minLeft = 0;
            
    that.number = Math.floor((event.clientX - that.disx) / unit);
    curLeft = that.disL + that.number * unit;

    if (oBtn == otBefore) {
    	curLeft = that.limit(curLeft, 0, that.star_left - otBefore.width());
    } else if (oBtn == starWork) { 
        if(is_ot_before==1){
        	 curLeft = that.limit(curLeft, that.ot_before_left + otBefore.width(), that.end_left - starWork.width());
        }else{
        	 curLeft = that.limit(curLeft, 0, that.end_left - starWork.width());
        }
    }else if (oBtn == endWork) {
        if(is_ot_after==1){
        	curLeft = that.limit(curLeft, that.star_left + starWork.width(), that.ot_after_left-endWork.width());
        }else{
        	curLeft = that.limit(curLeft, that.star_left + starWork.width(), axis.width() - endWork.width());
        }
    } else {
    	that.number = Math.floor((event.clientX - that.disx) / unit);
        curLeft = that.disL + that.number * unit;
    	curLeft = that.limit(curLeft, that.end_left + endWork.width(), axis.width() - otAfter.width());
    }
    oBtn.css({
        left: curLeft
    })
    if (that.temp != that.number) {
        that.temp = that.number;
        
        var increment = oBtn.position().left - that.disL>0 ? Math.ceil((oBtn.position().left - that.disL) / unit) : Math.floor((oBtn.position().left - that.disL) / unit);            
        this.opt.timeBox.html(timeOperator(that.disTime, increment * changeUnit))
    }

}

Drag.prototype.limit = function(val, min, max) {
    if (val < min) {
        return min;
    } else if (val > max) {
        return max;
    } else {
        return val
    }
}

Drag.prototype.changeWidth = function(l, r) {
    var that = this,
        obj = that.opt.obj;
    this.lBtn = l;
    this.rBtn = r;
    cwDrag(this.lBtn);
    cwDrag(this.rBtn);
    
    function cwDrag(oBtn) {
        var l, minLeft;
        oBtn.mousedown(function(event) {
            var disx = event.clientX,
                disLeft = obj.position().left,
                disWidth = obj.width(),
                temp = 0,
                disTime = that.opt.timeBox.html(),
                starWidth = starWork.width(),
                otBeforeWidth = otBefore.width(),
                otAfterWidth = otAfter.width(),
                endWidth = endWork.width(),
                axisWidth = axis.width();

            that.star_left = starWork.position().left;
            that.ot_before_left = otBefore.position().left;
            that.ot_after_left = otAfter.position().left;
            that.end_left = endWork.position().left;

            $(document).mousemove(function(event) {
                var width = 0,workHours=0,resetHours=0;
                number = Math.floor((event.clientX - disx) / unit);
                if (oBtn == that.lBtn) {
                    width = disWidth - number * unit;
                    if (width < minDiff) return;
                    displayImg();
                    if (obj.hasClass("ot_before_hours")) {
                        if (width > disLeft + disWidth) return;
                        minLeft = obj.elastic ? 0 : -0.5 * otBefore.width();
                        l = that.limit(disLeft + number * unit, minLeft, that.star_left - otBefore.width());
                    } else if (obj.hasClass("star_work")) {
                    	if(is_ot_before==1){
                    		if (width > disLeft + disWidth - that.ot_before_left - otBeforeWidth) return;
                            minLeft = that.ot_before_left + otBeforeWidth;
                            l = that.limit(disLeft + number * unit, minLeft, that.end_left - starWork.width());
                    	}else{
                    		if (width > disLeft + disWidth) return;
                            minLeft = obj.elastic ? 0 : -0.5 * starWork.width();
                            l = that.limit(disLeft + number * unit, minLeft, that.end_left - starWork.width());
                    	}                        
                    } else if (obj.hasClass("end_work")) {
                    	if(is_ot_after==1){
                    		if (width > disLeft + disWidth - that.star_left - starWidth) return;
                            minLeft = that.star_left + starWidth;
                            l = that.limit(disLeft + number * unit, minLeft, that.ot_after_left - endWork.width());
                    	}else{
                    		if (width > disLeft + disWidth - that.star_left - starWidth) return;
                            minLeft = that.star_left + starWidth;
                            l = that.limit(disLeft + number * unit, minLeft, obj.elastic ? axis.width() - endWidth : axisWidth - 0.5 * endWidth);
                    	}   
                    } else {
                        if (width > disLeft + disWidth - that.end_left - endWidth) return;
                        minLeft = that.end_left + endWidth;
                        l = that.limit(disLeft + number * unit, minLeft, obj.elastic ? axis.width() - otAfterWidth : axisWidth - 0.5 * otAfterWidth);
                    }
                    if(l!=obj.position().left){
                    	obj.css({
                            left: l,
                            width: width
                        });

                        obj.find(".flex").css("width", disWidth - number * unit - 34);
                        if (temp != number) {
                            temp = number;
                            that.opt.timeBox.html(timeOperator(disTime, number * changeUnit, "left"));
                        }
                    }
                } else { 
                    width = disWidth + number * unit;
                    if (width < minDiff) return;
                    displayImg();


                    if (obj.hasClass("ot_before_hours")) { 
                        if (width > that.star_left - that.ot_before_left) return;
                    } else if (obj.hasClass("star_work")) {                            
                        if (width > that.end_left - that.star_left) return;     
                    } else if (obj.hasClass("end_work")) {
                    	if(is_ot_after==1){
                    		if (width > that.ot_after_left - that.end_left) return;  
                    	}else{
                    		if (width > axisWidth - disLeft) return;
                    	}                           
                    } else {
                        if (width > axisWidth - disLeft) return;           
                    }

                    obj.css({
                        width: disWidth + number * unit
                    });
                    obj.find(".flex").css("width", disWidth + number * unit - 34);
                    if (temp != number) {
                        temp = number;
                        that.opt.timeBox.html(timeOperator(disTime, number * changeUnit, "right"));
                    }
                }

               
                $(".work_hours_val").html( getHours(true).workHours );

                function displayImg() {
                    if (width < minDiff * 2) {
                        obj.find(".btn_ico").hide();
                    } else {
                        obj.find(".btn_ico").show();
                    }
                }
                return false;
            })
            $(document).mouseup(function() {
                $(document).off("mousemove");
                $(document).off("mouseup");
            })
            event.preventDefault();
            event.stopPropagation();
        })
    }
}
function toTwo(n) {
    return n > 9 ? ''+n : '0' + n;
}
function timeOperator(curTime, increment, type) {
    if (type === 'left') { 
        return dateOperator(curTime.split("--")[0], increment) + "--" + curTime.split("--")[1];
    } else if (type === 'right') {
        return curTime.split("--")[0] + "--" + dateOperator(curTime.split("--")[1], increment);
    } else {
        return dateOperator(curTime.split("--")[0], increment) + "--" + dateOperator(curTime.split("--")[1], increment);
    }

    function dateOperator(curTime, increment) {
        
        var hm = new Date(2014, 1, 1, curTime.split(":")[0], curTime.split(":")[1]).getTime(); 
        var result = new Date(hm + increment * 60 * 1000);
        var H = result.getHours(),
            M = result.getMinutes();

        return toTwo(H) + ":" + toTwo(M);            
    }
}

function calculatingWidth(obj, top, time) {
    var timeDir = 0,
        str,
        Left = comparison(time.split("--")[0], starHours) / changeUnit * unit;
        str = time.split("--");
        if(str[1].split(":")[0]>=str[0].split(":")[0]){
        	timeDir = new Date(2015, 1, 1, str[1].split(":")[0], str[1].split(":")[1]) - new Date(2015, 1, 1, str[0].split(":")[0], str[0].split(":")[1]);
        }else{
        	var hours = 24-parseInt(str[0].split(":")[0],10)+parseInt(str[1].split(":")[0],10)+1;
        	timeDir = new Date(2015, 1, 1, hours, str[1].split(":")[1]) - new Date(2015, 1, 1, 1, str[0].split(":")[1]);
        }
        timeDir = timeDir / 1000 / 60;
        top.find('.flex').css("width", timeDir / changeUnit * unit - 34).parent().parent().css("width",timeDir / changeUnit * unit);
        if (timeDir / changeUnit * unit < minDiff * 2-1) { 
            obj.find(".btn_ico").hide();
        } else {
            obj.find(".btn_ico").show();
        }
        obj.css({
            left: Left
        })
}

function comparison(time1, time2) {
	var dir;
	
    if(time1.split(":")[0]>=time2.split(":")[0]){
    	dir = new Date(2015, 1, 1, time1.split(":")[0], time1.split(":")[1]) - new Date(2015, 1, 1, time2.split(":")[0], time2.split(":")[1]);
    }else{
    	var hours = 24-parseInt(time2.split(":")[0],10)+parseInt(time1.split(":")[0],10)+1;
    	dir = new Date(2015, 1, 1,hours , time1.split(":")[1]) - new Date(2015, 1, 1, 1, time2.split(":")[1]);
    }
    return dir / 1000 / 60;
}

function setWL() {
    calculatingWidth(starWork, starWork, star_time.html());
    calculatingWidth(endWork, $(".end_top"), end_time.html());
    calculatingWidth(otBefore, $(".ot_before_top"), ot_before_time.html());
    calculatingWidth(otAfter, $(".ot_after_top"), ot_after_time.html());
}

function setTimeVal(obj) {
    star_time.html((obj && obj.starTime) || "09:00--12:00");
    end_time.html((obj && obj.endTime) || "14:00--18:00");
    ot_before_time.html((obj && obj.otBefore) || "06:00--08:00");
    ot_after_time.html((obj && obj.otAfter) || "20:00--22:00");
    setWL();
}

function getHours() {
    var obj = {
        "workHours": 0
    },timeDir,str,time1,time2;
    str = star_time.html().split("--");
    time1 = comparison(str[1], str[0]); 
    str = end_time.html().split("--");
    time2 = comparison(str[1], str[0]); 
    obj.workHours= Number(((time1+time2) / 60).toFixed(2));
    return obj;
}

new Drag({
    obj: otBefore,
    timeBox: ot_before_time,
    elastic: true,
    lBtn: $("#ot_before_hours .add_left"),
    rBtn: $("#ot_before_hours .add_right")
})

new Drag({
    obj: otAfter,
    timeBox: ot_after_time,
    elastic: true,
    lBtn: $("#ot_after_hours .add_left"),
    rBtn: $("#ot_after_hours .add_right")
})

new Drag({
    obj: starWork, 
    timeBox: star_time, 
    elastic: true,
    lBtn: $(".star_work .add_left"), 
    rBtn: $(".star_work .add_right")
})


new Drag({
    obj: endWork,
    timeBox: end_time,
    elastic: true,
    lBtn: $(".end_work .add_left"),
    rBtn: $(".end_work .add_right")
})


function initAtPageData(obj){
	starHours = parseInt((obj.ot_before_in).split(":")[0],10);
	
	if(starHours<10){
		starHours = "0"+starHours.toString()+":00";
	}else{
		starHours = starHours.toString()+":00";	
	}
	
	endHours = parseInt(starHours.split(":")[0],10)+16;
	if(endHours>=24){
		endHours = endHours - 24;
	}
	if(endHours<10){
		endHours = "0"+endHours.toString()+":00";
	}else{
		endHours = endHours.toString()+":00";
	}
	
	
	$("#policy_id").val(obj.policy_id);
	$('.clockpicker .form-control').val(starHours);
	$(".work_hours_val").html(obj.work_hours);
	$("#axis b:eq(0)").text(starHours);
    $("#axis b:eq(1)").text(endHours);
   
    setTimeVal({
    	starTime:obj.first_in+"--"+obj.first_out,
    	endTime:obj.second_in+"--"+obj.second_out,
    	otBefore:obj.ot_before_in+"--"+obj.ot_before_out,
    	otAfter:obj.ot_after_in+"--"+obj.ot_after_out
    });
    
    wh_input.attr("disabled","true");
    wh_input.css("background-color","rgb(237, 237, 237)");
    
    if(obj.policy_id=="-1"){
    	ot_before_tr.hide();
    	ot_after_tr.hide();
    }
    
    if(obj.is_ot_before=='1'){
    	$("#is_ot_before").click();
    }
    
    if(obj.is_ot_after=='1'){
    	$("#is_need_ot").click();
    }
    
    var html = "";
    for (var i = 0; i < obj.policy_type.length; i++) {
        html += "<li _value='"+obj.policy_type[i].policy_id+"'>" + obj.policy_type[i].policy_name + "</li>"
    }
    $("#allSchedule").html(html);
    $(".selInput").val(obj.policy_name);
    
    if(obj.policy_type.length==0){
        $("#selSch").hide();
        delSch.hide();
        return;
    }
        
    if(obj.first_in_need_clock=="1"){
    	$("#fixedWH :checkbox:eq(0)").click();
    	$("#fixedWH ._tr_1_td:eq(0)").val(obj.first_in_before_buf_minutes);
    	$("#fixedWH ._tr_1_td:eq(1)").val(obj.first_in_after_buf_minutes);
    }
    if(obj.first_out_need_clock=="1"){
    	$("#fixedWH :checkbox:eq(1)").click();
    	$("#fixedWH ._tr_2_td:eq(0)").val(obj.first_out_before_buf_minutes);
    	$("#fixedWH ._tr_2_td:eq(1)").val(obj.first_out_after_buf_minutes);
    }
    if(obj.second_in_need_clock=="1"){
    	$("#fixedWH :checkbox:eq(2)").click();
    	$("#fixedWH ._tr_3_td:eq(0)").val(obj.second_in_before_buf_minutes);
    	$("#fixedWH ._tr_3_td:eq(1)").val(obj.second_in_after_buf_minutes);
    }
    if(obj.second_out_need_clock=="1"){
    	$("#fixedWH :checkbox:eq(3)").click();
    	$("#fixedWH ._tr_4_td:eq(0)").val(obj.second_out_before_buf_minutes);
    	$("#fixedWH ._tr_4_td:eq(1)").val(obj.second_out_after_buf_minutes);
    }
    if(obj.ot_before_in_need_clock=="1"){
    	$("#fixedWH :checkbox:eq(4)").click();
    	$("#fixedWH ._tr_5_td:eq(0)").val(obj.ot_before_in_buf_before);
    	$("#fixedWH ._tr_5_td:eq(1)").val(obj.ot_before_in_buf_after);
    }
    if(obj.ot_before_out_need_clock=="1"){
    	$("#fixedWH :checkbox:eq(5)").click();
    	$("#fixedWH ._tr_6_td:eq(0)").val(obj.ot_before_out_buf_before);
    	$("#fixedWH ._tr_6_td:eq(1)").val(obj.ot_before_out_buf_after);
    }
    if(obj.ot_after_in_need_clock=="1"){
    	$("#fixedWH :checkbox:eq(6)").click();
    	$("#fixedWH ._tr_7_td:eq(0)").val(obj.ot_after_in_buf_before);
    	$("#fixedWH ._tr_7_td:eq(1)").val(obj.ot_after_in_buf_after);
    }
    if(obj.ot_after_out_need_clock=="1"){
    	$("#fixedWH :checkbox:eq(7)").click();
    	$("#fixedWH ._tr_8_td:eq(0)").val(obj.ot_after_out_buf_before);
    	$("#fixedWH ._tr_8_td:eq(1)").val(obj.ot_after_out_buf_after);
    }
}








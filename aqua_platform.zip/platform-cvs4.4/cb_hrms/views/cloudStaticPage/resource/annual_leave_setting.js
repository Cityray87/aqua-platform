
$(".tab_title").click(function() {
    var index = $(".tab_title").index($(this));
    if(index==0){
    	if(curType==0){
    		return;
    	}else if(curType==1){
    		$(this).addClass("tab_title_active");
    		curType=2;
    	}else if(curType==2){
    		$(this).removeClass("tab_title_active");
    		curType=1;
    	}
    }else if(index==1){
    	if(curType==1){
    		return;
    	}else if(curType==0){
    		$(this).addClass("tab_title_active");
    		curType=2;
    	}else if(curType==2){
    		$(".tab_2").removeClass("tab_title_active");
    		curType=0;
    	}
    }
    $(".with_type").hide().eq(curType).show();
    $(".with_type").eq(curType).find("tbody").find("tr").length <= 1 ? $("#delTr").hide() : $("#delTr").show();
})
    
    
// ����һ��
$("#addTr").click(function() {
    addTr(curType);
})

function addTr(oIndex, callBack) {
    var Tbody = $(".with_type").eq(oIndex).find("tbody"),
        selRank = [],
        trLen = Tbody.find("tr").length,
        newStarName = "year_star_" + (trLen + 1),
        newEndName = "year_end_" + (trLen + 1),
        preEndName = "year_end_" + trLen,
        dayName = "day_" + (trLen + 1);
    	choiceName = "choice_field_" + (trLen + 1);
    var HTML;
    if(curType==0){
    	HTML = $("#template1").html();
    }else if(curType==1){
    	HTML = $("#template2").html();
    }else if(curType==2){
    	HTML = $("#template3").html();
    }
    HTML = HTML.replace(/annual_type/g, annual_type).replace(/{year_star_name}/g, newStarName).replace(/{year_end_name}/g, newEndName).replace(/{day}/g, dayName).replace(/{choice_field_name}/g, choiceName);
    Tbody.append(HTML);
    
    if(curType==0||curType==2){
    	$("input[name='"+newStarName+"']").val($("input[name='year_end_"+ trLen +"']").val());
    }
    $("#delTr").attr("display") !== "block" ? $("#delTr").show() : "";
    
    callBack && callBack();
}

// ɾ��һ��
$("#delTr").click(function() {
    var Tbody = $(".with_type").eq(curType).find("tbody"),
        delIndex = [];
    if (Tbody.find("tr").length === 1) return;
    Tbody.find("tr:last b").each(function(index, el) {
        if ($(this).hasClass('active')) {
            delIndex.push($(this).index());
        }
    });
    Tbody.find("tr:last").remove();
    if (Tbody.find("tr").length <= 1) {
        $("#delTr").hide();
    }
})

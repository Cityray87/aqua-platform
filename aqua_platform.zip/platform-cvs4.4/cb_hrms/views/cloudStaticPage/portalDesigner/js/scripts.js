﻿function supportstorage() {
	if (typeof window.localStorage=='object') 
		return true;
	else
		return false;		
}

function handleSaveLayout() {
	var e = $(".demo").html();
	window.demoHtml = e;
	saveLayout();
}

var layouthistory; 
function saveLayout(){
	var data = layouthistory;
	if (!data) {
		data={};
		data.count = 0;
		data.list = [];
	}
	if (data.list.length>data.count) {
		for (i=data.count;i<data.list.length;i++)
			data.list[i]=null;
	}
	data.list[data.count] = window.demoHtml;
	data.count++;
	if (supportstorage()) {
		localStorage.setItem("layoutdata",JSON.stringify(data));
	}
	layouthistory = data;
	var panel_list = "";
	var cmp_type = "";
	var layout_source = $('.demo').html();
	$('.demo .view .ui-draggable').each(function(){
		var $this = $(this);
		panel_list = panel_list + "," + $this.attr("panel_name");
	});
	
	$('.demo .view .box-element').each(function(){
		var $this = $(this);
		panel_list = panel_list + "," + $this.attr("panel_name");
		$this.find(".view").html($("#elmJS .box-element[panel_name='"+$this.attr("panel_name")+"'] .view").html());
	});
	
	$.ajax({  
		type: "POST",
		url: "index.cfm?event=cloudStaticPage.cloudStaticPageAdmin.saveUserPortal",  
		data: {layout: $('.demo').html(),panel_list:panel_list.substring(1) },  
		success: function(data) {
			$('.demo').html(layout_source);
		}
	})
}

function handleCmpType(panelName,cmpType) {
	if(cmpType == 'CHART'||cmpType == 'CALENDAR'||cmpType == 'LIST'||cmpType == 'GRID'){
		var jsfunction = new Function(panelName+"()");
		jsfunction();
	}
}

function initPortalList(panelName,initJson){	 
	var result=$.ajax({cache: false,url:"index.cfm?event=cloudStaticPage.cloudStaticPageAdmin.getPortalListData&panel_name="+panelName+"&datenow=" + new Date(),async:false});
	var repObj = jQuery.parseJSON(result.responseText).jsonObject.data;

	$('#template_'+panelName).tmpl(repObj).appendTo('.demo .'+panelName);
	if(typeof(initJson.height)!='undefined'){
		var obj = $(".demo ."+panelName).closest(".box-body");
		obj.slimScroll({
			height: initJson.height+"px"
		});
	}
}

function initPortalGrid(panelName,initJson){
	var result=$.ajax({cache: false,url:"index.cfm?event=cloudStaticPage.cloudStaticPageAdmin.getPortalListData&panel_name="+panelName+"&datenow=" + new Date(),async:false});
	var repObj = jQuery.parseJSON(result.responseText).jsonObject.data;
	$('#template_'+panelName).tmpl(repObj).appendTo('.demo .'+panelName);
	$(".demo ."+panelName).closest("table").dataTable({
		"bScrollCollapse": true,
		"oLanguage": {
	      "sLengthMenu": " _MENU_ 记录/页",
	      "sZeroRecords": "对不起，查询不到任何相关数据",
	      "sInfo": "显示 _START_ 到 _END_ 条，共 _TOTAL_ 条记录",
	      "sInfoEmtpy": "找不到相关数据",
	      "sInfoFiltered": "数据表中共为 _MAX_ 条记录",
	      "sProcessing": "正在加载中...",
	      "sSearch": "搜索:",	      
	      "oPaginate": {
	          "sFirst":"首页",
	          "sPrevious": "上一页 ",
	          "sNext":" 下一页 ",
	          "sLast":"末页"
	      }
	  }
	});
	if(typeof(initJson.height)!='undefined'){
		var obj = $(".demo ."+panelName).closest(".dataTable").closest("div");
		$(".demo ."+panelName).closest(".dataTable").attr("height",initJson.height+"px");
		obj.slimScroll({
			height: initJson.height+"px"
		});
	}
}

function initPortalCal(panelName,initJson){
	
	var result=$.ajax({cache: false,url:"index.cfm?event=cloudStaticPage.cloudStaticPageAdmin.getPortalCalData&panel_name="+panelName+"&datenow=" + new Date(),async:false});
	var repObj = jQuery.parseJSON(result.responseText).jsonObject.data;
	if(typeof(repObj)=='undefined')repObj = [];
	var options = {
		events_source: repObj,
		view: 'month',
		tmpl_path: "../cb_hrms/views/cloudStaticPage/portalDesigner/calendarTpl/",
		language:'zh-CN',
		tmpl_cache: false,
		time_start: '06:00',
		time_end: '24:00',
		onAfterEventsLoad: function(events) {
			
		},
		onAfterViewLoad: function(view) {
			$('.page-header h3').text(this.getTitle());
			$('.btn-group button').removeClass('active');
			$('button[data-calendar-view="' + view + '"]').addClass('active');
		},
		classes: {
			months: {
				general: 'label'
			}
		}
	};
	var calendar = $(".demo #"+panelName).calendar(options);  
	$('.demo .btn-group button[data-calendar-nav]').each(function() {
		var $this = $(this);
		$this.click(function() {
			calendar.navigate($this.data('calendar-nav'));
		});
	});

	$('.demo .btn-group button[data-calendar-view]').each(function() {
		var $this = $(this);
		$this.click(function() {
			calendar.view($this.data('calendar-view'));
		});
	});
}

function initPortalChart(panelName,initJson){
	console.log($(".demo #test_4").width());
	var e = $(".demo #"+panelName);
	var result=$.ajax({cache: false,url:"index.cfm?event=cloudStaticPage.cloudStaticPageAdmin.getPortalChartData&panel_name="+panelName+"&datenow=" + new Date(),async:false});
	var repObj = {};
	
	try{
		repObj = JSON.parse(result.responseText).jsonObject;
		initJson.series = repObj.data;
		initJson.xAxis['categories'] = repObj.categories;
		e.highcharts(initJson);
		$(".demo #"+panelName+" .highcharts-container").css("width","100%");
		
		$(".demo #"+panelName+" .highcharts-container svg").width("100%");
	}catch(e){
		console.log("init Chart error!");
	}
}

function configurationElm(e, t) {
	$(".demo").delegate(".configuration > a", "click", function(e) {
		e.preventDefault();
		var t = $(this).parent().next().next().children();
		$(this).toggleClass("active");
		t.toggleClass($(this).attr("rel"))
	});
}
function removeElm() {
	$(".demo").delegate(".remove", "click", function(e) {
		e.preventDefault();
		$(this).parent().remove();
		if (!$(".demo .lyrow").length > 0||!$(".demo .lyrow .view div").length > 0) {
			clearDemo()
		}
	})
}
function clearDemo() {
	$(".demo").empty();
	layouthistory = null;
	if (supportstorage())
		localStorage.removeItem("layoutdata");
}
function removeMenuClasses() {
	$("#menu-layoutit li button").removeClass("active")
}
function changeStructure(e, t) {
	$("#download-layout ." + e).removeClass(e).addClass(t)
}
function cleanHtml(e) {
	$(e).parent().append($(e).children().html())
}

var currentDocument = null;
var timerSave = 1000;
var stopsave = 0;
var startdrag = 0;
var demoHtml = $(".demo").html();
var currenteditor = null;
$(window).resize(function() {
	$("body").css("min-height", $(window).height() - 90);
	$(".demo").css("min-height", $(window).height() - 160);
});

function initContainer(){
	$(".demo, .demo .column").sortable({
		connectWith: ".column",
		opacity: .35,
		handle: ".drag",
		start: function(e,t) {
			if (!startdrag) stopsave++;
			startdrag = 1;
		},
		stop: function(e,t) {
			if(stopsave>0) stopsave--;
			startdrag = 0;
		}
	});
	configurationElm();
}

function handlerTemplate(){
	var html = $(".demo .template_view .view").html();
	$(".demo .template_view").after($(html));
	$(".demo .template_view").remove();
}

$(document).ready(function() {	
	$("body").css("min-height", $(window).height() - 90);
	$(".demo").css("min-height", $(window).height() - 160);
	$(".sidebar-nav .lyrow").draggable({
		connectToSortable: ".demo",
		helper: "clone",
		handle: ".drag",
		start: function(e,t) {
			if (!startdrag) stopsave++;
			startdrag = 1;
		},
		drag: function(e, t) {
			t.helper.width(400)
		},
		stop: function(e, t) {
			handlerTemplate();			
			$(".demo .column").sortable({
				opacity: .35,
				connectWith: ".column",
				start: function(e,t) {
					if (!startdrag) stopsave++;
					startdrag = 1;
				},
				stop: function(e,t) {
					if(stopsave>0) stopsave--;
					startdrag = 0;
				}
			});
			if(stopsave>0) stopsave--;
			startdrag = 0;
		}
	});
	$(".sidebar-nav .box").draggable({
		connectToSortable: ".column",
		helper: "clone",
		handle: ".drag",
		start: function(e,t) {
			if($(".demo #"+$(e.target.outerHTML).attr("panel_name")).length!=0||$(".demo ."+$(e.target.outerHTML).attr("panel_name")).length!=0){
				return false;
			}
			if (!startdrag) stopsave++;
			startdrag = 1;
		},
		stop: function(e,t) {
			handleCmpType($(e.target.outerHTML).attr("panel_name"),$(e.target.outerHTML).attr("cmp_type"));
			if(stopsave>0) stopsave--;
			startdrag = 0;
		}
	});
	initContainer();
	$('body.edit .demo').on("click","[data-target=#editorModal]",function(e) {
		e.preventDefault();
		currenteditor = $(this).parent().parent().find('.view');
		var eText = currenteditor.html();
		contenthandle.setData(eText);
	});
	$("[data-target=#shareModal]").click(function(e) {
		e.preventDefault();
		handleSaveLayout();
	});
	$("#edit").click(function() {
		$("body").removeClass("devpreview sourcepreview");
		$("body").addClass("edit");
		removeMenuClasses();
		$(this).addClass("active");
		setInterval(function() {
			$(window).resize();
		}, timerSave)
		return false
	});
	$("#clear").click(function(e) {
		e.preventDefault();
		clearDemo()
	});
	$("#sourcepreview").click(function() {
		$("body").removeClass("edit");
		$("body").addClass("devpreview sourcepreview");
		removeMenuClasses();
		$(this).addClass("active");
		setInterval(function() {
			$(window).resize();
		}, timerSave)
		return false
	});
	$("#layoutCmp").click(function() {
		$("#estRows").toggle();
		if($("#layoutCmp").hasClass("layout_up")){
			$("#layoutCmp").removeClass("layout_up").addClass("layout_down");
			$("#elmJS").css("height",window.screen.height-620+"px");
			$(".sidebar-nav .slimScrollDiv").css(window.screen.height-620+"px");
		}else{
			$("#layoutCmp").removeClass("layout_down").addClass("layout_up");
			$("#elmJS").css("height",window.screen.height-390+"px");
			$(".sidebar-nav .slimScrollDiv").css("height",window.screen.height-390+"px");
		}
	});
	
	removeElm();
	$("#elmJS").slimScroll({
		height: (window.screen.height-620)+"px"
	});

	
})